#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

insert ifmr operation

"""

from amct_mindspore.optimizer.utils import insert_ifmr_to_cell
from amct_mindspore.optimizer.utils import find_cells_by_name
from amct_mindspore.optimizer.base_quant_pass import BaseQuantPass


class InsertIfmrPass(BaseQuantPass):
    """Insert IFMR to network pass."""
    def do_pass(self, graph, network, object_node):
        """
        Function: Do actual "Conv2D", "MatMul", "DepthwiseConv2dNative" layer
                  convert to ifmr + compute_cell
        Parameters: graph: graph structure
                    network: MindSpore network
                    object_node: node to process
        Return: None
        """
        layer_name = object_node.name_prefix
        layer_config = self.conf.get_layer_config(layer_name)
        act_param = layer_config.get('activation_quant_params')
        layers = []
        find_cells_by_name(network, layer_name, layers)
        # skip weight reuse layer
        if len(layers) > 1:
            return
        insert_ifmr_to_cell(network, object_node, act_param)
