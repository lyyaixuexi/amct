#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

convert qat to original cell

"""
import numpy as np
import mindspore.nn as nn

from amct_mindspore.cells.conv2d_qat_cell import Conv2dQatBlock
from amct_mindspore.cells.dense_qat_cell import DenseQatBlock
from amct_mindspore.cells.cell_helper import get_name_prefix
from amct_mindspore.common.utils.util import is_invalid
from amct_mindspore.optimizer.utils import rename_parameters
from amct_mindspore.optimizer.base_fusion_pass import BaseFusionPass
from amct_mindspore.configuration.val_util import RETRAIN_BIT
from amct_mindspore.configuration.val_util import EPS


class DeleteQatLayersPass(BaseFusionPass):
    """ Convert qat to original cell pass."""

    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)


    def run(self, graph, network):
        """
        Function: perform the do_pass funciton of each pass
        Parameters:
            graph: the inner graph of network
            network: the cell structure network in mindspore
        Return:
            None
        """
        convert_qat(network)


def convert_qat(network):
    """
    convet sub cell to quant cell
    """
    cells = network.name_cells()
    for name in cells:
        subcell = cells[name]
        if subcell == network:
            continue
        if isinstance(subcell, (Conv2dQatBlock, DenseQatBlock)):
            new_subcell = convert_qat_to_original(subcell)
            name_prefix = get_name_prefix(subcell)
            rename_parameters(new_subcell, name_prefix)
            network.insert_child_to_cell(name, new_subcell)
        else:
            convert_qat(subcell)
    if isinstance(network, nn.SequentialCell):
        network.cell_list = list(network.cells())


def convert_qat_to_original(qat_subcell):
    """ convert qat block to original cell"""
    clip_min = qat_subcell.act_qat_cell.clip_min.data.asnumpy().reshape((1, ))
    clip_max = qat_subcell.act_qat_cell.clip_max.data.asnumpy().reshape((1, ))
    _check_clip_min_max(clip_min, clip_max)
    scale_d, offset_d = calc_scale_offset(clip_min, clip_max)
    original_cell = qat_subcell.subcell[0]
    # update Parameter
    original_cell.weight = qat_subcell.weight
    if qat_subcell.has_bias:
        original_cell.bias = qat_subcell.bias

    setattr(original_cell, 'scale_d', scale_d)
    setattr(original_cell, 'offset_d', offset_d)
    setattr(original_cell, 'need_convert', True)
    return original_cell


def _check_clip_min_max(clip_min, clip_max):
    """ function to check clip_min and clip_max"""
    if is_invalid(clip_min):
        raise ValueError("clip_min is nan or inf.")
    if is_invalid(clip_max):
        raise ValueError("clip_max is nan or inf.")


def calc_scale_offset(clip_min, clip_max):
    """ calculate the scale offset using clip max /min"""
    clip_min = np.minimum(0, clip_min)
    clip_max = np.maximum((2**RETRAIN_BIT - 1) * EPS, clip_max)

    scale_d = (clip_max - clip_min) / (2**8 - 1)
    offset_d = - np.round(clip_min / scale_d) - 128
    return scale_d, offset_d
