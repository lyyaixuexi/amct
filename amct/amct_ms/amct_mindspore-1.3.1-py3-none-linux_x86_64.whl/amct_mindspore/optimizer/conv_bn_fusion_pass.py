#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Convolution + BatchNorm fusion operation

"""

import copy
import numpy as np
from mindspore import nn
from mindspore import Tensor
from mindspore import dtype as mstype
from amct_mindspore.configuration.configuration import Configuration
from amct_mindspore.configuration.retrain_config import RetrainConfig
from amct_mindspore.optimizer.base_fusion_pass import BaseFusionPass
from amct_mindspore.optimizer.utils import convert_bn_with_identity
from amct_mindspore.optimizer.utils import find_cell_by_name
from amct_mindspore.optimizer.utils import find_cells_by_name
from amct_mindspore.optimizer.utils import match_op
from amct_mindspore.utils.log import LOGGER
from amct_mindspore.operation.conv_bn_fuse import fuse_conv_bn
from amct_mindspore.cells import Identity
from amct_mindspore.configuration.val_util import FUSE_TYPES
from amct_mindspore.common.utils.util import is_invalid


class ConvBnFusionPass(BaseFusionPass):
    """
    Function: Do "Convolution" layer and "BatchNorm" layer fusion operation
    APIs: match_pattern, do_pass, get_np_array_from_conv,
          get_np_array_from_bn, write_fused_weights_bias_back
    """
    def __init__(self, is_retrain=False):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.is_retrain = is_retrain
        if is_retrain:
            self.config = RetrainConfig()
        else:
            self.config = Configuration()

    @staticmethod
    def save_retrain_attrs(old_conv, new_conv):
        """save_retrain attrs"""
        if hasattr(old_conv, "scale_d") and hasattr(old_conv, "offset_d"):
            scale_d = float(getattr(old_conv, 'scale_d'))
            offset_d = int(getattr(old_conv, 'offset_d'))
            setattr(new_conv, 'scale_d', scale_d)
            setattr(new_conv, 'offset_d', offset_d)
            setattr(new_conv, 'need_convert', True)

    @staticmethod
    def replace_conv(network, name_prefix, new_conv):
        """
        replace specific conv cell with new conv cell
        """
        cells = network.name_cells()
        change = False
        for name in cells:
            subcell = cells[name]
            if subcell == network:
                continue
            if isinstance(subcell, (nn.Conv2d)) and match_op(
                    name_prefix, subcell.weight.name):
                new_subcell = new_conv
                network.insert_child_to_cell(name, new_subcell)
                change = True
            else:
                ConvBnFusionPass.replace_conv(subcell, name_prefix, new_conv)
        if isinstance(network, nn.SequentialCell) and change:
            network.cell_list = list(network.cells())

    @staticmethod
    def get_np_array_from_conv(param_weights, param_bias, conv_type):
        """
        Function: Trans weights and bias from parameter to numpy.array
        Parameters: param_weights: weights that in parameter format
                    param_bias: bias that in parameter format
        Return: weights_array： weights that in numpy.array format
                bias_array: bias that in numpy.array format
        """
        # Get array of weights from ms parameter
        if len(param_weights.data.shape) != 4:
            raise RuntimeError("Convolution weights\' shape should be " \
                "4 dims: N,C,H,W")
        weights_array = None
        if param_weights.data is not None:
            weights_array = param_weights.data.asnumpy()

        # Get array of bias from ms parameter
        bias_array = None
        if param_bias is not None:
            if len(param_bias.data.shape) != 1:
                raise RuntimeError("Convolution bias\' shape should be " \
                    "1 dims: N")
            if param_bias.data is not None:
                bias_array = param_bias.data.asnumpy()
        else:
            if conv_type == 'DepthwiseConv2dNative':
                bias_array = np.zeros(
                    (param_weights.data.shape[1]), dtype=np.float32)
            else:
                bias_array = np.zeros(
                    (param_weights.data.shape[0]), dtype=np.float32)
        return weights_array, bias_array

    @staticmethod
    def get_np_array_from_bn(param_mean, param_variance):
        """
        Function: Trans mean and variance from parameter to numpy.array
        Parameters: param_mean: mean of ms.parameter format
                    param_variance: variance of ms.parameter format
        Return: mean_array mean that in numpy.array format
                variance_array: variance that in numpy.array format
        """
        # Get array of mean from ms parameter
        if len(param_mean.data.shape) != 1:
            raise RuntimeError('BatchNorm mean\' shape should be [N]')
        mean_array = None
        if param_mean.data is not None:
            mean_array = param_mean.data.asnumpy()

        # Get array of variance from ms parameter
        if len(param_variance.data.shape) != 1:
            raise RuntimeError('BatchNorm variance\' shape should be [N]')
        variance_array = None
        if param_variance.data is not None:
            variance_array = param_variance.data.asnumpy()

        return mean_array, variance_array

    @staticmethod
    def get_parameters(node, param_name):
        """ get parameter from node"""
        param = None
        for parameter in node.get_parameters():
            if parameter.name.endswith(param_name):
                param = parameter
        if param is None:
            raise RuntimeError('Can not find {} parameter!'.format(param_name))
        return param

    def match_pattern(self, node):
        """
        Function: Match pattern of "Conv2D" + "FusedBatchNorm" in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        # only calibration has do fusion and skip fusion switch
        if not self.is_retrain:
            if not self.config.get_quant_config().get('do_fusion'):
                return False

            if node.type not in FUSE_TYPES or \
                node.name_prefix in self.config.get_skip_fusion_layers():
                return False
        else:
            # when retrain, only check whether node can be fused or not
            if node.type not in FUSE_TYPES:
                return False
        # If do Conv + BN fusion, conv must can only output to bn
        if len(node.output_anchors) != 1 or \
            len(node.get_output_anchor(0).get_peer_input_anchor()) != 1:
            return False
        peer_input_anchor = node.get_output_anchor(0).get_peer_input_anchor()
        bn_node = peer_input_anchor[0].node
        if bn_node.type not in ['FusedBatchNorm', 'BatchNorm']:
            return False

        return True

    def write_fused_weights_bias_back(self,
                                      network,
                                      conv_node,
                                      bn_node,
                                      param_weights,
                                      fused_weights,
                                      fused_bias):
        """
        Function: Write fused weights, bias to conv_node
        Parameters: conv_node: target conv_node to write fused weights,
                    bias back
                    param_weights: weights that in Parameter format
                    fused_weights: fused weights that in numpy.array format
                    fused_bias: fused bias that in numpy.array format
        Return: None
        """
        fused_weights_tensor = Tensor(
            fused_weights.reshape(param_weights.data.shape),
            param_weights.data.dtype)

        if fused_bias is not None:
            fused_bias_tensor = Tensor(
                fused_bias, param_weights.data.dtype)

        conv_cell = find_cell_by_name(network, conv_node.name_prefix)
        conv_flags = conv_cell.get_flags()
        data_format = conv_cell.format if hasattr(conv_cell, 'format') else conv_cell.data_format
        new_conv_cell = nn.Conv2d(
            in_channels=conv_cell.in_channels,
            out_channels=conv_cell.out_channels,
            kernel_size=conv_cell.kernel_size,
            stride=conv_cell.stride,
            pad_mode=conv_cell.pad_mode,
            padding=conv_cell.padding,
            dilation=conv_cell.dilation,
            group=conv_cell.group,
            has_bias=True,
            weight_init=fused_weights_tensor,
            bias_init=fused_bias_tensor,
            data_format=data_format)
        if conv_flags.get('fp16'):
            new_conv_cell = new_conv_cell.to_float(mstype.float16)
        new_conv_cell.weight.name = conv_node.name_prefix + '.weight'
        new_conv_cell.bias.name = conv_node.name_prefix + '.bias'

        if self.is_retrain:
            ConvBnFusionPass.save_retrain_attrs(conv_cell, new_conv_cell)
        ConvBnFusionPass.replace_conv(
            network, conv_node.name_prefix, new_conv_cell)
        new_identity_cell = Identity()
        convert_bn_with_identity(
            network, bn_node.name_prefix, new_identity_cell)

    def do_pass(self, graph, network, object_node):
        """
        Function: Do actual "Convolution" layer and "BatchNorm" layer
                  fusion operation
        Parameters: graph: graph structure
                    object_node: node to process
        Return: None
        """
        # Step1: remove edge of BatchNorm
        node_conv = object_node
        layer_name = node_conv.name_prefix
        name_cells = []
        find_cells_by_name(network, layer_name, name_cells)
        # skip weight reuse layer
        if len(name_cells) > 1:
            return
        conv_peer_input_anchors = \
            node_conv.get_output_anchor(0).get_peer_input_anchor()
        if len(conv_peer_input_anchors) != 1:
            raise RuntimeError('Can not fuse multi output conv.')
        node_bn = conv_peer_input_anchors[0].node

        # remove output links
        if len(node_bn.output_anchors) != 1:
            raise RuntimeError("BatchNorm should only have 1 output, " \
                "but actually have {}".format(len(node_bn.output_anchors)))
        bn_peer_in_anchors = node_bn.get_output_anchor(0). \
            get_peer_input_anchor()
        bn_peer_input_nodes = []
        bn_peer_input_indexes = []
        for input_anchor in bn_peer_in_anchors:
            bn_peer_input_nodes.append(input_anchor.node)
            bn_peer_input_indexes.append(input_anchor.index)
        for index, element in enumerate(bn_peer_input_nodes):
            graph.remove_edge(node_bn, 0, element,
                              bn_peer_input_indexes[index])

        bn_input_anchors = node_bn.input_anchors
        for index, bn_input_anchor in enumerate(bn_input_anchors):
            bn_peer_output_anchor = bn_input_anchor.get_peer_output_anchor()
            bn_input_node = bn_peer_output_anchor.node
            bn_peer_output_anchor_index = bn_peer_output_anchor.index
            graph.remove_edge(
                bn_input_node, bn_peer_output_anchor_index,
                node_bn, index)

        # Step3: Add link from conv to bn_peer_input_node
        for index, element in enumerate(bn_peer_input_nodes):
            graph.add_edge(node_conv, 0, element,
                           bn_peer_input_indexes[index])
        # Step4: Do conv + bn weights/bias fusion
        self.do_weights_bias_fusion(network, node_conv, node_bn)
        # Step5: Record fusion info to convolution node

        LOGGER.logi('Do conv:\'{}\' + bn:\'{}\' fuison success!'.format(
            node_conv.name_prefix, node_bn.name_prefix), 'ConvBnFusionPass')
        graph.remove_node(node_bn.name)

    def do_weights_bias_fusion(self,
                               network,
                               node_conv,
                               node_bn):
        """
        Function: Do conv+bn weights and bias fuison
        Parameters: node_conv: "Convolution" node
                    node_bn: "BatchNorm" node
        Return: None
        """
        if not node_conv.has_weight():
            raise RuntimeError('Convolution at least should have one parameter')
        conv_cell = find_cell_by_name(network, node_conv.name_prefix)
        if is_invalid(conv_cell.weight.data.asnumpy()):
            raise ValueError(
                'Invalid value(nan or inf) in weight of layer {}'.format(
                    node_conv.name_prefix))
        weight_param_name = node_conv.name_prefix + '.weight'
        bias_param_name = node_conv.name_prefix + '.bias'
        param_weights = conv_cell.parameters_dict()[weight_param_name]
        param_weights = copy.deepcopy(param_weights)
        param_bias = None
        if conv_cell.has_bias:
            if is_invalid(conv_cell.bias.data.asnumpy()):
                raise ValueError(
                    'Invalid value(nan or inf) in bias of layer {}'.format(
                        node_conv.name_prefix))
            param_bias = conv_cell.parameters_dict()[bias_param_name]
            param_bias = copy.deepcopy(param_bias)

        param_gamma = ConvBnFusionPass.get_parameters(node_bn, 'gamma')
        param_beta = ConvBnFusionPass.get_parameters(node_bn, 'beta')
        param_mean = ConvBnFusionPass.get_parameters(node_bn, 'moving_mean')
        param_variance = ConvBnFusionPass.get_parameters(node_bn, 'moving_variance')
        bn_params = [param_gamma, param_beta, param_mean, param_variance]
        for param in bn_params:
            if is_invalid(param.data.asnumpy()):
                raise ValueError(
                    'Invalid value(nan or inf) in {} of layer {}'.format(
                        param.name, node_bn.name_prefix))

        gamma_array = param_gamma.data.asnumpy()
        beta_array = param_beta.data.asnumpy()
        weights_array, bias_array = ConvBnFusionPass.get_np_array_from_conv(
                param_weights, param_bias, node_conv.type)
        mean_array, variance_array = ConvBnFusionPass.get_np_array_from_bn(
            param_mean, param_variance)
        fused_weights, fused_bias = \
            fuse_conv_bn([weights_array, bias_array],
                [mean_array, variance_array, gamma_array, beta_array], node_conv.type)
        weights_shape = param_weights.data.shape

        fused_weights.shape = (weights_shape[3] * weights_shape[2] *
                               weights_shape[1] * weights_shape[0])
        if node_conv.type == 'DepthwiseConv2dNative':
            fused_bias.shape = (weights_shape[1])
        else:
            fused_bias.shape = (weights_shape[0])

        self.write_fused_weights_bias_back(
            network, node_conv, node_bn, param_weights, fused_weights, fused_bias)
