#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

utils for optimizer

"""
import time
import numpy as np

import mindspore.nn as nn
from mindspore import Tensor
from amct_mindspore.cells import Fakequant
from amct_mindspore.cells import QuantIfmr
from amct_mindspore.utils.log import LOGGER
from amct_mindspore.common.config.field import NUM_BINS


def update_model_create_time(network):
    """update the network's create_time """
    new_create_time = int(time.time() * 1e9)
    network._create_time = new_create_time


def match_op(name_prefix, param_name):
    """ match the op according to param name"""
    param_name_list = param_name.split('.')
    param_name_prefix = '.'.join(param_name_list[:-1])
    if name_prefix == param_name_prefix:
        return True
    return False


def convert_bn_with_identity(network, name_prefix, identity):
    """
    convet sub cell to quant cell
    """
    cells = network.name_cells()
    change = False
    for name in cells:
        subcell = cells[name]
        if subcell == network:
            continue
        if isinstance(subcell, (nn.BatchNorm2d)) and match_op(
                name_prefix, subcell.gamma.name):
            new_subcell = identity
            network.insert_child_to_cell(name, new_subcell)
            change = True
        else:
            convert_bn_with_identity(subcell, name_prefix, identity)
    if isinstance(network, nn.SequentialCell) and change:
        network.cell_list = list(network.cells())


def find_cell_by_name(network, layer_name):
    """ find the specific cell from network use the input layer_name
        args:
            network: the network of mindspore
            layer_name: the name_prefix of parameters
    """
    cells = network.name_cells()
    for name in cells:
        subcell = cells[name]
        if subcell == network:
            continue
        if isinstance(
                subcell, (nn.Conv2d, nn.Dense)) and match_op(
                    layer_name, subcell.weight.name):
            return subcell

        ret = find_cell_by_name(subcell, layer_name)
        if ret is not None:
            return ret

    return None


def find_cells_by_name(network, layer_name, name_cells):
    """ find the specific cell from network use the input layer_name
        args:
            network: the network of mindspore
            layer_name: the name_prefix of parameters
    """
    cells = network.name_cells()
    for name in cells:
        subcell = cells[name]
        if subcell == network:
            continue
        if isinstance(subcell, (nn.Conv2d, nn.Dense)) and match_op(
                layer_name, subcell.weight.name):
            name_cells.append(subcell)

        find_cells_by_name(subcell, layer_name, name_cells)


def insert_ifmr_to_cell(network, object_node, act_param):
    """" Insert the IFMR cell to the network
        args:
            network: the network of mindspore
            object_node: the node in graph
            act_parm: the quant params of ifmr algorithm
    """
    name_prefix = object_node.name_prefix
    weight_parameter_name = '.'.join([name_prefix, 'weight'])
    shape = (1,)
    scale_init = Tensor(np.ones(*shape).astype(np.float32))
    offset_init = Tensor(np.zeros(*shape).astype(np.float32))
    for cell_name, subcell in network.cells_and_names():
        if isinstance(subcell, (nn.Conv2d, nn.Dense)) and \
                subcell.weight.name == weight_parameter_name:
            new_subcell = QuantIfmr(
                subcell,
                scale_init,
                offset_init,
                NUM_BINS,
                act_param['min_percentile'],
                act_param['max_percentile'],
                act_param['search_range_start'],
                act_param['search_range_end'],
                act_param['search_step'],
                act_param['with_offset']
            )
            rename_parameters(new_subcell, cell_name)
            insert_child_to_cell(network, cell_name, new_subcell)
            LOGGER.logi('Insert Ifmr op for layer:{} success!'.format(
                name_prefix), 'InsertIfmr')


def insert_child_to_cell(network, target_cell_name, new_subcell):
    """ insert the new_subcell to original's father cell """
    change = False
    cell_name_list = target_cell_name.split('.')
    cell_name = None
    sub_cell = None
    for cell_name, sub_cell in network.cells_and_names():
        if cell_name == '.'.join(cell_name_list[:-1]):
            sub_cell.insert_child_to_cell(cell_name_list[-1], new_subcell)
            change = True
            break
    if isinstance(sub_cell, nn.SequentialCell) and change:
        sub_cell.cell_list = list(sub_cell.cells())


def add_fakequant_to_cell(network, object_node, scale, offset, num_bits):
    """
    convet sub cell to quant cell
    """
    cells = network.name_cells()
    change = False
    for name in cells:
        subcell = cells[name]
        if subcell == network:
            continue
        if isinstance(subcell, (
                nn.Conv2d, nn.Dense)) and match_op(
                    object_node.name_prefix, subcell.weight.name):
            new_subcell = Fakequant(subcell, scale, offset, num_bits)
            rename_parameters(new_subcell, object_node.name_prefix)
            network.insert_child_to_cell(name, new_subcell)
            change = True
        else:
            add_fakequant_to_cell(
                subcell, object_node, scale, offset, num_bits)
    if isinstance(network, nn.SequentialCell) and change:
        network.cell_list = list(network.cells())


def rename_parameters(cell, prefix):
    """rename the parameters of cell with input prefix"""
    for key in cell.parameters_dict().keys():
        sufix = key.split('.')[-1]
        new_name = "{}.{}".format(prefix, sufix)
        cell.parameters_dict()[key].name = new_name
