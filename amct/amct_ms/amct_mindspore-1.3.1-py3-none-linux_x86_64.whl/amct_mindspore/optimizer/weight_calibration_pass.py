#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

weight calibration operation

"""
import numpy as np

from mindspore import Tensor

from amct_mindspore.utils.log import LOGGER
from amct_mindspore.configuration.retrain_config import RetrainConfig
from amct_mindspore.configuration.configuration import Configuration
from amct_mindspore.configuration.val_util import QUANTIZABLE_TYPES
from amct_mindspore.operation.arq_quantize_algorithm import WEIGHTS_QUANT_ALGO
from amct_mindspore.optimizer.utils import find_cells_by_name
from amct_mindspore.optimizer.base_fusion_pass import BaseFusionPass
from amct_mindspore.common.utils.util import is_invalid
WEIGHT_CALIBRATION = 'weight_calibration'


class WeightCalibrationPass(BaseFusionPass):
    """Weight calibration pass."""
    def __init__(self, is_retrain=False):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.retrain = is_retrain
        if self.retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()
        self._quant_config = self.conf.get_quant_config()

    def match_pattern(self, node):
        """
        Function: Match pattern of "Conv2D", "MatMul", "DepthwiseConv2dNative"
                  in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type not in QUANTIZABLE_TYPES:
            return False
        if node.name_prefix not in self._quant_config:
            return False
        if not self.retrain:
            if not self._quant_config[node.name_prefix].get(
                    'quant_enable', False):
                return False
        else:
            if not self._quant_config[node.name_prefix].get(
                    'retrain_enable', False):
                return False
        return True


    def do_pass(self, graph, network, object_node):
        """
        Function: Do weight calibration for quantizable layers.
        Parameters: graph: graph structure
                    network: MindSpore network
                    object_node: node to process
        Return: None
        """
        layer_name = object_node.name_prefix
        name_cells = []
        find_cells_by_name(network, layer_name, name_cells)
        # skip weight reuse layer
        if len(name_cells) > 1:
            return
        subcell = name_cells[0]

        # already has done weight calibration
        if hasattr(subcell, WEIGHT_CALIBRATION):
            return
        if subcell is None:
            raise RuntimeError('fail to find subcell for name {}'.format(layer_name))
        param_weights = subcell.weight

        data = param_weights.data.asnumpy()
        if is_invalid(data):
            raise ValueError('Invalid value(nan or inf) in weight in layer {}'.format(layer_name))

        orginal_dtype = data.dtype
        if orginal_dtype == np.float16:
            data = data.astype(np.float32)

        layer_config = self.conf.get_layer_config(layer_name)
        # calibration
        if not self.retrain:
            wts_param = layer_config.get('weight_quant_params')
            wts_algo = wts_param['wts_algo']
            if wts_algo not in WEIGHTS_QUANT_ALGO:
                raise RuntimeError('Not support quantize algorithm "{}" yet.'.format(wts_algo))
        else:
            retrain_wts_config = layer_config.get('retrain_weight_config')
            channel_wise = retrain_wts_config['channel_wise']
            wts_algo = 'arq_quantize'
            wts_param = {'channel_wise': channel_wise,
                         'with_offset': False, 'num_bits': 8}

        # depthwise out channel is axis 1, need to transepose
        if object_node.type == 'DepthwiseConv2dNative':
            weights_numpy = data.transpose((1, 0, 2, 3))
            scale, offset = WEIGHTS_QUANT_ALGO.get(wts_algo).quantize_data(
                weights_numpy, weights_numpy.shape, wts_param)
            data = weights_numpy.transpose((1, 0, 2, 3))
        else:
            scale, offset = WEIGHTS_QUANT_ALGO.get(wts_algo).quantize_data(
                data, data.shape, wts_param)
        if orginal_dtype == np.float16:
            data = data.astype(np.float16)

        param_weights.set_data(Tensor(data))
        for subcell in name_cells:
            setattr(subcell, 'scale_w', scale)
            setattr(subcell, 'offset_w', offset)
            setattr(subcell, WEIGHT_CALIBRATION, True)

        LOGGER.logi(
            'Do weight calibration for layer:{} success!'.format(layer_name), 'WeightCalibration')
