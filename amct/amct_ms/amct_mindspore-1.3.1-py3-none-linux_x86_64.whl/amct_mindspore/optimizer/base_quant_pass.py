#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

base quant pass

"""
from amct_mindspore.configuration.configuration import Configuration
from amct_mindspore.optimizer.base_fusion_pass import BaseFusionPass
from amct_mindspore.configuration.val_util import QUANTIZABLE_TYPES


class BaseQuantPass(BaseFusionPass):
    """Base quant pass"""
    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.conf = Configuration()
        self._quant_config = self.conf.get_quant_config()

    def match_pattern(self, node):
        """
        Function: Match pattern of "Conv2D", "MatMul", "DepthwiseConv2dNative"
                  in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type not in QUANTIZABLE_TYPES:
            return False
        if node.name_prefix not in self._quant_config:
            return False
        if not self._quant_config[node.name_prefix].get('quant_enable', False):
            return False

        return True
