#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

insert qat operation

"""
from collections import OrderedDict
import mindspore.nn as nn

from amct_mindspore.cells.conv2d_qat_cell import Conv2dQatBlock
from amct_mindspore.cells.dense_qat_cell import DenseQatBlock
from amct_mindspore.cells.weight_arq import WeightArq
from amct_mindspore.cells.activation_ulq import ActUlq
from amct_mindspore.optimizer.utils import insert_child_to_cell
from amct_mindspore.optimizer.utils import rename_parameters
from amct_mindspore.configuration.retrain_config import RetrainConfig
from amct_mindspore.optimizer.base_fusion_pass import BaseFusionPass
from amct_mindspore.configuration.val_util import RETRAIN_TYPES
from amct_mindspore.configuration.val_util import RETRAIN_BIT
from amct_mindspore.configuration.val_util import DEFAULT_ACT_ULQ_PARAMS
from amct_mindspore.utils.log import LOGGER


def gen_qat_cell(subcell, act_param, wts_param):
    """ get the qat cell instance method"""
    act_ulq_cell = ActUlq(act_param['min_init'],
                          act_param['max_init'],
                          act_param['fixed_min'],
                          act_param['num_bits'],
                          isinstance(subcell, nn.Conv2d))

    weight_arq_cell = WeightArq(wts_param['channel_axis'],
                                subcell,
                                wts_param['offset_flag'],
                                wts_param['num_bits'])

    if isinstance(subcell, nn.Conv2d):
        new_cell = Conv2dQatBlock(act_qat_cell=act_ulq_cell,
                                  weight_qat_cell=weight_arq_cell,
                                  subcell=subcell)
    elif isinstance(subcell, nn.Dense):
        new_cell = DenseQatBlock(act_qat_cell=act_ulq_cell,
                                 weight_qat_cell=weight_arq_cell,
                                 subcell=subcell)
    return new_cell


def _convert(network, layer_name, act_param, wts_param):
    """ convert quantable cells to qat block cells"""
    change = False
    cells = network.name_cells()
    for name in cells:
        subcell = cells[name]
        if subcell == network:
            continue
        if isinstance(subcell, (nn.Conv2d, nn.Dense)) and \
                (subcell.weight.name == '.'.join([layer_name, 'weight'])):
            change = True
            new_subcell = gen_qat_cell(subcell, act_param, wts_param)
            rename_parameters(new_subcell, layer_name)
            insert_child_to_cell(network, name, new_subcell)
            LOGGER.logi(
                'Insert QatLayer for layer:{} success!'.format(layer_name),
                'InsertQat')
            break
        if _convert(subcell, layer_name, act_param, wts_param):
            return True
    if change:
        if isinstance(network, nn.SequentialCell):
            network.cell_list = list(network.cells())
        return True
    return False


class InsertQatPass(BaseFusionPass):
    """Insert Qat layers to network pass."""
    def __init__(self, clip_min_max_init, is_restore=False):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.config = RetrainConfig()
        self._quant_config = self.config.get_quant_config()
        self.clip_min_max_init = clip_min_max_init
        self.is_restore = is_restore

    @staticmethod
    def gen_wts_params(object_node,
                       weight_config):
        """ method to get the wts params"""
        wts_qat_params = OrderedDict()
        wts_qat_params['num_bits'] = RETRAIN_BIT
        wts_qat_params['offset_flag'] = False

        channel_wise = weight_config.get('channel_wise', True)
        if object_node.type == 'Conv2D':
            wts_qat_params['channel_axis'] = [0] if channel_wise else []
        elif object_node.type == 'DepthwiseConv2dNative':
            wts_qat_params['channel_axis'] = [1] if channel_wise else []
        elif object_node.type == 'MatMul':
            wts_qat_params['channel_axis'] = []
        else:
            raise RuntimeError(
                'Not support quant aware training of {} yet.'.format(
                    object_node.type))
        return wts_qat_params

    @staticmethod
    def is_parent_relu(object_node):
        """ method to confirm whether parent node is relue"""
        input_anchors = object_node.input_anchors
        # the conv has no input layer
        if len(input_anchors) == 0:
            return False
        if len(input_anchors) == 1:
            input_anchor = input_anchors[0]
            input_node = input_anchor.node
            if input_node.type in ['ReLU', 'ReLU6']:
                return True
        return False

    def match_pattern(self, node):
        """
        Function: Match pattern of "Conv2D", "MatMul", "DepthwiseConv2dNative"
                  in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type not in RETRAIN_TYPES:
            return False
        if node.name_prefix not in self._quant_config:
            return False
        if not self._quant_config[node.name_prefix].get(
                'retrain_enable', False):
            return False

        return True

    def gen_act_params(self, object_node, retrain_data_config):
        """ method to get the act params"""
        layer_name = object_node.name_prefix
        act_ulq_params = DEFAULT_ACT_ULQ_PARAMS
        # when is not restore case, need to use calibration record to init
        # clip_min and clip_max, when is_restore, use default value;
        if not self.is_restore:
            if 'clip_max' in retrain_data_config.keys() and 'clip_min' \
                    in retrain_data_config.keys():
                act_ulq_params['min_init'] = retrain_data_config['clip_min']
                act_ulq_params['max_init'] = retrain_data_config['clip_max']
            else:
                if self.clip_min_max_init is not None and \
                        layer_name in self.clip_min_max_init.keys():
                    act_ulq_params['min_init'] = self.clip_min_max_init[
                        layer_name][0]
                    act_ulq_params['max_init'] = self.clip_min_max_init[
                        layer_name][1]
                else:
                    LOGGER.logw(
                        'Can not find initial value for layer {} in record '
                        'file, may influence the retrain result.'.format(
                            layer_name))

        if 'fixed_min' in retrain_data_config.keys():
            act_ulq_params['fixed_min'] = retrain_data_config['fixed_min']
        if InsertQatPass.is_parent_relu(object_node):
            act_ulq_params['fixed_min'] = True

        return act_ulq_params

    def do_pass(self, graph, network, object_node):
        """
        Function: Do actual "Conv2D", "MatMul", "DepthwiseConv2dNative" layer
                  convert to ifmr + compute_cell
        Parameters: graph: graph structure
                    network: MindSpore network
                    object_node: node to process
        Return: None
        """
        layer_name = object_node.name_prefix
        layer_config = self.config.get_layer_config(layer_name)
        retrain_weight_config = layer_config.get('retrain_weight_config',
                                                 {"algo": "arq_retrain",
                                                  "channel_wise": True})
        wts_qat_params = self.gen_wts_params(object_node,
                                             retrain_weight_config)

        retrain_data_config = layer_config.get('retrain_data_config')
        act_ulq_params = self.gen_act_params(object_node, retrain_data_config)
        _convert(network, layer_name, act_ulq_params, wts_qat_params)
