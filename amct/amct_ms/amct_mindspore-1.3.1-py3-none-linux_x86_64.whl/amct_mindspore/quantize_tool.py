#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

APIs of AMCT MindSpore tool for user

"""
import os
import sys
import copy
import time

import mindspore
from mindspore.train import serialization
import mindspore.nn as nn
from mindspore.train.serialization import load_checkpoint
from mindspore.train.serialization import load_param_into_net

from amct_mindspore.utils.log import LOGGER
from amct_mindspore.configuration.configuration import Configuration
from amct_mindspore.configuration.check import GraphChecker
from amct_mindspore.optimizer.conv_bn_fusion_pass import ConvBnFusionPass
from amct_mindspore.optimizer.weight_calibration_pass \
    import WeightCalibrationPass
from amct_mindspore.optimizer.insert_ifmr_pass import InsertIfmrPass
from amct_mindspore.optimizer.insert_qat_pass import InsertQatPass
from amct_mindspore.optimizer.delete_qat_layers_pass import DeleteQatLayersPass
from amct_mindspore.optimizer.graph_optimizer import GraphOptimizer
from amct_mindspore.optimizer.utils import update_model_create_time
from amct_mindspore.graph.parser import Parser
from amct_mindspore.graph.anf import get_anf_ir
from amct_mindspore.graph.anf import input_data_to_tensor
from amct_mindspore.cells import QuantIfmr
from amct_mindspore.cells import Conv2dQatBlock
from amct_mindspore.cells import DenseQatBlock
from amct_mindspore.common.utils.check_params import check_params
from amct_mindspore.utils.save_record import SaveRecord
import amct_mindspore.cells.cell_helper as cell_helper
from amct_mindspore.common.utils.files import is_valid_name
from amct_mindspore.common.utils.files import create_file_path
from amct_mindspore.common.utils.files import check_files_exist
from amct_mindspore.operation.save_air import convert_deploy
from amct_mindspore.configuration.retrain_config import RetrainConfig
from amct_mindspore.operation.save_air import convert_retrain_deploy
from amct_mindspore.initializer import UlqInitializer


@check_params(config_file=str,
              network=nn.Cell,
              skip_layers=(list, type(None)),
              activation_offset=bool,
              config_defination=(type(None), str))
def create_quant_config(
        config_file,
        network,
        *input_data,
        skip_layers=None,
        activation_offset=True,
        config_defination=None):
    """
    Function: Create quantize configuration json file for amct_mindspore tool
    Parameter: config_file: file path of quantize configuration json file
               network: use defined network
               input_data: used to compile network, can be ramdom data
               skip_layers: list of layers that not do quantize, default empty
               activation_offset: whether activation quantize with offset
               config_defination: simply config file from user to set
    Return: None
    """
    network = copy.deepcopy(network)
    # force executor recompile the network
    update_model_create_time(network)
    anf_ir = get_anf_ir(network, *input_data)
    graph = Parser.parse_net_to_graph(anf_ir, network)
    GraphChecker.check_quant_cells(network)

    # create config file for quantizetion
    GraphChecker.set_network(network)
    Configuration.create_quant_config(config_file, graph, skip_layers,
                                      activation_offset, config_defination)
    GraphChecker.del_network()


@check_params(config_file=str, network=nn.Cell)
def quantize_model(config_file, network, *input_data):
    """
    Function: generate calibration network
    Parameter: config_file: file path of quantize configuration json file
               network: user defined network
               input_data: used to compile network, can be ramdom data
    Return: a network for calibration
    """
    network = copy.deepcopy(network)
    anf_ir = get_anf_ir(network, *input_data)
    graph = Parser.parse_net_to_graph(anf_ir, network)
    GraphChecker.check_quant_cells(network)
    GraphChecker.set_network(network)
    Configuration().init(config_file, graph)
    GraphChecker.del_network()

    optimizer = GraphOptimizer()
    optimizer.add_pass(ConvBnFusionPass())
    optimizer.add_pass(WeightCalibrationPass())
    optimizer.add_pass(InsertIfmrPass())
    optimizer.do_optimizer(graph, network)
    network.set_train(False)
    # force executor recompile the network
    update_model_create_time(network)
    return network


def save_air(file_name, network, *input_data):
    """
    Function: save air file
    Parameter: file_name: file path of exported air
               network: calibration network
               input_data: used to compile network, can be ramdom data
    Return: None
    """
    input_tensor = input_data_to_tensor(*input_data)
    # force executor recompile the network
    origin_name = file_name
    file_name = file_name + '.air'
    check_files_exist([file_name])
    origin_create_time = network._create_time
    new_create_time = int(time.time() * 1e9)
    network._create_time = new_create_time
    try:
        serialization.export(network,
                             *input_tensor,
                             file_name=origin_name,
                             file_format='AIR')
    except Exception as ex:
        raise RuntimeError(
            'Generate AIR file:{} failed.'.format(file_name)) from ex
    else:
        network._create_time = origin_create_time
        LOGGER.logi('Generate AIR file:{} success!'.format(file_name),
                    'QuantizeTool')


@check_params(file_name=str, network=nn.Cell)
def save_model(file_name, network, *input_data):
    """
    Function: export air file
    Parameter: file_name: file path of exported air
               network: calibration network
               input_data: used to compile network, can be ramdom data
    Return: a network for calibration
    """
    is_valid_name(file_name, 'file_name')
    file_name = os.path.realpath(file_name)
    create_file_path(file_name)
    GraphChecker.check_quant_cells(network, skip_types=[QuantIfmr])

    SaveRecord().init('calibration_record.txt')
    network.update_cell_prefix()
    convert_deploy(network)
    SaveRecord().dump()
    save_air(file_name, network, *input_data)


@check_params(config_file=str,
              network=nn.Cell,
              config_defination=(type(None), str))
def create_quant_retrain_config(
        config_file,
        network,
        *input_data,
        config_defination=None):
    """
    Function: Create quantize configuration json file for amct_mindspore tool
    Parameter: config_file: file path of quantize configuration json file
               network: use defined network
               input_data: used to compile network, can be ramdom data
               config_defination: simply config file from user to set
    Return: None
    """
    network = copy.deepcopy(network)
    # force executor recompile the network
    update_model_create_time(network)
    anf_ir = get_anf_ir(network, *input_data)
    graph = Parser.parse_net_to_graph(anf_ir, network)
    GraphChecker.check_quant_cells(network)

    # create config file for quantizetion
    RetrainConfig.create_retrain_quant_config(config_file, graph,
                                              config_defination)


@check_params(config_file=str, network=nn.Cell)
def create_quant_retrain_model(config_file, network, initializer, *input_data):
    """
    Function: create retrain network
    Parameter: config_file: file path of quantize configuration json file
               network: User defined network (nn.Cell)
               initializer: the intializer to initialize the Qat cell
               *input_data: used to compile network, can be random data
    Return: a network for retrain
    """
    # check the network has ifmr, deploy, QatBlock or not
    GraphChecker.check_quant_cells(network)
    # check the file and path
    config_file_path = os.path.realpath(config_file)
    if not os.path.exists(config_file_path):
        raise RuntimeError(
            'Can not find the config file {}'.format(config_file))
    if not isinstance(initializer, (type(None), UlqInitializer)):
        raise ValueError('Not support this type of initializer {}'.format(
            type(initializer)))
    if initializer is None:
        clip_min_max_init = None
    else:
        clip_min_max_init = initializer.get_min_max_init(network)

    retrain_network = copy.deepcopy(network)
    anf_ir = get_anf_ir(retrain_network, *input_data)
    graph = Parser.parse_net_to_graph(anf_ir, retrain_network)

    RetrainConfig().init(config_file, graph)

    retrain_network.set_train(True)
    retrain_optimizer = GraphOptimizer()
    retrain_optimizer.add_pass(InsertQatPass(clip_min_max_init))
    retrain_optimizer.do_optimizer(graph, retrain_network)
    # force executor recompile the network
    update_model_create_time(retrain_network)
    return retrain_network


@check_params(config_file=str, network=nn.Cell, checkpoint_path=str)
def restore_quant_retrain_model(config_file, network, checkpoint_path,
                                *input_data):
    """
    Function: restore retrain network from last checkpoint
    Parameter: config_file: file path of quantize configuration json file
               network: User defined network (nn.Cell)
               checkpoint_path: User quant aware training checkpoint file path
               *input_data: used to compile network, can be random data
    Return: a network for retrain
    """
    # check the file and path
    if not os.path.exists(os.path.realpath(config_file)):
        raise RuntimeError(
            'Can not find the config file {}'.format(config_file))
    if not os.path.exists(os.path.realpath(checkpoint_path)):
        raise RuntimeError(
            'Can not find the checkpoint file {}'.format(checkpoint_path))
    # check the input checkpoint file
    param_dict = load_checkpoint(checkpoint_path)
    if not cell_helper.check_restore_ckpt(param_dict):
        raise RuntimeError(
            'This checkpoint {} does not contain amct qat learnable '
            'parameters clip_min and clip_max'.format(checkpoint_path))

    GraphChecker.check_quant_cells(network)
    # restore the network to retrain network
    anf_ir = get_anf_ir(network, *input_data)
    graph = Parser.parse_net_to_graph(anf_ir, network)
    RetrainConfig().init(config_file, graph)

    retrain_network = copy.deepcopy(network)
    retrain_network.set_train(True)
    retrain_optimizer = GraphOptimizer()
    retrain_optimizer.add_pass(InsertQatPass(None, is_restore=True))
    retrain_optimizer.do_optimizer(graph, retrain_network)

    # load the checkpoint to the retrain network
    load_param_into_net(retrain_network, param_dict)
    # force executor recompile the network
    update_model_create_time(retrain_network)
    return retrain_network


@check_params(config_file=str, file_name=str, network=nn.Cell)
def save_quant_retrain_model(config_file, file_name, network, *input_data):
    """
    Function: export air file
    Parameter: file_name: file path of exported air
               network: retrain network
               input_data: used to compile network, can be randon data
    """
    if not os.path.exists(os.path.realpath(config_file)):
        raise RuntimeError(
            'Can not find the config file {}'.format(config_file))

    is_valid_name(file_name, 'file_name')
    file_name = os.path.realpath(file_name)
    create_file_path(file_name)
    GraphChecker.check_quant_cells(network,
                                   skip_types=[Conv2dQatBlock, DenseQatBlock])
    if not GraphChecker.check_quant_cell_exist(
            network, check_types=[Conv2dQatBlock, DenseQatBlock]):
        raise RuntimeError(
            "The input network does not contain Conv2dQatBlock, DenseQatBlock,"
            " it may not be the quant aware training network.")

    optimizer = GraphOptimizer()
    # modify graph, delete ulq and arq op, bn fusion
    optimizer.add_pass(DeleteQatLayersPass())
    optimizer.do_optimizer(None, network)

    network2graph = copy.deepcopy(network)
    network2graph.set_train(False)

    with open(os.devnull, 'w') as new_stdout:
        origin_stdout = sys.stdout
        sys.stdout = new_stdout
        try:
            anf_ir = get_anf_ir(network2graph, *input_data)
        except TypeError as _:
            network2graph.to_float(mindspore.float32)
            anf_ir = get_anf_ir(network2graph, *input_data)
        finally:
            sys.stdout = origin_stdout
            new_stdout.close()

        graph = Parser.parse_net_to_graph(anf_ir, network2graph)

        network = copy.deepcopy(network)
        network.set_train(False)
        RetrainConfig().init(config_file, graph)
        SaveRecord().init('retrain_record.txt')

        optimizer = GraphOptimizer()
        optimizer.add_pass(ConvBnFusionPass(True))
        optimizer.add_pass(WeightCalibrationPass(True))
        optimizer.do_optimizer(graph, network)
        convert_retrain_deploy(network)
        SaveRecord().dump()
        save_air(file_name, network, *input_data)
