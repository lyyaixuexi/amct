#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

weight calibration operation

"""

import mindspore.nn as nn

from amct_mindspore.cells.cell_helper import get_scale_offset_from_ifmr
from amct_mindspore.cells.cell_helper import get_name_prefix
from amct_mindspore.optimizer.utils import rename_parameters
from amct_mindspore.cells import Fakequant
from amct_mindspore.cells import QuantIfmr


def replace_ifmr_with_fakequant(network, num_bits):
    """
    convet sub cell to quant cell
    """
    cells = network.name_cells()
    for name in cells:
        subcell = cells[name]
        if subcell == network:
            continue
        if isinstance(subcell, QuantIfmr):
            scale_d, offset_d = get_scale_offset_from_ifmr(subcell)
            scale_d = float(scale_d.data.asnumpy()[0])
            offset_d = int(offset_d.data.asnumpy()[0])
            name_prefix = get_name_prefix(subcell)
            compute_cell = subcell.name_cells()['compute_cell']
            new_subcell = Fakequant(compute_cell, scale_d, offset_d, num_bits)
            rename_parameters(new_subcell, name_prefix)
            network.insert_child_to_cell(name, new_subcell)
        else:
            replace_ifmr_with_fakequant(
                subcell, num_bits)
    if isinstance(network, nn.SequentialCell):
        network.cell_list = list(network.cells())



def convert_calibration_to_fakequant(
        network,
        num_bits):
    """ convert calibration network to fakequant network"""
    replace_ifmr_with_fakequant(network, num_bits)
    return network
