#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

save record file

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os

from google.protobuf import text_format
from amct_mindspore.proto \
    import scale_offset_record_pb2
from amct_mindspore.common.utils.files import create_empty_file
from amct_mindspore.utils.log import LOGGER

DUMP_DIR = 'amct_dump'
RECORD_FILE_PATH = os.path.realpath(DUMP_DIR)
DUMP_RECORD_ENV = 'DUMP_AMCT_RECORD'


__all__ = ['SaveRecord']


class SaveRecord:
    '''Save scale and offset in record.txt file.'''
    __instance = None
    __init = False

    def __new__(cls, *args, **kw):
        if cls.__instance is None:
            cls.__instance = object.__new__(cls, *args, **kw)
        return cls.__instance

    def __init__(self):
        if not self.__init:
            self._records = None
            self._do_record = False
            self.record_file_name = None
            self.__init = True

    @property
    def records(self):
        '''Get ScaleOffsetRecord object.'''
        return self._records

    @property
    def do_record(self):
        '''Whether dump scale offset in record.txt.'''
        return self._do_record

    def init(self, file_name):
        '''Init SaveRecord bbject'''
        env_var = os.environ.get(DUMP_RECORD_ENV)
        if env_var == '1':
            self._do_record = True
        else:
            self._do_record = False
        self._records = scale_offset_record_pb2.ScaleOffsetRecord()
        if self._do_record:
            self.record_file_name = os.path.realpath(
                os.path.join(RECORD_FILE_PATH, file_name))
            create_empty_file(self.record_file_name)
            with open(self.record_file_name, 'r') as fid:
                pbtxt_string = fid.read()
                text_format.Merge(pbtxt_string, self._records)

    def dump(self):
        '''Dump process.'''
        if self._do_record:
            with open(self.record_file_name, "w") as fid:
                fid.write(
                    text_format.MessageToString(self._records, as_utf8=True))
            LOGGER.logi(
                'Save record file in {} success!'.format(
                    self.record_file_name), 'SaveRecord')

        self._records = None
