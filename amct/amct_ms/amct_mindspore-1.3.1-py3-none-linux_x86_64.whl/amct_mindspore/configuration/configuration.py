#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

amct tool quant configuration class

"""
import os

from amct_mindspore.utils.log import LOGGER
from amct_mindspore.graph.graph import Graph
from amct_mindspore.configuration.check import GraphChecker
from amct_mindspore.configuration.check import GraphQuerier
from amct_mindspore.common.utils.check_params import check_params
from amct_mindspore.common.utils.files import is_valid_name
from amct_mindspore.common.config.config_base import ConfigBase
from amct_mindspore.common.config.config_base import GraphObjects
from amct_mindspore.common.config.config_base import check_config_quant_enable
from amct_mindspore.capacity import CAPACITY
from amct_mindspore.configuration.val_util import CLIBRATION_BIT

CONFIGURER = ConfigBase(
    GraphObjects(graph_querier=GraphQuerier, graph_checker=None), CAPACITY)


class Configuration:
    """
    Function: manage configuration of project including quant_config
              and record_file.
    APIs: get_quant_config, get_layer_config, get_record_file_path;
        create_quant_config, parse_quant_config
    """
    __instance = None
    __init = False

    def __new__(cls, *args, **kw):
        if cls.__instance is None:
            cls.__instance = object.__new__(cls, *args, **kw)
        return cls.__instance

    def __init__(self):
        if not self.__init:
            self.__quant_config = None
            self.__skip_fusion_layers = None
            self.__initialized = False
            self.__init = True

    @staticmethod
    @check_params(config_file=str,
                  graph=Graph,
                  skip_cells=(list, type(None)),
                  activation_offset=bool,
                  config_defination=(type(None), str))
    def create_quant_config(config_file,
                            graph,
                            skip_cells=None,
                            activation_offset=True,
                            config_defination=None):
        """
        Function: Create quant config.
        Inputs:
            config_file: a string, the file(including path information) to
                save quant config.
            graph: IR Graph, the graph to be quantized.
            skip_cells: a list, cell names which would not apply quantize,
                the skip layer type should be in ['Conv2D', 'MatMul'].
            activation_offset: a bool indicating whether there's offset or not
                in quantize activation.
            config_defination: a string, the simple config file path,
                containing the simple quant config according to proto.
        Returns: None
        """
        is_valid_name(config_file, 'config_file')
        GraphChecker.check_quant_behaviours(graph)

        if skip_cells is None:
            skip_cells = []
        if config_defination is None:
            CONFIGURER.create_quant_config(config_file,
                                           graph,
                                           skip_layers=skip_cells,
                                           activation_offset=activation_offset)
        else:
            CONFIGURER.create_config_from_proto(config_file, graph,
                                                config_defination)

    @staticmethod
    def add_global_to_layer(quant_config):
        """add global quantize parameter to each layer"""
        CONFIGURER.add_global_to_layer(quant_config, CLIBRATION_BIT,
                                       'arq_quantize')

        LOGGER.logd("Add global params to layer's config  success!",
                    module_name="Configuration")

    @staticmethod
    @check_params(file_name=str, graph=Graph)
    def parse_quant_config(file_name, graph):
        """parse quantize configuration from config json file"""
        quant_config = CONFIGURER.parse_config_file(file_name, graph)
        check_config_quant_enable(quant_config)
        Configuration.add_global_to_layer(quant_config)
        return quant_config

    @check_params(config_file=str, graph=Graph)
    def init(self, config_file, graph):
        """
        Function: init the Configuration.
        Inputs:
            config_file: a string, the file containing the quant config.
            graph: IR Graph
        Returns: None
        """
        self.__quant_config = self.parse_quant_config(
            os.path.realpath(config_file), graph)
        self.__skip_fusion_layers = \
            self.__quant_config.get('skip_fusion_layers')
        self.__initialized = True

    def uninit(self):
        '''uninit Configuration Class'''
        self.__quant_config = None
        self.__skip_fusion_layers = None
        self.__initialized = False

    def get_quant_config(self):
        """ get quant config. """
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__quant_config

    def get_fusion_switch(self):
        """get global fusion switch state"""
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__quant_config.get('do_fusion')

    def get_global_config(self, global_params_name):
        """ get global quant config. """
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__quant_config.get(global_params_name)

    def get_skip_fusion_layers(self):
        """Get layers that need to skip do fusion"""
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__skip_fusion_layers

    def get_layer_config(self, layer_name):
        """ get one lsyer's quant config. """
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__quant_config.get(layer_name)
