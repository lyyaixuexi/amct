#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

graph checker and graph quirer

"""
import mindspore

from amct_mindspore.utils.log import LOGGER
from amct_mindspore.configuration.val_util import QUANTIZABLE_TYPES
from amct_mindspore.cells.deploy_cell import DeployBlock
from amct_mindspore.cells import QuantIfmr
from amct_mindspore.cells import Conv2dQatBlock
from amct_mindspore.cells import DenseQatBlock
from amct_mindspore.optimizer.utils import find_cell_by_name

SYMMETRIC_LIMIT_TYPES = ['Conv3D']


class GraphQuerier():
    '''provide some APIs to query the graph'''
    @staticmethod
    def get_support_quant_layers(graph):
        '''return supported quant layers in graph'''
        layers = []
        for node in graph.nodes:
            if GraphChecker.check_quantize_type(node):
                layers.append(node.name_prefix)
        return layers

    @staticmethod
    def get_support_quant_layer2type(graph):
        '''return supported layer to type map in graph'''
        layers = {}
        for node in graph.nodes:
            if GraphChecker.check_quantize_type(node):
                layers[node.name_prefix] = node.type
        return layers

    @staticmethod
    def get_name_type_dict(graph):
        '''get all layer name to type dict'''
        layer_type = {}
        for node in graph.nodes:
            if node.name_prefix is not None:
                layer_type[node.name_prefix] = node.type
            else:
                layer_type[node.name] = node.type
        return layer_type

    @staticmethod
    def get_act_symmetric_limit_types():
        """get type only support activation symmetric"""
        return SYMMETRIC_LIMIT_TYPES

    @staticmethod
    def get_act_symmetric_limit_layers(graph):
        """get layer only support activation symmetric"""
        layers = []
        for node in graph.nodes:
            if node.type in SYMMETRIC_LIMIT_TYPES:
                layers.append(node.name_prefix if node.name_prefix else node.name)
        return layers


class GraphChecker():
    """Check the graph."""
    # ms graph need to check anf and cells
    @staticmethod
    def set_network(network):
        """ set the network """
        GraphChecker.network = network

    @staticmethod
    def del_network():
        """ del the network """
        del GraphChecker.network

    @staticmethod
    def check_quantize_type(node):
        """ check if node can be quantized or not."""
        # check type
        if node.type not in QUANTIZABLE_TYPES:
            return False
        if not node.has_weight():
            return False
        # check weight dtype, only support float16 and float32
        if node.get_weight().data.dtype not in (mindspore.float16,
                                                mindspore.float32):
            return False

        if hasattr(GraphChecker, 'network') and find_cell_by_name(
                GraphChecker.network, node.name_prefix) is None:
            return False

        if node.type in ('Conv2D', 'DepthwiseConv2dNative'):
            # conv2D
            if not _check_weight(node, 4):
                return False
        return True

    @staticmethod
    def check_quant_behaviours(graph):
        """Stub function for base config."""
        pass

    @staticmethod
    def check_quant_cells(network, skip_types=None):
        """Check quant cells."""
        if skip_types is None:
            skip_types = []
        quant_layers = [QuantIfmr, DeployBlock, Conv2dQatBlock, DenseQatBlock]
        check_types = tuple(set(quant_layers) - set(skip_types))
        appear_types = set()

        for _, cell in network.cells_and_names():
            for item in check_types:
                if isinstance(cell, item):
                    appear_types.add(item)

        if appear_types:
            raise RuntimeError("The model cannot be processed for following "\
                "cells types are in the net %s" % (appear_types))


    @staticmethod
    def check_quant_cell_exist(network, check_types=None):
        """Check quant cells."""
        check_types = tuple(check_types)
        appear_types = set()
        for _, cell in network.cells_and_names():
            for item in check_types:
                if isinstance(cell, item):
                    appear_types.add(item)
        if appear_types:
            return True
        return False


def _check_weight(node, weights_dimension):
    """ Check whether the node's weight shape satisfy weights_dimension"""
    if not node.has_weight():
        raise RuntimeError("Layer %s has no weight." % (node.name_prefix))

    weights_shape = node.get_weight().data.shape
    if weights_shape is None or len(weights_shape) != weights_dimension:
        LOGGER.logd("The %s's weights_shape is %s" \
                    % (node.name_prefix, weights_shape),
                    module_name="Configuration")
        return False

    return True


def _check_dilation(node, dilation_range):
    """ Check whether the node's dilation satisfy dilation_range"""
    dilation = node.get_attr('dilation')
    if dilation not in dilation_range:
        LOGGER.logd("Layer %s's dilation is %s." %
                    (node.name_prefix, dilation),
                    module_name="Configuration")
        return False

    return True


def _check_group(node, group_range):
    """ Check whether the node's group satisfy dilation_range"""
    group = node.get_attr('group')
    if group not in group_range:
        LOGGER.logd("Layer %s's group is %s." %
                    (node.name_prefix, group),
                    module_name="Configuration")
        return False

    return True
