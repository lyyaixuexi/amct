#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

amct tool quant configuration class

"""
import os

from amct_mindspore.utils.log import LOGGER
from amct_mindspore.graph.graph import Graph
from amct_mindspore.configuration.check import GraphChecker
from amct_mindspore.configuration.check import GraphQuerier
from amct_mindspore.common.utils.check_params import check_params
from amct_mindspore.common.utils.files import is_valid_name
from amct_mindspore.common.retrain_config.retrain_config_base import \
    RetrainConfigBase
from amct_mindspore.common.config.config_base import GraphObjects
from amct_mindspore.capacity import CAPACITY

CONFIGURER = RetrainConfigBase(
    GraphObjects(graph_querier=GraphQuerier, graph_checker=None), CAPACITY)


class RetrainConfig:
    """
    Function: manage configuration of project including quant_config
              and record_file.
    APIs: get_quant_config, get_layer_config, get_record_file_path;
        create_quant_config, parse_quant_config
    """
    __retrain_instance = None
    __init = False

    def __new__(cls, *args, **kw):
        if cls.__retrain_instance is None:
            cls.__retrain_instance = object.__new__(cls, *args, **kw)
        return cls.__retrain_instance

    def __init__(self):
        if not self.__init:
            self.__quant_config = None
            self.__skip_retrain_fusion_layers = None
            self.__initialized = False
            self.__init = True

    @staticmethod
    @check_params(config_file=str,
                  graph=Graph,
                  config_defination=(type(None), str))
    def create_retrain_quant_config(config_file,
                                    graph,
                                    config_defination=None):
        """
        Function: Create quant config.
        Inputs:
            config_file: a string, the file(including path information) to
                save quant config.
            graph: IR Graph, the graph to be quantized.
            skip_cells: a list, cell names which would not apply quantize,
                the skip layer type should be in ['Conv2D', 'MatMul'].
            activation_offset: a bool indicating whether there's offset or not
                in quantize activation.
            config_defination: a string, the simple config file path,
                containing the simple quant config according to proto.
        Returns: None
        """
        is_valid_name(config_file, 'config_file')

        if config_defination is None:
            RetrainConfig.create_default_retrain_config(config_file, graph)
        # create config file for quantizetion
        else:
            RetrainConfig.create_retrain_config(
                config_file,
                graph,
                config_defination)

    @staticmethod
    @check_params(config_name=str, graph=Graph, config_defination=(str))
    def create_retrain_config(
            config_name,
            graph,
            config_defination):
        """
        Function: Create retrain config.
        Inputs:
            config_name: a string, the file(including path information) to
                save retrain config.
            graph: IR Graph, the graph to be retrainized.
            config_file: the file containing the simple retrain config
                according to proto.
        Returns: None
        """
        config_name = os.path.realpath(config_name)

        config_file = os.path.realpath(config_defination)
        LOGGER.logi("Create %s according to %s." % (config_name, config_file),
                    module_name='RetrainConfig')
        CONFIGURER.create_config_from_proto(
            config_name,
            graph,
            config_file)

        LOGGER.logi("Create quant config by simple retrain config success!",
                    module_name='RetrainConfig')

    @staticmethod
    @check_params(file_name=str, graph=Graph)
    def create_default_retrain_config(file_name, graph):
        """create deafult config"""

        CONFIGURER.create_default_config(
            file_name,
            graph)
        LOGGER.logi("Create retrain default config success!",
                    module_name='RetrainConfig')

    @staticmethod
    @check_params(file_name=str, graph=Graph)
    def parse_quant_config(file_name, graph):
        """parse quantize configuration from config json file"""
        GraphChecker.check_quant_behaviours(graph)
        quant_config = CONFIGURER.parse_config_file(file_name, graph)
        return quant_config

    @check_params(config_file=str, retrain_graph=Graph)
    def init(self, config_file, retrain_graph):
        """
        Function: init the Configuration.
        Inputs:
            config_file: a string, the file containing the quant config.
            retrain_graph: IR Graph
        Returns: None
        """
        self.__quant_config = self.parse_quant_config(
            os.path.realpath(config_file), retrain_graph)
        self.__skip_retrain_fusion_layers = \
            self.__quant_config.get('skip_fusion_layers')
        self.__initialized = True

    def uninit(self):
        '''uninit Retrain Configuration Class'''
        self.__quant_config = None
        self.__skip_retrain_fusion_layers = None
        self.__initialized = False

    def get_quant_config(self):
        """ get retrain config. """
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__quant_config

    def get_layer_config(self, layer_name):
        """ get one lsyer's quant config. """
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__quant_config.get(layer_name)

    def get_global_config(self, global_params_name):
        """ get global quant config. """
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__quant_config.get(global_params_name)
