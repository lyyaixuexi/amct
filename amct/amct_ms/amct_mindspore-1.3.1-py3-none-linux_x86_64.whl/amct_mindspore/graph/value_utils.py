#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

utils function for value proto of anf ir

"""

from mindspore.train.anf_ir_pb2 import DataType as dt


SINGLE_VALUE_MAP = {
    dt.DT_BOOL: 'bool_val',
    dt.DT_INT8: 'int_val',
    dt.DT_INT16: 'int_val',
    dt.DT_INT32: 'int_val',
    dt.DT_INT64: 'int_val',
    dt.DT_UINT8: 'uint_val',
    dt.DT_UINT16: 'uint_val',
    dt.DT_UINT32: 'uint_val',
    dt.DT_UINT64: 'uint_val',
    dt.DT_FLOAT16: 'float_val',
    dt.DT_FLOAT32: 'float_val',
    dt.DT_FLOAT64: 'double_val',
    dt.DT_STRING: 'str_val'
}


ITERABLE_VALUE_MAP = {
    dt.DT_BOOLS: 'bool_vals',
    dt.DT_INTS8: 'int_vals',
    dt.DT_INTS16: 'int_vals',
    dt.DT_INTS32: 'int_vals',
    dt.DT_INTS64: 'int_vals',
    dt.DT_UINTS8: 'uint_vals',
    dt.DT_UINTS16: 'uint_vals',
    dt.DT_UINTS32: 'uint_vals',
    dt.DT_UINTS64: 'uint_vals',
    dt.DT_FLOATS16: 'float_vals',
    dt.DT_FLOATS32: 'float_vals',
    dt.DT_FLOATS64: 'double_vals',
    dt.DT_STRINGS: 'str_vals'
}


def parse_value_proto(value_proto, values):
    """ parse the value proto of anf ir"""
    if value_proto.dtype in SINGLE_VALUE_MAP.keys():
        values.append(getattr(
            value_proto, SINGLE_VALUE_MAP.get(value_proto.dtype)))
    elif value_proto.dtype in ITERABLE_VALUE_MAP:
        for value in getattr(
                value_proto, ITERABLE_VALUE_MAP[value_proto.dtype]):
            values.append(value)
    elif value_proto.dtype in [dt.DT_LIST, dt.DT_TUPLE]:
        for sub_value_proto in value_proto.values:
            parse_value_proto(sub_value_proto, values)
    else:
        return
