#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Data structure of ANF graph

"""
from mindspore.train.anf_ir_pb2 import DataType as dt
from amct_mindspore.optimizer.utils import match_op
from amct_mindspore.graph.parameter import ParameterNode
from amct_mindspore.graph.constant import ConstantNode
from amct_mindspore.graph.node import Node
from amct_mindspore.graph.data_node import DataNode
from amct_mindspore.graph.value_utils import parse_value_proto
from amct_mindspore.common.graph_base.graph_base import GraphBase


class Graph(GraphBase):
    """" the build in graph to represent anf ir"""
    def __init__(self, network, param_dict=None):
        """Initialize the grah"""
        super().__init__(network)
        self._net = network
        self._param_dict = {} if param_dict is None else param_dict
        self._parameters = []
        self._constants = []
        self.data_node_names = []
        self._init_graph()

    @staticmethod
    def parse_type_proto(type_proto, data_types, shapes):
        """ parse the type proto in anf ir"""
        if type_proto.data_type == dt.DT_TENSOR:
            data_type = type_proto.tensor_type.elem_type
            dims = type_proto.tensor_type.shape.dim
            shape = [dim.size for dim in dims]
            data_types.append(data_type)
            shapes.append(shape)
        if type_proto.data_type == dt.DT_TUPLE:
            sub_type_protos = type_proto.sequence_type.elem_types
            for sub_type_proto in sub_type_protos:
                Graph.parse_type_proto(sub_type_proto, data_types, shapes)

    def update_node_names(self):
        """ update the name_prefix with the parameters,
            name_prefix linked with nodes
        """
        for node in self._nodes:
            if node.type == "Cast":
                continue
            if node.get_parameter_names():
                parameter_name = node.get_parameter_names()[0].name
                name_list = parameter_name.split('.')
                new_node_name = '.'.join(name_list[:-1])
                node.set_name_prefix(new_node_name)

    def remove_data_nodes_from_parameter(self):
        """"remove the data node from parameters list"""
        data_node_names = []
        for node in self._data_nodes:
            if len(node.name.split('.')) == 1:
                data_node_names.append(node.name)
        for node in self._nodes:
            for parameter in node.get_parameter_names():
                if parameter.name in data_node_names:
                    node.remove_parameter_name(parameter.name)

    def get_node_by_parameter_prefix(self, parameter_name):
        """get the node from graph by parameter_name"""
        for node in self._nodes:
            for parameter in node.get_parameter_names():
                if match_op(parameter_name, parameter.name):
                    return node
        raise ValueError('No cnode has parameter name {}'.format(
            parameter_name))

    def get_parameter_by_name(self, name):
        """get the paramter instance from graph by name"""
        for parameter in self._parameters:
            if parameter.name == name:
                return parameter
        return None

    def get_constant_by_name(self, name):
        """get the constant instance from graph by name"""
        for constant in self._constants:
            if constant.name == name:
                return constant
        return None

    def parse_parameter_proto(self):
        """ parse the parameter proto in anf ir"""
        for parameter in self._net.graph.parameters:
            data_types = []
            shapes = []
            Graph.parse_type_proto(parameter.type, data_types, shapes)
            self._parameters.append(
                ParameterNode(parameter.name, data_types, shapes))

    def parse_cnode_proto(self):
        """ parse the cnode proto in anf ir"""
        for index, node_proto in enumerate(self._net.graph.node):
            node_name = node_proto.name
            node_inputs = []
            node_constants = []
            node_parameters = []
            for input_ in node_proto.input:
                if self.get_parameter_by_name(input_.name):
                    node_parameters.append(input_)
                elif self.get_constant_by_name(input_.name):
                    node_constants.append(input_)
                else:
                    node_inputs.append(input_)
            node = Node(node_name, index, node_proto, node_inputs)
            for parameter in node_parameters:
                node.add_parameter_name(
                    self.get_parameter_by_name(parameter.name))
            for constant in node_constants:
                node.add_constant(
                    self.get_constant_by_name(constant.name))

            for attribute in node_proto.attribute:
                name = attribute.name
                values = []
                parse_value_proto(attribute.value, values)
                node.set_attr(name, values)
            self._nodes.append(node)

    def parse_constant_proto(self):
        """ parse the constant proto in anf ir"""
        for constant in self._net.graph.const_vals:
            name = constant.key
            value_proto = constant.value
            values = []
            parse_value_proto(value_proto, values)
            self._constants.append(
                ConstantNode(name, value_proto.dtype, values))

    def add_node(self, node_proto):
        """
        Function: Add node that constructed from node_proto to graph
        Parameter: None
        Return: Node that be added
        """
        node = Node(node_proto.name, len(self._nodes), node_proto, None)
        self._nodes.append(node)

    def remove_node(self, node_name):
        """
        Function: Remove data node from graph by name
        Parameter: None
        Return: None
        """
        for index, node in enumerate(self._nodes):
            if node.name == node_name:
                del self._nodes[index]
                return
        raise RuntimeError('Remove %s from graph failed, cannot found' %
                           (node_name))

    def handle_default_nodes(self, node_type):
        """relink the paramters from cast to original node"""
        to_handle_nodes = []
        for node in self._nodes:
            if node.type != node_type:
                continue
            node_pair = []
            node_pair.append(node)
            if not node.output_anchors:
                continue
            consumers, _ = node.get_consumers(0)
            for consumer in consumers:
                if consumer.type not in ['MakeTuple', 'UpdateState']:
                    node_pair.append(consumer)
            if len(node_pair) == 2:
                to_handle_nodes.append(node_pair)
        for node_pair in to_handle_nodes:
            first_node = node_pair[0]
            second_node = node_pair[1]
            for parmeter_name in first_node.get_parameter_names():
                second_node.add_parameter_name(parmeter_name)
            first_node.clear_parameter()


    def do_anf_fuse(self, fuse_op_pattern):
        """ Fuse some anf node the original cell representation"""
        to_fuse_nodes = []
        # match the node to be fuse
        for node in self._nodes:
            if node.type == fuse_op_pattern[0]:
                node_pair = []
                node_pair.append(node)
                # if the first node is last node of graph, skip fusion
                if not node.output_anchors:
                    continue
                peer_node = \
                    node.get_output_anchor(0).get_peer_input_anchor()[0].node
                if peer_node.type == fuse_op_pattern[1]:
                    node_pair.append(peer_node)
                if len(node_pair) == len(fuse_op_pattern):
                    to_fuse_nodes.append(node_pair)

        for node_pair in to_fuse_nodes:
            first_node = node_pair[0]
            second_node = node_pair[1]
            # when second node is leaf node, no third node to match
            if not second_node.output_anchors:
                self.remove_edge(first_node, 0, second_node, 0)
                self.remove_node(second_node.name)
                continue
            second_peer_input_anchors = second_node.get_output_anchor(0). \
                get_peer_input_anchor()
            second_peer_input_nodes = []
            second_peer_input_indexes = []

            # step1 remove the edges between second and second output nodes
            for input_anchor in second_peer_input_anchors:
                second_peer_input_nodes.append(input_anchor.node)
                second_peer_input_indexes.append(input_anchor.index)

            for index, element in enumerate(second_peer_input_nodes):
                self.remove_edge(second_node, 0, element,
                                 second_peer_input_indexes[index])

            # step2 remove the edges between first and second node
            for parmeters in second_node.get_parameter_names():
                first_node.add_parameter_name(parmeters)
            second_input_anchors = second_node.input_anchors
            for index, second_input_anchor in enumerate(second_input_anchors):
                second_peer_output_anchor = \
                    second_input_anchor.get_peer_output_anchor()
                second_input_node = second_peer_output_anchor.node
                second_peer_output_anchor_index = \
                    second_peer_output_anchor.index
                self.remove_edge(
                    second_input_node, second_peer_output_anchor_index,
                    second_node, index)

            # step3 add edge between first node and second node output nodes
            for index, element in enumerate(second_peer_input_nodes):
                self.add_edge(first_node, 0, element,
                              second_peer_input_indexes[index])
            self.remove_node(second_node.name)

    def _init_data_node(self):
        """Find the data node of input network"""
        for node in self._nodes:
            # the first input of head node is network input
            if node.get_parameter_names():
                if node.get_parameter_names()[0].name in list(
                        self._param_dict.keys()):
                    continue
                input_name = node.get_parameter_names()[0].name
                self._data_nodes.append(
                    DataNode(len(self._data_nodes), input_name))
                if len(input_name.split('.')) == 1:
                    self.data_node_names.append(input_name)
                node.set_input_anchor(self._data_nodes[-1], input_name)

    def _init_graph(self):
        """ Parse the anf ir nodes, parameters, constants
            and construct the graph
        """
        # 1. parse constant node
        self.parse_constant_proto()
        # 2. parse parameter node
        self.parse_parameter_proto()
        # 3. parse cnode
        self.parse_cnode_proto()
        # 4. link the cnode together
        self._init_data_node()
        for node in self._nodes:
            for _, input_anchor in enumerate(node.input_anchors):
                peer_output_node = self.get_node_by_name(input_anchor.name)
                # when peer output node has not been visited,
                # add output anchor to it
                if not peer_output_node.output_anchors:
                    peer_output_node.set_output_anchor(
                        peer_output_node, peer_output_node.name)
                src_node = peer_output_node
                output_index = len(peer_output_node.output_anchors) - 1
                dst_anchor = input_anchor
                dst_anchor.add_link(src_node.get_output_anchor(output_index))
                src_node.get_output_anchor(output_index).add_link(dst_anchor)
        # Move the Load node's parameters to compute node
        self.handle_default_nodes("Load")
        # Move the Cast node's parameters to compute node
        self.handle_default_nodes("Cast")
        self.do_anf_fuse(['FusedBatchNorm', 'tuple_getitem'])
        self.do_anf_fuse(['Conv2D', 'BiasAdd'])
        self.do_anf_fuse(['MatMul', 'BiasAdd'])
        self.do_anf_fuse(['DepthwiseConv2dNative', 'BiasAdd'])
        self.remove_data_nodes_from_parameter()
        self.update_node_names()
