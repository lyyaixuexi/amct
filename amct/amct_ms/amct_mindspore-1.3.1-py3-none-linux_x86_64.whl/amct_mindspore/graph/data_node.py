#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Data structure of data node which contains ANF input info

"""
from amct_mindspore.common.graph_base.data_node_base import DataNodeBase
from amct_mindspore.graph.anchor import OutputAnchor


class DataNode(DataNodeBase):
    """
    Function: Data structure of data node which contains model input info
    """
    def __repre__(self):
        return '< name : {} >'.format(self._data_name)

    def set_output_anchor(self, node, name):
        """
        Function: set output anchor
        Parameter:
            node: the node the set output anchor
            name: the  name of output anchor
        Return: Output anchor
        """
        index = len(self.output_anchors)
        self._output_anchors.append(OutputAnchor(node, index, name))
