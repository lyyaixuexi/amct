#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Data structure of ParameterNode node of ANF graph

"""


class ParameterNode():
    """
    Function: Data structure of parameter node which contains parameter info
    """
    def __init__(self, parameter_name, dtype, shape):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        self.__parameter_name = parameter_name
        self.__type = 'ParameterNode'
        self.__dtype = dtype
        self.__shape = shape
        self.__data = None

    def __repr__(self):
        return '< name: {} dtype : {} shape : {} >'.format(
            self.__parameter_name, str(self.dtypes), str(self.shapes))

    @property
    def data(self):
        """ the data of parameter"""
        return self.__data

    @property
    def dtypes(self):
        """ the dypes of parameter node"""
        if len(self.__dtype) == 1:
            return self.__dtype[0]
        return self.__dtype

    @property
    def shapes(self):
        """" the shape of parameter node"""
        if len(self.__shape) == 1:
            return self.__shape[0]
        return self.__shape

    @property
    def name(self):
        """
        Function: Get name of current node
        Parameter: None
        Return: Name of node
        """
        return self.__parameter_name

    @property
    def type(self):
        """
        Function: Get type of current node
        Parameter: None
        Return: type of node
        """
        return self.__type

    def set_data(self, data):
        """ set the data of parameter"""
        self.__data = data
