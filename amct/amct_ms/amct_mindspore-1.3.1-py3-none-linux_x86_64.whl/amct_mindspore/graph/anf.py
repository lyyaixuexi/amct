#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

ANF utils

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import time

from mindspore import Tensor
from mindspore.train.anf_ir_pb2 import ModelProto

from amct_mindspore.common.utils.files import create_empty_file


def input_data_to_tensor(*input_data):
    """ Convert the input data to Tensor of mindspore
    args:
        *input_data: the input data of numpy array
    """
    input_tensor = []
    for item in input_data:
        if isinstance(item, Tensor):
            input_tensor.append(item)
        else:
            input_tensor.append(Tensor(item))
    return tuple(input_tensor)


def get_anf_ir(network, *input_data):
    """ Get the anf ir of input network

    args:
        network: the network
        *input_data: the input data of network
    """
    network.phase = str(time.time())
    network.compile(*input_data_to_tensor(*input_data))
    graph_proto = network.get_func_graph_proto()
    anf_ir = ModelProto()
    anf_ir.ParseFromString(graph_proto)
    return anf_ir


def _write_anf_to_file(anf_ir, file_name):
    """"Serialize the input anf ir to string and save to file

    args:
        anf_ir: the input anf ir
        file_name: the name of file to save
    """
    create_empty_file(file_name)
    with open(file_name, 'wb') as fid:
        fid.write(anf_ir.SerializeToString())
