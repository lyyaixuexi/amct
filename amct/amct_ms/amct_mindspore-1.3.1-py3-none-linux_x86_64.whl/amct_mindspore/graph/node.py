#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Data structure of cnode in ANF graph

"""
from amct_mindspore.common.graph_base.node_base import NodeBase
from amct_mindspore.graph.anchor import InputAnchor
from amct_mindspore.graph.anchor import OutputAnchor


class Node(NodeBase):
    """
    Function: Data structure of node which contains node info
    """
    def __init__(self, node_name, node_index, node_proto, inputs):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        super().__init__(node_name, node_index, node_proto)
        self._basic_info['type'] = node_proto.op_type
        self._scope = None
        self._inputs = inputs

        # Init inputs, outputs info form node
        self._init_input_info()

        self._parameter_names = []
        self._parameters = []
        self._constants = []

    @property
    def name_prefix(self):
        """ get the name prefix of node"""
        if 'name_prefix' not in self._basic_info.keys():
            return None
        return self._basic_info.get('name_prefix')

    @property
    def scope(self):
        """ scope of node"""
        return self._scope

    @property
    def inputs(self):
        """ get the inputs of node"""
        return self._inputs

    def add_parameter_name(self, value):
        """" add a parameter name to the node."""
        self._parameter_names.append(value)

    def get_parameter_names(self):
        """ get all the parameter names of node."""
        return self._parameter_names

    def add_parameter(self, parameter):
        """" add a parameter to the node"""
        self._parameters.append(parameter)

    def get_parameters(self):
        """ get all the paramters from the node."""
        return self._parameters

    def has_weight(self):
        """" whether node has weight"""
        for param in self._parameters:
            if param.name.endswith('weight'):
                return True
        return False

    def has_bias(self):
        """" whether node has bias"""
        for param in self._parameters:
            if param.name.endswith('bias'):
                return True
        return False

    def get_weight(self):
        """ get the weight if node has weight"""
        if not self.has_weight():
            raise ValueError('node has not parameter name weight.')
        for param in self._parameters:
            if param.name.endswith('weight'):
                return param
        return None

    def get_bias(self):
        """ get the bias if node has bias"""
        if not self.has_bias():
            raise ValueError('node has not parameter name bias.')
        for param in self._parameters:
            if param.name.endswith('bias'):
                return param
        return None

    def remove_parameter_name(self, name):
        """ remove parameter name of node"""
        for index, parameter_name in enumerate(self._parameter_names):
            if parameter_name.name == name:
                del self._parameter_names[index]

    def clear_parameter(self):
        """ clear all parameters of node"""
        self._parameter_names = []
        self._parameters = []

    def add_constant(self, value):
        """" add a constant to the node."""
        self._constants.append(value)

    def get_constants(self):
        """ get all the constants of node."""
        return self._constants

    def find_parameter(self, name):
        """ whether the node has parameter match the name"""
        for parameter in self._parameter_names:
            if parameter.name == name:
                return True
        return False

    def set_name_prefix(self, name):
        """ set the name prefix of node"""
        self._basic_info['name_prefix'] = name

    def set_scope(self, scope):
        """ set the scope of node"""
        self._scope = scope

    def set_input_anchor(self, node, name):
        """" set the input anchor of node"""
        index = len(self.output_anchors)
        self._input_anchors.append(InputAnchor(node, index, name))

    def set_output_anchor(self, node, name):
        """" set the output anchor of node"""
        index = len(self.output_anchors)
        self._output_anchors.append(OutputAnchor(node, index, name))

    def _init_input_info(self):
        """
        Function: Parse input info from node, and construct input anchor
                  to node
        Parameter: None
        Return: None
        """
        for index in range(len(self._inputs)):
            self._input_anchors.append(InputAnchor(self, index, \
                self._inputs[index].name))
