#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Data structure of ConstantNode of ANF graph

"""


class ConstantNode:
    """ the constant node of anf ir"""
    def __init__(self, name, dtype, values):
        self.__type = 'ConstantNode'
        self.__name = name
        self.__dtype = dtype
        self.__values = values

    def __repr__(self):
        return '< name: {} dtype: {} shape: {} >'.format(
            self.__name, self.dtype, self.__values)

    @property
    def name(self):
        """ name of constant node"""
        return self.__name

    @property
    def dtype(self):
        """ dtype of constant node"""
        return self.__dtype

    @property
    def values(self):
        """ values of constant node"""
        return self.__values

    @property
    def type(self):
        """" type of constant node"""
        return self.__type
