#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Parse to parse ANF graph and checkpoint

"""
from amct_mindspore.graph.graph import Graph


class Parser:
    '''Parse MindSpore cell network to intermediate AMCT graph.'''
    @staticmethod
    def parse_net_to_graph(anf_ir, network):
        """"parse the ANF graph to inner graph,
            and set the parameters to correlative nodes
        """
        param_dict = network.parameters_dict()
        graph = Graph(anf_ir, param_dict)
        for node in graph.nodes:
            parameter_names = node.get_parameter_names()
            for parameter_proto in parameter_names:
                if parameter_proto.name in graph.data_node_names \
                        or parameter_proto.name not in param_dict.keys():
                    continue
                node.add_parameter(param_dict[parameter_proto.name])
        return graph
