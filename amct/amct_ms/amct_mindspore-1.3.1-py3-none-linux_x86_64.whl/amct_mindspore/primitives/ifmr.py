#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Ifmr Primitive

"""
from mindspore.ops.primitive import PrimitiveWithInfer
from mindspore.ops.primitive import prim_attr_register


class Ifmr(PrimitiveWithInfer):
    """ Primitive of Ifmr"""
    @prim_attr_register
    def __init__(self,
                 min_percentile=0.999999,
                 max_percentile=0.999999,
                 search_range=(0.7, 1.3),
                 search_step=0.01,
                 offset_flag=True):
        """init AlgIfmr OP"""
        self.min_percentile = min_percentile
        self.max_percentile = max_percentile
        self.search_range = list(search_range)
        self.search_step = search_step
        self.offset_flag = offset_flag
        self.init_prim_io_names(
            inputs=['input_value', 'input_min', 'input_max', 'bins'],
            outputs=['scale', 'offset'])

    def infer_shape(
            self,
            x_shape,
            y_shape,
            z_shape,
            w_shape):
        """ infer shape of primitive"""
        return (1, ), (1, )

    def infer_dtype(
            self,
            x_type,
            y_type,
            z_type,
            w_type):
        """ infer dtype of primitive"""
        return x_type, x_type
