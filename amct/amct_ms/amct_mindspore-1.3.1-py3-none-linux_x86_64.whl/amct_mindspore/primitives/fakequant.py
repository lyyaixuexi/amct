#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Fakequant Primitive

"""

from mindspore.ops.primitive import PrimitiveWithInfer
from mindspore.ops.primitive import prim_attr_register


class Fakequant(PrimitiveWithInfer):
    """ Primitive of Fakequant"""
    @prim_attr_register
    def __init__(self,
                 scale,
                 offset,
                 num_bits):
        """init AlgIfmr OP"""
        self.scale = scale
        self.offset = offset
        self.num_bits = num_bits
        self.init_prim_io_names(inputs=['x'], outputs=['x'])

    def infer_shape(self, x_shape):
        """ infer shape of primitive"""
        return x_shape

    def infer_dtype(self, x_type):
        """ infer dtype of primitive"""
        return x_type
