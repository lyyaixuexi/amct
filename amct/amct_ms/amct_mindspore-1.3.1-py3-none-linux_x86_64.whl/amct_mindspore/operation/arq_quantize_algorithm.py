#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

ARQ quantize algorithm
"""
import ctypes

from amct_mindspore.lib.load_library import Load
from amct_mindspore.operation.base_quantize_algorithm \
    import BaseQuantizeAlgorithm
from amct_mindspore.operation.base_quantize_algorithm import WEIGHTS_QUANT_ALGO
from amct_mindspore.operation.base_quantize_algorithm import FloatData
from amct_mindspore.operation.base_quantize_algorithm import IntData


class ArqParam(ctypes.Structure):
    """
    Function: Data structure for c++ 'ArqParam'
    """
    _fields_ = [("numBits", ctypes.c_uint), ("channelWise", ctypes.c_bool),
                ("withOffset", ctypes.c_bool)]


class ArqQuantizeAlgorithm(BaseQuantizeAlgorithm):
    """Function: The implement of ARQ quantize algorithm
       APIs: preprocess_params, quantize_data
    """
    @staticmethod
    def preprocess_params(data, shape, args):
        """Extract and check input parameters, then convert them to cTypes's
           data type.
        """
        data_p = ctypes.cast(data.ctypes.data, ctypes.POINTER(ctypes.c_float))
        data_length = ArqQuantizeAlgorithm.get_data_length(shape)

        arq_params = dict()
        arq_params['channel_wise'] = ArqQuantizeAlgorithm.extract_quant_param(
            args, 'channel_wise', bool)
        arq_params['with_offset'] = ArqQuantizeAlgorithm.extract_quant_param(
            args, 'with_offset', bool)
        arq_params['num_bits'] = ArqQuantizeAlgorithm.extract_quant_param(
            args, 'num_bits', int)

        return data_p, data_length, arq_params

    @staticmethod
    def quantize_data(data, shape, args):
        """Do arq quantize.
           Parameters: data(array): data to be quantized
                       shape(list/tuple): shape of data, should be 2 dims(fc)
                                          or 4dims(conv, deconv, lstm...)
                       args: quantize algorithm parameters, such as 'num_bits',
                             'channel_wise', 'with_offset'
           Return: scale, offset: quantize factor
        """
        data_p, data_length, arq_params = \
            ArqQuantizeAlgorithm.preprocess_params(data, shape, args)

        if arq_params.get('channel_wise'):
            scale_size = shape[0]
        else:
            scale_size = 1

        scale_offset_size = [(ctypes.c_float * scale_size)(),
                             (ctypes.c_int * scale_size)()]
        scale_offset_data = \
            [FloatData(scale_size, scale_offset_size[0]),
             IntData(scale_size, scale_offset_size[1])]

        ret = Load().lib.ArqQuantFloatPython(
            data_p, data_length,
            ArqParam(arq_params.get('num_bits'),
                     arq_params.get('channel_wise'),
                     arq_params.get('with_offset')), scale_offset_data[0],
            scale_offset_data[1])

        if ret != 0:
            raise RuntimeError(
                "Do quantize data failed, error code: {}".format(ret))

        scale = [scale_offset_size[0][i] for i in range(scale_size)]
        offset = [scale_offset_size[1][i] for i in range(scale_size)]

        return scale, offset


WEIGHTS_QUANT_ALGO['arq_quantize'] = ArqQuantizeAlgorithm
