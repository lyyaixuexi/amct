#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

func fuse CONV and BN.

"""
import numpy as np

EPSILON_DEFAULT_VALUE = 0.00001


def _check_params(conv_params, bn_params, channel_axis=0):
    """check the input conv bn params

    Arguments:
        conv_params {list} -- list of conv_weights and conv_bias
        bn_params {list} -- list of bn_mean, bn_variance, bn_scale_factor
                            and bn_epsilon
        channel_axis -- the axis of conv channel

    Raises:
        RuntimeError: the dtype not support
    """
    conv_weight = conv_params[0]
    conv_bias = conv_params[1]
    bn_mean = bn_params[0]
    bn_variance = bn_params[1]
    supported_dtype = [np.float16, np.float32, np.float64]

    def check_dtype(arr):
        """Check whether input data dtype support or not
        """
        if arr.dtype not in supported_dtype:
            raise RuntimeError("Only support dtype np.float32 and np.float64")
    if conv_bias is not None:
        check_dtype(conv_bias)
    check_dtype(conv_weight)
    check_dtype(bn_mean)
    check_dtype(bn_variance)

    if len(conv_weight.shape) != 4:
        raise RuntimeError('Conv weight is not 4 dimension!')
    channels = conv_weight.shape[channel_axis]
    if bn_mean.shape[0] != channels:
        raise RuntimeError(
            'Bn mean shape {} not equal to channels {}'.format(
                bn_mean.shape[0], channels))
    if bn_variance.shape[0] != channels:
        raise RuntimeError(
            'Bn variance shape {} not equal to channels {}'.format(
                bn_variance.shape[0], channels))



def fuse_conv_bn(conv_params, bn_params, conv_type):
    """check the input conv bn params

    Arguments:
        conv_params {list} -- list of conv_weights, conv_bias
        bn_params {list} -- list bn_mean, bn_variance,
                            bn_scale_factor, bn_epsilon

    return:
        the fused conv weights and bias
    """
    if conv_type == 'DepthwiseConv2dNative':
        channel_axis = 1
    else:
        channel_axis = 0
    _check_params(conv_params, bn_params, channel_axis)
    conv_weight = conv_params[0]
    conv_bias = conv_params[1]
    bn_mean = bn_params[0]
    bn_variance = bn_params[1]
    bn_gamma = bn_params[2]
    bn_beta = bn_params[3]
    bn_epsilon = EPSILON_DEFAULT_VALUE

    fused_weight = fuse_weight(
        conv_weight, bn_gamma, bn_variance, bn_epsilon, conv_type)
    fused_bias = fuse_bias(
        conv_bias, bn_gamma, bn_beta, bn_mean, bn_variance, bn_epsilon)
    return fused_weight, fused_bias


def fuse_weight(conv_weight, bn_gamma, bn_variance, bn_epsilon, conv_type):
    '''Inputs:
        conv_weight: a np.array, the weight to be fused.
        bn_variance: a np.array, the variance of BN layer.
        bn_epsilon: a small value, the epsilon of BN layer.
    Returns:
        fused_weight: a np.array, the fused weight.
    '''
    variance = np.add(bn_variance, bn_epsilon)
    variance = reshape_bn_params(conv_type, variance)
    bn_gamma = reshape_scale_params(conv_type, bn_gamma)

    stdev = np.sqrt(variance)
    fused_weight = np.divide(conv_weight, stdev)
    fused_weight = np.multiply(fused_weight, bn_gamma)
    return fused_weight


def fuse_bias(conv_bias,
              bn_gamma,
              bn_beta,
              bn_mean,
              bn_variance,
              bn_epsilon):
    """ Fuse bias with BN layer's parameters.

    Inputs:
        conv_bias: a np.array, the bias to be fused.
        bn_mean: a np.array, the mean of BN layer.
        bn_variance: a np.array, the variance of BN layer.
    Returns:
        fused_bias: a np.array, the fused bias.
    """
    if conv_bias is None:
        tmp_bias = np.multiply(bn_mean, -1)
    else:
        tmp_bias = conv_bias - bn_mean
    variance = np.add(bn_variance, bn_epsilon)
    stdev = np.sqrt(variance)
    fused_bias = np.divide(tmp_bias, stdev)

    fused_bias = np.multiply(bn_gamma, fused_bias)
    fused_bias = np.add(fused_bias, bn_beta)
    return fused_bias


def reshape_bn_params(compute_type, bn_params):
    '''Reshape parameters of BN layer before fusing.
    The bn_params is with size matching the 'Channel' dimension.
    '''
    if compute_type == "Conv2D":
        # Channel of output is dim[0], expand shape to 4 dims based on dim[0]
        shape = [-1, 1, 1, 1]
    elif compute_type == 'DepthwiseConv2dNative':
        # Channel of output is dim[1], expand shape to 4 dims based on dim[1]
        shape = [1, -1, 1, 1]
    else:
        raise TypeError('{} is not supported yet.'.format(compute_type))

    return bn_params.reshape(shape)


def reshape_scale_params(compute_type, scale_params):
    '''Reshape parameters of Scale layer before fusing.
    The scale_params is with size matching the 'Channel' dimension.
    '''
    if compute_type == "Conv2D":
        shape = [-1, 1, 1, 1]
    elif compute_type == 'DepthwiseConv2dNative':
        # Channel of output is dim[1], expand shape to 4 dims based on dim[1]
        shape = [1, -1, 1, 1]
    else:
        raise TypeError('{} is not supported yet.'.format(compute_type))

    return scale_params.reshape(shape)
