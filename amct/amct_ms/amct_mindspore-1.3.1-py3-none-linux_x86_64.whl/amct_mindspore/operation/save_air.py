#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

save air

"""
import numpy as np

import mindspore.nn as nn
from mindspore import Tensor
from mindspore.ops.operations import _inner_ops
from mindspore.common import dtype as mstype
from mindspore.ops import operations as P

from amct_mindspore.common.utils.util import is_invalid
from amct_mindspore.cells.deploy_cell import DeployBlock
from amct_mindspore.operation.convert_weight import convert_fakequant_to_int8
from amct_mindspore.cells.cell_helper import get_scale_offset_from_ifmr
from amct_mindspore.cells import QuantIfmr
from amct_mindspore.cells.cell_helper import get_name_prefix
from amct_mindspore.optimizer.utils import rename_parameters
from amct_mindspore.common.utils.record_file_operator \
    import record_activation_scale_offset
from amct_mindspore.common.utils.record_file_operator \
    import record_weights_scale_offset
from amct_mindspore.utils.save_record import SaveRecord
from amct_mindspore.utils.log import LOGGER



def convert_deploy(network):
    """
    convet sub cell to quant cell
    """
    for cell_name, subcell in network.cells_and_names():
        if subcell == network:
            continue
        if isinstance(subcell, QuantIfmr):
            new_subcell = convert_ifmr_to_deploy_block(subcell)
            prefix = subcell.param_prefix
            new_subcell.update_parameters_name('{}{}'.format(prefix, '.'))
            network.insert_child_to_cell(cell_name, new_subcell)
        elif isinstance(subcell, (nn.Conv2d, nn.Dense)):
            prefix = subcell.param_prefix
            subcell.update_parameters_name('{}{}'.format(prefix, '.'))
        else:
            convert_deploy(subcell)
    if isinstance(network, nn.SequentialCell):
        network.cell_list = list(network.cells())


def convert_retrain_deploy(network):
    """
    convert sub cell to quant cell
    """
    cells = network.name_cells()
    for name in cells:
        subcell = cells[name]
        if subcell == network:
            continue
        if isinstance(subcell, nn.Conv2d) and \
                hasattr(subcell, 'need_convert'):
            new_subcell = convert_ulq_to_deploy_block(subcell)
            name_prefix = get_name_prefix(subcell)
            rename_parameters(new_subcell, name_prefix)
            network.insert_child_to_cell(name, new_subcell)
        elif isinstance(subcell, nn.Dense) and \
                hasattr(subcell, 'need_convert'):
            new_subcell = convert_ulq_to_deploy_block(subcell)
            name_prefix = get_name_prefix(subcell)
            rename_parameters(new_subcell, name_prefix)
            network.insert_child_to_cell(name, new_subcell)
        else:
            convert_retrain_deploy(subcell)
    if isinstance(network, nn.SequentialCell):
        network.cell_list = list(network.cells())


def _fuse_quant_param(deq_scale, offset_w, shift_bits):
    """Fuse dequant scale, offset_w and shift_bits to uint64 data"""
    float32_deq_scale = np.array(deq_scale, np.float32)
    uint32_deq_scale = np.frombuffer(float32_deq_scale, np.uint32)

    int8_offset_w = np.array(offset_w, np.int8)
    uint8_offset_w = np.frombuffer(int8_offset_w, np.uint8)

    int8_shift_n = np.array(shift_bits, np.int8)
    uint8_shift_n = np.frombuffer(int8_shift_n, np.uint8)

    # fuse parameter
    # |-----------------|47:40|--------|39:32|--------|31:0|
    #                  offset_w [8]    shift_N [8]    deq_scale [32]
    quant_param = np.zeros(deq_scale.size, dtype=np.uint64)
    for index in range(deq_scale.size):
        quant_param[index] = uint8_offset_w[index]
        quant_param[index] = (quant_param[index] << np.uint32(8))\
                                + uint8_shift_n[index]
        quant_param[index] = (quant_param[index] << np.uint32(32))\
                                + uint32_deq_scale[index]
    return quant_param


def _get_fused_quant_param(scale_d, scale_w, offset_w):
    deq_scale = scale_d * scale_w
    shift_bits = [0] * deq_scale.size
    quant_param = _fuse_quant_param(deq_scale, offset_w, shift_bits)
    return quant_param


def _check_scale(scale, name, layer_name):
    if not isinstance(scale, np.ndarray):
        scale = np.array(scale, np.float64)

    if is_invalid(scale):
        raise ValueError('Invalid value(nan or inf) in {} in layer {}'.format(
            name, layer_name))

    if (scale <= 0).any():
        raise ValueError(
            '{} in layer {} should be greater than zero, but is {}'.format(
                name, layer_name, scale))


def _check_offset(offset, name, layer_name):
    if not isinstance(offset, np.ndarray):
        offset = np.array(offset, np.int64)

    if (offset < -128).any() or (offset > 127).any():
        raise ValueError(
            "{} in layer {} should be in [-128, 127], but is {}".format(
                name, layer_name, offset))


def _fuse_bias_tensor(cell, weight_w, offset_d, bias, layer_name):
    if isinstance(cell, nn.Dense):
        weight_w = weight_w.asnumpy().astype(np.int32)
        bias = bias - (weight_w * offset_d).sum(axis=0)

    left_bound = -2**31
    right_bound = 2**31-1
    for item in bias:
        int_bias = round(item)
        if int_bias <= left_bound or int_bias >= right_bound:
            LOGGER.loge('Quantized bias {} of layer "{}" exceed int32 ' \
                'range:[{}, {}], please add it to skip layer.'.format(
                    int_bias, layer_name, left_bound, right_bound))
            raise RuntimeError('Do bias quantize failed.')

    return Tensor(bias, mstype.int32)


def convert_ifmr_to_deploy_block(subcell):
    '''transform ifmr subcell to deploy subcell'''

    scale_d, offset_d = get_scale_offset_from_ifmr(subcell)
    layer_name = scale_d.name[:-6]
    scale_d = float(scale_d.data.asnumpy()[0])
    offset_d = int(offset_d.data.asnumpy()[0])
    _check_scale(scale_d, 'scale_d', layer_name)
    _check_offset(offset_d, 'offset_d', layer_name)

    compute_cell = subcell.name_cells()['compute_cell']
    scale_w = np.array(getattr(compute_cell, 'scale_w'))
    offset_w = np.array(getattr(compute_cell, 'offset_w'))
    _check_scale(scale_w, 'scale_w', layer_name)
    _check_offset(offset_w, 'offset_w', layer_name)

    deploy_cell = convert_to_deploy_block(
        compute_cell, layer_name, scale_d, offset_d, scale_w, offset_w)

    return deploy_cell


def convert_ulq_to_deploy_block(subcell):
    """ transform ulq subcell to deploy subcell """

    compute_cell = subcell
    scale_d = float(getattr(compute_cell, 'scale_d'))
    offset_d = int(getattr(compute_cell, 'offset_d'))
    layer_name = compute_cell.weight.name[:-7]

    _check_scale(scale_d, 'scale_d', layer_name)
    _check_offset(offset_d, 'offset_d', layer_name)

    scale_w = np.array(getattr(compute_cell, 'scale_w'))
    offset_w = np.array(getattr(compute_cell, 'offset_w'))
    _check_scale(scale_w, 'scale_w', layer_name)
    _check_offset(offset_w, 'offset_w', layer_name)

    deploy_cell = convert_to_deploy_block(
        compute_cell, layer_name, scale_d, offset_d, scale_w, offset_w)

    return deploy_cell


def convert_to_deploy_block(
        compute_cell,
        layer_name,
        scale_d,
        offset_d,
        scale_w,
        offset_w):
    '''transform quantable subcell to deploy subcell'''
    def has_bias(subcell):
        for key in subcell.parameters_dict().keys():
            if key.endswith('bias'):
                return True
        return False

    if SaveRecord().do_record:
        record_activation_scale_offset(SaveRecord().records, layer_name,
                                       scale_d, offset_d)
        record_weights_scale_offset(SaveRecord().records, layer_name, scale_w,
                                    offset_w)

    if is_invalid(compute_cell.weight.data.asnumpy()):
        raise ValueError(
            'Invalid value(nan or inf) in weight in layer {}'.format(
                layer_name))
    weight_tensor = Tensor(
        convert_fakequant_to_int8(compute_cell, scale_w, offset_w),
        mstype.int8)

    bias_tensor = None
    if has_bias(compute_cell):
        if is_invalid(compute_cell.bias.data.asnumpy()):
            raise ValueError(
                'Invalid value(nan or inf) in bias in layer {}'.format(
                    layer_name))
        bias_tensor = compute_cell.bias.data.asnumpy() / (scale_d * scale_w)
        bias_tensor = _fuse_bias_tensor(compute_cell, weight_tensor, offset_d,
                                        bias_tensor, layer_name)

    quant_param = Tensor(_get_fused_quant_param(scale_d, scale_w, offset_w),
                         mstype.uint64)

    if isinstance(compute_cell, nn.Dense):
        op_core = P.MatMul()
    elif isinstance(compute_cell, nn.Conv2d):
        op_core = compute_cell.conv2d
    else:
        raise RuntimeError('Not supported compute cell type')

    quant_op = _inner_ops.Quant(float(1 / scale_d), float(offset_d))
    dequant_op = _inner_ops.Dequant()

    return DeployBlock(op_core, weight_tensor, quant_op, dequant_op,
                       quant_param, compute_cell, bias_tensor)
