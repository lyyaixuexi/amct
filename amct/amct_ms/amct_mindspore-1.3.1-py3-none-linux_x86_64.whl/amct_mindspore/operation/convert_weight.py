#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

convert weights data

"""

import numpy as np

from mindspore import nn


def convert_fakequant_to_int8(compute_cell, scale_w, offset_w):
    '''Convert fack-quant weight to int weight'''
    weight = compute_cell.weight.data.asnumpy()

    if len(scale_w) == 1 and len(offset_w) == 1:
        weight = np.round(weight / scale_w) + offset_w
    else:
        for index, _ in enumerate(scale_w):
            scale_w_cur_channel = scale_w[index]
            offset_w_cur_channel = offset_w[index]
            weight[index] = np.round(weight[
                index] / scale_w_cur_channel) + offset_w_cur_channel

    weight_int8 = weight.astype(np.int8)

    if isinstance(compute_cell, nn.Dense):
        weight_int8 = np.transpose(weight_int8)

    return weight_int8
