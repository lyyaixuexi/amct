#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

QAT(quantization-aware training) cell

"""
import mindspore
from mindspore import nn
from mindspore import Tensor
from mindspore.common.parameter import Parameter
from mindspore.ops.operations import _quant_ops as Q
from mindspore import context


class ActUlq(nn.Cell):
    """" ActUlq layer

    args:
        fixed_min: whether fixed the learnable parameter clip_min
        clip_min: the learnable parameter clip_min
        clip_max: the learnable parameter clip_max
    Inputs:
        Tensor input_x: the input tensor

    Output:
        Tensor of fake quantized tensor
    """
    def __init__(self,
                 clip_min,
                 clip_max,
                 fixed_min=False,
                 num_bits=8,
                 is_conv=True):
        super().__init__()
        if context.get_context("device_target") == "Ascend":
            self.activation_ulq = Q.ActsULQ(
                fixed_min=fixed_min,
                num_bits=num_bits)

        if is_conv:
            clip_min = [[[[clip_min]]]]
            clip_max = [[[[clip_max]]]]
        else:
            clip_min = [[clip_min]]
            clip_max = [[clip_max]]
        self.clip_min = Parameter(Tensor(clip_min, mindspore.float32),
                                  name='clip_min')
        self.clip_max = Parameter(Tensor(clip_max, mindspore.float32),
                                  name='clip_max')

    def construct(self, input_x):
        '''Definition of subgraph.'''
        return self.activation_ulq(input_x, self.clip_min, self.clip_max)

    def extend_repr(self):
        """A pretty print for ActUlq layer."""
        str_desc = 'clip_min={}, clip_max={}'.format(self.clip_min,
                                                     self.clip_max)
        return str_desc
