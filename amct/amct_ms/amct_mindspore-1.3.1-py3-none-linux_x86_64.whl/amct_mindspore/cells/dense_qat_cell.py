#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Dense quant aware training block

"""
import mindspore.nn as nn
from mindspore.common.parameter import Parameter
from mindspore import Tensor


class DenseQatBlock(nn.Cell):
    """ Quant aware training block cell for dense"""
    def __init__(self,
                 act_qat_cell,
                 weight_qat_cell,
                 subcell):
        super().__init__()
        self.act_qat_cell = act_qat_cell
        self.weight_qat_cell = weight_qat_cell
        self.subcell = []
        self.subcell.append(subcell)
        self.matmul = subcell.matmul
        self.weight = Parameter(
            Tensor(subcell.weight.data.asnumpy()), name='weight')
        self.bias = None
        if subcell.has_bias:
            self.bias = Parameter(
                Tensor(subcell.bias.data.asnumpy()), name='bias')
            self.bias_add = subcell.bias_add
        self.has_bias = self.bias is not None
        self.activation = subcell.activation
        self.activation_flag = subcell.activation_flag

    def construct(self, input_x):
        """Use operators to construct the DenseQatBlock layer."""
        input_x, _, _, _ = self.act_qat_cell(input_x)
        weight = self.weight_qat_cell(self.weight)
        output = self.matmul(input_x, weight)
        if self.has_bias:
            output = self.bias_add(output, self.bias)
        if self.activation_flag:
            return self.activation(output)
        return output

    def extend_repr(self):
        """A pretty print for DenseQatBlock layer."""
        subcell = self.subcell[0]
        str_desc = 'in_channels={}, out_channels={}, '\
                   'has_bias={}, activation_flag={}'.format(
                       subcell.in_channels, subcell.out_channels,
                       subcell.has_bias, subcell.activation_flag)
        return str_desc
