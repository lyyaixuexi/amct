#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

helper func for cell operation

"""
import mindspore.nn as nn
from amct_mindspore.cells import QuantIfmr

__all__ = [
    'get_scale_offset_from_ifmr',
    'get_name_prefix',
    'is_depthwise_conv2d',
    'collect_scale_offset',
    'check_restore_ckpt']


def get_scale_offset_from_ifmr(ifmr_cell):
    """" get the scale offset from ifmr cell"""
    if not isinstance(ifmr_cell, QuantIfmr):
        raise TypeError('input cell type is not QuantIfmr')
    parameter_dict = ifmr_cell.parameters_dict()
    scale_d = None
    offset_d = None
    for key in parameter_dict.keys():
        if key.endswith('scale'):
            scale_d = parameter_dict[key]
        if key.endswith('offset'):
            offset_d = parameter_dict[key]
    return scale_d, offset_d


def get_name_prefix(cell):
    """ get the name prefix of cell"""
    param = list(cell.parameters_dict().keys())[0]
    name_list = param.split('.')[:-1]
    name_prefix = '.'.join(name_list)
    return name_prefix


def is_depthwise_conv2d(cell):
    """ figure out whether nn.Conv2d is depthwise"""
    if not isinstance(cell, nn.Conv2d):
        return False
    if cell.group == 1:
        return False
    if cell.in_channels == cell.out_channels and \
            cell.in_channels == cell.group:
        return True
    return False


def collect_scale_offset(network, scale_offset):
    """
    collect the scale_d and offset_d from calibration network
    """
    cells = network.name_cells()
    for name in cells:
        subcell = cells[name]
        if subcell == network:
            continue
        if isinstance(subcell, QuantIfmr):
            scale_d, offset_d = get_scale_offset_from_ifmr(subcell)
            layer_name = scale_d.name[:-6]
            scale_d = float(scale_d.data.asnumpy()[0])
            offset_d = int(offset_d.data.asnumpy()[0])
            scale_offset[layer_name] = [scale_d, offset_d]
        else:
            collect_scale_offset(subcell, scale_offset)
    if isinstance(network, nn.SequentialCell):
        network.cell_list = list(network.cells())


def check_restore_ckpt(param_dict):
    """ check whether the param_dict contains clip_min and clip_max"""
    for key in param_dict.keys():
        if key.endswith('clip_min') or key.endswith('clip_max'):
            return True

    return False
