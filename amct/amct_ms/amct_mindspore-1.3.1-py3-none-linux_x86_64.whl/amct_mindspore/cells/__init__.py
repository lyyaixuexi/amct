#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

init cell

"""

from .identity import Identity
from .quant_ifmr import QuantIfmr
from .fakequant import Fakequant
from .deploy_cell import DeployBlock
from .conv2d_qat_cell import Conv2dQatBlock
from .dense_qat_cell import DenseQatBlock
from .activation_ulq import ActUlq
from .weight_arq import WeightArq
from . import cell_helper

__all__ = [
    'Identity',
    'QuantIfmr',
    'Fakequant',
    'DeployBlock',
    'Conv2dQatBlock',
    'DenseQatBlock',
    'ActUlq',
    'WeightArq']

__all__.extend(cell_helper.__all__)
