#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Histogram

"""
from mindspore.nn.cell import Cell

from amct_mindspore import primitives


class Histogram(Cell):
    """" Histogram layer, seperate all the input data to fixed number of bins;

    args:
        num_bins: the number of bins
    Inputs:
        Tensor input_x: the input data tensor
        Tensor input_y: the range of output bins

    Output:
        Tensor shape of (bins,)
    """
    def __init__(self, num_bins):
        super().__init__()
        self.num_bins = num_bins
        self.hist = primitives.Histogram(self.num_bins)

    def construct(self, input_x, input_y):
        '''Definition of subgraph.'''
        return self.hist(input_x, input_y)
