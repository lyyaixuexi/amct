#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

DeployBlock

"""
import numpy as np
from mindspore import nn
from mindspore.common.parameter import Parameter
from mindspore.ops import operations as P


class DeployBlock(nn.Cell):
    r"""
    The deploy block of quantized model

    use the scale and offset quant input float or float16 data to int8 data,
    then use the op core compute wiht input int8 data, output with int32
    dequant layer dequant int32 data to float data

    args:
        op_core: The cube layer
        weight: The quantized int8 weight
        quant_op: The quant layer
        dequant_op: The dequant layer
        quant_param: The uint64 deq_scale
        dtype: The dtype of op_core compute output
        bias: The quantized int32 bias of op_core
    Inputs:
        Tensor of shape :math:`(N, C_{in}, H_{in}, W_{in})`
    Outputs:
        Tensor of shape :math:`(N, C_{out}, H_{out}, W_{out})`.
    """
    def __init__(self,
                 op_core,
                 weight,
                 quant_op,
                 dequant_op,
                 quant_param,
                 compute_cell,
                 bias=None):
        super().__init__()
        self.op_core = op_core
        self.weight = Parameter(weight, name='weight')
        self.weight_offset = Parameter(
            np.zeros(shape=(1, 1, 1, 1), dtype=np.int8), name='weight_offset')
        self.quant = quant_op
        self.dequant = dequant_op
        self.quant_param = quant_param
        self.cast = P.Cast()
        self.sub = P.Sub()
        self.is_matmul = isinstance(compute_cell, nn.Dense)
        if bias is not None:
            self.bias = Parameter(bias, name='bias')
        else:
            self.bias = None
        self.has_bias = bias is not None
        if self.has_bias:
            self.bias_add = compute_cell.bias_add
        self.dtype = P.DType()
        if isinstance(compute_cell, nn.Dense):
            self.activation = compute_cell.activation
            self.activation_flag = compute_cell.activation_flag
        else:
            self.activation = None
            self.activation_flag = False

    def construct(self, input_x):
        '''Definition of subgraph.'''
        input_dtype = self.dtype(input_x)
        input_x = self.quant(input_x)
        if not self.is_matmul:
            # is conv2d
            if self.has_bias:
                # weight - weight_offset(all zero) to match FE pattern
                weight = self.sub(self.weight, self.weight_offset)
                input_x = self.op_core(input_x, weight)
                input_x = self.bias_add(input_x, self.bias)
            else:
                input_x = self.op_core(input_x, self.weight)
        else:
            # is matmul
            input_x = self.op_core(input_x, self.weight)
            if self.has_bias:
                input_x = self.bias_add(input_x, self.bias)
        input_x = self.dequant(input_x, self.quant_param)
        # cast dequant output tensor to input tensor DataType;
        input_x = self.cast(input_x, input_dtype)
        if self.activation_flag:
            input_x = self.activation(input_x)
        return input_x

    def extend_repr(self):
        '''reprentation of subgraph'''
        desc = 'quant={}, op_core={}, dequant={}, weight={}, bias={}'.format(
            self.quant, self.op_core, self.dequant, self.weight, self.bias)
        return desc
