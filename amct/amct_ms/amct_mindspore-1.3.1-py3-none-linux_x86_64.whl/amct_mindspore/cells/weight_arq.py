#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Histogram

"""
from mindspore.nn.cell import Cell
from mindspore.ops import operations as P
from mindspore.ops.operations import _quant_ops as Q
from mindspore import context
import mindspore.nn as nn


class WeightArq(Cell):
    """" WeightArq layer

    args:
        channel_axis: the index of channel
        offset_flag: whether use offset in quantize
        num_bits: the number of quant data bits
    Inputs:
        Tensor input_x: the input weight tensor

    Output:
        Tensor of fake quantized weight
    """
    def __init__(self, channel_axis, subcell, offset_flag=False, num_bits=8):
        super().__init__()
        self.channel_axis = channel_axis
        self.offset_flag = offset_flag
        self.num_bits = num_bits
        if context.get_context("device_target") == "Ascend":
            self.weight_qat = Q.WtsARQ(
                self.num_bits, self.offset_flag)

        is_dense = isinstance(subcell, nn.Dense)
        if not channel_axis:
            self.reduce_axis = (0, 1) if is_dense else (0, 1, 2, 3)
        else:
            self.reduce_axis = (1, 2, 3)

        self.reduce_max = P.ReduceMax(keep_dims=True)
        self.neg = P.Neg()

    def construct(self, input_x):
        '''Definition of subgraph.'''
        w_min = self.neg(self.reduce_max(self.neg(input_x), self.reduce_axis))
        w_max = self.reduce_max(input_x, self.reduce_axis)
        output = self.weight_qat(input_x, w_min, w_max)
        return output

    def extend_repr(self):
        """A pretty print for WeightArq layer."""
        str_desc = 'channel_axis={}, num_bits={}, offset_flag={}'.format(
            self.channel_axis, self.num_bits, self.offset_flag)
        return str_desc
