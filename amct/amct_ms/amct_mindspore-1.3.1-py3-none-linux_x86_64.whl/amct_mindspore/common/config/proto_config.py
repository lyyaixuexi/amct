#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Get config dict for quantization from .cfg file.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import copy
from collections import OrderedDict, namedtuple

from google.protobuf import text_format # pylint: disable=E0401

from ..utils.util import find_repeated_items
from ..utils.util import check_no_repeated
from ..utils.util import proto_float_to_python_float
from .field import NUM_STEPS
from .field import NUM_OF_ITERATION
from ..nuq_parser.amct_parse_fusion_json import get_weight_compress_layers
from ...utils.log import LOGGER # pylint: disable=relative-beyond-top-level

_MODULE_NAME = 'Proto_config'


ProtoConfRet = namedtuple('ProtoConfRet', ['global_config', 'common_config', 'type_config', 'layer_config'])


class ProtoConfig(): # pylint: disable=too-many-instance-attributes, too-few-public-methods
    """
    Function: Cope with simple config file from proto.
    APIs:
    """
    def __init__(self, config_file, # pylint: disable=R0913
                 capacity, graph_querier, graph, proto_config):
        self.config_file = config_file
        self.proto_config = proto_config
        with open(self.config_file, 'rb') as cfg_file:
            pbtxt_string = cfg_file.read()
            text_format.Merge(pbtxt_string, self.proto_config)
        self.channel_wise_types = \
            capacity.get_value('CHANNEL_WISE_TYPES')

        self.capacity = capacity
        self.quantizable_type = capacity.get_value('QUANTIZABLE_TYPES')
        self.graph_querier = graph_querier
        self.graph = graph
        self.layer_type = graph_querier.get_name_type_dict(graph)

    @staticmethod
    def _get_nuq_quantize(nuq_quantize):
        steps = nuq_quantize.num_steps
        iterations = nuq_quantize.num_of_iteration
        return steps, iterations

    @staticmethod
    def _get_hfmg_config(config, act_params):
        '''extract hfmg configs'''
        act_params['act_algo'] = 'hfmg'
        hfmg_quantize = config.hfmg_quantize
        num_of_bins = hfmg_quantize.num_of_bins
        act_params['num_of_bins'] = num_of_bins
        if hfmg_quantize.HasField('asymmetric'):
            act_params['asymmetric'] = hfmg_quantize.asymmetric
        else:
            act_params['asymmetric'] = None

    @staticmethod
    def _channel_wise_is_true(config):
        if config.get('weight_quant_params') is None:
            return False

        weight_params = config['weight_quant_params']
        if weight_params.get('wts_algo') in ('arq_quantize', None) and \
            weight_params.get('channel_wise', False):
            return True
        return False

    @staticmethod
    def _gen_nuq_config(steps, iterations):
        config = OrderedDict()
        weight_params = OrderedDict()
        config['weight_quant_params'] = weight_params
        weight_params['wts_algo'] = 'nuq_quantize'
        weight_params['num_steps'] = steps
        weight_params['num_of_iteration'] = iterations
        return config

    @staticmethod
    def _get_ifmr_config(config, act_params):
        '''extract ifmr configs'''
        ifmr_quantize = config.ifmr_quantize
        act_params['act_algo'] = 'ifmr'
        act_params['max_percentile'] = \
            proto_float_to_python_float(ifmr_quantize.max_percentile)
        act_params['min_percentile'] = \
            proto_float_to_python_float(ifmr_quantize.min_percentile)
        act_params['search_range'] = \
            [proto_float_to_python_float(ifmr_quantize.search_range_start),
            proto_float_to_python_float(ifmr_quantize.search_range_end)]
        act_params['search_step'] = proto_float_to_python_float(
            ifmr_quantize.search_step)
        if ifmr_quantize.HasField('asymmetric'):
            act_params['asymmetric'] = ifmr_quantize.asymmetric
        else:
            act_params['asymmetric'] = None

    def get_nuq_layer_config(self,
                             layer_config,
                             common_config):
        """
        brief:generate NUQ config for the supported layers.
        parameters:
            layer_config: OrderedDict, layer config
            common_config: OrderedDict, common_config
        return: layer config with nuq config
        """
        nuq_layers, steps, iterations = self._get_nuq_setting()
        type_config = self._get_override_layer_types()
        if len(nuq_layers) == 0:
            LOGGER.logw("nuq_config is given, while no layer is supported for NUQ!")
        for layer in nuq_layers:
            if layer in layer_config:
                continue
            if self.layer_type.get(layer) in type_config:
                continue
            layer_config[layer] = self._gen_nuq_config(steps, iterations)
            if 'activation_quant_params' in common_config.keys():
                layer_config[layer]['activation_quant_params'] = \
                    common_config['activation_quant_params']
        return layer_config

    def get_proto_config(self, enable_quant=True, enable_approximate=False):
        """parse proto config"""
        if enable_approximate:
            global_config = self._get_approx_global_config()
            return ProtoConfRet(global_config, {}, {}, {})
        elif enable_quant:
            global_config = self._get_global_config()

            # the priority of layer config and type config is
            # higher than nuq config
            layer_config = self._get_override_layer_configs()
            type_config = self._get_override_layer_types()
            common_config = self._get_common_config()

            if hasattr(self.proto_config, 'nuq_config'):
                if self.proto_config.HasField('nuq_config'):
                    layer_config = self.get_nuq_layer_config(
                        layer_config, common_config)

            if not common_config and not type_config:
                if hasattr(self.proto_config, 'conv_calibration_config'):
                    common_config = self._get_conv_calibration_config()
                if hasattr(self.proto_config, 'fc_calibration_config'):
                    fc_config = self._get_fc_calibration_config()
                    for item in (set(self.quantizable_type) -
                                set(self.channel_wise_types)):
                        type_config[item] = copy.deepcopy(fc_config)
            else:
                if hasattr(self.proto_config, 'conv_calibration_config'):
                    self._raise_ignore_info('conv_calibration_config')
                if hasattr(self.proto_config, 'fc_calibration_config'):
                    self._raise_ignore_info('fc_calibration_config')

            if hasattr(self.proto_config, 'tensor_quantize'):
                global_config['tensor_quantize'] = self._get_tensor_quantize_config(
                    self.proto_config.tensor_quantize)

            LOGGER.logd('global_config is {}'.format(global_config))
            LOGGER.logd('common_config is {}'.format(common_config))
            LOGGER.logd('type_config is {}'.format(type_config))
            LOGGER.logd('layer_config is {}'.format(layer_config))
            return ProtoConfRet(global_config, common_config, type_config, layer_config)
        return ProtoConfRet({}, {}, {}, {})

    def _get_batch_num(self):
        if self.proto_config.HasField('batch_num'):
            return self.proto_config.batch_num
        return None

    def _get_activation_offset(self):
        if self.proto_config.HasField('activation_offset'):
            return self.proto_config.activation_offset
        return None

    def _get_joint_quant(self):
        if self.proto_config.HasField('joint_quant'):
            return self.proto_config.joint_quant
        return None

    def _get_weight_offset(self):
        if self.proto_config.HasField('weight_offset'):
            return self.proto_config.weight_offset
        return None

    def _get_skip_layers(self):
        skip_layers = list(self.proto_config.skip_layers)
        repeated_layers = find_repeated_items(skip_layers)
        check_no_repeated(repeated_layers, 'skip_layers')
        return skip_layers

    def _get_skip_approx_layers(self):
        skip_layers = list(self.proto_config.skip_approximation_layers)
        repeated_layers = find_repeated_items(skip_layers)
        check_no_repeated(repeated_layers, 'skip_approximation_layers')
        return skip_layers

    def _get_mapped_type(self, layer_type, map_types):
        if layer_type not in map_types:
            raise ValueError(
                'Unrecognized layer type:{}, only support {}'.format(
                    layer_type, map_types))
        return self.quantizable_type[map_types.index(layer_type)]

    def _transform_layer_types(self, layer_types):
        map_types = self.capacity.get_value('QUANTIZABLE_MAP_TYPES')
        if map_types is None:
            return layer_types

        if not isinstance(layer_types, list):
            return self._get_mapped_type(layer_types, map_types)

        ret = []
        for item in layer_types:
            ret.append(self._get_mapped_type(item, map_types))
        return ret

    def _get_skip_layer_types(self):
        skip_layer_types = list(self.proto_config.skip_layer_types)
        repeated_items = find_repeated_items(skip_layer_types)
        check_no_repeated(repeated_items, 'skip_layer_types')
        return self._transform_layer_types(skip_layer_types)

    def _get_do_fusion(self):
        if hasattr(self.proto_config, 'do_fusion'):
            return self.proto_config.do_fusion
        return True

    def _get_skip_fusion_layers(self):
        if not hasattr(self.proto_config, 'skip_fusion_layers'):
            return []
        skip_fusion_layers = list(self.proto_config.skip_fusion_layers)
        repeated_layers = find_repeated_items(skip_fusion_layers)
        check_no_repeated(repeated_layers, 'skip_fusion_layers')
        return skip_fusion_layers

    def _get_nuq_layers(self, mapping_file, steps):
        nuq_layers = []
        if mapping_file is None:
            return nuq_layers
        # get compress layers
        compress_layers, parsed_json_ops = get_weight_compress_layers(mapping_file)
        # check whether the ops in json the ops in the original graph
        self.graph_querier.check_op_matching(self.graph, parsed_json_ops)

        nuq_quantizable_layers = self.graph_querier.get_nuq_quant_layers(self.graph)
        for ori_layer in compress_layers:
            if ori_layer in nuq_quantizable_layers:
                if self.graph_querier.check_nuq_steps(self.graph, ori_layer, steps):
                    nuq_layers.append(ori_layer)
        return nuq_layers

    def _get_nuq_setting(self):
        mapping_file = None
        steps = NUM_STEPS
        iterations = NUM_OF_ITERATION
        if self.proto_config.HasField('nuq_config'):
            nuq_config = self.proto_config.nuq_config
            mapping_file = nuq_config.mapping_file

            if nuq_config.HasField('nuq_quantize'):
                steps, iterations = self._get_nuq_quantize(
                    nuq_config.nuq_quantize)

        nuq_layers = self._get_nuq_layers(mapping_file, steps)
        return nuq_layers, steps, iterations

    def _parser_calibration_config(self, config):
        layer_config = OrderedDict()
        act_params = OrderedDict()

        if config.HasField('ifmr_quantize'):
            self._get_ifmr_config(config, act_params)
        elif hasattr(config, 'hfmg_quantize') and config.HasField('hfmg_quantize'):
            self._get_hfmg_config(config, act_params)
        weight_params = OrderedDict()
        if config.HasField('arq_quantize'):
            if self.capacity.is_enable('NUQ'):
                weight_params['wts_algo'] = 'arq_quantize'
            arq_quantize = config.arq_quantize
            if arq_quantize.HasField('channel_wise'):
                weight_params['channel_wise'] = arq_quantize.channel_wise
        elif self.capacity.is_enable('NUQ') and config.HasField(
                'nuq_quantize'):
            weight_params['wts_algo'] = 'nuq_quantize'
            nuq_quantize = config.nuq_quantize
            steps, iterations = self._get_nuq_quantize(nuq_quantize)
            weight_params['num_steps'] = steps
            weight_params['num_of_iteration'] = iterations

        layer_config['activation_quant_params'] = act_params
        layer_config['weight_quant_params'] = weight_params

        if hasattr(config, 'dmq_balancer') and config.HasField('dmq_balancer'):
            migration_strength = proto_float_to_python_float(config.dmq_balancer.migration_strength)
            layer_config['dmq_balancer_param'] = migration_strength

        return layer_config

    def _get_common_config(self):
        if self.proto_config.HasField('common_config'):
            common_config = self.proto_config.common_config
            return self._parser_calibration_config(common_config)
        return OrderedDict()

    def _get_override_layer_types(self):
        types = [item.layer_type for item in self.proto_config.override_layer_types]
        repeated_items = find_repeated_items(types)
        check_no_repeated(repeated_items, 'override_layer_types')

        override_types = OrderedDict()
        for item in self.proto_config.override_layer_types:
            layer_type = item.layer_type
            layer_type = self._transform_layer_types(layer_type)
            if layer_type not in self.quantizable_type:
                raise ValueError("Layer type {} does not support "
                                 "quantize.".format(layer_type))

            override_types[layer_type] = self._parser_calibration_config(item.calibration_config)
            symmetric_limit_types = self.graph_querier.get_act_symmetric_limit_types()
            if layer_type in symmetric_limit_types:
                if override_types.get(layer_type).get('activation_quant_params').get('asymmetric'):
                    raise ValueError('Layer type {} can only set asymmetric be False '.format(layer_type))
            if layer_type not in self.channel_wise_types and \
                self._channel_wise_is_true(override_types.get(layer_type)):
                raise ValueError('channel_wise can only be False '
                                 'for {} type'.format(layer_type))
            if override_types.get(layer_type).get('dmq_balancer_param') and \
                layer_type not in self.graph_querier.get_support_dmq_balancer_types():
                raise ValueError('dmq_balancer not support '
                                 'for {} type'.format(layer_type))
        return override_types

    def _get_override_layer_configs(self):
        names = [item.layer_name for item in self.proto_config.override_layer_configs]
        repeated_items = find_repeated_items(names)
        check_no_repeated(repeated_items, 'override_layer_configs')
        override_layers = OrderedDict()
        for item in self.proto_config.override_layer_configs:
            layer_name = item.layer_name
            if layer_name not in self.layer_type:
                raise ValueError('Layer {} does not exist in '
                                 'the graph.'.format(layer_name))

            override_layers[layer_name] = self._parser_calibration_config(item.calibration_config)
            symmetric_limit_layers = self.graph_querier.get_act_symmetric_limit_layers(self.graph)
            if layer_name in symmetric_limit_layers:
                if override_layers.get(layer_name).get('activation_quant_params').get('asymmetric'):
                    raise ValueError('Layer {} can only set asymmetric be False '.format(layer_name))
            if self.layer_type.get(layer_name) not in self.channel_wise_types and \
                self._channel_wise_is_true(override_layers.get(layer_name)):
                raise ValueError('channel_wise can only be False '
                                 'for {} layer.'.format(layer_name))
            if override_layers.get(layer_name).get('dmq_balancer_param') and \
                layer_name not in self.graph_querier.get_support_dmq_balancer_layers(self.graph):
                raise ValueError('dmq_balancer not support '
                                 'for {} layer'.format(layer_name))
        return override_layers

    def _parse_deprecated_config(self, name, config):
        LOGGER.logi('{} field has been deprecated, use common_config and '
                    'override_layer_types instead.'.format(name))
        return self._parser_calibration_config(config)

    def _get_conv_calibration_config(self):
        name = 'conv_calibration_config'
        if not self.proto_config.HasField(name):
            return OrderedDict()
        config = self.proto_config.conv_calibration_config
        return self._parse_deprecated_config(name, config)

    def _get_fc_calibration_config(self):
        name = 'fc_calibration_config'
        if not self.proto_config.HasField(name):
            return OrderedDict()
        config = self.proto_config.fc_calibration_config
        fc_config = self._parse_deprecated_config(name, config)
        if self._channel_wise_is_true(fc_config):
            raise ValueError('channel_wise can only be False '
                             'for fc_calibration_config field')
        return fc_config

    def _raise_ignore_info(self, name):
        if self.proto_config.HasField(name):
            LOGGER.logw('{} field would be ignored when common_config '
                        'or override_layer_types exists'.format(name))

    def _get_global_config(self):
        """parse global config"""
        global_config = OrderedDict()
        if hasattr(self.proto_config, 'batch_num'):
            global_config['batch_num'] = self._get_batch_num()
        global_config['activation_offset'] = self._get_activation_offset()
        if hasattr(self.proto_config, 'joint_quant'):
            global_config['joint_quant'] = self._get_joint_quant()
        if hasattr(self.proto_config, 'weight_offset'):
            global_config['weight_offset'] = self._get_weight_offset()
        global_config['skip_layers'] = self._get_skip_layers()
        global_config['skip_layer_types'] = self._get_skip_layer_types()
        global_config['do_fusion'] = self._get_do_fusion()
        global_config['skip_fusion_layers'] = self._get_skip_fusion_layers()
        return global_config

    def _get_approx_global_config(self):
        """parse global config for op approximation"""
        global_config = OrderedDict()
        if hasattr(self.proto_config, 'batch_num'):
            global_config['batch_num'] = self._get_batch_num()
        global_config['skip_approximation_layers'] = self._get_skip_approx_layers()
        return global_config

    def _get_tensor_quantize_config(self, tensor_configs):
        '''parse config of tensor_quantize'''
        tensor_quantizes = []
        for layer_config in tensor_configs:
            tensor_quantize = {}
            if not layer_config.HasField('layer_name'):
                raise RuntimeError('To quantize tensor, must set "layer_name" at first.')
            if not layer_config.HasField('input_index'):
                raise RuntimeError('To quantize tensor, must set "input_index" at first.')
            tensor_quantize['layer_name'] = layer_config.layer_name
            tensor_quantize['input_index'] = layer_config.input_index
            quantize_params = {}
            if hasattr(layer_config, 'hfmg_quantize') and layer_config.HasField('hfmg_quantize'): # default set to ifmr
                self._get_hfmg_config(layer_config, quantize_params)
            else:
                self._get_ifmr_config(layer_config, quantize_params)
            tensor_quantize['activation_quant_params'] = quantize_params
            tensor_quantizes.append(tensor_quantize)
        return tensor_quantizes
