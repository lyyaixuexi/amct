#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

ifmr init ulq initializer

"""

import os
from collections import OrderedDict
from google.protobuf import text_format
from amct_mindspore.proto \
    import scale_offset_record_pb2
from amct_mindspore.common.utils.util import is_invalid
from amct_mindspore.common.utils.parse_record_file import DATA_OFFSET_RANGE
from amct_mindspore.common.utils.parse_record_file import SCALE_RANGE
from amct_mindspore.initializer.base_initializer import BaseInitializer
from amct_mindspore.utils.log import LOGGER


class UlqInitializer(BaseInitializer):
    """ ulq initializer"""
    def __init__(self, scale_offset_record):
        """ init func for UlqInitializer"""
        super().__init__()
        self.scale_offset_record = scale_offset_record

    @staticmethod
    def check_record_key(key, network):
        """ check the record key"""
        for param_name in network.parameters_dict().keys():
            if param_name.startswith(key):
                return True
        return False

    @staticmethod
    def check_record_value(key, scale_d, offset_d):
        """ method to check scale and offset"""
        def is_in_range(value, min_val, max_val, included=True):
            ''' whether value is in the range of [min_val, max_val]'''
            if included:
                is_in_range = (value >= min_val) & \
                              (value <= max_val)
            else:
                is_in_range = (value > min_val) & \
                              (value < max_val)
            return is_in_range

        # scale_d
        if is_invalid(scale_d) or \
            not is_in_range(scale_d,
                            SCALE_RANGE[0],
                            SCALE_RANGE[1],
                            False):
            raise ValueError("scale_d's value shoule be in positivate range "
                             "of float32 in layer %s." % (key))
        # offset_d
        if is_invalid(offset_d) or \
            not is_in_range(offset_d,
                            DATA_OFFSET_RANGE[0],
                            DATA_OFFSET_RANGE[1]):
            raise ValueError("offset_d's value should be in %s in layer %s." %
                             (DATA_OFFSET_RANGE, key))

    @staticmethod
    def calc_min_max_init(scale_d, offset_d, num_bits):
        """ calculate the clip_min / clip_max init
            from scale_d and offset_d
        """
        min_limit = -2**(num_bits - 1)
        clip_min_init = scale_d * (min_limit - offset_d)
        clip_max_init = scale_d * (2**(num_bits) - 1) + clip_min_init

        return clip_min_init, clip_max_init

    def get_min_max_init(self, network):
        """
        Function: get the clip min / clip max init
        Parameter:
            network: the network
        Return:
            the clip min / clip max init
        """

        record_dir = os.path.realpath(self.scale_offset_record)
        if not os.path.exists(record_dir):
            raise RuntimeError('{} file not exists.'.format(
                record_dir))
        records = scale_offset_record_pb2.ScaleOffsetRecord()
        with open(record_dir, 'r') as read_file:
            pbtxt_string = read_file.read()
            text_format.Merge(pbtxt_string, records)

        min_max_init = OrderedDict()
        if len(records.record) == 0:
            LOGGER.logw(
                "No record found in record file {}, please check "
                "the record file.".format(record_dir))
        for record in records.record:
            if not record.HasField('key'):
                raise RuntimeError('Cannot find "key" in record file.')
            key = record.key

            matched = UlqInitializer.check_record_key(key, network)
            # Check whether layer specified in record file exist in network.
            if not matched:
                raise RuntimeError('Cannot find "{}" in network.'.format(key))
            # each record should have key and value combine
            if not record.HasField('value'):
                raise RuntimeError('Cannot find "value" in record file ' \
                    'of {}'.format(record.key))
            layer_name = record.key
            scale_d = record.value.scale_d
            offset_d = record.value.offset_d
            # check the input scale_d, offset_d
            UlqInitializer.check_record_value(layer_name, scale_d, offset_d)
            if is_invalid(scale_d) or is_invalid(offset_d):
                raise ValueError('scale {} or offset {} is invalid.'.format(
                    scale_d, offset_d))
            min_init, max_init = UlqInitializer.calc_min_max_init(
                scale_d, offset_d, 8)
            if min_init > max_init:
                raise ValueError(
                    'The min_init is larger than max_init, '
                    'which does not satisfy the initialization rules')
            min_max_init[layer_name] = [min_init, max_init]

        return min_max_init
