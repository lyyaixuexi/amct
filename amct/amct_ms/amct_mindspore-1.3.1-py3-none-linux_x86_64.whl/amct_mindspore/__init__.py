#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os

from amct_mindspore.quantize_tool import create_quant_config
from amct_mindspore.quantize_tool import quantize_model
from amct_mindspore.quantize_tool import save_model
from amct_mindspore.quantize_tool import create_quant_retrain_config
from amct_mindspore.quantize_tool import create_quant_retrain_model
from amct_mindspore.quantize_tool import restore_quant_retrain_model
from amct_mindspore.quantize_tool import save_quant_retrain_model
from amct_mindspore.utils.log import set_logging_level

__all__ = [
    'create_quant_config',
    'quantize_model',
    'save_model',
    'create_quant_retrain_config',
    'create_quant_retrain_model',
    'restore_quant_retrain_model',
    'save_quant_retrain_model',
    'set_logging_level',
    '__version__'
]

CUR_DIR = os.path.split(os.path.realpath(__file__))[0]

with open(os.path.join(CUR_DIR, '.version')) as version_file:
    __version__ = version_file.readlines()[0].strip()
