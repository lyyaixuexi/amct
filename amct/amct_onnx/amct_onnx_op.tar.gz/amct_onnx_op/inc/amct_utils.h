/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief AMCT utils header file
 *
 * @file amct_utils.h
 *
 * @version 1.0
 */
#ifndef AMCT_UTILS_H
#define AMCT_UTILS_H
#include <fstream>
#include <string>
#include "custom_op_library.h"
#include "util.h"

namespace AmctUtils {
#ifdef __cplusplus
extern "C" {
#endif

void AmctDumpData(const char* filePath,
                  const int32_t* inputShapeArray,
                  int shapeLen,
                  const void* inputDataArray,
                  int dataLen);

void ConvertLayerName(std::string& originalLayerName,
                      const std::string& subString,
                      const std::string& replaceString);

std::string TrimTailSpace(std::string& str);
void CheckTensorNotEmpty(size_t tensorElementSize);
ONNXTensorElementDataType AmctOpDynamicTypeCheck();

Status SaveInputDataToFloat32(const void* inputData,
                              float* saveData,
                              size_t dataLength,
                              int dataId);
#ifdef __cplusplus
}
#endif
}
#endif /* AMCT_UTILS_H */