/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief AMCT custom ops
 *
 * @file ifmr_kernel.cpp
 *
 * @version 1.0
 */

#include <sstream>

#include "amct_utils.h"
#include "ifmr_kernel.h"
#include "util.h"


IFMRKernel::IFMRKernel(OrtApi api, const OrtKernelInfo* info)
    : api_(api),
      ort_(api_) {
    size_t size = 0;
    std::string out = "length_10";
    OrtStatus* status = api_.KernelInfoGetAttribute_string(info, "input_stamp", &out[0], &size);
    if (api_.GetErrorCode(status) != ORT_FAIL) {
        inputStamp_ = ort_.KernelInfoGetAttribute<std::string>(info, "input_stamp");
    }
    bathNum_ = ort_.KernelInfoGetAttribute<int64_t>(info, "batch_num");
    ifmrParam_.numBits = static_cast<unsigned int>(ort_.KernelInfoGetAttribute<int64_t>(info, "num_bits"));
    ifmrParam_.withOffset = ort_.KernelInfoGetAttribute<int64_t>(info, "with_offset") == 1;
    ifmrParam_.startRatio = ort_.KernelInfoGetAttribute<float>(info, "start_ratio");
    ifmrParam_.endRatio = ort_.KernelInfoGetAttribute<float>(info, "end_ratio");
    ifmrParam_.step = ort_.KernelInfoGetAttribute<float>(info, "step");
    ifmrParam_.maxPercentile = ort_.KernelInfoGetAttribute<float>(info, "max_percentile");
    ifmrParam_.minPercentile = ort_.KernelInfoGetAttribute<float>(info, "min_percentile");
    ifmrParam_.needDump = ort_.KernelInfoGetAttribute<int64_t>(info, "need_dump");
    recordFileName_ = ort_.KernelInfoGetAttribute<std::string>(info, "record_file_path");
    int layerNum = ort_.KernelInfoGetAttribute<int64_t>(info, "layer_num");
    for (int i = 0; i < layerNum; ++i) {
        std::string attrName = "object_layer";
        attrName = attrName + std::to_string(i);
        objectLayerNames_.push_back(ort_.KernelInfoGetAttribute<std::string>(info, attrName.c_str()));
    }
    dumpDir_ = ort_.KernelInfoGetAttribute<std::string>(info, "dump_dir");

    scale_.length = 1;
    scale_.data = &scaleData_;
    offset_.length = 1;
    offset_.data = &offsetData_;
}

void IFMRKernel::DumpData(const void* x, const int inputSize, const std::vector<int32_t>& inputShapeFlt,
    std::string objectLayerName)
{
    std::string trimedLayerName = AmctUtils::TrimTailSpace(objectLayerName);
    std::string trimedDumpDir = AmctUtils::TrimTailSpace(dumpDir_);
    AmctUtils::ConvertLayerName(trimedLayerName, "/", "_");
    std::stringstream ss;
    ss << trimedDumpDir << '/' << trimedLayerName << \
        "_act_calibration_layer_" << std::to_string(currentBatch_) << ".bin";
    std::string fileName = ss.str();
    AmctUtils::AmctDumpData(fileName.c_str(), inputShapeFlt.data(), inputShapeFlt.size(), x, inputSize);
    LOG_INFO("Dump stored data \"%s\" succ!", fileName.c_str());
}

void IFMRKernel::Compute(OrtKernelContext* context)
{
    // set output
    std::vector<int64_t> outputShape = {1};
    OrtValue* output = ort_.KernelContext_GetOutput(context, 0, outputShape.data(), outputShape.size());
    float* out = ort_.GetTensorMutableData<float>(output);
    out[0] = scaleData_;
    // Setup inputs
    currentBatch_++;
    if (currentBatch_ > bathNum_) {
        return;
    }
    // accumulate data
    const OrtValue* inputX = ort_.KernelContext_GetInput(context, 0);
    const OrtTensorTypeAndShapeInfo* inputInfo = ort_.GetTensorTypeAndShape(inputX);
    std::vector<int64_t> inputShape = ort_.GetTensorShape(inputInfo);
    size_t inputSize = ort_.GetTensorShapeElementCount(inputInfo);
    size_t dataByteCount = sizeof(float) * inputSize;
    AmctUtils::CheckTensorNotEmpty(inputSize);

    size_t shape_len = inputShape.size() + 1;
    std::vector<int32_t> inputShapeFlt(shape_len, 0);
    inputShapeFlt[0] = static_cast<int32_t>(inputShape.size());
    for (unsigned int i = 0; i < inputShape.size(); i++) {
        inputShapeFlt[i + 1] = static_cast<int32_t>(inputShape[i]);
    }
    auto x = ort_.GetTensorData<void>(inputX);
    auto inputTypeId = ort_.GetTensorElementType(inputInfo);
    if (inputTypeId == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16) {
        dataByteCount = sizeof(uint16_t) * inputSize;
    }
    size_t dataOffset = accumulateData_.size();
    accumulateData_.resize(dataOffset + inputSize);
    auto resStatus = AmctUtils::SaveInputDataToFloat32(x, accumulateData_.data() + dataOffset, inputSize, inputTypeId);
    if (resStatus != AmctCommon::SUCCESS) {
        LOG_ERROR("Wrong input data type. Only support float16 and float32 for ifmr.\n");
        return;
    }
    for (auto objectLayerName : objectLayerNames_) {
        if (ifmrParam_.needDump) {
            this->DumpData(x, dataByteCount, inputShapeFlt, objectLayerName);
        }
        LOG_INFO("Op \"%s\" already store %ld/%ld data.\n", objectLayerName.c_str(), currentBatch_, bathNum_);
    }
    if (currentBatch_ != bathNum_) {
        return;
    }
    DoCalibration(out);
}

void IFMRKernel::DoCalibration(float* out)
{
    // start to do ifmr calibration
    ifmrParam_.calibration = 0;
    ifmrParam_.needDump = false;
    int ret = AmctCommon::IfmrQuant(accumulateData_.data(), accumulateData_.size(), ifmrParam_, scale_, offset_);
    if (ret != 0) {
        LOG_ERROR("Do IFMR calibration failed, error code: %d.\n", ret);
        return;
    }
    out[0] = scaleData_;
    std::string trimedRecordFilePath = AmctUtils::TrimTailSpace(recordFileName_);
    for (auto objectLayerName : objectLayerNames_) {
        std::string trimedObjectLayerName = AmctUtils::TrimTailSpace(objectLayerName);
        std::string trimedInputSign_ = AmctUtils::TrimTailSpace(inputStamp_);
        if (trimedInputSign_ == "data") {
            util::RecordScaleOffset(trimedRecordFilePath, trimedObjectLayerName, scale_, offset_);
        } else {
            util::RecordScaleOffsetWeight(trimedRecordFilePath, trimedObjectLayerName, scale_, offset_);
        }

        LOG_INFO("Do \"%s\" IFMR calibration success!\n", objectLayerName.c_str());
    }
}