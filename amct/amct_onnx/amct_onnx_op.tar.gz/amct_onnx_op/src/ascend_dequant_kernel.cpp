/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief AMCT custom ops
 *
 * @file ascend_dequant_kernel.cpp
 *
 * @version 1.0
 */

#include <cmath>
#include "amct_utils.h"
#include "dequant_quant.h"
#include "ascend_dequant_kernel.h"
#include "util.h"


void GetShapeInfo(bool channelWise,
                  std::vector<int64_t> shapeInfo,
                  int64_t& hwSize,
                  int64_t& chwSize)
{
    if (channelWise) {
        for (size_t idx = 1; idx < shapeInfo.size(); ++idx) {
            chwSize *= shapeInfo[idx];
            if (idx > 1) {
                hwSize *= shapeInfo[idx];
            }
        }
    }
}


AscendDequantKernel::AscendDequantKernel(OrtApi api, const OrtKernelInfo* info)
    : api_(api),
      ort_(api_) {}

void AscendDequantKernel::Compute(OrtKernelContext* context)
{
    // Setup inputs input 0: data
    const OrtValue* inputX = ort_.KernelContext_GetInput(context, 0);
    auto x = ort_.GetTensorData<void>(inputX);
    const OrtTensorTypeAndShapeInfo* inputInfo = ort_.GetTensorTypeAndShape(inputX);
    auto inputTensorType = ort_.GetTensorElementType(inputInfo);
    size_t inputSize = ort_.GetTensorShapeElementCount(inputInfo);
    AmctUtils::CheckTensorNotEmpty(inputSize);

    std::vector<int64_t> shapeInfo = ort_.GetTensorShape(inputInfo);
    int64_t chwSize = 1;
    int64_t hwSize = 1;
    bool channelWise;
    // input 1: shift bit
    const OrtValue* param = ort_.KernelContext_GetInput(context, 1);
    const uint64_t* paramData = ort_.GetTensorData<uint64_t>(param);
    const OrtTensorTypeAndShapeInfo* paramInfo = ort_.GetTensorTypeAndShape(param);
    size_t paramSize = ort_.GetTensorShapeElementCount(paramInfo);
    AmctUtils::CheckTensorNotEmpty(paramSize);

    channelWise = paramSize == 1 ? false : true;
    GetShapeInfo(channelWise, shapeInfo, hwSize, chwSize);
    // Setup output
    OrtTensorDimensions dimensions(ort_, inputX);
    OrtValue* output = ort_.KernelContext_GetOutput(context, 0, dimensions.data(), dimensions.size());
    auto y = ort_.GetTensorMutableData<void>(output);

    OrtTensorTypeAndShapeInfo* outputInfo = ort_.GetTensorTypeAndShape(output);
    auto outputTensorType = ort_.GetTensorElementType(outputInfo);
    ort_.ReleaseTensorTypeAndShapeInfo(outputInfo);
    //  fake dequant compute
    std::vector<float> shiftValueHost(paramSize);
    std::vector<float> deqScaleHost(paramSize);
    dequantParam_.paramSize = paramSize;
    dequantParam_.chwSize = chwSize;
    dequantParam_.hwSize = hwSize;
    dequantParam_.clipMode = CLIP_32;
    dequantParam_.paramData = paramData;
    dequantParam_.shiftValue = shiftValueHost.data();
    dequantParam_.deqScale = deqScaleHost.data();
    dequantParam_.channelWise = channelWise;
    InputDataParam params = {x, y, inputTensorType, outputTensorType, inputSize};

#ifdef USE_CUDA
    int ret = FakeDequantCuda(params, dequantParam_);
    if (ret != 0) {
        LOG_ERROR("Do AscendDequant cuda compute failed, error code: %d.\n", ret);
        return;
    }
#else
    int ret = ParseParamData(dequantParam_);
    if (ret != 0) {
        LOG_ERROR("Do ParseParamData failed, error code: %d.\n", ret);
        return;
    }
    ret = FakeDequant(params, dequantParam_);
    if (ret != 0) {
        LOG_ERROR("Do AscendDequant compute failed, error code: %d.\n", ret);
        return;
    }
#endif
}