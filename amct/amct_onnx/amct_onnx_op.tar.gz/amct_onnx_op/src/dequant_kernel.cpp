/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief AMCT custom ops
 *
 * @file dequant_kernel.cpp
 *
 * @version 1.0
 */

#include <cmath>
#include "amct_utils.h"
#include "dequant_quant.h"
#include "dequant_kernel.h"
#include "util.h"


DequantKernel::DequantKernel(OrtApi api, const OrtKernelInfo* info)
    : api_(api),
      ort_(api_) {
    dequantParam_.clipMode = ort_.KernelInfoGetAttribute<int64_t>(info, "clip_mode");
}

void DequantKernel::Compute(OrtKernelContext* context)
{
    // Setup inputs input 0: data
    const OrtValue* inputX = ort_.KernelContext_GetInput(context, 0);

    auto inputData = ort_.GetTensorData<void>(inputX);
    const OrtTensorTypeAndShapeInfo* inputInfo = ort_.GetTensorTypeAndShape(inputX);
    auto inputTensorType = ort_.GetTensorElementType(inputInfo);
    size_t inputSize = ort_.GetTensorShapeElementCount(inputInfo);
    AmctUtils::CheckTensorNotEmpty(inputSize);

    std::vector<int64_t> shapeInfo = ort_.GetTensorShape(inputInfo);
    int64_t chwSize = 1;
    int64_t hwSize = 1;
    bool channelWise;
    // input 1: shift bit
    const OrtValue* shiftValue = ort_.KernelContext_GetInput(context, 1);
    const float* shiftData = ort_.GetTensorData<float>(shiftValue);
    // input 2: deqScale
    const OrtValue* deqScale = ort_.KernelContext_GetInput(context, IDX_TWO);
    const float* deqScaleData = ort_.GetTensorData<float>(deqScale);
    const OrtTensorTypeAndShapeInfo* deqScaleInfo = ort_.GetTensorTypeAndShape(deqScale);

    size_t deqScaleSize = ort_.GetTensorShapeElementCount(deqScaleInfo);
    channelWise = deqScaleSize == 1 ? false : true;
    if (channelWise) {
        for (size_t idx = 1; idx < shapeInfo.size(); ++idx) {
            chwSize *= shapeInfo[idx];
            if (idx > 1) {
                hwSize *= shapeInfo[idx];
            }
        }
    }

    std::vector<float> shiftDataWithPow(deqScaleSize);
    std::vector<float> deqScaleDataTmp(deqScaleSize);
    for (unsigned int idx = 0; idx < deqScaleSize; idx++) {
        shiftDataWithPow[idx] = pow(NUM_TWO, shiftData[idx]);
        deqScaleDataTmp[idx] = deqScaleData[idx];
    }
    // Setup output
    OrtTensorDimensions dimensions(ort_, inputX);
    OrtValue* output = ort_.KernelContext_GetOutput(context, 0, dimensions.data(), dimensions.size());
    auto outputData = ort_.GetTensorMutableData<void>(output);

    OrtTensorTypeAndShapeInfo* outputInfo = ort_.GetTensorTypeAndShape(output);
    auto outputTensorType = ort_.GetTensorElementType(outputInfo);
    ort_.ReleaseTensorTypeAndShapeInfo(outputInfo);
    //  fake dequant compute
    dequantParam_.chwSize = chwSize;
    dequantParam_.hwSize = hwSize;
    dequantParam_.shiftValue = shiftDataWithPow.data();
    dequantParam_.deqScale = deqScaleDataTmp.data();
    dequantParam_.channelWise = channelWise;
    InputDataParam params = {inputData, outputData, inputTensorType, outputTensorType, inputSize};
    int ret = FakeDequant(params, dequantParam_);
    if (ret != 0) {
        LOG_ERROR("Do dequant compute failed, error code: %d.\n", ret);
        return;
    }
}
