/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief AMCT custom ops
 *
 * @file hfmg_kernel.cpp
 *
 * @version 1.0
 */

#include <sstream>
#include "amct_utils.h"
#include "hfmg_kernel.h"
#include "util.h"

using namespace util;

HFMGKernel::HFMGKernel(OrtApi api, const OrtKernelInfo* info)
    : api_(api), ort_(api_)
{
    // try to get attr, if not use default value
    size_t size = 0;
    std::string out = "length_10";
    OrtStatus* status = api_.KernelInfoGetAttribute_string(info, "input_stamp", &out[0], &size);
    if (api_.GetErrorCode(status) != ORT_FAIL) {
        inputStamp_ = ort_.KernelInfoGetAttribute<std::string>(info, "input_stamp");
    }
    bathNum_ = ort_.KernelInfoGetAttribute<int64_t>(info, "batch_num");
    hfmgAlgoParam_.quantBitNum = static_cast<unsigned int>(ort_.KernelInfoGetAttribute<int64_t>(info, "num_bits"));
    hfmgAlgoParam_.withOffset = ort_.KernelInfoGetAttribute<int64_t>(info, "with_offset") == 1;
    hfmgAlgoParam_.nbins = ort_.KernelInfoGetAttribute<int64_t>(info, "nbins");
    needDump_ = ort_.KernelInfoGetAttribute<int64_t>(info, "need_dump");
    recordFileName_ = ort_.KernelInfoGetAttribute<std::string>(info, "record_file_path");
    int layerNum = ort_.KernelInfoGetAttribute<int64_t>(info, "layer_num");
    for (int i = 0; i < layerNum; ++i) {
        std::string attrName = "object_layer";
        attrName = attrName.append(std::to_string(i));
        objectLayerNames_.push_back(ort_.KernelInfoGetAttribute<std::string>(info, attrName.c_str()));
    }
    dumpDir_ = ort_.KernelInfoGetAttribute<std::string>(info, "dump_dir");
    scale_.data = &scaleData_;
    offset_.length = 1;
    offset_.data = &offsetData_;
}

void HFMGKernel::UpdateMinMax(const float* inputData, const int count, float& min, float& max)
{
    float inputMin = *std::min_element(inputData, inputData + count);
    float inputMax = *std::max_element(inputData, inputData + count);
    min = inputMin < min ? inputMin : min;
    max = inputMax > max ? inputMax : max;
}


void HFMGKernel::DumpData(const void* x, const int inputSize, const std::vector<int32_t>& inputShapeFlt)
{
    for (auto objectLayerName : objectLayerNames_) {
        if (needDump_) {
            std::string trimedLayerName_ = AmctUtils::TrimTailSpace(objectLayerName);
            std::string trimedDumpDir_ = AmctUtils::TrimTailSpace(dumpDir_);
            AmctUtils::ConvertLayerName(trimedLayerName_, "/", "_");
            std::stringstream ss;
            ss << trimedDumpDir_ << '/' << trimedLayerName_ << \
                "_act_calibration_layer_" << std::to_string(currentBatch_) << ".bin";
            std::string fileName = ss.str();
            AmctUtils::AmctDumpData(fileName.c_str(), inputShapeFlt.data(), inputShapeFlt.size(), x, inputSize);
            LOG_INFO("Dump stored data \"%s\" succ!", fileName.c_str());
        }
    }
}


int HFMGKernel::Accumlate(OrtKernelContext* context)
{
    const OrtValue* inputX = ort_.KernelContext_GetInput(context, 0);
    const OrtTensorTypeAndShapeInfo* inputInfo = ort_.GetTensorTypeAndShape(inputX);
    std::vector<int64_t> inputShape = ort_.GetTensorShape(inputInfo);
    size_t inputSize = ort_.GetTensorShapeElementCount(inputInfo);
    size_t dataByteCount = sizeof(float) * inputSize;
    AmctUtils::CheckTensorNotEmpty(inputSize);
    size_t shape_len = inputShape.size() + 1;
    std::vector<int32_t> inputShapeFlt(shape_len, 0);
    inputShapeFlt[0] = static_cast<int32_t>(inputShape.size());
    for (unsigned int i = 0; i < inputShape.size(); i++) {
        inputShapeFlt[i + 1] = static_cast<int32_t>(inputShape[i]);
    }
    // dump the input data each batch
    this->DumpData(ort_.GetTensorData<void>(inputX), dataByteCount, inputShapeFlt);
    inputTypeId_ = ort_.GetTensorElementType(inputInfo);
    if (inputTypeId_ == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT) {
        auto x = ort_.GetTensorData<float>(inputX);
        this->DumpData(ort_.GetTensorData<void>(inputX), dataByteCount, inputShapeFlt);
        AmctCommon::InputData<float> inputData{static_cast<unsigned int>(inputSize), x};
        int ret = HfmgMerge(hfmgAlgoParam_.nbins, dataBins_, inputData);
        if (ret != AmctCommon::SUCCESS) {
            LOG_ERROR("Do HfmgMerge error, error code is %d", ret);
        }
        return ret;
    }

    auto x = ort_.GetTensorData<void>(inputX);
    std::vector<float> accumulateData(inputSize);
    auto resStatus = AmctUtils::SaveInputDataToFloat32(x, accumulateData.data(), inputSize, inputTypeId_);
    if (resStatus != AmctCommon::SUCCESS) {
        LOG_ERROR("Wrong input data type. Only support float16 and float32 for hfmg.\n");
        return resStatus;
    }
    dataByteCount = sizeof(uint16_t) * inputSize;
    this->DumpData(ort_.GetTensorData<void>(inputX), dataByteCount, inputShapeFlt);
    AmctCommon::InputData<float> inputData{static_cast<unsigned int>(inputSize), accumulateData.data()};
    int ret = HfmgMerge(hfmgAlgoParam_.nbins, dataBins_, inputData);
    if (ret != AmctCommon::SUCCESS) {
        LOG_ERROR("Do HfmgMerge error, error code is %d", ret);
    }

    return ret;
}


void HFMGKernel::Compute(OrtKernelContext* context)
{
    // set output
    std::vector<int64_t> outputDims = {1};
    OrtValue* output = ort_.KernelContext_GetOutput(context, 0, outputDims.data(), outputDims.size());
    float* out = ort_.GetTensorMutableData<float>(output);
    out[0] = scaleData_;
    // Setup inputs
    currentBatch_++;
    if (currentBatch_ > bathNum_) {
        return;
    }
    // accumulate data to Histogram and dump the input data each batch
    if (this->Accumlate(context) != AmctCommon::SUCCESS) {
        LOG_ERROR("HFMGKernel::Accumlate fail");
        return;
    }

    if (currentBatch_ == bathNum_) {
        // start to do hfmg calibration
        int ret = AmctCommon::HfmgCompute(dataBins_, scaleData_, offsetData_, hfmgAlgoParam_);
        if (ret != AmctCommon::SUCCESS) {
            LOG_ERROR("Do HfmgCompute calculate scale and offset error, error code is %d", ret);
            return;
        }
        std::string trimedRecordFilePath = AmctUtils::TrimTailSpace(recordFileName_);
        for (auto objectLayerName : objectLayerNames_) {
            std::string trimedObjectLayerName = AmctUtils::TrimTailSpace(objectLayerName);
            std::string trimedInputSign_ = AmctUtils::TrimTailSpace(inputStamp_);
            if (trimedInputSign_ == "data") {
                util::RecordScaleOffset(trimedRecordFilePath, trimedObjectLayerName, scale_, offset_);
            } else {
                util::RecordScaleOffsetWeight(trimedRecordFilePath, trimedObjectLayerName, scale_, offset_);
            }

            LOG_INFO("Do \"%s\" HFMG calibration success!\n", objectLayerName.c_str());
        }
    } else {
        const OrtValue* inputX = ort_.KernelContext_GetInput(context, 0);
        size_t inputSize = ort_.GetTensorShapeElementCount(ort_.GetTensorTypeAndShape(inputX));
        auto x = ort_.GetTensorData<void>(inputX);
        std::vector<float> currentData(inputSize);
        auto resStatus = AmctUtils::SaveInputDataToFloat32(x, currentData.data(), inputSize, inputTypeId_);
        if (resStatus != AmctCommon::SUCCESS) {
            LOG_ERROR("Wrong input data type. Only support float16 and float32 for hfmg.\n");
            return;
        }
        float currentMin = 0;
        float currentMax = 0;
        UpdateMinMax(currentData.data(), inputSize, currentMin, currentMax);
        FloatData scaleData = {1, &scaleData_};
        IntData offsetData = {1, &offsetData_};
        AmctCommon::ActArqCalibration(currentMin, currentMax, scaleData, offsetData, hfmgAlgoParam_);
    }
    for (auto objectLayerName : objectLayerNames_) {
        LOG_INFO("Op \"%s\" hfmg already process %ld/%ld data.\n", objectLayerName.c_str(), currentBatch_, bathNum_);
    }
    out[0] = scaleData_;
}
