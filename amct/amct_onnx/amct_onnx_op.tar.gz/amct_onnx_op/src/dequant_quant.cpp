/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief fake_dequant_quant custom op kernel func C++ implement
 *
 * @file dequant_quant.cpp
 *
 * @version 1.0
 */
#include <cmath>
#include <mutex>
#include <cfloat>
#include <algorithm>
#include <numeric>
#include <iostream>
#include <cmath>

#include "dequant_quant.h"
#include "util.h"
#include "cast_util.h"

using namespace std;
using namespace util;

const int SHIFT_VAL_LEN = 32;
const int FLOAT_TYPE_ID = 1;

template<class T>
Status FakeDequantKernel(const T* data,
                         T* outputData,
                         int64_t length,
                         DequantParam dequantParam)
{
    T clipMin = -static_cast<T>(pow(BINARY_BASE, dequantParam.clipMode - 1));
    T clipMax = static_cast<T>(pow(BINARY_BASE, dequantParam.clipMode - 1) - 1);
    if (dequantParam.chwSize == 0 || dequantParam.hwSize == 0) {
        return AmctCommon::GENERIC_ERROR;
    }
#pragma omp parallel for
    for (int index = 0; index < length; index++) {
        int channelIndex = !dequantParam.channelWise ? 0 : (index % (dequantParam.chwSize)) / dequantParam.hwSize;
        float shiftValuePow = dequantParam.shiftValue[channelIndex];
        if (std::fabs(shiftValuePow - 1) <= std::numeric_limits<float>::epsilon()) {
            outputData[index] = data[index] * dequantParam.deqScale[channelIndex];
        } else {
            T tmpData = floor(data[index] / shiftValuePow);
            if (tmpData < clipMin) {
                tmpData = clipMin;
            } else if (tmpData > clipMax) {
                tmpData = clipMax;
            }
            outputData[index] = tmpData * dequantParam.deqScale[channelIndex] * shiftValuePow;
        }
    }
    return AmctCommon::SUCCESS;
}


template<class T>
Status FakeQuantKernel(const T* inputData,
                       T* outputData,
                       int64_t length,
                       int64_t quantBits,
                       float scale,
                       int64_t offset)
{
    int64_t clipMin = -pow(BINARY_BASE, quantBits - 1);
    int64_t clipMax = pow(BINARY_BASE, quantBits - 1) - 1;
    // Do quant computation
#pragma omp parallel for
    for (int64_t i = 0; i < length; i++) {
        int64_t temp = round(inputData[i] * scale) + offset;
        temp = temp < clipMin ? clipMin : temp;
        temp = temp > clipMax ? clipMax : temp;
        outputData[i] = static_cast<float>(temp - offset);
    }
    return AmctCommon::SUCCESS;
}


template<class T>
Status FakeAntiQuantKernel(const T* inputData, T* outputData, int64_t length, float scale)
{
#pragma omp parallel for
    for (int64_t idx = 0; idx < length; idx++) {
        outputData[idx] = inputData[idx] * scale;
    }
    return AmctCommon::SUCCESS;
}


int ParseParamData(
    DequantParam& dequantParam)
{
    const uint64_t shiftnMask = 0x000000ff00000000;
    const uint64_t deqscaleMask = 0x00000000ffffffff;
#pragma omp parallel for
    for (unsigned int idx = 0; idx < dequantParam.paramSize; idx++) {
        unsigned int shiftValue = (dequantParam.paramData[idx] & shiftnMask) >> SHIFT_VAL_LEN;
        dequantParam.shiftValue[idx] = pow(BINARY_BASE, shiftValue);
        if (shiftValue != 0) {
            dequantParam.clipMode = CLIP_16;
        }
        unsigned int deqscaleUint = dequantParam.paramData[idx] & deqscaleMask;
        float* deqscalePtr = reinterpret_cast<float*>(&deqscaleUint);
        dequantParam.deqScale[idx] = deqscalePtr[0];
    }
    return AmctCommon::SUCCESS;
}


int FakeDequant(InputDataParam param,
                DequantParam dequantParam)
{
    int res = AmctCommon::SUCCESS;
    if (param.outType != FLOAT_TYPE_ID) {
        std::vector<float> outCast(param.length, 0);
        // in_16, out_16
        if (param.inType != FLOAT_TYPE_ID) {
            std::vector<float> inCast(param.length, 0);
            DataCastToFloat32Functor<util::CPUDevice, uint16_t>()(
                reinterpret_cast<const uint16_t*>(param.in), inCast.data(), param.length);
            res = FakeDequantKernel(inCast.data(), outCast.data(), param.length, dequantParam);
        } else {
            // in_32, out_16
            res = FakeDequantKernel(reinterpret_cast<const float*>(param.in), outCast.data(),
                param.length, dequantParam);
        }
        DataCastToFloat16Functor<util::CPUDevice, float>()(
            outCast.data(), reinterpret_cast<uint16_t*>(param.out), param.length);
        return res;
    }
    // in_32, out_32
    res = FakeDequantKernel(reinterpret_cast<const float*>(param.in), reinterpret_cast<float*>(param.out),
        param.length, dequantParam);
    return res;
}


int FakeQuant(InputDataParam param,
              int64_t quantBits,
              float scale,
              int64_t offset)
{
    int res = AmctCommon::SUCCESS;
    if (param.inType != FLOAT_TYPE_ID) {
        std::vector<float> inCast(param.length, 0);
        DataCastToFloat32Functor<util::CPUDevice, uint16_t>()(
            reinterpret_cast<const uint16_t*>(param.in), inCast.data(), param.length);
        // in_16, out_16
        if (param.outType != FLOAT_TYPE_ID) {
            std::vector<float> outCast(param.length, 0);
            res = FakeQuantKernel(inCast.data(), outCast.data(), param.length, quantBits, scale, offset);
            DataCastToFloat16Functor<util::CPUDevice, float>()(
                outCast.data(), reinterpret_cast<uint16_t*>(param.out), param.length);
            return res;
        }
        // in_16, out_32
        res = FakeQuantKernel(inCast.data(), reinterpret_cast<float*>(param.out), param.length,
            quantBits, scale, offset);
        return res;
    }
    // in_32, out_32
    res = FakeQuantKernel(reinterpret_cast<const float*>(param.in), reinterpret_cast<float*>(param.out),
        param.length, quantBits, scale, offset);
    return res;
}


int FakeAntiQuant(InputDataParam param, float scaleData)
{
    if (param.outType != FLOAT_TYPE_ID) {
        std::vector<float> outCast(param.length, 0);
        // in_16, out_16
        if (param.inType != FLOAT_TYPE_ID) {
            std::vector<float> inCast(param.length, 0);
            DataCastToFloat32Functor<util::GPUDevice, uint16_t>()(
                reinterpret_cast<const uint16_t*>(param.in), inCast.data(), param.length);
            FakeAntiQuantKernel(inCast.data(), outCast.data(), param.length, scaleData);
        } else {
            // in_32, out_16
            FakeAntiQuantKernel(reinterpret_cast<const float*>(param.in), outCast.data(), param.length, scaleData);
        }
        DataCastToFloat16Functor<util::GPUDevice, float>()(outCast.data(), reinterpret_cast<uint16_t*>(param.out),
                                                           param.length);
        return AmctCommon::SUCCESS;
    }
    // in_32, out_32
    FakeAntiQuantKernel(reinterpret_cast<const float*>(param.in), reinterpret_cast<float*>(param.out),
                        param.length, scaleData);
    return AmctCommon::SUCCESS;
}