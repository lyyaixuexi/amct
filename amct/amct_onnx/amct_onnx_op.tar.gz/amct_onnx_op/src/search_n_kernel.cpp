/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief AMCT custom ops
 *
 * @file search_n_kernel.cpp
 *
 * @version 1.0
 */

#include <string>
#include <cmath>

#include "amct_utils.h"
#include "search_n_kernel.h"
#include "util.h"

using namespace util;

void InitSearchnError(std::vector<std::vector<float>>& searchNError,
                      const std::vector<int64_t>& inputshape,
                      bool channelWise)
{
    size_t channelNum = channelWise ? inputshape[0] : 1;
    for (size_t channel = 0; channel < channelNum; channel++) {
        std::vector<float> error(SHIFT_BITS);
        searchNError.push_back(error);
    }
}

void StoreInputTensorToND(const float* inputData,
                          const size_t inputSize,
                          const std::vector<int64_t>& inputshape,
                          std::vector<std::vector<float>>& outData,
                          size_t scaleWSize)
{
    bool channelWise = !(scaleWSize == 1);

    if (!channelWise) {
        // not channel wise
        if (outData.size() == 0) {
            std::vector<float> data;
            data.insert(data.end(), inputData, inputData + inputSize);
            outData.push_back(data);
        } else {
            outData[0].insert(outData[0].end(), inputData, inputData + inputSize);
        }
    } else {
        // channel wise
        int channelSize = 1;
        for (uint i = 1; i < inputshape.size(); i++) {
            channelSize = channelSize * inputshape[i];
        }
        // store data by channel
        for (uint channel = 0; channel < inputshape[0]; channel++) {
            if (outData.size() == channel) {
                std::vector<float> data;
                data.insert(data.end(), inputData, inputData + channelSize);
                outData.push_back(data);
            } else {
                outData[channel].insert(outData[channel].end(), inputData, inputData + channelSize);
            }
            inputData = inputData + channelSize;
        }
    }
}

Status SearchNKernel::CheckChannelNum(size_t coutNum, size_t scaleWSize, std::string layerNames)
{
    bool channelWise = (scaleWSize != 1);
    if (channelWise) {
        // data has been transposed to CNHW in advance
        if (coutNum != scaleWSize) {
            LOG_ERROR("Op \"%s SearchN\" inputs[1]'s shape[1]{%ld} isn't equal to inputs[1]'s length {%ld}\n", \
                layerNames.c_str(), coutNum, scaleWSize);
            return AmctCommon::BAD_PARAMETERS_ERROR;
        }
    }
    return AmctCommon::SUCCESS;
}

SearchNKernel::SearchNKernel(OrtApi api, const OrtKernelInfo* info)
    : api_(api),
      ort_(api_)
{
    batchNum_ = ort_.KernelInfoGetAttribute<int64_t>(info, "batch_num");
    recordFileName_ = ort_.KernelInfoGetAttribute<std::string>(info, "record_file_path");
    int layerNum = ort_.KernelInfoGetAttribute<int64_t>(info, "layer_num");
    for (int i = 0; i < layerNum; ++i) {
        std::string attrName = "object_layer";
        attrName = attrName.append(std::to_string(i));
        objectLayerNames_.push_back(ort_.KernelInfoGetAttribute<std::string>(info, attrName.c_str()));
    }
}

void SearchNKernel::RecordShiftBit(const std::vector<int>& bestN)
{
    for (auto objectLayerName : objectLayerNames_) {
        std::string trimedRecordFilePath = AmctUtils::TrimTailSpace(recordFileName_);
        std::string trimedObjectLayerName = AmctUtils::TrimTailSpace(objectLayerName);
        util::RecordRepeatData(trimedRecordFilePath, trimedObjectLayerName, bestN, "shift_bit");
        LOG_INFO("Do \"%s\" SearchN calibration success!\n", objectLayerName.c_str());
    }
}

SearchNKernel::~SearchNKernel()
{
    // Release memory used for data accumulation
    for (uint channel = 0; channel < accumulateData_.size(); channel++) {
        accumulateData_.clear();
        accumulateData_.shrink_to_fit();
    }
}

void SearchNKernel::Compute(OrtKernelContext* context)
{
    if (++current_batch_ > batchNum_) {
        return;
    }

    // get scale_w
    const OrtValue* inputScaleW = ort_.KernelContext_GetInput(context, 2);
    const OrtTensorTypeAndShapeInfo* scaleWInfo = ort_.GetTensorTypeAndShape(inputScaleW);
    size_t scaleWSize = ort_.GetTensorShapeElementCount(scaleWInfo);
    const float* scaleW = ort_.GetTensorData<float>(inputScaleW);

    // accumulate data
    const OrtValue* inputX = ort_.KernelContext_GetInput(context, 0);
    const OrtTensorTypeAndShapeInfo* inputInfo = ort_.GetTensorTypeAndShape(inputX);
    std::vector<int64_t> inputshape = ort_.GetTensorShape(inputInfo);
    size_t inputSize = ort_.GetTensorShapeElementCount(inputInfo);
    AmctUtils::CheckTensorNotEmpty(inputSize);

    if (CheckChannelNum(static_cast<size_t>(inputshape[0]), scaleWSize, objectLayerNames_[0]) != AmctCommon::SUCCESS) {
        return;
    }
    auto x = ort_.GetTensorData<void>(inputX);
    std::vector<float> inData(inputSize);
    auto inputTypeId = ort_.GetTensorElementType(inputInfo);
    auto resStatus = AmctUtils::SaveInputDataToFloat32(x, inData.data(), inputSize, inputTypeId);
    if (resStatus != AmctCommon::SUCCESS) {
        LOG_ERROR("Wrong input data type. Only support float16 and float32 for searchn.\n");
        return;
    }

    // store data in ND
    StoreInputTensorToND(inData.data(), inputSize, inputshape, accumulateData_, scaleWSize);
    LOG_INFO("SearchN Op \"%s\" already store %ld/%ld data.\n", objectLayerNames_[0].c_str(),
        current_batch_, batchNum_);

    if (current_batch_ != batchNum_) {
        return;
    }
    // get scale_d
    const OrtValue* inputScaleD = ort_.KernelContext_GetInput(context, 1);
    const OrtTensorTypeAndShapeInfo* scaleDInfo = ort_.GetTensorTypeAndShape(inputScaleD);
    int scaleDSize = ort_.GetTensorShapeElementCount(scaleDInfo);
    if (scaleDSize != 1) {
        LOG_ERROR("SearchN Op \"%s\" can only have 1 scale_d, but get %d\n", objectLayerNames_[0].c_str(), scaleDSize);
        return;
    }
    const float* scaleD = ort_.GetTensorData<float>(inputScaleD);
    std::vector<float> deqScale;
    for (size_t i = 0; i < scaleWSize; ++i) {
        deqScale.push_back(scaleD[0] * scaleW[i]);
    }
    std::vector<std::vector<int>> int32Data(accumulateData_.size(), std::vector<int>(accumulateData_[0].size(), 0));
    for (size_t i = 0; i < accumulateData_.size(); ++i) {
        for (size_t j = 0; j < accumulateData_[i].size(); ++j) {
            int32Data[i][j] = round(accumulateData_[i][j] / deqScale[i]);
        }
    }

    std::vector<int> bestN;
    AmctCommon::SearchShiftBits(int32Data, bestN);
    RecordShiftBit(bestN);
}
