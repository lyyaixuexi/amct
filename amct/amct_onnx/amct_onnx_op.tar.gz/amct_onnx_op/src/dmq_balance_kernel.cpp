/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2023-2023. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief AMCT custom ops
 *
 * @file dmq_balance_kernel.cpp
 *
 * @version 1.0
 */


#include "dmq_balance_kernel.h"
#include "amct_utils.h"
#include "cast_util.h"
#include "dmq_balance.h"

DMQBalanceKernel::DMQBalanceKernel(OrtApi api, const OrtKernelInfo* info)
    : api_(api),
      ort_(api_) {
    migrationStrength_ = ort_.KernelInfoGetAttribute<float>(info, "migration_strength");
    channelNum_ = static_cast<uint32_t>(ort_.KernelInfoGetAttribute<int64_t>(info, "channel_num"));
    objectLayerName_ = ort_.KernelInfoGetAttribute<std::string>(info, "object_layer");
    recordFileName_ = ort_.KernelInfoGetAttribute<std::string>(info, "record_file_path");
}

void DMQBalanceKernel::GetInput(OrtKernelContext* context, uint32_t index, std::vector<float> &inputData)
{
    const OrtValue* input = ort_.KernelContext_GetInput(context, index);
    const OrtTensorTypeAndShapeInfo* inputInfo = ort_.GetTensorTypeAndShape(input);
    size_t inputSize = ort_.GetTensorShapeElementCount(inputInfo);
    AmctUtils::CheckTensorNotEmpty(inputSize);
    inputData.resize(inputSize, 0);
    ONNXTensorElementDataType inputType = ort_.GetTensorElementType(inputInfo);
    if (inputType == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT16) {
        const uint16_t* data = ort_.GetTensorData<uint16_t>(input);
        util::DataCastToFloat32Functor<util::CPUDevice, uint16_t>()(data, inputData.data(), inputSize);
    } else {
        const float* data = ort_.GetTensorData<float>(input);
        inputData.assign(data, data + inputSize);
    }
    return;
}

void DMQBalanceKernel::Compute(OrtKernelContext* context)
{
    std::vector<float> dmqbFactor(channelNum_, 0);

#ifdef USE_CUDA
    const OrtValue* input0 = ort_.KernelContext_GetInput(context, 0);
    const OrtTensorTypeAndShapeInfo* input0Info = ort_.GetTensorTypeAndShape(input0);
    size_t input0Size = ort_.GetTensorShapeElementCount(input0Info);
    AmctUtils::CheckTensorNotEmpty(input0Size);
    auto input0Type = ort_.GetTensorElementType(input0Info);
    auto data0 = ort_.GetTensorData<void>(input0);
    AmctCommon::InputDataParam act = {const_cast<void*>(data0), input0Type, input0Size};

    const OrtValue* input1 = ort_.KernelContext_GetInput(context, 1);
    const OrtTensorTypeAndShapeInfo* input1Info = ort_.GetTensorTypeAndShape(input1);
    size_t input1Size = ort_.GetTensorShapeElementCount(input1Info);
    AmctUtils::CheckTensorNotEmpty(input1Size);
    auto input1Type = ort_.GetTensorElementType(input1Info);
    auto data1 = ort_.GetTensorData<void>(input1);
    AmctCommon::InputDataParam wts = {const_cast<void*>(data1), input1Type, input1Size};
    int ret = AmctCommon::DMQBalanceGpuMemCopy(act, wts, migrationStrength_, channelNum_, dmqbFactor.data());
    if (ret != 0) {
        LOG_ERROR("Do \"%s\" DMQBalance cuda compute failed, error code: %d.\n", objectLayerName_.c_str(), ret);
        return;
    }
#else
    std::vector<float> actData;
    GetInput(context, 0, actData);
    util::FloatData act = {static_cast<unsigned int>(actData.size()), actData.data()};

    std::vector<float> wtsData;
    GetInput(context, 1, wtsData);
    util::FloatData wts = {static_cast<unsigned int>(wtsData.size()), wtsData.data()};
    int ret = AmctCommon::DMQBalance(act, wts, migrationStrength_, channelNum_, dmqbFactor.data());
    if (ret != 0) {
        LOG_ERROR("Do \"%s\" DMQBalance failed, error code: %d.\n", objectLayerName_.c_str(), ret);
        return;
    }
#endif

    ret = util::CheckBalanceFactor(dmqbFactor.data(), channelNum_);
    if (ret != AmctCommon::SUCCESS) {
        return;
    }

    std::string trimedRecordFileName = AmctUtils::TrimTailSpace(recordFileName_);
    std::string trimedLayerName = AmctUtils::TrimTailSpace(objectLayerName_);
    ret = util::RecordRepeatData(trimedRecordFileName, trimedLayerName, dmqbFactor, "tensor_balance_factor");
    if (ret != AmctCommon::SUCCESS) {
        return;
    }

    LOG_INFO("Do \"%s\" DMQBalance success!\n", objectLayerName_.c_str());
}
