/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief AMCT custom ops
 *
 * @file search_n_v2_kernel.cpp
 *
 * @version 1.0
 */

#include "amct_utils.h"
#include "search_n_v2_kernel.h"
#include "search_n_kernel.h"
#include "util.h"

using namespace util;

Status SearchNV2Kernel::CheckChannelNum(size_t coutNum, size_t scaleWSize, std::string layerNames)
{
    bool channelWise = !(scaleWSize == 1);
    if (channelWise) {
        // data has been transposed to CNHW in advance
        if (coutNum != scaleWSize) {
            LOG_ERROR("Op \"%s SearchNv2\" inputs[1]'s shape[1]{%ld} isn't equal to inputs[1]'s length {%ld}\n", \
                layerNames.c_str(), coutNum, scaleWSize);
            return AmctCommon::BAD_PARAMETERS_ERROR;
        }
    }
    return AmctCommon::SUCCESS;
}

void SearchNV2Kernel::RecordShiftBit(const std::vector<int>& bestN)
{
    for (auto objectLayerName : objectLayerNames_) {
        std::string trimedRecordFilePath = AmctUtils::TrimTailSpace(recordFileName_);
        std::string trimedObjectLayerName = AmctUtils::TrimTailSpace(objectLayerName);
        util::RecordRepeatData(trimedRecordFilePath, trimedObjectLayerName, bestN, "shift_bit");
        LOG_INFO("Do \"%s\" SEARCHN_V2 calibration success!\n", objectLayerName.c_str());
    }
}

SearchNV2Kernel::SearchNV2Kernel(OrtApi api, const OrtKernelInfo* info)
    : api_(api),
      ort_(api_) {
    batchNum_ = ort_.KernelInfoGetAttribute<int64_t>(info, "batch_num");
    recordFileName_ = ort_.KernelInfoGetAttribute<std::string>(info, "record_file_path");
    int layerNum = ort_.KernelInfoGetAttribute<int64_t>(info, "layer_num");
    for (int i = 0; i < layerNum; ++i) {
        std::string attrName = "object_layer";
        attrName = attrName + std::to_string(i);
        objectLayerNames_.push_back(ort_.KernelInfoGetAttribute<std::string>(info, attrName.c_str()));
    }
}

SearchNV2Kernel::~SearchNV2Kernel()
{
    // Release memory used for accumulation error
    for (uint channel = 0; channel < searchNError_.size(); channel++) {
        searchNError_.clear();
        searchNError_.shrink_to_fit();
    }
}

void SearchNV2Kernel::Compute(OrtKernelContext* context)
{
    if (++current_batch_ > batchNum_) {
        return;
    }
    // obtain input data
    const OrtValue* inputX = ort_.KernelContext_GetInput(context, 0);
    const OrtTensorTypeAndShapeInfo* inputInfo = ort_.GetTensorTypeAndShape(inputX);
    std::vector<int64_t> inputshape = ort_.GetTensorShape(inputInfo);
    size_t inputSize = ort_.GetTensorShapeElementCount(inputInfo); // CNHW
    AmctUtils::CheckTensorNotEmpty(inputSize);

    auto x = ort_.GetTensorData<void>(inputX);
    std::vector<float> inData(inputSize);
    auto inputTypeId = ort_.GetTensorElementType(inputInfo);
    auto resStatus = AmctUtils::SaveInputDataToFloat32(x, inData.data(), inputSize, inputTypeId);
    if (resStatus != AmctCommon::SUCCESS) {
        LOG_ERROR("Wrong input data type. Only support float16 and float32 for searchnv2.\n");
        return;
    }

    // obtain scale_d
    const OrtValue* inputScaleD = ort_.KernelContext_GetInput(context, 1);
    const OrtTensorTypeAndShapeInfo* scaleDInfo = ort_.GetTensorTypeAndShape(inputScaleD);
    int scaleDSize = ort_.GetTensorShapeElementCount(scaleDInfo);
    AmctUtils::CheckTensorNotEmpty(scaleDSize);
    if (scaleDSize != 1) {
        LOG_ERROR("SEARCHN_V2 Op \"%s\" can only have 1 scale_d, but get %d\n",
            objectLayerNames_[0].c_str(), scaleDSize);
        return;
    }
    const float* scaleD = ort_.GetTensorData<float>(inputScaleD);

    // obtain scale_w
    const OrtValue* inputScaleW = ort_.KernelContext_GetInput(context, 2);
    const OrtTensorTypeAndShapeInfo* scaleWInfo = ort_.GetTensorTypeAndShape(inputScaleW);
    size_t scaleWSize = ort_.GetTensorShapeElementCount(scaleWInfo);
    const float* scaleW = ort_.GetTensorData<float>(inputScaleW);
    // check channel
    if (CheckChannelNum(static_cast<size_t>(inputshape[0]), scaleWSize, objectLayerNames_[0]) != AmctCommon::SUCCESS) {
        return;
    }

    // calculate deqscale
    std::vector<float> deqScale;
    for (size_t i = 0; i < scaleWSize; ++i) {
        deqScale.push_back(scaleD[0] * scaleW[i]);
    }
    FloatData deqScaleCpu = {static_cast<uint>(scaleWSize), deqScale.data()};

    // store data in ND
    std::vector<std::vector<float>> currentData;
    StoreInputTensorToND(inData.data(), inputSize, inputshape, currentData, scaleWSize);

    // search_n_v2 calculate best N
    LOG_INFO("SearchNv2 Op \"%s\" already process %ld/%ld data.\n", objectLayerNames_[0].c_str(),
        current_batch_, batchNum_);
    if (current_batch_ == 1) {
        bool channelWise = !(scaleWSize == 1);
        InitSearchnError(searchNError_, inputshape, channelWise);
        isBroadcast_ = (inputshape[NHWC_H_DIM] == 1) && (inputshape[NHWC_W_DIM] == 1);
    }

    if (AmctCommon::SearchNV2AccumulateError(currentData, searchNError_, deqScaleCpu, isBroadcast_) !=
        AmctCommon::SUCCESS) {
        LOG_ERROR("Layer \"%s\" SearchNV2AccumulateError failed! \n", objectLayerNames_[0].c_str());
        return;
    }

    if (current_batch_ == batchNum_) {
        std::vector<int> bestN(searchNError_.size());
        IntData bestNCpu = {static_cast<uint>(searchNError_.size()), bestN.data()};
        AmctCommon::SearchNV2FindBestNCpu(searchNError_, bestNCpu, isBroadcast_);
        // record best n
        RecordShiftBit(bestN);
    }
}
