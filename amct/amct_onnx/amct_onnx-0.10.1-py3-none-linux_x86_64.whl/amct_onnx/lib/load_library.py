#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

load weight calibration dynamic library

"""
import os
import ctypes

__all__ = ['Load']


class Load():
    """
    Function: Wrapper class for the dynamic library API.
    APIs: cpu_lib, gpu_lib, lib
    """
    _lib_instance = None

    def __new__(cls, *args, **kw):
        if cls._lib_instance is None:
            cls._lib_instance = object.__new__(cls, *args, **kw)
        return cls._lib_instance

    def __init__(self):
        if not hasattr(self, '_cpu_lib'):
            self._cpu_lib = None

    @property
    def lib(self):
        """
        Function: Get dynamic library.
        Parameters: None
        Return: dynamic library handle
        """
        return self.cpu_lib

    @property
    def cpu_lib(self):
        """
        Function: Get CPU version dynamic library.
        Parameters: None
        Return: dynamic library handle
        """
        if self._cpu_lib:
            return self._cpu_lib
        library_name = self._get_library_name()
        self._cpu_lib = ctypes.cdll.LoadLibrary(library_name)
        return self._cpu_lib

    @staticmethod
    def _get_library_name():
        cur_dir = os.path.split(os.path.realpath(__file__))[0]
        library_name = 'libquant_onnx.so'

        library_name = os.path.join(cur_dir, library_name)
        return library_name