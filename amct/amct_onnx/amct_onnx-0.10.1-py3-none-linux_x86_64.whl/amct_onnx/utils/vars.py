#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Common data definition module.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
from amct_onnx.capacity import CAPACITY

CUR_DIR = os.path.split(os.path.realpath(__file__))[0]

QUANTIZABLE_TYPES = CAPACITY.get_value('QUANTIZABLE_TYPES')
CHANNEL_WISE_TYPES = CAPACITY.get_value('CHANNEL_WISE_TYPES')
MATMUL_TWO_INPUT = CAPACITY.get_value('MATMUL_TWO_INPUT')

CONVERT_QAT_QUANTIZABLE_TYPES = CAPACITY.get_value('CONVERT_QAT_QUANTIZABLE_TYPES')

SHIFT_N_TYPES = CAPACITY.get_value('SHIFT_N_TYPES')

FUSE_TYPES = CAPACITY.get_value('FUSE_TYPES')

AMCT_OPERATIONS = CAPACITY.get_value('AMCT_OPERATIONS')
MULT_OUTPUT_TYPES = CAPACITY.get_value('MULT_OUTPUT_TYPES')
SUPPORT_OPSET_VERSION = [int(x) for x in CAPACITY.get_value('SUPPORT_OPSET_VERSION')]

CLIBRATION_BIT = 8
QUANT_BIAS_BITS = 32
BASE = 2
EPSILON = 1E-6
ZERO = 0.0
ONE = 1.0
DEFAULT_BN_EPSILON = 1E-5
DEFAULT_BN_MOMENTUM = 0.9

QUANT_LAYER_SUFFIX = ('.quant', '.dequant', '.anti_quant')
CONSTANT_NODE_TYPE = ('Constant', 'initializer', 'sparse_initializer')

# TensorQuantize
TENSOR_QUANTIZABLE_TYPES = CAPACITY.get_value('TENSOR_QUANTIZABLE_TYPES')
