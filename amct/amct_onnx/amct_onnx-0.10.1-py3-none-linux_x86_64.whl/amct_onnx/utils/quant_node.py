#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Information Hepler to cope with different quant related operation

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_onnx.capacity import CAPACITY
from amct_onnx.opset_utils import ConstantUtils
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.weight_quant_api import get_deconv_group


class QuantOpInfo():
    '''
    Find infomation of quant_op.
    '''
    @staticmethod
    def get_scale_shape(node, channel_wise):
        """
        Function: Get the weights' scale's shape of node.
        Inputs:
            node: Node, it's type should be in QUANTIZABLE_TYPES.
            channel_wise: a bool, parameter of quantization.
        Returns:
            shape: a list, the shape of scale.
            scale_length : a number, the length of scale.
        """

        if node.type not in CAPACITY.get_value('QUANTIZABLE_TYPES'):
            raise RuntimeError(
                'Not supported get scale shape from type:%s(%s)' %
                (node.type, node.name))
        if channel_wise and node.type in CAPACITY.get_value(
                'CHANNEL_WISE_TYPES'):
            weight_tensor = QuantOpInfo.get_weight_tensor(node)
            if node.type == 'ConvTranspose':
                # deconv2d or decov3d
                group = get_deconv_group(node)
                length = weight_tensor.dims[1] * group
                shape = [1] * len(weight_tensor.dims)
                shape[1] = length
            else:
                # conv2D or conv3D
                length = weight_tensor.dims[0]
                shape = [1] * len(weight_tensor.dims)
                shape[0] = weight_tensor.dims[0]
        else:
            # matmul and gemm
            length = 1
            shape = []

        return shape, length

    @staticmethod
    def get_quant_index(node):
        """
        Function: get act's index and weight's index of node.
        Inputs:
            node: Node, it's type should be in QUANTIZABLE_TYPES.
        Returns:
            act_index: the act's index in inputs of node.
            weight_index: the weight's index in inputs of node.
        """
        if node.type not in CAPACITY.get_value('QUANTIZABLE_TYPES'):
            raise RuntimeError("%s is not supported." % (node.type))

        quant_indexs = {
            "Conv": [0, 1, 2],
            'ConvTranspose': [0, 1, 2],
            "Gemm": [0, 1, 2],
            "MatMul": [0, 1, None],
            "AveragePool": [0, None, None],
        }

        act_index, weight_index, bias_index = quant_indexs.get(node.type)

        return act_index, weight_index, bias_index

    @staticmethod
    def get_dequant_shape(node):
        """
        Function: Get the dequant scale's shape from node
        Inputs: node: the node te be quantized
        Returns: the shape of dequant scale
        """
        if node.type in ["Gemm", "MatMul", "AveragePool"]:
            dequant_shape = [1, -1]
        elif node.type in ["Conv", "AscendDequant", "ConvTranspose"]:
            dequant_shape = [1, -1, 1, 1]
        else:
            raise RuntimeError("%s is not supported." % (node.type))

        return dequant_shape

    @staticmethod
    def get_weight_node(quantizable_node):
        '''
        Function: Get quantizable_node's weight node
        Parameters:
            quantizable_node: a node, which is quantizable
        Return:
            weight_param: a node, it's quantizable_node' weight
        '''
        _, weight_index, _ = QuantOpInfo.get_quant_index(quantizable_node)

        weight_in_anchor = quantizable_node.get_input_anchor(weight_index)
        weight_param = weight_in_anchor.get_peer_output_anchor().node

        if weight_param.type == 'Transpose':
            weight_in_anchor = weight_param.get_input_anchor(0)
            weight_param = weight_in_anchor.get_peer_output_anchor().node
            quantizable_node.set_attr('with_weights_trans', True)

        return weight_param

    @staticmethod
    def get_bias_node(quantizable_node):
        '''
        Function: Get quantizable_node's bias node
        Parameters:
            quantizable_node: a node, which is quantizable
        Return:
            bias_param: a node, it's quantizable_node' bias
        '''
        if quantizable_node.type == 'MatMul':
            return QuantOpInfo.get_bias_for_matmul(quantizable_node)

        _, _, bias_index = QuantOpInfo.get_quant_index(quantizable_node)
        if bias_index is None or \
                bias_index >= len(quantizable_node.input_anchors):
            return None

        bias_in_anchor = quantizable_node.get_input_anchor(bias_index)
        bias_param = bias_in_anchor.get_peer_output_anchor().node

        return bias_param

    @staticmethod
    def get_bias_for_matmul(matmul_node):
        '''
        Function: Get matmul_node's bias node
        param:matmul_node: a node, which type is MatMul
        return:bias_param: a node, it's quantizable_node' bias. return None when no bias
        '''
        if matmul_node.type != 'MatMul':
            raise TypeError("only support MatMul but {} is {}.".format(matmul_node.name, matmul_node.type))

        weight_node = QuantOpInfo.get_weight_node(matmul_node)
        if weight_node is None or weight_node.type not in ['initializer', 'Constant']:
            return None

        consumers, _ = matmul_node.get_consumers(0)
        if len(consumers) != 1 or consumers[0].type != 'Add':
            return None
        bias_node, _ = consumers[0].get_producer(1)
        if bias_node is None or bias_node.type not in ['initializer', 'Constant']:
            return None

        weight_value = QuantOpInfo.get_node_value(weight_node)
        bias_value = QuantOpInfo.get_node_value(bias_node)
        if len(bias_value.shape) != 1 or bias_value.shape[0] != weight_value.shape[1]:
            return None
        return bias_node

    @staticmethod
    def get_weight_tensor(node):
        '''
        Function: Get quantizable_node's weight node's value tensor
        Parameters:
            quantizable_node: a node, which is quantizable
        Return:
            weight_param: a node, it's quantizable_node' weight
        '''
        weight_node = QuantOpInfo.get_weight_node(node)
        weight_tensor = QuantOpInfo.get_node_tensor(weight_node)
        return weight_tensor

    @staticmethod
    def get_node_tensor(node):
        '''
        Function: Get node's value tensor
        Parameters:
            node: a node, which contain value, usually is initiallizer or constant
        Return:
        '''
        node_type = node.type
        if node_type not in ['initializer', 'Constant']:
            raise RuntimeError("Do not support get tensor from node {} with type {}".format(node.name, node_type))
        if node_type == 'initializer':
            # for 'initializer' type
            node_tensor = node.proto
        else:
            # for 'Constant' type
            constant_util = ConstantUtils(node)
            node_tensor = constant_util.get_attribute_value('value')

        return node_tensor

    @staticmethod
    def get_node_value(node):
        '''
        Function: Get node's value
        Parameters:
            node: a node, which contain value, usually is initiallizer or constant
        Return:
        '''
        node_tensor = QuantOpInfo.get_node_tensor(node)
        tensor_helper = TensorProtoHelper(node_tensor)
        node_value = tensor_helper.get_data()

        return node_value

    @staticmethod
    def get_cin_length(node):
        """
        Function: Get cin length of the given node
        Parameter: node
        Return: cin_length
        """
        if node.type not in CAPACITY.get_value('QUANTIZABLE_TYPES'):
            raise RuntimeError("Unexpected node's type {} for {}".format(node.type, node.name))
        cin_length = None
        tensor = QuantOpInfo.get_weight_tensor(node)
        if node.type == 'Conv':
            group = get_deconv_group(node)
            cin_length = tensor.dims[1] * group
        elif node.type == 'ConvTranspose':
            cin_length = tensor.dims[0]
        elif node.type == 'MatMul':
            if node.has_attr('with_weights_trans') and \
                node.get_attr('with_weights_trans'):
                cin_length = tensor.dims[1]
            else:
                cin_length = tensor.dims[0]
        elif node.type == 'Gemm':
            attr_helper = AttributeProtoHelper(node.proto)
            if not attr_helper.has_attr('transB') or attr_helper.get_attr_value('transB') == 0:
                cin_length = tensor.dims[0]
            else:
                cin_length = tensor.dims[1]
        return cin_length
