#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Tools for compile amct_onnx_op.so with setup.

"""
import os
from distutils.extension import Extension

import setuptools
from setuptools.command.build_ext import build_ext


CUD_DIR = os.path.split(os.path.realpath(__file__))[0]
AMCT_DIR = os.path.join(CUD_DIR, "../")
AMCT_LIB_DIR = os.path.join(AMCT_DIR, "lib")


def create_cuda_extension(sources, *args, **kwargs):
    '''
    Creates a :class:`setuptools.Extension` for CUDA.
    All arguments are forwarded to the :class:`setuptools.Extension`
    constructor.
    '''
    name = 'amct_onnx_ops'
    library_dirs = kwargs.get('library_dirs', [])
    kwargs['library_dirs'] = library_dirs
    include_dirs = kwargs.get('include_dirs', [])
    kwargs['include_dirs'] = include_dirs
    kwargs['language'] = 'c++'
    extra_compile_args = kwargs.get('extra_compile_args', [])
    extra_compile_args['gcc'] += [
        '-D_GNU_SOURCE', '-DUSE_C3_ENGINE', '-g', '-O3', '-Wall', '-fPIC',
        '-std=c++11', '-fopenmp', '-D_GLIBCXX_USE_CXX11_ABI=0'
    ]
    kwargs['extra_compile_args'] = extra_compile_args
    extra_link_args = kwargs.get('extra_link_args', [])
    extra_link_args += [
        '-Wl,-z,noexecstack', '-fopenmp',
        '-Wl,-rpath,%s' % (AMCT_LIB_DIR)
    ]
    kwargs['extra_link_args'] = extra_link_args

    library_dirs = kwargs.get('library_dirs', [])
    library_dirs += [AMCT_LIB_DIR]
    kwargs['library_dirs'] = library_dirs

    libraries = kwargs.get('libraries', [])
    libraries += ['pthread', 'rt', 'c', 'dl', 'stdc++', 'quant_onnx']
    kwargs['libraries'] = libraries

    return Extension(name, sources, *args, **kwargs)



def create_cpp_extension(sources, *args, **kwargs):
    '''
    Creates a :class:`setuptools.Extension` for C++.
    All arguments are forwarded to the :class:`setuptools.Extension`
    constructor.
    '''
    name = 'amct_onnx_ops'
    kwargs['language'] = 'c++'

    extra_compile_args = kwargs.get('extra_compile_args', [])
    extra_compile_args += [
        '-D_GNU_SOURCE', '-DUSE_C3_ENGINE', '-g', '-O3', '-Wall', '-fPIC',
        '-std=c++11', '-fopenmp', '-D_GLIBCXX_USE_CXX11_ABI=0'
    ]
    kwargs['extra_compile_args'] = extra_compile_args

    extra_link_args = kwargs.get('extra_link_args', [])
    extra_link_args += [
        '-Wl,-z,relro,-z,now', '-Wl,-z,noexecstack', '-fopenmp',
        '-Wl,-rpath,%s' % (AMCT_LIB_DIR)
    ]
    kwargs['extra_link_args'] = extra_link_args

    library_dirs = kwargs.get('library_dirs', [])
    library_dirs += [AMCT_LIB_DIR]
    kwargs['library_dirs'] = library_dirs

    libraries = kwargs.get('libraries', [])
    libraries += ['pthread', 'rt', 'c', 'dl', 'stdc++', 'quant_onnx']
    kwargs['libraries'] = libraries

    return setuptools.Extension(name, sources, *args, **kwargs)


def setup(ext_modules):
    """Compile modules """
    setuptools.setup(name='amct_onnx_ops',
                     ext_modules=ext_modules,
                     cmdclass={'build_ext': build_ext})
