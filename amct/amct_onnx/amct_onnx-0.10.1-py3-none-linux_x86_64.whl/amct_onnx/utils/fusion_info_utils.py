#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

fusion info util

"""
from amct_onnx.common.utils.attrs_list import ATTR_NODE_FUSION_INFO
from amct_onnx.common.utils.attrs_list import ATTR_NODE_OUTPUT_NODE
from amct_onnx.common.utils.attrs_list import ATTR_NODE_EQUIVALENT_OBJECT_LAYER
from amct_onnx.common.utils.attrs_list import ATTR_NODE_EQUIVALENT_INPUT
from amct_onnx.common.utils.attrs_list import ATTR_NODE_EQUIVALENT_OUTPUT


def add_fusion_info_attr(pre_nodes, post_nodes, ori_output):
    """
    Function: Add atrr for fusion, if pre_nodes + post_nodes => pre_nodes,
        this function can be simplely used.
    """
    # add fusion ops to pre_nodes
    if not pre_nodes.has_attr(ATTR_NODE_FUSION_INFO):
        pre_nodes.set_attr(ATTR_NODE_FUSION_INFO, [pre_nodes.name])
    fusion_info = pre_nodes.get_attr(ATTR_NODE_FUSION_INFO)
    for post_node in post_nodes:
        if post_node.has_attr(ATTR_NODE_FUSION_INFO):
            fusion_info.extend(post_node.get_attr(ATTR_NODE_FUSION_INFO))
        else:
            fusion_info.append(post_node.name)
    pre_nodes.set_attr(ATTR_NODE_FUSION_INFO, fusion_info)

    # add ori output to pre_nodes
    if ori_output.has_attr(ATTR_NODE_OUTPUT_NODE):
        ori_output_name = ori_output.get_attr(ATTR_NODE_OUTPUT_NODE)
    else:
        ori_output_name = ori_output.name
    pre_nodes.set_attr(ATTR_NODE_OUTPUT_NODE, ori_output_name)


def add_equivalent_info_attr(object_node, insert_nodes, new_input, new_output):
    """
    Function: Add atrr for equivalent fusion info. This function can be
        simplely used if object_node => object_node + post_nodes, for example,
        after InsertQuantPass conv1 => conv + conv.quant
    """
    for node in insert_nodes:
        node.set_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER, object_node.name)
    if new_input:
        object_node.set_attr(ATTR_NODE_EQUIVALENT_INPUT, new_input.name)
    if new_output:
        object_node.set_attr(ATTR_NODE_EQUIVALENT_OUTPUT, new_output.name)
