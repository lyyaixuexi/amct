#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Ctypes APIs for arq_quant algorithm

"""

import numpy as np
from amct_onnx.lib.load_library import Load
from amct_onnx.algo.wts_quant_algo import WEIGHTS_QUANT_ALGO
from amct_onnx.common.algo.weight_quant_api import WtsPtqBase
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
DEFAULT_WITH_OFFSET = False


class WtsPtq(WtsPtqBase):
    """ class WtsPtq"""
    def __init__(self):
        device_mode = 'CPU'
        super().__init__(device_mode, Load())


def weight_calibration_np(numpy_data, wts_param):
    """
    Function: warpper of arq_quant_np and nuq_quant_np
    Parameter: numpy_data: data to be quantized as numpy array
               wts_param: weight quantize algorithm parameter
    Return: scale: scale of input data
            offset: offset of input data
    """
    return WtsPtq().weight_calibration_np(
        numpy_data, wts_param, WEIGHTS_QUANT_ALGO)


def weights_quantize_np(numpy_data, scale, offset, num_bits=8):
    """
    Function: warpper of weights quantize of numpy
    Parameter: numpy_array: data to be quantized as numpy array
               scale: scale of input data
               offset: offset of input data
    Return: int8_data: quantized int8 data
    """
    return WtsPtq().weights_quantize_np(numpy_data, scale, offset, num_bits)


def get_deconv_group(node_deconv):
    """Get ConvTranspose's group param value"""
    attrs_helper = AttributeProtoHelper(node_deconv.proto)
    if not attrs_helper.has_attr('group'):
        raise RuntimeError("can not get the 'group' attr of {}".format(node_deconv.name))
    group = attrs_helper.get_attr_value('group')
    return group


def adjust_deconv_weight_shape(node_deconv, weights_array):
    """Adjust ConvTranspose weight shape to fit group param """
    group = get_deconv_group(node_deconv)
    if group == 1:
        weights_array = weights_array.transpose((1, 0, 2, 3))
        return weights_array
    weight_shape = weights_array.shape
    new_shape = tuple([group, -1] + list(weight_shape)[1:])
    weights_array = np.reshape(weights_array, new_shape)

    weights_array = np.transpose(weights_array, (0, 2, 1, 3, 4))

    weight_shape = weights_array.shape
    new_shape = tuple([-1] + list(weight_shape)[2:])
    weights_array = np.reshape(weights_array, new_shape)

    return weights_array


def adjust_conv_weight_shape(node, weights):
    """Adjust Conv weight shape to fit group param """
    group = get_deconv_group(node)
    if group == 1:
        if len(weights.shape) == 4:
            weights = weights.transpose((1, 0, 2, 3))
        else:
            weights = weights.transpose((1, 0, 2, 3, 4))
        return weights
    weight_shape = weights.shape
    new_shape = tuple([group, -1] + list(weight_shape)[1:])
    weights = np.reshape(weights, new_shape)
    if len(weights.shape) == 5:
        weights = np.transpose(weights, (0, 2, 1, 3, 4))
    else:
        weights = np.transpose(weights, (0, 2, 1, 3, 4, 5))
    weight_shape = weights.shape
    new_shape = tuple([-1] + list(weight_shape)[2:])
    weights = weights.reshape(new_shape)
    return weights
