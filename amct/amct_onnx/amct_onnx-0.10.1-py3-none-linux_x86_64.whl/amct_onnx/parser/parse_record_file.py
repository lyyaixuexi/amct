#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Parse record file.
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_onnx.proto import scale_offset_record_pb2
from amct_onnx.capacity import CAPACITY
from amct_onnx.common.utils.parse_record_file import RecordFileParserBase
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.configuration.check import GraphQuerier
from amct_onnx.configuration.configuration import Configuration

CONFIG_GLOBAL_PARAM = [
    "version", "batch_num", 'activation_offset', "do_fusion",
    "skip_fusion_layers", 'joint_quant', 'tensor_quantize'
]

__all__ = ["RecordFileParser"]


class RecordFileParser(RecordFileParserBase):
    """
    Function: Parse the information of compression from record_file.
    APIs: read_record_file, parse
    """
    def __init__(self, record_file, graph, model_name):
        """
        Function: init object
        Inputs:
            record_file: a string, the file to parse.
            graph: Graph, the graph corresponding to record_file.
            model_name: a string, the model's name.
        """
        capacity = {
            'QUANTIZABLE_TYPES':
            CAPACITY.get_value('QUANTIZABLE_TYPES'),
            'FUSE_TYPES':
            CAPACITY.get_value('FUSE_TYPES'),
            'NO_WEIGHT_QUANT_TYPES':
            CAPACITY.get_value('NO_WEIGHT_QUANT_TYPES'),
            'SHIFT_N_TYPES':
            CAPACITY.get_value('SHIFT_N_TYPES'),
        }
        config = {
            "capacity": capacity,
            "op_quirer": QuantOpInfo,
            "graph_querier": GraphQuerier,
            "graph_checker": None,
            "records_pb2": scale_offset_record_pb2,
        }
        RecordFileParserBase.__init__(self, record_file, graph, model_name,
                                      config)

    @staticmethod
    def cmp_config(records):
        """
        Function: compare records with quant config in quantizable layers
        Inputs:
            records: a dict containing quant factors
        Returns: None
        """
        conf_quant_layers = Configuration().get_quant_config().keys()
        has_tensor_quantize = Configuration().get_quant_config().get('tensor_quantize')
        tensor_quantize_layers = []
        if has_tensor_quantize:
            for tensor_config in has_tensor_quantize:
                tensor_name = ':'.join([tensor_config.get('layer_name'), str(tensor_config.get('input_index'))])
                tensor_quantize_layers.append(tensor_name)

        for layer in records:
            if layer not in conf_quant_layers and \
                layer not in tensor_quantize_layers:
                raise RuntimeError(
                    "{} is not quantizable in config".format(layer))

        for layer in conf_quant_layers:
            if layer not in CONFIG_GLOBAL_PARAM and layer not in records:
                raise RuntimeError(
                    "{} is quantizable in config but has no record "
                    "in record_file".format(layer))
