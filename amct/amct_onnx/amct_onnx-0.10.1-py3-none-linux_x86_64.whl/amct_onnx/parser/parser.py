#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Parse to parse onnx model

"""
import os
import pathlib
import onnx

from onnx import onnx_pb
from amct_onnx.utils.log import LOGGER
from amct_onnx.graph.graph import Graph
from amct_onnx.parser.opset_context import OpsetContext
from amct_onnx.utils.vars import SUPPORT_OPSET_VERSION


class Parser:
    """ Helper of onnx file
    """
    @staticmethod
    def parse_proto(proto_file):
        """ parse the onnx pb pb file to """
        proto_file_path = pathlib.Path(proto_file)
        # parse by proto
        if not proto_file_path.is_file():
            raise ValueError('The input onnx pb file {} is not exist.'.format(proto_file))

        if isinstance(proto_file, str):
            proto_file = os.path.realpath(proto_file)
            try:
                onnx.checker.check_model(proto_file)
            except Exception as e:
                LOGGER.logd(repr(e))
            with open(proto_file, 'rb') as onnx_pb_file:
                onnx_pb_str = onnx_pb_file.read()
                model = onnx_pb.ModelProto()
                model.ParseFromString(onnx_pb_str)
                LOGGER.logd('Parse onnx model from %s success.' % (proto_file))
                return model
        else:
            raise TypeError('Unsupport proto type: "%s"' % (type(proto_file)))

    @staticmethod
    def parse_net_to_graph(proto_file, update_node=True):
        """" parse the onnx pb graph to inner graph,
        """
        model = Parser.parse_proto(proto_file)
        opset_context = OpsetContext()
        # check opset
        for opset in model.opset_import:
            if opset.HasField('domain') and \
                opset.domain not in ['', "ai.onnx"]:
                raise RuntimeError(
                    "onnx model's opset_import.domain must be ai.onnx "
                    "but is {}.".format(opset.domain))
            if not opset.HasField('version'):
                raise RuntimeError(
                    "onnx model's opset_import.version is missing.")
            if opset.version not in SUPPORT_OPSET_VERSION:
                raise RuntimeError(
                    "onnx model's opset_import.version must be in {} but is {}.".
                    format(SUPPORT_OPSET_VERSION, opset.version))
            # set the opset version
            opset_context.set_version(opset.version)
        graph = Graph(model, update_node)
        return graph
