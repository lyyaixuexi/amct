#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

amct_onxx custom op of onnxruntime

"""
import os
import onnxruntime as ort

from amct_onnx.utils.log import LOGGER

CUR_DIR = os.path.split(os.path.realpath(__file__))[0]
SHARED_LIBRARY = os.path.join(CUR_DIR, 'libamct_onnx_ops.so')


def amct_so():
    """Load AMCT custom op library
    """
    ort_sess = ort.SessionOptions()
    if not os.path.exists(SHARED_LIBRARY) or \
            not os.path.getsize(SHARED_LIBRARY):
        LOGGER.logw('amct custom op library is empty, build it first.')
        return None

    try:
        ort_sess.register_custom_ops_library(SHARED_LIBRARY)
    except Exception as e:
        LOGGER.logw('{}'.format(e))
        return None
    return ort_sess


AMCT_SO = amct_so()
