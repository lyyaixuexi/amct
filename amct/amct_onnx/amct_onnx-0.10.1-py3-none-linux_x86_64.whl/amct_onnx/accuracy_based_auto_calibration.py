#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

the accuracy based auto calibration main API

"""
import os
import copy
import json
from collections import OrderedDict

import amct_onnx.quantize_tool as quantize_tool
from amct_onnx.common.utils.check_params import check_params
from amct_onnx.common.utils import files as files_util
from amct_onnx.common.auto_calibration import SensitivityBase
from amct_onnx.common.auto_calibration import AutoCalibrationStrategyBase
from amct_onnx.common.auto_calibration import AutoCalibrationEvaluatorBase
from amct_onnx.common.auto_calibration import AccuracyBasedAutoCalibrationBase
from amct_onnx.common.auto_calibration import BinarySearchStrategy
from amct_onnx.common.auto_calibration import CosineSimilaritySensitivity
from amct_onnx.configuration.configuration import Configuration
from amct_onnx.parser.parser import Parser
from amct_onnx.utils.auto_calibration_helper import AutoCalibrationHelper
from amct_onnx.utils.auto_calibration_helper import inner_fuse_model
from amct_onnx.utils.auto_calibration_helper import inner_quantize_model
from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.save import split_dir_prefix
from amct_onnx.utils.save import generate_onnx_file_name


AUTO_CALI_SATISFY = 0
AUTO_CALI_KEEP_SEARCH = 1

__all__ = ['accuracy_based_auto_calibration']


class AccuracyBasedAutoCalibration(AccuracyBasedAutoCalibrationBase):
    """ the class for accuracy_based_auto_calibration API"""
    def __init__(self,
                 model_file,
                 model_evaluator,
                 strategy,
                 config_file,
                 record_file,
                 save_dir,
                 sensitivity):
        """ init function for class AccuracyBasedAutoCalibration
        Parameters:
                model_file: the onnx model file of onnx model
                record_file: the scale and offset record file dir
                model_evaluator: the user implemented evaluator instance
                config_file: the quant config json file
                save_dir: prefix of filename of save model
        """
        super().__init__(
            record_file,
            config_file,
            save_dir,
            model_evaluator,
            strategy,
            sensitivity)
        self.model_file = os.path.realpath(model_file)
        self.fake_quant_model = None
        self.quant_layers = []
        self.original_quant_config = None
        self.ranking_info = None
        self.auto_calibration_helper = None
        self.original_graph = None
        self.final_config = None
        self.tmp_quant_config = None
        self.tmp_config_file = os.path.join(self.temp_dir, 'tmp_roll_back_config.json')

    @staticmethod
    def get_quant_enable_layers(quant_config):
        """ find the quant enable layers from quant config"""
        quant_enable_layers = []
        for key, value in quant_config.items():
            if isinstance(value, dict) and value['quant_enable']:
                quant_enable_layers.append(key)
        return quant_enable_layers

    def get_original_accuracy(self):
        """ get orginal_metrics and test eval model """
        self.original_accuracy = self.evaluator.evaluate(self.model_file)
        LOGGER.logi("original evaluation accurcay: {}".format(
            self.original_accuracy), 'auto_calibration')
        return self.original_accuracy

    def get_global_quant_accuracy(self):
        """ do the calibration and get accuracy of fake quant model """
        file_realpath = files_util.create_empty_file(
            self.record_file)
        self.original_graph = Parser.parse_net_to_graph(self.model_file)
        Configuration().init(self.config_file,
                             file_realpath,
                             self.original_graph)
        # do the calibration and get the metric of all quant fake quant model
        # when insert quant layer pass, it will filter the global average
        # pooling layer, so the updated quant config is basic quant config
        global_quant_accuracy = self.global_calibration()
        quant_config = Configuration().get_quant_config()
        self.original_quant_config = quant_config
        # record the layers that need quantization
        self.quant_layers = \
            AccuracyBasedAutoCalibration.get_quant_enable_layers(quant_config)
        roll_back_config = OrderedDict()
        for layer in self.quant_layers:
            roll_back_config[layer] = True
        record = {
            'roll_back_config': roll_back_config,
            'metric_eval': self.evaluator.metric_eval(
                self.original_accuracy, global_quant_accuracy)
        }
        self.final_config = roll_back_config
        self.history_records.append(record)
        return global_quant_accuracy

    def global_calibration(self):
        """ do the calibration without joint quantization"""
        # do the calibration and save fake quant deploy model
        modified_model_file = self.generate_tmp_file_path('modified_model.onnx')

        graph = self.original_graph.deep_copy()
        # generate a quantize model
        inner_quantize_model(
            graph,
            self.config_file,
            modified_model_file,
            self.record_file,
            self.temp_dir)
        # activation calibration process
        self.evaluator.calibration(
            modified_model_file)
        quantize_tool.save_model(
            modified_model_file, self.record_file, self.save_dir)

        # evaluate the generated fake quant model
        save_path, save_prefix = split_dir_prefix(self.save_dir)
        self.fake_quant_model = generate_onnx_file_name(
            save_path, save_prefix, 'Fakequant')
        current_accuracy = self.evaluator.evaluate(
            self.fake_quant_model)
        LOGGER.logi(
            "global calibration accuracy: {}".format(
                current_accuracy), 'auto_calibration')

        return current_accuracy

    def generate_tmp_file_path(self, file_name):
        """ generate the file path for modified model, fused model"""
        file_path = os.path.join(self.temp_dir, file_name)
        return file_path

    def get_ranking_info(self):
        """ get the ranking infomation of accuracy based auto calibration"""
        to_fuse_graph = self.original_graph.deep_copy()
        # generate the fused onnx model file file for
        # single layer and single fake quant layer cosine similarity compare
        fused_model_file = self.generate_tmp_file_path('fused_model.onnx')
        inner_fuse_model(to_fuse_graph, fused_model_file)

        auto_calibration_helper = AutoCalibrationHelper(
            fused_model_file,
            self.fake_quant_model,
            self.quant_layers,
            self.record_file,
            self.temp_dir,
            self.sensitivity)
        ranking_info = auto_calibration_helper.calc_ranking_info()
        self.ranking_info = ranking_info
        return ranking_info

    def roll_back_and_evaluate_model(self, roll_back_config):
        """ generate the roll-back fake quant model and evaluate
            the fake quant model
        """
        # turn down the joint quant in auto calibration
        quant_config = copy.deepcopy(self.original_quant_config)
        for key, value in roll_back_config.items():
            if not value:
                del quant_config[key]
        if self.tmp_quant_config is None:
            with open(self.config_file, 'r') as config_file:
                self.tmp_quant_config = json.load(config_file)
        for key, value in roll_back_config.items():
            self.tmp_quant_config[key]['quant_enable'] = value

        with open(self.tmp_config_file, 'w') as config_file:
            config_file.write(json.dumps(
                self.tmp_quant_config, sort_keys=False, indent=4,
                separators=(',', ':'), ensure_ascii=False))

        modified_model_file = self.generate_tmp_file_path(
            'modified_model.onnx')

        quantize_tool.quantize_model(
            self.tmp_config_file, self.model_file,
            modified_model_file, self.record_file)
        # activation calibration process
        self.evaluator.calibration(modified_model_file)
        quantize_tool.save_model(
            modified_model_file, self.record_file, self.save_dir)
        current_fq_metric = self.evaluator.evaluate(
            self.fake_quant_model)
        return current_fq_metric


@check_params(model_file=str, config_file=str,
              record_file=str, save_dir=str)
def accuracy_based_auto_calibration(model_file,
                                    model_evaluator,
                                    config_file,
                                    record_file,
                                    save_dir,
                                    strategy='BinarySearch',
                                    sensitivity='CosineSimilarity'):
    """
    Function:
            calibration the input model automatically, decide which layers need
            to roll back and save the final quantized model
            (fake quant and deploy models)
    Parameters:
            model_file: the onnx model file of onnx model
            model_evaluator: the user implemented evaluator instance
            config_file: the quant config json file
            record_file: the scale and offset record file path
            save_dir: prefix of filename of save model
            strategy: union [str, BinarySearchStrategy] the instance of
                    strategy to control the search process,
                    set 'BinarySearch' to use default value
            sensitivity: union [str, CosineSimilaritySensitivity] the instance
                    of sensitivity to measure the quant
                    sensitivity of quantable layers, set 'CosineSimilarity'
                    to use default value
    """

    if strategy == 'BinarySearch':
        strategy = BinarySearchStrategy()
    else:
        if not isinstance(strategy, AutoCalibrationStrategyBase):
            raise RuntimeError(
                "strategy is not inherited from base class "
                "AutoCalibrationStrategyBase")

    if sensitivity == 'CosineSimilarity':
        sensitivity = CosineSimilaritySensitivity()
    else:
        if not isinstance(sensitivity, SensitivityBase):
            raise RuntimeError(
                "sensitivity is not inherited from base class SensitivityBase")

    files_util.check_file_path(model_file, 'model_file')
    files_util.check_file_path(config_file, 'config_file')
    if not isinstance(model_evaluator, AutoCalibrationEvaluatorBase):
        raise RuntimeError(
            "the model evaluator is not inherited from base class "
            "AutoCalibrationEvaluatorBase")

    auto_calibration_controller = AccuracyBasedAutoCalibration(
        model_file, model_evaluator, strategy,
        config_file, record_file, save_dir, sensitivity)
    auto_calibration_controller.run()
