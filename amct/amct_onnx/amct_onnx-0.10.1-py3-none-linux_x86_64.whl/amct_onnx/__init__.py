#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0
"""


from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os

from amct_onnx.quantize_tool import create_quant_config
from amct_onnx.quantize_tool import quantize_preprocess
from amct_onnx.quantize_tool import quantize_model
from amct_onnx.quantize_tool import save_model
from amct_onnx.convert_model import convert_qat_model
from amct_onnx.accuracy_based_auto_calibration import accuracy_based_auto_calibration
from amct_onnx.perf_based_auto_calibration import perf_based_auto_calibration
from amct_onnx.custom_op.amct_custom_op import AMCT_SO
from amct_onnx.common.auto_calibration.auto_calibration_evaluator_base\
        import AutoCalibrationEvaluatorBase as CalibrationEvaluatorBase


__all__ = [
    'create_quant_config',
    'quantize_preprocess',
    'quantize_model',
    'save_model',
    'convert_qat_model',
    'accuracy_based_auto_calibration',
    'perf_based_auto_calibration',
    '__version__'
]

CUR_DIR = os.path.split(os.path.realpath(__file__))[0]


with open(os.path.join(CUR_DIR, '.version')) as fid:
    __version__ = fid.readlines()[0].strip()
