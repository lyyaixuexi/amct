#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Common function used by other modules.

"""

import stat
import numpy as np

# mode is 640
FILE_MODE = stat.S_IRUSR + stat.S_IWUSR + stat.S_IRGRP
# mode is 750
DIR_MODE = stat.S_IRWXU + stat.S_IRGRP + stat.S_IXGRP


def find_repeated_items(items):
    '''find repeated items in a list '''
    repeat_items = set()
    for item in items:
        count = items.count(item)
        if count > 1:
            repeat_items.add(item)

    return list(repeat_items)


def check_no_repeated(items, name):
    '''raise error when item is not empty'''
    if items:
        raise ValueError("Please delete repeated items in %s, "
                         "repeated items are %s " % (name, items))


def proto_float_to_python_float(value):
    '''transform proto float to python float'''
    val_fp32 = np.float32(value)
    return float(str(val_fp32))


def is_invalid(value_array):
    ''' whether there's inf or nan in value_array'''
    is_array_invalid = np.isnan(value_array) | np.isinf(value_array)
    return is_array_invalid.any()
