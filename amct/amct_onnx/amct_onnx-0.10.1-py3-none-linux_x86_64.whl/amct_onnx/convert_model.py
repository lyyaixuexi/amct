#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Convert ONNX QAT model to Ascend 'fake_quant' model and 'deploy' model.
The 'fake_quant' model can be used to inference in onnx runtime.
The 'deploy' model can be transfered to be deployed on the core by OMG Tools.
"""


import os

from amct_onnx.common.utils.log_base import LOG_FILE_DIR
from amct_onnx.common.utils.check_params import check_params
from amct_onnx.common.utils import files as files_util
from amct_onnx.common.utils.record_file_operator import ScaleOffsetRecordHelper

from amct_onnx.configuration.configuration import GraphChecker

import amct_onnx.optimizer as opt

from amct_onnx.parser.parser import Parser
from amct_onnx.parser.parse_record_file import RecordFileParser

from amct_onnx.proto import scale_offset_record_pb2

from amct_onnx.utils.save import generate_onnx_file_name
from amct_onnx.utils.save import split_dir_prefix
from amct_onnx.utils.save import save_onnx_model


@check_params(model_file=str, save_path=str, record_file=(type(None), str))
def convert_qat_model(model_file, save_path, record_file=None):
    """Convert from qat model"""
    if record_file is None:
        record_file = os.path.join(LOG_FILE_DIR, 'scale_offset_record.txt')
    os.makedirs(os.path.split(record_file)[0], exist_ok=True)

    graph = Parser.parse_net_to_graph(model_file)
    GraphChecker.check_quant_behaviours(graph)
    GraphChecker.check_convert_behaviours(graph)
    record_helper = ScaleOffsetRecordHelper(scale_offset_record_pb2.ScaleOffsetRecord)

    optimizer = opt.GraphOptimizer()
    optimizer.add_pass(opt.DeleteFakeQuantNodePass(graph, record_helper))
    optimizer.add_pass(opt.ConvAddBiasFusionPass(record_helper))
    optimizer.add_pass(opt.ConvBnFusionPass(record_helper))
    optimizer.do_optimizer(graph)

    files_util.check_files_exist([record_file])
    record_helper.dump(record_file)

    save_dir, save_prefix = split_dir_prefix(save_path)
    files_util.create_path(save_dir)
    # parse record_file
    record_parser = RecordFileParser(record_file, graph, '')

    deploy_file = generate_onnx_file_name(save_dir, save_prefix, 'Deploy')
    fakequant_file = generate_onnx_file_name(save_dir, save_prefix, 'Fakequant')

    if record_parser.is_records_empty():
        raise RuntimeError(
            "record_file is empty, no layers to be converted. "
            "please ensure convert is finished by checking information!")

    records, _ = record_parser.parse(enable_shift_n=False)

    # generate and save deploy model
    optimizer = opt.GraphOptimizer()
    optimizer.add_pass(opt.GemmTransBOptimizePass(records))
    optimizer.add_pass(opt.InsertQuantPass(records))
    optimizer.add_pass(opt.InsertDequantPass(records))
    optimizer.add_pass(opt.QuantFusionPass(records))
    optimizer.add_pass(opt.WeightQuantPass(records))
    optimizer.add_pass(opt.BiasQuantPass(records))
    optimizer.do_optimizer(graph)
    save_onnx_model(graph, deploy_file)

    # generate and save fakequant model
    optimizer = opt.GraphOptimizer()
    optimizer.add_pass(opt.UpdateAscendOpPass())
    optimizer.add_pass(opt.WeightFakequantPass(records))
    optimizer.add_pass(opt.BiasFakequantPass(records))
    optimizer.do_optimizer(graph)
    save_onnx_model(graph, fakequant_file)
