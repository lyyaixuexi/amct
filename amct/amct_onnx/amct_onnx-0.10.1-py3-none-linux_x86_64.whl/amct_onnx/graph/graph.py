#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Data structure of graph which contains graph topologic info

"""
from onnx import onnx_pb

from amct_onnx.utils.log import LOGGER
from amct_onnx.common.graph_base.graph_base import GraphBase
from amct_onnx.graph.node import Node


class Graph(GraphBase):
    """
    Function: Data structure of graph IR
    APIs: add_node, remove_node, net, dump_proto
    """
    def __init__(self, network, update_node=True):
        """init graph from network"""
        super().__init__(network)
        self._net = network
        self._update_node = update_node
        self._init_graph()
        self.topologic_sort()

    @property
    def net(self):
        """Return onnx_pb.ModelProto of graph
        """
        return self._net

    def get_graph_input_by_name(self, input_name):
        """only get initializer by name"""
        for node in self._nodes:
            if node.type != 'graph_input':
                continue
            if node.proto.name == input_name:
                return node
        raise RuntimeError('Cannot find initializer "%s" in file.' %
                           (input_name))

    def add_node(self, node_proto, index=None):
        """
        Function: Add node that constructed from node_proto to graph
        Parameter: None
        Return: Node that be added
        """
        # Set node_id to be unique by decorate_node_name function
        if isinstance(node_proto, onnx_pb.SparseTensorProto):
            if node_proto.HasField('indices'):
                node_id = node_proto.indices.name
                node_proto.indices.name = self._decorate_node_name(node_id)
            elif node_proto.HasField('values'):
                node_id = node_proto.values.name
                node_proto.values.name = self._decorate_node_name(node_id)
            else:
                raise RuntimeError('Cannot find tensor in sparse_initializer')
        else:
            node_id = node_proto.name
            node_proto.name = self._decorate_node_name(node_id)
        # Generate node to graph
        node = Node(self._tail, node_proto)
        if index is not None:
            self._nodes.insert(index, node)
        else:
            self._nodes.insert(0, node)
        LOGGER.logd('Add node "%s" to graph success.' % (node.name), 'Graph')
        return node

    def remove_node(self, delete_node):
        """
        Function: Remove operation node from graph
        Parameter: None
        Return: None
        """
        remove_done_flag = False
        for index, node in enumerate(self._nodes):
            if node == delete_node:
                if isinstance(node.proto, onnx_pb.ValueInfoProto):
                    raise RuntimeError('Cannot remove ValueInfoProto node ' \
                        '%s from graph.' % (node.name))
                del self._nodes[index]
                remove_done_flag = True
                LOGGER.logd('Remove node "%s" from graph success.' %
                            (delete_node.name))
                break
        if not remove_done_flag:
            raise RuntimeError('Remove %s from graph failed, cannot found' %
                               (delete_node.name))

    def remove_initializer(self, delete_node):
        """
        Function: Remove initializer node from graph
        Parameter: delete_node, the node to be removed
        Return: None
        """
        remove_done = False
        for index, node in enumerate(self._nodes):
            if node == delete_node:
                if not isinstance(node.proto, onnx_pb.TensorProto):
                    raise RuntimeError('Cannot only remove initializer node ' \
                        'from graph by this api. "%s" is "%s"' % (node.name, \
                        node.type))
                if delete_node.get_output_anchor(0).get_peer_input_anchor():
                    LOGGER.logd('Node "%s" still connect to other node, cannot'
                                'remove it now.' % (delete_node.name))
                    return
                del self._nodes[index]

                initializer_name = node.ori_name
                for i, del_node in enumerate(self._nodes):
                    if isinstance(del_node.proto, onnx_pb.ValueInfoProto) and \
                            del_node.ori_name == initializer_name:
                        del self._nodes[i]

                remove_done = True
                LOGGER.logd('Remove node "%s" from graph success.' %
                            (delete_node.name))
                break
        if not remove_done:
            raise RuntimeError('Remove %s from graph failed, cannot found' %
                               (delete_node.name))

    def dump_proto(self):
        """Dump all nodes and weights of graph to onnx_pb.ModelProto format
        """
        LOGGER.logi('Doing whole model dump...', module_name='Graph')
        self.topologic_sort()

        net = onnx_pb.ModelProto()
        net.CopyFrom(self._net)
        graph = net.graph
        for node in self._nodes:
            if isinstance(node.proto, onnx_pb.NodeProto):
                node_proto = graph.node.add()
                node_proto.CopyFrom(node.dump_proto())
            elif isinstance(node.proto, onnx_pb.SparseTensorProto):
                sparse = graph.sparse_initializer.add()
                sparse.CopyFrom(node.dump_proto())
            elif isinstance(node.proto, onnx_pb.TensorProto):
                tensor = graph.initializer.add()
                tensor.CopyFrom(node.dump_proto())
            elif isinstance(node.proto, onnx_pb.ValueInfoProto):
                if node.type == 'graph_input':
                    # refresh graph inputs
                    inputs = graph.input.add()
                    inputs.CopyFrom(node.dump_proto())
                else:
                    continue
            else:
                raise TypeError("Unexcepted node_proto %s! only [NodeProto, "
                                "TensorProto, SparseTensorProto] are "
                                "supporetd." % (type(node.proto)))
        return net


    def deep_copy(self):
        """
        Function: Make a copy of current graph
        Parameter: None
        Return: Graph's copy
        """
        copy_net = self.dump_proto()
        copy_graph = Graph(copy_net)
        return copy_graph


    def insert_node_after(self, node, in_idx, out_idx,
                          pre_node, pre_out_idx):
        """
        Function: Insert node after pre_node as follows, so
        node.intput[in_idx] is link to producer[*] and node.output[out_idx]
        is link to post_node.input[post_in_idx]
                    pre_node          pre_node
                      / \\      -->      |
                 node1   node2          node
                                        / \
                                    node1  node2
        Parameter:
            node: Node, node to be insert
            in_idx: int, which input will to be linked producer
            out_idx: int, which input will to be linked post_node
            post_node: Node, node to be insert before it
            post_in_idx: int, which input to insert node
        Return: None
        """
        super().insert_node_after(node, in_idx, out_idx, pre_node, pre_out_idx)

        # modify outputs is necessary
        consumers, _ = node.get_consumers(out_idx)
        for consumer in consumers:
            if consumer.type == 'graph_output':
                pre_node_out_anchor = pre_node.get_output_anchor(pre_out_idx)
                new_name = '{}_output{}'.format(pre_node.name, pre_out_idx)
                pre_node_out_anchor.set_name(new_name)
                node.get_output_anchor(out_idx).set_name(consumer.name)


    def delete_node(self, node, in_idx, out_idx):
        """
        Function: Insert node after pre_node as follows, so
        node.intput[in_idx] is link to producer[*] and node.output[out_idx]
        is link to post_node.input[post_in_idx]
                    pre_node           pre_node
                       |                /  \
                     node     -->   node1  node2
                      / \\
                 node1   node2

        Parameter:
            node: Node, node to be insert
            in_idx: int, which input will to be delted
            out_idx: int, which input will to be delted
        Return: None
        """
        pre_node, pre_node_out_idx = node.get_producer(in_idx)
        super().delete_node(node, in_idx, out_idx)

        # modify outputs is necessary
        consumers, _ = pre_node.get_consumers(pre_node_out_idx)
        for consumer in consumers:
            if consumer.type == 'graph_output':
                out_anchor = pre_node.get_output_anchor(pre_node_out_idx)
                out_anchor.set_name(consumer.name)

    def _init_graph(self):
        """parse Graph from onnx_pb.Model.graph"""
        output_record = {}
        # 0. init graph input/output nodes
        self._init_graph_input_node(output_record)
        # 1. parse node proto structure
        self._parse_initializer(output_record)
        self._parse_sparse_initializer(output_record)
        self._parse_node_proto(output_record)
        self._init_graph_output_node(output_record)

        # delete node and initializer in graph
        self._net.graph.ClearField('input')
        self._net.graph.ClearField('node')
        self._net.graph.ClearField('initializer')
        self._net.graph.ClearField('sparse_initializer')

    def _init_graph_input_node(self, output_record):
        """parse graph_input node from onnx_pb.Model.graph.input"""
        for input_desc in self._net.graph.input:
            graph_input_node = Node(self._tail, input_desc, is_input=True)
            graph_input_node.add_output_anchor(input_desc.name)
            self._nodes.append(graph_input_node)
            output_record[input_desc.name] = [graph_input_node, 0]

    def _init_graph_output_node(self, output_record):
        """parse graph_output node from onnx_pb.Model.graph.output"""
        for output_desc in self._net.graph.output:
            graph_output_node = Node(self._tail, output_desc)
            graph_output_node.add_input_anchor(output_desc.name)
            self._nodes.append(graph_output_node)
            # Add link to output
            if output_desc.name not in output_record:
                raise ReferenceError('Cannot find tensor %s in model.' %
                                     (output_desc.name))
            src_node, src_index = output_record[output_desc.name]
            self.add_edge(src_node, src_index, graph_output_node, 0)

    def _parse_initializer(self, output_record):
        """parse params node from onnx_pb.Model.graph.initializer"""
        for initializer_proto in self._net.graph.initializer:
            node = Node(self._tail, initializer_proto)
            node.set_name(self._decorate_node_name(node.name))
            self._nodes.append(node)
            output_record[node.name] = [node, 0]

    def _parse_sparse_initializer(self, output_record):
        """parse sparse params node from onnx_pb.Model.graph.sparse_initializer
        """
        for sparse_initializer_proto in self._net.graph.sparse_initializer:
            node = Node(self._tail, sparse_initializer_proto)
            self._nodes.append(node)
            output_record[node.name] = [node, 0]

    def _parse_node_proto(self, output_record):
        """parse node in onnx model to amct_onnx Node"""
        # to check
        node_names = []
        for node in self._net.graph.node:
            if node.HasField('name') and node.name != "":
                node_names.append(node.name)

        def set_name(node_proto, index):
            """set name for node_proto is ti has no name """
            if self._update_node:
                # if need update node name, set name to {op_type}_{index}
                # and decorate to unique
                node_id = '%s_%d' % (node_proto.op_type, index)
                dec_index = 1
                while node_id in node_names:
                    node_id = '%s_%d' % (node_proto.op_type, index + dec_index)
                    dec_index += 1
                node_proto.name = node_id
                node_names.append(node_id)
                return True

            # otherwise, set all node to uniform name
            node_proto.name = '%s::common' % (node_proto.op_type)
            return False

        for index, node_proto in enumerate(self._net.graph.node):
            node_updated = False
            if not node_proto.HasField('name') or node_proto.name == "":
                node_updated = set_name(node_proto, index)
            node = Node(self._tail, node_proto)
            node.set_attr('is_update', node_updated)
            self._nodes.append(node)
            for output_anchor in node.output_anchors:
                output_record[output_anchor.name] = [node, output_anchor.index]

        # Add link to output
        for node in self._nodes:
            self._add_link_to_producer(node, output_record)

    def _add_link_to_producer(self, node, output_record):
        ''' for node add link to its producer'''
        for input_anchor in node.input_anchors:
            if input_anchor.name not in output_record:
                if input_anchor.name == '':
                    continue
                raise ReferenceError('Cannot find tensor %s in model.' %
                                        (input_anchor.name))
            src_node, src_index = output_record[input_anchor.name]
            self.add_edge(src_node, src_index, node, input_anchor.index)