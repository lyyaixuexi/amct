#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert activation calibration ifmr | hfmg layer couple with layer to be quantized

"""
from google.protobuf import text_format
from onnx import onnx_pb

from amct_onnx.configuration.check import GraphChecker
from amct_onnx.configuration.check import check_kernel_shape
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.configuration.configuration import Configuration
from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.attrs_list import ATTR_NODE_TWO_INPUTS
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
from amct_onnx.opset_utils.pad_utils import PadUtils
from amct_onnx.proto import scale_offset_record_pb2
from amct_onnx.common.utils.record_file_operator import create_empty_record
from amct_onnx.utils.vars import TENSOR_QUANTIZABLE_TYPES

INSERT_ACT_CALIBRATION_DONE_FLAG = 'eltwise_opt_insert_act_cali'


class InsertActCalibrationPass(BaseFusionPass):
    """
    Function: Insert ifmr layer couple with layer to be quantized
    APIs: match_pattern, do_fusion
    """
    def __init__(self, need_dump=False, dump_dir=''):
        """
        Function: Init InsertActCalibrationPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.need_dump = need_dump
        self.dump_dir = dump_dir
        self.records = scale_offset_record_pb2.ScaleOffsetRecord()
        self.record_file_path = Configuration().get_record_file_path()
        self.read_quant_config = Configuration().get_quant_config()
        self.tensor_config = self.read_quant_config.get('tensor_quantize')
        batch_num = self.read_quant_config.get('batch_num')
        preprocess_config_to_layer(self.tensor_config, batch_num)
        self.tensor_quant_config = {}

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, 'r') as record_read_file:
            pbtxt_string = record_read_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def tear_down(self):
        """
        Function: write the scale and offset to Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, "w") as record_write_file:
            record_write_file.write(
                text_format.MessageToString(self.records, as_utf8=True))

    def match_pattern(self, node):
        """
        Function: Find node need to insert IFMR/HFMG
                  layer in graph
        Parameters: node: node in graph
        Return: True: node that need to insert ifmr/hfmg layer
                False: skip the node
        """
        # match type
        if node.has_attr(INSERT_ACT_CALIBRATION_DONE_FLAG):
            return False
        if not GraphChecker.check_quantize_type(node) \
            and node.type not in TENSOR_QUANTIZABLE_TYPES:
            return False
        # match config
        return self.match_config(node)

    def match_config(self, node):
        ''' match tensor quant config and op quant config'''
        # check is op quantize
        if node.name in self.read_quant_config:
            return True
        # check is tensor quantize
        if node.type in TENSOR_QUANTIZABLE_TYPES and self.tensor_config:
            for tensor_quantize in self.tensor_config:
                if tensor_quantize.get('layer_name') != node.name:
                    continue
                if node.name not in self.tensor_quant_config:
                    self.tensor_quant_config[node.name] = {'act_index':[], 'activation_quant_params':[]}
                self.tensor_quant_config[node.name]['act_index'].append(tensor_quantize.get('input_index'))
                self.tensor_quant_config[node.name]['activation_quant_params'] \
                    .append(tensor_quantize.get('activation_quant_params'))
            if self.tensor_quant_config.get(node.name):
                return True

        return False

    def generate_ifmr_node(self,
                           graph,
                           object_layers,
                           act_config,
                           node_index=None,
                           in_idx=0):
        """
        Function: Genereate IFMR node according to input parameters
        Parameters: graph: graph that add IFMR node to
                    object_layers: layer that add IFMR node for
                    act_config: act quant config for a node
        Return: ifmr_node: generated IFMR node
        """
        if not isinstance(object_layers, list) or not object_layers:
            raise RuntimeError('Input object_layers must be a non-empty list')

        ifmr_op = onnx_pb.NodeProto()
        # Set basic info
        if not in_idx:
            # for data input
            ifmr_name = "{}_{}".format('_'.join(object_layers), 'ifmr_op')
            input_stamp = 'data'
        else:
            # for weight input
            ifmr_name = "{}_{}_{}".format('_'.join(object_layers), 'ifmr_op', str(in_idx))
            input_stamp = 'weight'

        ifmr_op.name = ifmr_name
        ifmr_op.op_type = 'IFMR'
        ifmr_op.domain = 'amct.customop'
        ifmr_op.input[:] = ['%s_input' % ifmr_op.name]
        ifmr_op.output[:] = ['%s_output' % ifmr_op.name]
        # Set quantize algorithm parameters
        ifmr_helper = AttributeProtoHelper(ifmr_op)
        ifmr_helper.set_attr_value('input_stamp', 'STRING', bytes(input_stamp + ' ', 'utf-8'))
        ifmr_helper.set_attr_value('batch_num', 'INT', act_config['batch_num'])
        ifmr_helper.set_attr_value('num_bits', 'INT', 8)
        ifmr_helper.set_attr_value('with_offset', 'INT',
                                   1 if act_config['with_offset'] else 0)
        ifmr_helper.set_attr_value('start_ratio', 'FLOAT',
                                   act_config['search_range_start'])
        ifmr_helper.set_attr_value('end_ratio', 'FLOAT',
                                   act_config['search_range_end'])
        ifmr_helper.set_attr_value('step', 'FLOAT', act_config['search_step'])
        ifmr_helper.set_attr_value('max_percentile', 'FLOAT',
                                   act_config['max_percentile'])
        ifmr_helper.set_attr_value('min_percentile', 'FLOAT',
                                   act_config['min_percentile'])
        ifmr_helper.set_attr_value('need_dump', 'INT',
                                   1 if self.need_dump else 0)
        ifmr_helper.set_attr_value('dump_dir', 'STRING',
                                   bytes(self.dump_dir + ' ', 'utf-8'))
        ifmr_helper.set_attr_value('layer_num', 'INT', len(object_layers))
        for index, object_layer in enumerate(object_layers):
            ifmr_helper.set_attr_value('object_layer%d' % index, 'STRING',
                                       bytes('%s ' % (object_layer), 'utf-8'))
        ifmr_helper.set_attr_value(
            'record_file_path', 'STRING',
            bytes(Configuration().get_record_file_path() + ' ', 'utf-8'))
        # Add node of IFMR to graph
        ifmr_node = graph.add_node(ifmr_op, node_index)
        return ifmr_node

    def generate_hfmg_node(self,
                           graph,
                           object_layers,
                           act_config,
                           node_index=None,
                           in_idx=0):
        """
        Function: Genereate HFMG node according to input parameters
        Parameters: graph: graph that add HFMG node to
                    object_layers: layer that add HFMG node for
                    act_config: act quant config for a node
        Return: hfmg_node: generated HFMG node
        """
        if not isinstance(object_layers, list) or not object_layers:
            raise RuntimeError('Input object_layers must be a non-empty list')

        hfmg_op = onnx_pb.NodeProto()
        # Set basic info
        if not in_idx:
            # for data input
            hfmg_name = "{}_{}".format('_'.join(object_layers), 'hfmg_op')
            input_stamp = 'data'
        else:
            # for weight input
            hfmg_name = "{}_{}_{}".format('_'.join(object_layers), 'hfmg_op', str(in_idx))
            input_stamp = 'weight'
        hfmg_op.name = hfmg_name
        hfmg_op.op_type = 'HFMG'
        hfmg_op.domain = 'amct.customop'
        hfmg_op.input[:] = ['%s_input' % hfmg_op.name]
        hfmg_op.output[:] = ['%s_output' % hfmg_op.name]
        # Set quantize algorithm parameters
        hfmg_helper = AttributeProtoHelper(hfmg_op)
        hfmg_helper.set_attr_value('input_stamp', 'STRING', bytes(input_stamp + ' ', 'utf-8'))
        hfmg_helper.set_attr_value('batch_num', 'INT', act_config['batch_num'])
        hfmg_helper.set_attr_value('num_bits', 'INT', 8)
        hfmg_helper.set_attr_value('with_offset', 'INT',
                                   1 if act_config['with_offset'] else 0)
        hfmg_helper.set_attr_value('nbins', 'INT', act_config['num_of_bins'])
        hfmg_helper.set_attr_value('need_dump', 'INT',
                                   1 if self.need_dump else 0)
        hfmg_helper.set_attr_value('dump_dir', 'STRING',
                                   bytes(self.dump_dir + ' ', 'utf-8'))
        hfmg_helper.set_attr_value('layer_num', 'INT', len(object_layers))
        for index, object_layer in enumerate(object_layers):
            hfmg_helper.set_attr_value('object_layer%d' % index, 'STRING',
                                       bytes('%s ' % (object_layer), 'utf-8'))
        hfmg_helper.set_attr_value(
            'record_file_path', 'STRING',
            bytes(Configuration().get_record_file_path() + ' ', 'utf-8'))
        # Add node of HFMG to graph
        hfmg_node = graph.add_node(hfmg_op, node_index)
        return hfmg_node

    def generate_act_calibration_node(self, graph, object_layers, config_layer_name, in_idx=0):
        """
        Function: Genereate act calibration node according to input parameters
        Parameters:
        graph: graph that add node to
        object_layers: layers that add act calibration node for
        config_layer_name: name for get quantize parameter from config
        Return: act_cali_nodes: generated act calibration node
        """
        act_cali_nodes = {}
        if self.tensor_quant_config.get(config_layer_name):
            quant_config = self.tensor_quant_config.get(config_layer_name)
            in_idxs = quant_config['act_index']
            for idx, in_idx in enumerate(in_idxs):
                record = self.records.record.add()
                record.key = ':'.join([config_layer_name, str(in_idx)])
                record.value.is_tensor_quantize = True
                object_layers = [record.key]
                act_config = quant_config['activation_quant_params'][idx]
                # if not act_algo key, default is ifmr
                act_algo = act_config.get('act_algo', 'ifmr')
                if act_algo == 'hfmg':
                    act_cali_nodes[in_idx] = self.generate_hfmg_node(graph, object_layers, act_config)
                else:
                    act_cali_nodes[in_idx] = self.generate_ifmr_node(graph, object_layers, act_config)
            return act_cali_nodes
        else:
            quant_config = Configuration().get_layer_config(config_layer_name)
        act_config = quant_config['activation_quant_params']

        # if not act_algo key, default is ifmr
        act_algo = act_config.get('act_algo', 'ifmr')
        if act_algo == 'hfmg':
            act_cali_nodes[in_idx] = self.generate_hfmg_node(graph, object_layers, act_config, in_idx=in_idx)
        else:
            act_cali_nodes[in_idx] = self.generate_ifmr_node(graph, object_layers, act_config, in_idx=in_idx)
        return act_cali_nodes

    def do_pass(self, graph, object_node):
        """
        Function: Do actual insert ifmr layer operation.
        Parameters: graph: graph that contains object node
                    object_node: node to process
        Return: None
        """
        if object_node.has_attr(ATTR_NODE_TWO_INPUTS) and object_node.get_attr(ATTR_NODE_TWO_INPUTS):
            quant_config = Configuration().get_layer_config(object_node.name)
            quant_config['activation_quant_params']['with_offset'] = False

        act_cali_nodes = self.generate_act_calibration_node(graph, [object_node.name], object_node.name)
        obj_producer, _ = object_node.get_producer(0)
        if object_node.type == "AveragePool" and obj_producer.type == "Pad":
            # when Pad's pad value constant_value(optional),
            # need to check whether constant_value is zero or not, not zero
            # value is not supported
            pad_utils = PadUtils(obj_producer)
            constant_value = pad_utils.get_pad_value()
            if constant_value != 0:
                return
            graph.insert_parallel_node(act_cali_nodes.get(0), 0, obj_producer, 0)
        else:
            for index in act_cali_nodes:
                graph.insert_parallel_node(act_cali_nodes.get(index), 0, object_node, index)

        if object_node.has_attr(ATTR_NODE_TWO_INPUTS) and object_node.get_attr(ATTR_NODE_TWO_INPUTS):
            create_empty_record(self.records, object_node.name)
            input2_cali_node = self.generate_act_calibration_node(graph, [object_node.name], object_node.name, 1)
            graph.insert_parallel_node(input2_cali_node.get(1), 0, object_node, 1)

        for act_cali_node in act_cali_nodes.values():
            LOGGER.logd(
                "Insert {} layer '{}' to '{}' success!".format(
                    act_cali_node.type, act_cali_node.name, object_node.name),
                    'InsertActCalibrationPass')


def preprocess_config_to_layer(quant_config, batch_num):
    """ parse config to onnx layer """
    for item in quant_config:
        act_config = item["activation_quant_params"]
        act_algo = act_config.get('act_algo', 'ifmr')
        if act_algo == 'ifmr':
            act_config["search_range_start"] = \
                act_config["search_range"][0]
            act_config["search_range_end"] = \
                act_config["search_range"][1]
        act_config['with_offset'] = act_config['asymmetric']
        act_config['batch_num'] = batch_num
