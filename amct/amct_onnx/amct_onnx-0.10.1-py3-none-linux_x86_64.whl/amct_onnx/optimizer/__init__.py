#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

__ini__ for optimizer module

"""

from .base_fusion_pass import BaseFusionPass
from .bias_fakequant_pass import BiasFakequantPass
from .bias_quant_pass import BiasQuantPass
from .bn_add_fusion_pass import BnAddFusionPass
from .bn_mul_fusion_pass import BnMulFusionPass
from .conv_bn_fusion_pass import ConvBnFusionPass
from .conv_add_bias_fusion import ConvAddBiasFusionPass
from .delete_bypass_node_pass import DeleteActCalibrationPass
from .delete_bypass_node_pass import DeleteSearchNPass
from .delete_fake_quant_node_pass import DeleteFakeQuantNodePass
from .gemm_transb_optimize_pass import GemmTransBOptimizePass
from .gen_fusion_json import GenFusionJsonPass
from .insert_dequant_pass import InsertDequantPass
from .insert_act_calibration import InsertActCalibrationPass
from .insert_quant_pass import InsertQuantPass
from .mult_output_with_quant_optimizer import MultQuantOptimizerPass
from .quant_fusion_pass import QuantFusionPass
from .update_ascendop_pass import UpdateAscendOpPass
from .update_fusion_info import UpdateFusionInfoPass
from .set_fusion_info import SetFusionInfoPass
from .transpose_fold_pass import TransposeFoldPass
from .weight_calibration import WeightsCalibrationPass
from .weight_fakequant_pass import WeightFakequantPass
from .weight_quant_pass import WeightQuantPass
from .insert_search_n import InsertSearchNPass
from .add_opt_insert_act_calibration import AddOptInsertActCalibrationPass
from .add_opt_insert_searchn import AddOptInsertSearchNLayerPass
from .eltwise_opt_weights_calibration import AddOptWeightsCalibrationPass
from .get_quant_info_pass import GetQuantInfoPass
from .adjust_input_index_pass import AdjustInputIndexPass
from .insert_dmq_balancer_pass import InsertDMQBalancerPass
from .apply_dmq_balancer_pass import ApplyDMQBalancerPass

from .graph_optimizer import GraphOptimizer


__all__ = [
    "BaseFusionPass",
    "BiasFakequantPass",
    "BiasQuantPass",
    "BnAddFusionPass",
    "BnMulFusionPass",
    "ConvBnFusionPass",
    'ConvAddBiasFusionPass',
    "DeleteSearchNPass",
    "DeleteActCalibrationPass",
    "DeleteFakeQuantNodePass",
    "GemmTransBOptimizePass",
    "GenFusionJsonPass",
    "InsertDequantPass",
    "InsertActCalibrationPass",
    "InsertQuantPass",
    "MultQuantOptimizerPass",
    "QuantFusionPass",
    "UpdateAscendOpPass",
    "UpdateFusionInfoPass",
    "SetFusionInfoPass",
    "TransposeFoldPass",
    "WeightsCalibrationPass",
    "WeightFakequantPass",
    "WeightQuantPass",
    "GraphOptimizer",
    "InsertSearchNPass",
    "AddOptInsertSearchNLayerPass",
    "AddOptWeightsCalibrationPass",
    "AdjustInputIndexPass",
    "GetQuantInfoPass",
    "InsertDMQBalancerPass",
    "ApplyDMQBalancerPass"
]
