#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Do caliration for weight, sacle and offset for weight will be finded and
weight is fake_quantized.

"""
import copy
from google.protobuf import text_format

from amct_onnx.configuration.configuration import Configuration
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.proto import \
    scale_offset_record_pb2

from amct_onnx.common.utils.record_file_operator import \
    record_weights_scale_offset
from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.vars import QUANTIZABLE_TYPES
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.weight_quant_api import weight_calibration_np
from amct_onnx.utils.weight_quant_api import adjust_deconv_weight_shape
from amct_onnx.utils.attrs_list import ATTR_NODE_TWO_INPUTS
from amct_onnx.configuration.check import GraphChecker
from amct_onnx.common.algo.base_quant_algo import BaseQuantizeAlgorithm

CALIBRATION_DONE_FLAG = 'eltwise_opt_calibration'


class WeightsCalibrationPass(BaseFusionPass):
    """
    Function: Do caliration for weight, sacle and offset for weight will
        be found and weight is fake_quantized.
    APIs: set_up, tear_down, match_pattern, do_pass
    """
    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = scale_offset_record_pb2.ScaleOffsetRecord()
        self.conf = Configuration()
        self.record_file_path = self.conf.get_record_file_path()

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, 'r') as record_read_file:
            pbtxt_string = record_read_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def match_pattern(self, node):
        """
        Function:Match the module to be quantized in model
        Parameters:
            module: module to be matched
            name: module's name
            graph: graph structure, not necessary
        Return: True: matched
                False: mismatch
        """
        if node.type not in QUANTIZABLE_TYPES:
            return False
        if node.name not in self.conf.get_quant_config():
            return False
        # eltwise optimization was done before this pass
        if node.has_attr(CALIBRATION_DONE_FLAG):
            return False
        # check whether node that has two inputs
        if node.has_attr(ATTR_NODE_TWO_INPUTS) and node.get_attr(ATTR_NODE_TWO_INPUTS):
            return False
        return True

    def do_pass(self, graph, object_node):
        """
        Function: Do weights calibration.
        Parameters: graph: graph structure,
                    object_node: node to process
        Return: None
        """
        # Step0: do avgpooling calibration only by kernel shape
        object_name = object_node.name

        # if quantized node is pooling, only calculate scale_w according
        # to it's kernel size
        if object_node.type == 'AveragePool':
            offset = [0]
            scale = [1.0]
            record_weights_scale_offset(
                self.records, object_name, scale, offset)
            LOGGER.logd(
                'Do layer:\'{}\' weights calibration success!'.format(
                    object_name), 'WeightsCalibrationPass')
            return
        # Step1: do weight calibration by algo
        # get weights' information for quantization
        layer_config = self.conf.get_layer_config(object_name)
        wts_param = layer_config.get('weight_quant_params')
        weights_node = QuantOpInfo.get_weight_node(object_node)
        if object_node.has_attr('with_weights_trans') and \
            object_node.get_attr('with_weights_trans'):
            raise RuntimeError(
                "Quantizable node{%s} should directly connected to weight"
                % (object_name))

        # check if current weights is reused, then skip do calibration
        if weights_node.has_attr('weights_calibration_done'):
            scale, offset = weights_node.get_attr('weights_calibration_done')
            record_weights_scale_offset(self.records, object_name, scale,
                                        offset)
            return

        # split reused weight
        self._split_reused_weight(graph, weights_node)
        weights_node = QuantOpInfo.get_weight_node(object_node)
        # quant weight to find scale and offset
        weight_tensor = QuantOpInfo.get_node_tensor(weights_node)
        weights_helper = TensorProtoHelper(weight_tensor)
        weights = weights_helper.get_data().copy()
        weights_helper.clear_data()

        weights_len = BaseQuantizeAlgorithm.get_data_length(weights.shape)
        # Check whether nuq is supported for nodes with wts_algo set to 'nuq_quantize'.
        if wts_param['wts_algo'] == 'nuq_quantize':
            _check_nuq_executable(wts_param, object_node, weights_len)

        if object_node.type == 'ConvTranspose':
            weights = adjust_deconv_weight_shape(object_node, weights)
        scale, offset = weight_calibration_np(weights, wts_param)
        if object_node.type == 'ConvTranspose':
            weights = adjust_deconv_weight_shape(object_node, weights)

        weights_helper.set_data(weights.flatten())

        # save the quantize information
        record_weights_scale_offset(self.records, object_name, scale, offset)
        # set weights calibration done flag
        weights_node.set_attr('weights_calibration_done', (scale, offset))

        LOGGER.logd('Do layer \'{}[{}]\' weights calibration success!'\
                    .format(object_node.name, wts_param['wts_algo']), \
                    'WeightsCalibrationPass')

    def tear_down(self):
        """
        Function: write the scale and offset to Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, "w") as record_write_file:
            record_write_file.write(
                text_format.MessageToString(self.records, as_utf8=True))

    def _split_reused_weight(self, graph, weights_node):
        """
        Function: Split reused weight.
        Inputs:
            graph: graph structure,
            weights_node: object_node's weight
        Returns: None
        """
        weight_consumers_grp = _group_consumers(weights_node, self.conf)

        # split weight param
        grp_num = len(weight_consumers_grp)
        for grp_name, grp in weight_consumers_grp.items():
            grp_num = grp_num - 1
            # the last group has no need to copy weight
            if grp_num == 0:
                break
            _link_to_new_weight(weights_node, grp_name, grp, graph)


def _check_nuq_executable(wts_param, object_node, weights_len):
    """
    Function: check whether nuq is supported for current object_node.
    Inputs:
        wts_param: weight quantization parameters.
        object_node: 'node' in the 'graph'.
        weights_len: length of weight's node.
    Returns: None
    """
    is_supported = GraphChecker.check_nuq_quantize_type(object_node)
    object_name = object_node.name
    if not is_supported:
        raise RuntimeError("Layer '{}' is not supported for NUQ, but 'wts_algo' is set to 'nuq_quantize'!" \
            .format(object_name))
    nuq_steps = wts_param.get('num_steps')
    if nuq_steps > weights_len:
        raise RuntimeError("Layer '{}' is not supported for NUQ with num_steps: {} > weight length {}!" \
            .format(object_name, nuq_steps, weights_len))


def _group_consumers(weights_node, quant_config):
    '''
    Function: Group parent node of weights_node. Nodes with same weight quant
        param will be grouped.
    Inputs:
        weights_node: a Node, weights of nodes in grp
        quant_config: a dict, config of quantization.
    Returns:
        weight_consumers_grp: a dict, grouped consumers
    '''
    weight_consumers = _get_weight_consumers(weights_node)

    def get_wts_param(layer_name):
        """get layer's weights quant config """
        layer_conf = quant_config.get_layer_config(layer_name)
        if layer_conf is None:
            return None
        return layer_conf.get('weight_quant_params')
    # group weight_consumers according to weights quant config
    weight_consumers_grp = dict()
    for consumer in weight_consumers:
        wts_param = get_wts_param(consumer.name)
        grouped_flag = False
        # add consumer to exist group
        for grp_nodes in weight_consumers_grp.values():
            if wts_param == get_wts_param(grp_nodes[0].name):
                grp_nodes.append(consumer)
                grouped_flag = True
                break
        # create a new group for node
        if not grouped_flag:
            weight_consumers_grp[consumer.name] = [consumer]

    return weight_consumers_grp


def _link_to_new_weight(weights_node, grp_name, grp, graph):
    '''
    Function: Link nodes in grp to a new copy of weights_node.
    Inputs:
        weights_node: a Node, weights of nodes in grp
        grp_name: a string, name for grp
        grp: a list of node
        graph: graph structure,
    Returns: None
    '''
    # Step1: copy a new weight
    weights_op = copy.deepcopy(weights_node.proto)
    weights_op.name = '_'.join([weights_node.name, grp_name])
    new_weights_node = graph.add_node(weights_op)

    consumers, in_idxes = weights_node.get_consumers(0)
    # Step2: relink nodes to new weight
    for node in grp:
        weight_index = in_idxes[consumers.index(node)]
        graph.remove_edge(weights_node, 0, node, weight_index)
        graph.add_edge(new_weights_node, 0, node, weight_index)

    LOGGER.logd(
        "weight of %s is updated to %s" %
        ([node.name for node in grp], new_weights_node.name))


def _get_weight_consumers(weight_param):
    '''
    Function: Get weight_node's node
    Parameters:
        weight_param: a node, which is weight
    Return:
        weight_consumers: a list of node, each one's weight is weight_node
    '''
    weight_consumers = []
    wts_ahcnor = weight_param.get_output_anchor(0)
    for peer_in in wts_ahcnor.get_peer_input_anchor():
        weight_consumers.append(peer_in.node)
    LOGGER.logd(
        "weight_param{%s} is weight of %s" %
        (weight_param.name, [node.name for node in weight_consumers]))

    return weight_consumers
