#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2023. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Update Ascend ops to fakeqaunt with amct domain.

"""
from amct_onnx.utils.log import LOGGER
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.utils.attrs_list import ATTR_NODE_TWO_INPUTS
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
from onnx.onnx_pb import TensorProto


class UpdateAscendOpPass(BaseFusionPass):
    """
    Function: Update Ascend ops to fakeqaunt with amct domain.
    APIs: match_pattern, do_pass
    """
    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    def match_pattern(self, node):
        """
        Function: Match the AscendQuant node
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type != 'AscendQuant':
            return False

        return True

    def do_pass(self, graph, object_node):
        """
        Function: Do actually replacing AscendQuant to fakeqaunt 'Quant'
            with onnx's ops
        Parameters: graph: graph structure
                    object_node: node to process
        Return: None
        """
        op_domain = 'amct.customop'
        calculate_type = object_node.quant_type
        ascend_nodes = set()
        ascend_nodes.add(object_node)
        consumers, _ = object_node.get_consumers(0)
        for consumer in consumers:
            if consumer.type == 'AscendAntiQuant':
                ascend_nodes.add(consumer)
                continue
            if consumer.type == 'Pad':
                quant_op = consumer.get_consumers(0)[0][0]
                dequant_op = quant_op.get_consumers(0)[0][0]
                ascend_nodes.add(dequant_op)
                continue
            if consumer.type == 'AveragePool':
                dequant_op = consumer.get_consumers(0)[0][0]
                ascend_nodes.add(dequant_op)
                continue
            if consumer.type == 'MatMul':
                if consumer.has_attr(ATTR_NODE_TWO_INPUTS) and consumer.get_attr(ATTR_NODE_TWO_INPUTS):
                    dequant_op = consumer.get_consumers(0)[0][0]
                    ascend_nodes.add(dequant_op)
                    continue
                dequant_op = consumer.get_consumers(0)[0][0]
                bias_node = QuantOpInfo.get_bias_node(consumer)
                if bias_node is not None:
                    dequant_op = dequant_op.get_consumers(0)[0][0]
                ascend_nodes.add(dequant_op)
                continue
            dequant_op = consumer.get_consumers(0)[0][0]
            ascend_nodes.add(dequant_op)

        if calculate_type == TensorProto.DataType.FLOAT16:
            op_domain = 'amct.customop.extfp16'
        for node in ascend_nodes:
            node.proto.domain = op_domain
            LOGGER.logd("Update ascend op '{}' to do fake quant success!".
                format(node.name), 'ReplaceQuantPass')
