#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Get the quantization information of the quantization node.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np

from amct_onnx.configuration.check import GraphChecker
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
from amct_onnx.opset_utils import BatchNormalizationUtils
from amct_onnx.utils.vars import FUSE_TYPES
from amct_onnx.utils.log import LOGGER

__all__ = ['GetQuantInfoPass']


class GetQuantInfoPass(BaseFusionPass):
    """
    Function: Get the quantization information of the quantization node.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, quant_info):
        """
        Function: init object
        Inputs:
            records: a dictionary containing quant factors
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.quant_info = quant_info
        self.outputs = []
        self.structure = {}

    @staticmethod
    def match_quantize_operation(node):
        """
        Function: Matching a single quantization node
        Inputs:
            node: node to match
        Returns:
            is_matched: a bool whether is matched.
            quant_op: a operation that quantize activation.
            dequant_op: a operation that dequantize outputs.
            skip_fusion: a bool whether is skiped fusion.
        """
        is_matched = False
        quant_op = None
        dequant_op = None
        skip_fusion = False
        act_index, _, _ = QuantOpInfo.get_quant_index(node)
        pre_node, _ = node.get_producer(act_index)
        if pre_node.type == 'Pad':
            pre_node, _ = pre_node.get_producer(0)
        if pre_node.type == 'AscendQuant':
            last_node, _ = node.get_consumers(0)
            if last_node[0].type == 'Add':
                last_node, _ = last_node.get_consumers(0)
            if last_node[0].type == 'AscendDequant':
                quant_op = pre_node
                dequant_op = last_node[0]
                is_matched = True
                skip_fusion = GetQuantInfoPass.check_skip_fusion(last_node, node)
        return [is_matched, quant_op, dequant_op, skip_fusion]

    @staticmethod
    def check_skip_fusion(ascend_dequant_node, conv_node):
        """Check if fusion can be skipped"""
        if len(ascend_dequant_node[0].get_consumers(0)[0]) == 1:
            dequant_consumer, _ = ascend_dequant_node[0].get_consumers(0)
            if GetQuantInfoPass.is_fusionable_bn(dequant_consumer[0])\
                and conv_node.type in FUSE_TYPES:
                return True
        return False

    @staticmethod
    def parser_uint64(uint64_deq_scales):
        """Parser the data of uint64 to get deqscale and shift n."""
        deq_scales = []
        deq_offsets = []
        shift_ns = []
        for uint64_deq_scale in uint64_deq_scales:
            value = np.array(uint64_deq_scale, dtype=np.uint64)
            value = value << np.uint32(32)
            value = value >> np.uint32(32)
            value = value.astype(np.uint32)
            deq_scales.append(np.frombuffer(value, np.float32))

            value = np.array(uint64_deq_scale, dtype=np.uint64)
            value = value << np.uint32(16)
            value = value >> np.uint32(56)
            deq_offsets.append(value.astype(np.uint8))

            value = np.array(uint64_deq_scale, dtype=np.uint64)
            value = value << np.uint32(24)
            value = value >> np.uint32(56)
            shift_ns.append(value.astype(np.uint8))

        return np.array(deq_scales), np.array(deq_offsets), np.array(shift_ns)

    @staticmethod
    def is_fusionable_bn(node):
        """ is the bn can be fused"""
        if node.type != 'BatchNormalization':
            return False
        bn_utils = BatchNormalizationUtils(node)
        if bn_utils.has_attribute('spatial') and \
                bn_utils.get_attribute_value('spatial') != 1:
            return False
        if bn_utils.has_attribute("training_mode") and \
                bn_utils.get_attribute_value("training_mode") != 0:
            return False
        if len(node.input_anchors) != 5:
            raise RuntimeError('BatchNorm node should only have 5 output ' \
                'actually have {}'.format(len(node.input_anchors)))
        return True

    def match_pattern(self, operation):
        """
        Function: Match quantization node.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        is_matched = False
        skip_fusion = False
        auxi_layer = []
        layer_name = operation.name
        layer_type = operation.type

        # match the quant op
        if not GraphChecker.check_quantize_type(operation):
            return is_matched
        is_matched, quant_op, dequant_op, skip_fusion = \
            GetQuantInfoPass.match_quantize_operation(operation)
        ops = [operation, quant_op, dequant_op, None]
        if is_matched:
            self._add_items(False, ops, skip_fusion)
            return is_matched
        layer_info = {'layer_name': layer_name, 'auxi_layer': auxi_layer, 'layer_type': layer_type}
        self.quant_info.add_items(layer_info, is_matched, skip_fusion)

        return is_matched

    def do_pass(self, graph, object_op):
        """
        Function: Insert Quant(for act) before object_op
        Inputs:
            graph: graph to process
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        quant_op, dequant_op = self.structure[object_op.name]['auxi_ops']

        record = {}
        record['data_scale'] = 1 / AttributeProtoHelper(quant_op.proto).get_attr_value('scale')
        record['data_offset'] = int(AttributeProtoHelper(quant_op.proto).get_attr_value('offset'))

        self.quant_info.add_total_records(object_op.name, record)

        # get weight_scale, weight_offset and shift n
        scale_d = self.quant_info.get_total_records()[
            object_op.name]['data_scale']

        # get scale uint64 from produce[1] of ascend dequant op
        scale_uint64_node, _ = dequant_op.get_producer(1)
        if scale_uint64_node is None:
            raise RuntimeError('Dequant node should only have 2 input.')
        deq_scale_uint64 = QuantOpInfo.get_node_value(scale_uint64_node)

        deq_scales, deq_offsets, shift_ns = GetQuantInfoPass.parser_uint64(
            deq_scale_uint64)
        weight_scale = deq_scales / scale_d
        weight_offset = deq_offsets

        self.quant_info.set_total_records(object_op.name, weight_scale,
                                          weight_offset, shift_ns)
        LOGGER.logd(
            "finish get quant info for %s" % (object_op.name),
            "GetQuantInfoPass")

    def _add_items(self, is_group, ops, skip_fusion):
        operation, quant_op, dequant_op, group_ops = ops
        layer_name = operation.name
        layer_type = operation.type
        quant_quxi_layer = [quant_op.name, dequant_op.name]
        if not is_group:
            group_layer = [operation.name]
        else:
            group_layer = [group_op.name for group_op in group_ops]
        if group_layer not in self.quant_info.get_group_layers():
            self.quant_info.add_group_layers(group_layer)
        layer_info = {'layer_name': layer_name, 'auxi_layer': quant_quxi_layer, 'layer_type': layer_type}
        self.quant_info.add_items(layer_info, True, skip_fusion)
        self.structure[layer_name] = {
            'is_group': is_group,
            'auxi_ops': [quant_op, dequant_op]
        }