#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Delete QuantizeLinear, DequantizeLinear and bypass nodes in graph
"""


import numpy as np

from amct_onnx.configuration.check import GraphQuerier
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.optimizer.insert_quant_pass import construct_quant_node
from amct_onnx.optimizer.mult_output_with_quant_optimizer import construct_anti_quant_node
from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.utils.vars import CONVERT_QAT_QUANTIZABLE_TYPES


BYPASS_NODE_ACT = ['Identity', 'MaxPool', 'Pad', 'Reshape', 'Transpose']
BYPASS_NODE_WEIGHT = ['Reshape', 'Transpose']
QUANTIZABLE_TYPES = ['Conv', 'Gemm', 'MatMul']


class DeleteFakeQuantNodePass(BaseFusionPass):
    """
    Function: Delete QuantizeLinear, DequantizeLinear and bypass nodes
    APIs: match_pattern, do_pass
    """
    def __init__(self, graph, record_helper, replace=False):
        BaseFusionPass.__init__(self)
        self.graph = graph
        self.record_helper = record_helper
        self.replace = replace
        self.quantized_node = {}
        self.convert_qat_quantable_layers = GraphQuerier.get_support_convert_layers(graph)
        self.quant_constant_node = set()

    @staticmethod
    def _get_scale_offset(quantize_node):
        scale_node = quantize_node.get_input_anchor(1).get_peer_output_anchor().node
        scale = QuantOpInfo.get_node_value(scale_node)

        offset_node = quantize_node.get_input_anchor(2).get_peer_output_anchor().node
        offset = QuantOpInfo.get_node_value(offset_node)

        if offset.dtype == np.uint8:
            offset = offset.astype(np.int32) - 128

        scale = scale.tolist()
        offset = offset.tolist()
        if not isinstance(scale, list):
            scale = [scale]
        if not isinstance(offset, list):
            offset = [offset]

        return scale, offset

    @staticmethod
    def _is_weight(quantize_node):
        weight_node = quantize_node.get_input_anchor(0).get_peer_output_anchor().node
        if weight_node.type in ['initializer', 'Constant']:
            return True
        return False

    @staticmethod
    def _is_perchannel(quantize_node):
        attr_helper = AttributeProtoHelper(quantize_node.proto)
        if attr_helper.has_attr('axis'):
            channel = attr_helper.get_attr_value('axis')
            if channel != 1:
                LOGGER.loge('Cannot support to quantize node "{}" with axis {}!'.format(quantize_node.name, channel))
                raise RuntimeError(
                    'Cannot support to quantize node "{}" with axis {}!'.format(quantize_node.name, channel))

        scale_node = quantize_node.get_input_anchor(1).get_peer_output_anchor().node
        scale = QuantOpInfo.get_node_value(scale_node)
        if scale.size > 1:
            LOGGER.loge('Cannot support to quantize node "{}" with perchannel!'.format(quantize_node.name))
            raise RuntimeError('Cannot support to quantize node "{}" with perchannel!'.format(quantize_node.name))

    @staticmethod
    def _check_matmul_weight(bypass_nodes):
        if bypass_nodes[-1].type == 'MatMul':
            weight_node = bypass_nodes[0].get_input_anchor(0).get_peer_output_anchor().node
            weight_tensor = QuantOpInfo.get_node_tensor(weight_node)
            if len(weight_tensor.dims) != 2:
                return False
        return True

    @staticmethod
    def _check_weight_bypass_nodes(bypass_nodes):
        for bypass_node in bypass_nodes:
            if bypass_node.type not in BYPASS_NODE_WEIGHT:
                return False
        return True

    def tear_down(self):
        """
        Function: Do some set up for pass. Add inner fusion info to
            Configuration
        Parameter: None
        Return: None
        """
        quantize_node = []
        for consumer, bypass_nodes_list in self.quantized_node.items():
            if len(bypass_nodes_list) == 1:
                bypass_nodes = bypass_nodes_list[0]
                act_index, _, _ = QuantOpInfo.get_quant_index(consumer)
                act_node = consumer.get_input_anchor(act_index).get_peer_output_anchor().node
                if bypass_nodes[-2] == act_node:
                    if self.replace:
                        self._replace_quantize_nodes(bypass_nodes)
                    else:
                        self._rematch_quantize_nodes(bypass_nodes)
                else:
                    self._fold_weight_quantize_nodes(bypass_nodes)

                self.record_helper.delete_key(consumer.name)
            else:
                self._standard_conversion(bypass_nodes_list)
            for bypass_nodes in bypass_nodes_list:
                if bypass_nodes[0: 2] not in quantize_node:
                    quantize_node.append(bypass_nodes[0: 2])

        for bypass_nodes in quantize_node:
            self._delete_bypass_nodes(bypass_nodes)

        for key in self.record_helper.keys:
            if not self.record_helper.check_record(key, self.record_helper.get_record(key)):
                self.record_helper.delete_key(key)

        self._delete_single_node()

    def match_pattern(self, node):
        """
        Function: Find node has fusion info in graph
        Parameters: node: node in graph
        Return: True: node that has info
                False: skip the node
        """
        if node.type == 'QuantizeLinear':
            consumer = node.get_output_anchor(0).get_peer_input_anchor()[0].node
            if consumer.type == 'DequantizeLinear':
                quant_scale, quant_offset = self._get_scale_offset(node)
                dequant_scale, dequant_offset = self._get_scale_offset(consumer)
                quant_scale = np.array(quant_scale)
                quant_offset = np.array(quant_offset)
                dequant_scale = np.array(dequant_scale)
                dequant_offset = np.array(dequant_offset)
                if quant_scale.shape != dequant_scale.shape or quant_offset.shape != dequant_offset.shape:
                    LOGGER.loge(
                        'The shapes of quantization information of node "{}" and node "{}" are inconsistent!'.format(
                            node.name, consumer.name))
                    raise ValueError(
                        'The shapes of quantization information of node "{}" and node "{}" are inconsistent!'.format(
                            node.name, consumer.name))

                if (quant_scale == dequant_scale).all() and (quant_offset == dequant_offset).all():
                    return True

                LOGGER.loge(
                    'The values of quantization information of node "{}" and node "{}" are inconsistent!'.format(
                        node.name, consumer.name))
                raise ValueError(
                    'The values of quantization information of node "{}" and node "{}" are inconsistent!'.format(
                        node.name, consumer.name))

            LOGGER.loge('Cannot find a matching "DequantizeLinear" node for node "{}"!'.format(node.name))
            raise RuntimeError('Cannot find a matching "DequantizeLinear" node for node "{}"!'.format(node.name))

        if node.type == 'DequantizeLinear':
            producer = node.get_input_anchor(0).get_peer_output_anchor().node
            if producer.type == 'QuantizeLinear':
                return False

            LOGGER.loge('Cannot find a matching "QuantizeLinear" node for node "{}"!'.format(node.name))
            raise RuntimeError('Cannot find a matching "QuantizeLinear" node for node "{}"!'.format(node.name))

        return False

    def do_pass(self, graph, object_node):
        """
        Function: process object_node
        Parameters:
            object_node: matched node
        Return: None
        """
        self._find_constant_input(object_node)
        act_replace, weight_fold, act_quant, weight_quant = self._find_consumer(object_node)

        for bypass_nodes in act_replace:
            if self.replace:
                self._replace_quantize_nodes(bypass_nodes)
            else:
                self._rematch_quantize_nodes(bypass_nodes)

        for bypass_nodes in weight_fold:
            self._fold_weight_quantize_nodes(bypass_nodes)

        if not act_quant and not weight_quant:
            self._delete_bypass_nodes(bypass_nodes[0: 2])

        transpose_list = []
        for bypass_nodes in act_quant:
            self._act_bypass(bypass_nodes, transpose_list)

            if bypass_nodes[-1] in self.quantized_node:
                self.quantized_node[bypass_nodes[-1]].append(bypass_nodes)
            else:
                self.quantized_node[bypass_nodes[-1]] = [bypass_nodes]

        for transpose_node in set(transpose_list):
            self._delete_bypass_nodes([transpose_node])

        for bypass_nodes in weight_quant:
            self._weight_bypass(bypass_nodes)

            if bypass_nodes[-1] in self.quantized_node:
                self.quantized_node[bypass_nodes[-1]].append(bypass_nodes)
            else:
                self.quantized_node[bypass_nodes[-1]] = [bypass_nodes]

    def _act_bypass(self, bypass_nodes, transpose_list):
        scale, offset = self._get_scale_offset(bypass_nodes[0])
        self.record_helper.record_activation_scale_offset(bypass_nodes[-1].name, scale[0], offset[0])

        if len(bypass_nodes) >= 3:
            if bypass_nodes[2].type == 'Transpose':
                producer = bypass_nodes[0].get_input_anchor(0).get_peer_output_anchor().node
                if producer.type == 'Transpose':
                    former_helper = AttributeProtoHelper(producer.proto)
                    former_perm = former_helper.get_attr_value('perm')
                    latter_helper = AttributeProtoHelper(bypass_nodes[2].proto)
                    latter_perm = latter_helper.get_attr_value('perm')
                    if len(former_perm) != len(latter_perm):
                        return
                    flag = True
                    for i, value in enumerate(former_perm):
                        if latter_perm[value] != i:
                            flag = False
                            break
                    if flag:
                        transpose_list.append(producer)
                        transpose_list.append(bypass_nodes[2])
                        del bypass_nodes[2]

    def _weight_bypass(self, bypass_nodes):
        scale, offset = self._get_scale_offset(bypass_nodes[0])
        self.record_helper.record_weights_scale_offset(bypass_nodes[-1].name, scale, offset)

    def _fold_weight_quantize_nodes(self, bypass_nodes):
        weight_node = bypass_nodes[0].get_input_anchor(0).get_peer_output_anchor().node
        weight_tensor = QuantOpInfo.get_node_tensor(weight_node)
        weight_helper = TensorProtoHelper(weight_tensor)
        weight = weight_helper.get_data().copy()
        weight_helper.clear_data()

        scale, offset = self._get_scale_offset(bypass_nodes[0])

        weight = np.clip(np.round(np.array(weight) / scale - offset), -128, 127)
        weight = (weight + offset) * scale
        weight_helper.set_data(weight.flatten(), dims=weight.shape, graph=self.graph)

        self._rematch_quantize_nodes(bypass_nodes)

    def _standard_conversion(self, bypass_nodes_list):
        for bypass_nodes in bypass_nodes_list:
            _, weight_index, _ = QuantOpInfo.get_quant_index(bypass_nodes[-1])
            weight_bypass = bypass_nodes[-1].get_input_anchor(weight_index).get_peer_output_anchor().node

            if bypass_nodes[-2] == weight_bypass:
                weight_node = bypass_nodes[0].get_input_anchor(0).get_peer_output_anchor().node
                weight_helper = TensorProtoHelper(QuantOpInfo.get_node_tensor(weight_node))
                weight = weight_helper.get_data().copy()
                weight_helper.clear_data()
                count = 0
                for bypass_node in bypass_nodes[2:]:
                    if bypass_node.type == 'Reshape':
                        shape_node = bypass_node.get_input_anchor(1).get_peer_output_anchor().node
                        shape = TensorProtoHelper(shape_node.proto).get_data()
                        weight = weight.reshape(shape)
                        count += 1
                    elif bypass_node.type == 'Transpose':
                        perm_helper = AttributeProtoHelper(bypass_node.proto)
                        perm = perm_helper.get_attr_value('perm')
                        weight = weight.transpose(perm)
                        count += 1
                    else:
                        break
                weight_helper.set_data(weight.flatten(), dims=weight.shape, graph=self.graph)
                if count > 0:
                    self._delete_bypass_nodes(bypass_nodes[2: 2 + count])
                    del bypass_nodes[2: 2 + count]
            self._rematch_quantize_nodes(bypass_nodes)

    def _find_consumer(self, quantize_node):
        bypass_dict = {}
        act_replace = []
        weight_fold = []
        act_quant = []
        weight_quant = []

        dequantize_node = quantize_node.get_output_anchor(0).get_peer_input_anchor()[0].node
        for anchor in dequantize_node.get_output_anchor(0).get_peer_input_anchor():
            bypass_dict[anchor.node] = [quantize_node, dequantize_node]

        while bypass_dict:
            consumer, bypass_nodes = bypass_dict.popitem()
            bypass_nodes = bypass_nodes.copy()
            bypass_nodes.append(consumer)

            if consumer.type in BYPASS_NODE_ACT:
                anchors = consumer.get_output_anchor(0).get_peer_input_anchor()
                if not anchors:
                    if self._is_weight(quantize_node):
                        weight_fold.append(bypass_nodes)
                    else:
                        act_replace.append(bypass_nodes)
                    continue

                for anchor in anchors:
                    bypass_dict[anchor.node] = bypass_nodes

            elif consumer.type in CONVERT_QAT_QUANTIZABLE_TYPES:
                act_bypass, weight_bypass = self._quantable_bypass_nodes(bypass_nodes, act_replace, weight_fold)
                if act_bypass:
                    act_quant.append(act_bypass)
                if weight_bypass:
                    weight_quant.append(weight_bypass)
            else:
                if self._is_weight(quantize_node):
                    weight_fold.append(bypass_nodes)
                else:
                    act_replace.append(bypass_nodes)

        return [act_replace, weight_fold, act_quant, weight_quant]

    def _quantable_bypass_nodes(self, bypass_nodes, act_replace, weight_fold):
        act_quant = []
        weight_quant = []

        if bypass_nodes[-1].name not in self.convert_qat_quantable_layers:
            LOGGER.logw('Cannot support convert "QuantizeLinear" node "{}", '
                'for "{}" not supports quant'.format(bypass_nodes[0].name, bypass_nodes[-1].name))
            if self._is_weight(bypass_nodes[0]):
                weight_fold.append(bypass_nodes)
            else:
                act_replace.append(bypass_nodes)
            return act_quant, weight_quant

        act_index, weight_index, _ = QuantOpInfo.get_quant_index(bypass_nodes[-1])
        act_node = bypass_nodes[-1].get_input_anchor(act_index).get_peer_output_anchor().node
        weight_node = bypass_nodes[-1].get_input_anchor(weight_index).get_peer_output_anchor().node

        if bypass_nodes[-2] == act_node:
            self._is_perchannel(bypass_nodes[0])
            act_quant.extend(bypass_nodes)

        elif bypass_nodes[-2] == weight_node:
            if not self._is_weight(bypass_nodes[0]):
                LOGGER.logw('Cannot support convert "QuantizeLinear" node "{}", '
                    'for "{}" has no-const weight input'.format(bypass_nodes[0].name, bypass_nodes[-1].name))
                act_replace.append(bypass_nodes)
                return act_quant, weight_quant

            _, offset = self._get_scale_offset(bypass_nodes[0])
            if (np.array(offset) != 0).any():
                LOGGER.loge(
                    'Cannot support "QuantizeLinear" node "{}" with nonzero offset!'.format(bypass_nodes[0].name))
                raise RuntimeError(
                    'Cannot support "QuantizeLinear" node "{}" with nonzero offset!'.format(bypass_nodes[0].name))

            if not self._check_matmul_weight(bypass_nodes):
                LOGGER.logw('Cannot support convert "QuantizeLinear" node "{}", '
                    'only support 2D weight input for node {}'.format(bypass_nodes[0].name, bypass_nodes[-1].name))
                weight_fold.append(bypass_nodes)
                return act_quant, weight_quant

            if self._check_weight_bypass_nodes(bypass_nodes[2: -1]):
                weight_quant.extend(bypass_nodes)
            else:
                weight_fold.append(bypass_nodes)
        else:
            LOGGER.loge('Cannot support node "{}" with bias quantized!'.format(bypass_nodes[0].name))
            raise RuntimeError('Cannot support node "{}" with bias quantized!'.format(bypass_nodes[0].name))

        return act_quant, weight_quant

    def _delete_bypass_nodes(self, bypass_nodes):
        producer_anchor = bypass_nodes[0].get_input_anchor(0).get_peer_output_anchor()
        producer = producer_anchor.node

        initializers = []
        for bypass_node in bypass_nodes:
            for input_anchor in bypass_node.input_anchors:
                src_anchor = input_anchor.get_peer_output_anchor()
                self.graph.remove_edge(src_anchor.node, src_anchor.index, bypass_node, input_anchor.index)

                if src_anchor.node.type == 'initializer':
                    initializers.append(src_anchor.node)

        consumer_anchors = bypass_nodes[-1].get_output_anchor(0).get_peer_input_anchor()
        consumer_anchors = consumer_anchors.copy()
        for consumer_anchor in consumer_anchors:
            consumer = consumer_anchor.node
            self.graph.remove_edge(bypass_nodes[-1], 0, consumer, consumer_anchor.index)
            self.graph.add_edge(producer, producer_anchor.index, consumer, consumer_anchor.index)

        for initializer in set(initializers):
            self.graph.remove_initializer(initializer)

        for bypass_node in bypass_nodes:
            self.graph.remove_node(bypass_node)

    def _rematch_quantize_nodes(self, bypass_nodes):
        producer_anchor = bypass_nodes[0].get_input_anchor(0).get_peer_output_anchor()
        producer = producer_anchor.node

        consumer_anchors = bypass_nodes[1].get_output_anchor(0).get_peer_input_anchor()
        consumer_anchors = consumer_anchors.copy()
        for consumer_anchor in consumer_anchors:
            if consumer_anchor.node == bypass_nodes[2]:
                self.graph.remove_edge(bypass_nodes[1], 0, bypass_nodes[2], consumer_anchor.index)
                self.graph.add_edge(producer, producer_anchor.index, bypass_nodes[2], consumer_anchor.index)

    def _replace_quantize_nodes(self, bypass_nodes):
        quantize_node = bypass_nodes[0]
        scale, offset = self._get_scale_offset(quantize_node)

        producer_anchor = quantize_node.get_input_anchor(0).get_peer_output_anchor()
        producer = producer_anchor.node

        quant_node_proto = construct_quant_node(
            inputs=[producer.name + '.quant.input0'],
            outputs=[producer.name + '.quant.output0'],
            attrs={
                'scale': 1.0 / scale[0],
                'offset': offset[0],
                'quant_bit': 8
            },
            layer_name=producer.ori_name)

        anti_quant_node_proto = construct_anti_quant_node(
            inputs=[producer.name + '.antiquant.input0'],
            outputs=[producer.name + '.antiquant.output0'],
            attrs={
                'scale': scale[0],
                'offset': offset[0],
                'quant_bit': 8
            },
            layer_name=producer.ori_name)

        quant_node = self.graph.add_node(quant_node_proto)
        quant_node.set_attr('object_node', producer.name)
        anti_quant_node = self.graph.add_node(anti_quant_node_proto)
        anti_quant_node.set_attr('object_node', producer.name)
        self.graph.add_edge(producer, producer_anchor.index, quant_node, 0)
        self.graph.add_edge(quant_node, 0, anti_quant_node, 0)

        consumer_anchors = bypass_nodes[1].get_output_anchor(0).get_peer_input_anchor().copy()
        for consumer_anchor in consumer_anchors:
            if consumer_anchor.node == bypass_nodes[2]:
                self.graph.remove_edge(bypass_nodes[1], 0, bypass_nodes[2], consumer_anchor.index)
                self.graph.add_edge(anti_quant_node, 0, bypass_nodes[2], consumer_anchor.index)

    def _find_constant_input(self, quant_node):
        quant_scale_node = quant_node.get_input_anchor(1).get_peer_output_anchor().node
        qaunt_offset_node = quant_node.get_input_anchor(2).get_peer_output_anchor().node

        dequant_node = quant_node.get_output_anchor(0).get_peer_input_anchor()[0].node
        dequant_scale_node = dequant_node.get_input_anchor(1).get_peer_output_anchor().node
        deqaunt_offset_node = dequant_node.get_input_anchor(2).get_peer_output_anchor().node

        cadi_constant_nodes = [quant_scale_node, qaunt_offset_node, dequant_scale_node, deqaunt_offset_node]
        for cadi_node in cadi_constant_nodes:
            if cadi_node.type in ['Constant']:
                self.quant_constant_node.add(cadi_node)

    def _delete_single_node(self):
        for node in self.quant_constant_node:
            if node.is_isolated:
                self.graph.remove_node(node)