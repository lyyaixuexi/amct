#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quant bias from floa32 to int32.

"""
import copy
import numpy as np

from amct_onnx.utils.vars import QUANT_BIAS_BITS
from amct_onnx.utils.vars import BASE
from amct_onnx.utils.log import LOGGER
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.vars import QUANTIZABLE_TYPES


class BiasQuantPass(BaseFusionPass):
    """
    Function: Quant bias from floa32 to int32.
    APIs: match_pattern, do_pass
    """
    def __init__(self, records):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records

    @staticmethod
    def split_reused_bias(graph, object_node, bias_node):
        """
        Function:split object_node's bias(in bias_node) to several parts if it is reused
        param:graph
        param:object_node, split object_node's bias
        param:bias_node, bias of object_node
        return:new_bias_node, new bias
        """
        if len(bias_node.get_output_anchor(0).get_peer_input_anchor()) <= 1:
            return bias_node

        bias_op = copy.deepcopy(bias_node.proto)
        bias_op.name = '_'.join([bias_op.name, object_node.name])
        new_bias_node = graph.add_node(bias_op)
        if len(new_bias_node.output_anchors) == 0:
            new_bias_node.add_output_anchor(
                '{}_quantized_bias'.format(object_node.name))

        if object_node.type == 'MatMul':
            add_node = object_node.get_consumers(0)[0][0]
            bias_index = 1
            graph.remove_edge(bias_node, 0, add_node, bias_index)
            graph.add_edge(new_bias_node, 0, add_node, bias_index)
        else:
            _, _, bias_index = QuantOpInfo.get_quant_index(object_node)
            graph.remove_edge(bias_node, 0, object_node, bias_index)
            graph.add_edge(new_bias_node, 0, object_node, bias_index)
        return new_bias_node

    @staticmethod
    def quant_bias(bias, scale_w, scale_d, layer_name):
        '''Function: kernel function, quant bias with scale and offset
        Parameters:
            bias: np.array, to be quantized
            scale: float number, quant factor
            offset: int number, quant factor
        Returns:
            quant_bias, np.array with type int32, quantized bias
        '''
        left_limit = -pow(1.0 * BASE, QUANT_BIAS_BITS - 1)
        right_limit = pow(1.0 * BASE, QUANT_BIAS_BITS - 1) - 1
        deq_scale = np.multiply(scale_w, scale_d).reshape([-1])
        quant_bias = np.round(np.true_divide(bias, deq_scale))
        # check the quant_bias in range of int32
        quant_bias = quant_bias.reshape(-1)
        cmp_ans = np.add(quant_bias < left_limit, quant_bias > right_limit)
        if cmp_ans.any():
            invalid_value = quant_bias[np.argmax(cmp_ans)]
            LOGGER.loge('Quantized bias {} of layer "{}" exceed int32 ' \
                'range:[{}, {}], please add it to skip layer.'.format(
                    invalid_value, layer_name,
                    left_limit, right_limit))
            raise RuntimeError('Do bias quantize failed.')
        quant_bias = quant_bias.astype(np.int32)
        return quant_bias

    def match_pattern(self, node):
        """
        Function: Match pattern of node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type == "AveragePool":
            return False

        if node.name not in self.records:
            return False

        if node.type not in QUANTIZABLE_TYPES:
            return False

        bias_node = QuantOpInfo.get_bias_node(node)
        if bias_node is None:
            return False

        return True

    def do_pass(self, graph, object_node):
        """
        Function: Do actual quantization and node's bias is changed to int32.
        Parameters:
            graph: graph structure
            object_node: node to process
        Return: None
        """
        bias_node = QuantOpInfo.get_bias_node(object_node)
        # check whether bias already done quantize
        if bias_node.has_attr('bias_quant_done'):
            raise RuntimeError("{} bias_quant has been quantized." \
                .format(bias_node.name))
        # check bias is reused
        bias_node = self.split_reused_bias(graph, object_node, bias_node)

        bias_tensor = QuantOpInfo.get_node_tensor(bias_node)
        bias_helper = TensorProtoHelper(bias_tensor)
        bias = bias_helper.get_data()
        bias_helper.clear_data()
        bias_int32 = BiasQuantPass.quant_bias(
            bias,
            self.records.get(object_node.name).get('weight_scale'),
            self.records.get(object_node.name).get('data_scale'),
            object_node.name)
        bias_helper.set_data(bias_int32, 'INT32', graph=graph)
        # set bias quantize done flag
        bias_node.set_attr('bias_quant_done', True)
        LOGGER.logd("Quant bias from float32 to int32 for layer '{}' " \
            "success!".format(object_node.name), 'BiasQuantPass')