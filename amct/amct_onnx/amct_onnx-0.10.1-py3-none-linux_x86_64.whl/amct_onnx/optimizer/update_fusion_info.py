#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Restore fusion info from configuration to node in graph

"""
from amct_onnx.configuration.configuration import Configuration


class UpdateFusionInfoPass():
    """
    Function: Restore fusion info from configuration to node in graph
    APIs: set_up, tear_down, match_pattern, do_pass, run
    """
    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        self.op_names = []
        self.fusion_info = None

    @staticmethod
    def tear_down():
        """
        Function: Do some tear down for pass. Delete inner fusion info in
            Configuration
        Parameter: None
        Return: None
        """
        Configuration().delete_fusion_info()

    def set_up(self):
        """
        Function: Do some set up for pass. Get inner fusion info from
            Configuration
        Parameter: None
        Return: None
        """
        self.fusion_info = Configuration().inner_fusion_info
        self.op_names = [op.name for op in self.fusion_info.graph[0].op]

    def match_pattern(self, node):
        """
        Function: Find node need restore info in graph
        Parameters:
            node: node in graph
        Return: True: node need to restore info
                False: skip the node
        """
        if node.name not in self.op_names:
            return False

        return True

    def do_pass(self, object_node):
        """
        Function: restore fusion info to object_node
        Parameters:
            object_node: matched node
        Return: None
        """
        idx = self.op_names.index(object_node.name)
        attr_info = self.fusion_info.graph[0].op[idx].attr
        for attr in attr_info:
            key = attr.key
            if attr.value.HasField('s'):
                value = attr.value.s
            if attr.value.HasField('list'):
                value = attr.value.list.s
            object_node.set_attr(key, value)

    def run(self, graph):
        """
        Function: Restore fusion info for graph
        Parameters:
            graph: Graph
        Return: None
        """
        self.set_up()
        # Step1: match pattern and record first matched node
        matched_nodes = []
        for node in graph.nodes:
            if self.match_pattern(node):
                matched_nodes.append(node)
        # Step2: do each matched node fusion operation
        for node in matched_nodes:
            self.do_pass(node)

        self.tear_down()
