#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert AscendDequant in the graph

"""
import numpy as np
from onnx import onnx_pb

from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.fusion_info_utils import add_equivalent_info_attr
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.quant_node import QuantOpInfo

from amct_onnx.utils.vars import QUANTIZABLE_TYPES


class InsertDequantPass(BaseFusionPass):
    """
    Function: Insert AscendDequant
    APIs: match_pattern, do_pass
    """
    def __init__(self, records):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records

    def match_pattern(self, node):
        """
        Function: Match pattern of node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type not in QUANTIZABLE_TYPES:
            return False
        if node.name not in self.records:
            return False
        return True

    def do_pass(self, graph, object_node):
        """
        Function: Do actually inserting AscendDequant.
        Parameters:
            graph: graph structure
            object_node: node to process
        Return: None
        """
        # Step1: add node_dequant and param_dequant in graph
        node_dequant, param_dequant = self.insert_layer(graph, object_node)
        # Step2: Relink nodes in th graph
        graph.add_edge(param_dequant, 0, node_dequant, 1)
        # if 'MatMul' has 'Add' bias, insert SEARCHN after 'Add'
        if object_node.type == 'MatMul' and QuantOpInfo.get_bias_node(object_node) is not None:
            add_node = object_node.get_consumers(0)[0][0]
            graph.insert_node_after(node_dequant, 0, 0, add_node, 0)
        else:
            graph.insert_node_after(node_dequant, 0, 0, object_node, 0)
        # Step2: Record inserted dequant node info
        add_equivalent_info_attr(object_node, [node_dequant, param_dequant],
                                 new_input=None, new_output=node_dequant)
        LOGGER.logd(
            'Add dequant "%s" to "%s" success.' %
            (node_dequant.name, object_node.name), 'InsertDequantPass')

    def insert_layer(self, graph, object_node):
        """
        Function: Insert a node for param_dequant in the graph.
        Parameters:
            graph: graph structure
            layer_name: a string, name of layer for param_dequant
        Returns:
            node_dequant: a dequant node
            param_dequant: a node containing param_dequant
        """
        # concat dequant param to uint64
        deq_scale = self.records.get(object_node.name).get('data_scale') * \
            self.records.get(object_node.name).get('weight_scale')
        quant_param = fuse_dequant_param(
            deq_scale,
            self.records.get(object_node.name).get('weight_offset'),
            self.records.get(object_node.name).get('shift_n'))
        # add quant_param as initializer in graph
        initializer_proto = construct_dequant_param(graph, quant_param,
                                                    object_node.ori_name)
        param_dequant = graph.add_node(initializer_proto)
        # add dequant ad node in graph
        node_proto = construct_dequant_node(
            [object_node.ori_name + '.dequant.input0', \
             object_node.ori_name + '.dequant.param'],
            [object_node.ori_name + '.dequant.output0'],
            object_node.ori_name)
        node_dequant = graph.add_node(node_proto)

        return node_dequant, param_dequant


def construct_dequant_node(inputs,
                           outputs,
                           layer_name):
    """
    Function: construct dequant node in onnx
    Inputs:
        input: a list of inputs' name
        output: a list of outputs' name
        layer_name: a string, layer to be quantized
    Return: node_proto: AscendDequant's onnx_pb.NodeProto
    """
    node_proto = onnx_pb.NodeProto()

    node_proto.op_type = 'AscendDequant'
    node_proto.name = layer_name + '.dequant'

    node_proto.input.extend(inputs)
    node_proto.output.extend(outputs)

    return node_proto


def construct_dequant_param(graph, dequant_param,
                            layer_name):
    """ Construct a initializer for dequant_param
    """
    initializer_proto = onnx_pb.TensorProto()
    initializer_proto.name = layer_name + '.dequant.param'
    tensor_helper = TensorProtoHelper(initializer_proto)
    tensor_helper.set_data(dequant_param,
                           'UINT64', [len(dequant_param)],
                           graph=graph)

    return initializer_proto


def fuse_dequant_param(float32_deq_scale, int8_offset_w, uint8_shift_bits):
    """Fused dequant scale, offset_w and shift_bits to uint64 data
    """
    uint8_offset_w = np.frombuffer(int8_offset_w, np.uint8)
    uint32_deq_scale = np.frombuffer(float32_deq_scale, np.uint32)
    uint8_shift_n = np.frombuffer(uint8_shift_bits, np.uint8)

    # fuse parameter
    # |-----------------|47:40|--------|39:32|--------|31:0|
    #                  offset_w [8]    shift_N [8]    deq_scale [32]
    scale_length = float32_deq_scale.size
    param_quant = np.zeros(scale_length, dtype=np.uint64)
    for index in range(scale_length):
        param_quant[index] = uint8_offset_w[index]
        param_quant[index] = (param_quant[index] << np.uint32(8))\
                                + uint8_shift_n[index]
        param_quant[index] = (param_quant[index] << np.uint32(32))\
                                + uint32_deq_scale[index]
    return param_quant
