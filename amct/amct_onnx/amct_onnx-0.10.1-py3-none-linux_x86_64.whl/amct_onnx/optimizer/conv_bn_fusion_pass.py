#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Convolution + BatchNorm fusion operation

"""
import math
from onnx import onnx_pb
import numpy as np

from amct_onnx.configuration.configuration import Configuration
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.fusion_info_utils import add_fusion_info_attr

from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
from amct_onnx.algo.conv_bn_fuse import fuse_conv_bn
from amct_onnx.algo.conv_scale_fuse import fuse_conv_scale
from amct_onnx.opset_utils import BatchNormalizationUtils
from amct_onnx.utils.vars import DEFAULT_BN_EPSILON

WEIGHT_SUPPORT_DIMENSION = {4, 5}


class ConvBnFusionPass(BaseFusionPass):
    """
    Function: Do "Convolution" layer and "BatchNorm" layer fusion operation
    APIs: match_pattern, do_pass, get_np_array_from_conv,
          get_np_array_from_bn, write_fused_weights_bias_back
    """
    def __init__(self, record_helper=None):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.config = Configuration()
        self.record_helper = record_helper

    @staticmethod
    def is_fusionable_bn(node):
        """ is the bn can be fused"""
        if node.type != 'BatchNormalization':
            return False
        bn_utils = BatchNormalizationUtils(node)
        if bn_utils.has_attribute('spatial') and \
                bn_utils.get_attribute_value('spatial') != 1:
            return False
        if bn_utils.has_attribute("training_mode") and \
                bn_utils.get_attribute_value("training_mode") != 0:
            return False
        if len(node.input_anchors) != 5:
            raise RuntimeError('BatchNorm node should only have 5 output ' \
                'actually have {}'.format(len(node.input_anchors)))
        return True

    @staticmethod
    def _conv_bn_node_fusion_kernel(graph, node_conv, node_bn):
        """do conv+bn graph fusion"""
        node_scale = node_bn.get_input_anchor(1).get_peer_output_anchor().node
        node_b = node_bn.get_input_anchor(2).get_peer_output_anchor().node
        node_mean = node_bn.get_input_anchor(3).get_peer_output_anchor().node
        node_var = node_bn.get_input_anchor(4).get_peer_output_anchor().node
        # remove input links
        graph.remove_edge(node_conv, 0, node_bn, 0)
        graph.remove_edge(node_scale, 0, node_bn, 1)
        graph.remove_edge(node_b, 0, node_bn, 2)
        graph.remove_edge(node_mean, 0, node_bn, 3)
        graph.remove_edge(node_var, 0, node_bn, 4)
        # remove output links
        bn_peer_in_anchors = \
            node_bn.get_output_anchor(0).get_peer_input_anchor()
        bn_peer_input_nodes = []
        bn_peer_input_indexes = []
        for input_anchor in bn_peer_in_anchors:
            bn_peer_input_nodes.append(input_anchor.node)
            bn_peer_input_indexes.append(input_anchor.index)
        for index, element in enumerate(bn_peer_input_nodes):
            graph.remove_edge(node_bn, 0, element,
                              bn_peer_input_indexes[index])

        # Step3: Add link from conv to bn_peer_input_node
        for index, element in enumerate(bn_peer_input_nodes):
            graph.add_edge(node_conv, 0, element, bn_peer_input_indexes[index])
            if element.type == 'graph_output':
                node_conv.get_output_anchor(0).set_name(element.name)

        graph.remove_node(node_bn)
        # nodes maybe shared
        need_reove = {node_scale, node_b, node_mean, node_var}
        for ele in need_reove:
            if not ele.is_isolated:
                continue
            if ele.type == 'Initializer':
                graph.remove_initializer(ele)
            else:
                graph.remove_node(ele)

    def _conv_bn_params_fusion_kernel(self, weights, bias, node_bn, node_conv):
        """do conv+bn params fusion"""
        # get bn param from bn node
        node_mean = node_bn.get_input_anchor(3).get_peer_output_anchor().node
        bn_mean = QuantOpInfo.get_node_value(node_mean)

        node_var = node_bn.get_input_anchor(4).get_peer_output_anchor().node
        bn_var = QuantOpInfo.get_node_value(node_var)
        if AttributeProtoHelper(node_bn.proto).has_attr('epsilon'):
            bn_eps = AttributeProtoHelper(
                node_bn.proto).get_attr_value('epsilon')
        else:
            bn_eps = DEFAULT_BN_EPSILON

        fused_weights, fused_bias = fuse_conv_bn([weights, bias],
                                                 [bn_mean, bn_var, bn_eps])

        # get scale param from scale node
        node_scale = node_bn.get_input_anchor(1).get_peer_output_anchor().node
        scale_scale = QuantOpInfo.get_node_value(node_scale)

        node_b = node_bn.get_input_anchor(2).get_peer_output_anchor().node
        scale_b = QuantOpInfo.get_node_value(node_b)

        fused_weights, fused_bias = fuse_conv_scale(fused_weights, fused_bias,
                                                    scale_scale, scale_b)

        # if do fusion after qat, update quant factors in record
        if self.record_helper is not None and self.record_helper.has_key(node_conv.name):
            self._update_record_for_fusion(bn_var, bn_eps, scale_scale, node_conv)
            LOGGER.logd(
            'Update record for conv:\'{}\' + bn:\'{}\' fuison!'.format(
                node_conv.name, node_bn.name), 'ConvBnFusionPass')

        return fused_weights.astype(weights.dtype), fused_bias.astype(weights.dtype)

    def _check_fused_data_overflow(self, data):
        """ check data value after fusing """
        judge_itr = (math.isinf(i) for i in data.reshape(-1,))
        return any(judge_itr)

    def _update_record_for_fusion(self, bn_var, bn_eps, bn_scale, node_conv):
        """ update quant factors in record for fused weight """
        scale_w, offset_w = self.record_helper.read_weights_scale_offset(node_conv.name)
        if len(scale_w) == len(offset_w):
            if len(scale_w) == 1:
                scale_w = np.ones((bn_var.size), np.float32) * scale_w[0]
                offset_w = np.ones((bn_var.size), np.int8) * offset_w[0]
        else:
            raise RuntimeError('scale_w must be same length with offset_w.')
        variance = np.add(bn_var, bn_eps)
        stdev = np.sqrt(variance)
        fused_scale_w = np.divide(scale_w, stdev) * np.absolute(bn_scale)
        self.record_helper.record_weights_scale_offset(node_conv.name, fused_scale_w, offset_w)

    def match_pattern(self, node):
        """
        Function: Match pattern of "Conv" + "BatchNormalization" in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if not self.is_fusionable_bn(node):
            return False

        node_conv, _ = node.get_producer(0)
        # If do Conv + BN fusion, conv must can only output to bn
        if len(node_conv.output_anchors) != 1 or \
            len(node_conv.get_output_anchor(0).get_peer_input_anchor()) != 1:
            return False
        skip_fusion_layers = [] if self.record_helper is not None else self.config.get_skip_fusion_layers()
        if node_conv.type != 'Conv' or \
            node_conv.name in skip_fusion_layers:
            return False

        return True

    def do_pass(self, graph, object_node):
        """
        Function: Do actual "Convolution" layer and "BatchNorm" layer
                  fusion operation
        Parameters: graph: graph structure
                    object_node: node to process
        Return: None
        """
        bn_peer_output_anchor = \
            object_node.get_input_anchor(0).get_peer_output_anchor()
        if bn_peer_output_anchor.index != 0:
            raise RuntimeError('Conv output index should be 0, actually is ', \
                bn_peer_output_anchor.index)
        node_conv = bn_peer_output_anchor.node
        # Step1: fuse "bn + conv" in model
        conv_weights_node = QuantOpInfo.get_weight_node(node_conv)
        weight_tensor = QuantOpInfo.get_node_tensor(conv_weights_node)
        weights_helper = TensorProtoHelper(weight_tensor)
        weights = weights_helper.get_data()
        if len(weights.shape) not in WEIGHT_SUPPORT_DIMENSION:
            LOGGER.logd(
                "conv weight is not 4 or 5 dimension, "
                "do not support conv bn fusion.")
            return
        if len(node_conv.input_anchors) <= 2:
            bias = None
        else:
            conv_bias = QuantOpInfo.get_bias_node(node_conv)
            bias_tensor = QuantOpInfo.get_node_tensor(conv_bias)
            bias_helper = TensorProtoHelper(bias_tensor)
            bias = bias_helper.get_data()

        fused_weights, fused_bias = self._conv_bn_params_fusion_kernel(
            weights, bias, object_node, node_conv)

        # check inf overflow
        if self._check_fused_data_overflow(fused_weights) or self._check_fused_data_overflow(fused_bias):
            LOGGER.logd(f'Cannot do conv:\'{node_conv.name}\' + bn:\'{object_node.name}\' fuison, \
                    due to fused bias or weight has overflowed, some value is inf.', 'ConvBnFusionPass')
            return

        # if do fusion after qat, check whether fused_bias can be quantized.
        if self.record_helper is not None and self.record_helper.has_key(node_conv.name):
            scale_d, _ = self.record_helper.read_activation_scale_offset(node_conv.name)
            scale_w, _ = self.record_helper.read_weights_scale_offset(node_conv.name)
            if (fused_bias / scale_d / scale_w > np.iinfo(np.int32).max).any():
                LOGGER.logd(
                    'Cannot do conv:\'{}\' + bn:\'{}\' fuison, due to fused bias \
                    greater than np.int32 max value after quantize'.format(node_conv.name, object_node.name),
                    'ConvBnFusionPass')
                return

        # Set fused weights and bias back
        weights_helper.clear_data()
        weights_helper.set_data(fused_weights.flatten())
        if bias is None:
            bias_tensor = onnx_pb.TensorProto()
            bias_tensor.name = '%s.bias' % (node_conv.name)
            bias_helper = TensorProtoHelper(bias_tensor)
            type_string = 'FLOAT' if weights.dtype == np.float32 else 'FLOAT16'
            bias_helper.set_data(fused_bias,
                                 type_string=type_string,
                                 dims=[fused_bias.size],
                                 graph=graph)
            conv_bias = graph.add_node(bias_tensor)
            node_conv.add_input_anchor('%s.bias' % (node_conv.name))
            graph.add_edge(conv_bias, 0, node_conv, 2)
        else:
            bias_helper.clear_data()
            bias_helper.set_data(fused_bias)

        # Step2: remove edge of BatchNorm
        self._conv_bn_node_fusion_kernel(graph, node_conv, object_node)

        # Step3: Record fusion info to convolution node
        add_fusion_info_attr(node_conv, [object_node], object_node)

        LOGGER.logd(
            'Do conv:\'{}\' + bn:\'{}\' fuison success!'.format(
                node_conv.name, object_node.name), 'ConvBnFusionPass')