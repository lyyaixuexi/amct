#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert AscendQuant in the graph

"""
from onnx import onnx_pb
from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.fusion_info_utils import add_equivalent_info_attr
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
from amct_onnx.utils.attrs_list import ATTR_NODE_TWO_INPUTS
from amct_onnx.utils.vars import QUANTIZABLE_TYPES
from amct_onnx.utils.vars import CLIBRATION_BIT
from amct_onnx.utils.vars import TENSOR_QUANTIZABLE_TYPES
from amct_onnx.utils.quant_node import QuantOpInfo

SYNC_IN_OUT_TYPE = [onnx_pb.TensorProto.DataType.FLOAT]


class InsertQuantPass(BaseFusionPass):
    """
    Function: Insert AscendQuant
    APIs: match_pattern, do_pass
    """
    def __init__(self, records):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
            num_bits: int number indicating the bit to be quanted such 8
        Return: None
        """
        BaseFusionPass.__init__(self)
        if records:
            self.records = records
        else:
            self.records = {}
        self.preprocess_tensor_quantize_config()
        self.num_bits = CLIBRATION_BIT

    def match_pattern(self, node):
        """
        Function: Match pattern of node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type not in QUANTIZABLE_TYPES + TENSOR_QUANTIZABLE_TYPES:
            return False
        if node.name not in self.records:
            return False
        return True

    def do_pass(self, graph, object_node):
        """
        Function: Do actually inserting AscendQuant.
        Parameters:
            graph: graph structure
            object_node: node to process
        Return: None
        """
        is_tensor_quantize = self.records.get(object_node.name).get('tensor_quantize')

        if is_tensor_quantize:
            object_names = self.records.get(object_node.name).get('object_names')
            for object_name in object_names:
                act_index = self.records.get(object_name).get('act_index')
                node_quant = self.generate_quant_node(graph, object_node, object_name, True)
                anti_node = self.generate_antiquant_node(graph, object_node, object_name, True)
                graph.insert_node_before(node_quant, 0, 0, object_node, act_index)

                LOGGER.logd("Insert quant layer '{}' before '{}' " \
                    "success!".format(node_quant.name, object_node.name), \
                                    'InsertQuantPass')

                graph.insert_node_before(anti_node, 0, 0, object_node, act_index)

                LOGGER.logd("Insert antiquant layer '{}' before '{}' " \
                    "success!".format(anti_node.name, object_node.name), \
                                    'InsertQuantPass')

                # Record inserted quant node info
                add_equivalent_info_attr(object_node, [node_quant, anti_node],
                                            new_input=node_quant, new_output=None)
        else:
            obj_producer, _ = object_node.get_producer(0)
            node_quant = self.generate_quant_node(graph, object_node, object_node.name)
            if object_node.type == "AveragePool" and obj_producer.type == "Pad":
                graph.insert_node_before(node_quant, 0, 0, obj_producer, 0)
                # Record inserted quant node info
                add_equivalent_info_attr(object_node, [node_quant, obj_producer],
                                        new_input=node_quant, new_output=None)
            else:
                self.set_node_quant_type(node_quant, object_node)
                graph.insert_node_before(node_quant, 0, 0, object_node, 0)
                # Record inserted quant node info
                add_equivalent_info_attr(object_node, [node_quant],
                                        new_input=node_quant, new_output=None)

            LOGGER.logd("Insert quant layer '{}' before '{}' " \
                "success!".format(node_quant.name, object_node.name), \
                                'InsertQuantPass')
            # insert quant in weight is necessary
            self.insert_weight_quant(graph, object_node)

    def set_node_quant_type(self, node_quant, object_node):
        ''' set quant-type for domain select '''
        quant_type = onnx_pb.TensorProto.DataType.FLOAT
        if object_node.type == "AveragePool":
            node_quant.set_quant_type(quant_type)
            return
        weight_node = QuantOpInfo.get_weight_node(object_node)
        if weight_node.type not in ['initializer', 'Constant']:
            bias_node = QuantOpInfo.get_bias_node(object_node)
            if bias_node is not None:
                bias_tensor = QuantOpInfo.get_node_tensor(bias_node.get_producer(1)[0])
                quant_type = bias_tensor.data_type
        else:
            weight_tensor = QuantOpInfo.get_node_tensor(weight_node)
            quant_type = weight_tensor.data_type
        if quant_type not in SYNC_IN_OUT_TYPE:
            node_quant.set_quant_type(quant_type)

    def insert_weight_quant(self, graph, object_node):
        """
        Function: Insert quant in 'weight' input if weight is not constant
        param:graph, Graph
        param:node, Node, node to process
        return: None
        """
        if not object_node.has_attr(ATTR_NODE_TWO_INPUTS) or not object_node.get_attr(ATTR_NODE_TWO_INPUTS):
            return
        attrs = {
            'scale': 1.0 / self.records.get(object_node.name).get('weight_scale'),
            'offset': self.records.get(object_node.name).get('weight_offset'),
            'quant_bit': self.num_bits
        }
        proto_node = construct_quant_node(
            ['.'.join([object_node.name, 'quant_1', 'input0'])],
            ['.'.join([object_node.name, 'quant_1', 'output0'])],
            attrs,
            object_node.ori_name)
        node_quant = graph.add_node(proto_node)
        node_quant.set_attr('object_node', object_node.name)

        graph.insert_node_before(node_quant, 0, 0, object_node, 1)
        # Record inserted quant node info
        add_equivalent_info_attr(object_node, [node_quant],
                                    new_input=node_quant, new_output=None)

        LOGGER.logd("Insert weight quant layer '{}' before '{}' success!".format(node_quant.name, object_node.name), \
                    'InsertQuantPass')

    def generate_antiquant_node(self, graph, object_node, object_name, is_tensor_quantize=False):
        ''' Generate AscendAntiQuant node '''
        scale = self.records.get(object_name).get('data_scale')
        offset = self.records.get(object_name).get('data_offset')
        if is_tensor_quantize:
            layer_name = object_name
        else:
            layer_name = object_node.ori_name
        anti_quant_node_proto = construct_anti_quant_node(
            ['.'.join([object_name, 'antiquant', 'input0'])],
            ['.'.join([object_name, 'antiquant', 'output0'])],
            attrs={
                'scale': scale,
                'offset': offset,
                'quant_bit': self.num_bits
            },
            layer_name=layer_name)
        anti_quant_node = graph.add_node(anti_quant_node_proto)
        anti_quant_node.set_attr('object_node', object_node.name)

        return anti_quant_node

    def generate_quant_node(self, graph, object_node, object_name, is_tensor_quantize=False):
        ''' Generate AscendQuant node '''
        attrs = {
            'scale': 1.0 / self.records.get(object_name).get('data_scale'),
            'offset': self.records.get(object_name).get('data_offset'),
            'quant_bit': self.num_bits
        }
        if is_tensor_quantize:
            layer_name = object_name
        else:
            layer_name = object_node.ori_name
        proto_node = construct_quant_node(
            ['.'.join([object_name, 'quant', 'input0'])],
            ['.'.join([object_name, 'quant', 'output0'])],
            attrs,
            layer_name)
        node_quant = graph.add_node(proto_node)
        node_quant.set_attr('object_node', object_name)
        return node_quant

    def preprocess_tensor_quantize_config(self):
        ''' process tensor_quantize_config before match '''
        for key in list(self.records.keys()):
            if ':' in key:
                node_name, input_index = key.split(':')
                # in order to pass match_pattern and trans record info.
                if node_name not in self.records:
                    self.records[node_name] = {'object_names':[], 'tensor_quantize':True}
                self.records[node_name]['object_names'].append(key)
                self.records[key]['act_index'] = int(input_index)


def construct_quant_node(inputs,
                         outputs,
                         attrs,
                         layer_name):
    """
    Function: construct quant node in onnx
    Inputs:
        input: a list of inputs' name
        output: a list of outputs' name
        attrs: a dict of attrs including
            scale: numpy.array
            offset: numpy.array
            quant_bit: a number
        layer_name: a string, layer to be quantized
    """
    proto_node = onnx_pb.NodeProto()

    proto_node.name = '.'.join([layer_name, 'quant'])
    proto_node.op_type = 'AscendQuant'
    proto_node.input.extend(inputs)
    proto_node.output.extend(outputs)

    attr_helper = AttributeProtoHelper(proto_node)
    attr_helper.set_attr_value('scale', 'FLOAT', attrs['scale'])
    attr_helper.set_attr_value('offset', 'FLOAT', attrs['offset'])
    attr_helper.set_attr_value('quant_bit', 'INT', attrs['quant_bit'])

    return proto_node


def construct_anti_quant_node(inputs,
                              outputs,
                              attrs,
                              layer_name):
    """
    Function: construct anti-quant node in onnx
    Inputs:
        input: a list of inputs' name
        output: a list of outputs' name
        attrs: a dict of attrs including
            scale: numpy.array
            offset: numpy.array
            quant_bit: a number
        layer_name: a string, layer to be quantized
    """
    antiquant_node_proto = onnx_pb.NodeProto()

    antiquant_node_proto.name = layer_name + '.anti_quant'
    antiquant_node_proto.op_type = 'AscendAntiQuant'
    antiquant_node_proto.input.extend(inputs)
    antiquant_node_proto.output.extend(outputs)

    attr_helper = AttributeProtoHelper(antiquant_node_proto)
    attr_helper.set_attr_value('scale', 'FLOAT', attrs['scale'])
    attr_helper.set_attr_value('offset', 'FLOAT', attrs['offset'])
    attr_helper.set_attr_value('quant_bit', 'INT', attrs['quant_bit'])

    return antiquant_node_proto