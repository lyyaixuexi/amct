#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert searchn layer couple with layer to be quantized

"""
from google.protobuf import text_format
from onnx import onnx_pb

from amct_onnx.configuration.check import GraphChecker
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.configuration.configuration import Configuration
from amct_onnx.proto import scale_offset_record_pb2
from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.vars import SHIFT_N_TYPES
from amct_onnx.utils.vars import CHANNEL_WISE_TYPES
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.utils.attrs_list import ATTR_NODE_TWO_INPUTS
from amct_onnx.common.utils.record_file_operator import read_weights_scale_offset

INSERT_SEARCH_N_DONE_FLAG = 'eltwise_opt_insert_searchn'
ACT_CALIBRATION_NODE_TYPE = ('IFMR', 'HFMG')


def generate_scalew_node(records, graph, layer_name):
    """
    Function: create scale_w node for layer node with layer_name.
    Parameters:
    records: ScaleOffsetRecord.
    graph: graph IR.
    layer_name: name of the layer to be modified.
    Return: scalew_node: generated scalew_node.
    """
    scale_w, _ = read_weights_scale_offset(records, layer_name)
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'scale_w'])
    node_proto.op_type = 'Constant'
    node_proto.doc_string = 'scale_w for SearchN'
    node_proto.output.extend(['.'.join([layer_name, 'scale_w', 'output0'])])

    AttributeProtoHelper(node_proto).set_attr_value('value', 'TENSOR', None)
    attr = node_proto.attribute[0]
    TensorProtoHelper(attr.t).set_data(scale_w, 'FLOAT', [len(scale_w)], graph=graph)

    scalew_node = graph.add_node(node_proto)

    return scalew_node


def generate_transpose_node(graph, layer_name, perm):
    """
    Function: create transpose_node for layer node with layer_name.
    Parameters:
    graph: graph IR.
    layer_name: name of the layer to be modified.
    perm: transpose dim
    Return: scalew_node: generated transpose_node.
    """
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'transpose'])
    node_proto.op_type = 'Transpose'
    node_proto.doc_string = 'transpose for SearchN'
    node_proto.input.extend(
        ['.'.join([layer_name, 'transpose', 'input0'])])
    node_proto.output.extend(
        ['.'.join([layer_name, 'transpose', 'output0'])])

    AttributeProtoHelper(node_proto).set_attr_value('perm', 'INTS', perm)

    transpose_node = graph.add_node(node_proto)

    return transpose_node


def get_node_perm(object_node):
    """
    Function: Find 'Convolution' or 'ConvTranspose' node need to create transpose_node
    Parameters: node: node in graph
    Return: transpose dim
    """
    perm = []
    conv_weights_node = QuantOpInfo.get_weight_node(object_node)
    weight_tensor = QuantOpInfo.get_node_tensor(conv_weights_node)
    weights_helper = TensorProtoHelper(weight_tensor)
    weights = weights_helper.get_data()
    if len(weights.shape) == 4:
        perm = [1, 0, 2, 3]
    if len(weights.shape) == 5:
        perm = [1, 0, 2, 3, 4]
    if not perm:
        raise RuntimeError('Only support Conv2d or Conv3d, transpose perm parameter is invalid.')
    return perm


class InsertSearchNPass(BaseFusionPass):
    """
    Function: Insert searchn layer couple with layer to be quantized
    APIs: match_pattern, do_fusion
    """
    def __init__(self):
        """
        Function: Init InsertIFMRPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = scale_offset_record_pb2.ScaleOffsetRecord()
        self.conf = Configuration()
        self.record_file_path = self.conf.get_record_file_path()

    @staticmethod
    def match_pattern(node):
        """
        Function: Find 'Convolution' or 'InnerProduct' node need to insert IFMR
        layer in graph
        Parameters: node: node in graph
        Return: True: node that need to insert searchn layer; False: skip the node
        """
        # match type
        if node.type not in SHIFT_N_TYPES:
            return False
        if not GraphChecker.check_quantize_type(node):
            return False
        if node.has_attr(INSERT_SEARCH_N_DONE_FLAG):
            return False
        # match config
        if node.name not in Configuration().get_quant_config():
            return False
        return True

    @staticmethod
    def generate_searchn_node(graph, object_layers, act_quant_type, node_index=None):
        """
        Function: Genereate SeachN node according to input parameters.
        Parameters:
        graph: graph that add SeachN node to.
        object_layers: layer that add SeachN node for.
        act_quant_type: activation calibration node type HFMG/IFMR.
        Return: searchn_node: generated SeachN node.
        """
        if not isinstance(object_layers, list) or not object_layers:
            raise RuntimeError('Input object_layers must be a non-empty list')

        searchn_op = onnx_pb.NodeProto()
        # Set basic info
        searchn_op.name = "{}_{}".format('_'.join(object_layers), 'searchn_op')
        searchn_op.op_type = 'SearchNv2' if act_quant_type == 'HFMG' else 'SearchN'

        searchn_op.domain = 'amct.customop'
        searchn_op.input[:] = ['%s_input:1' % searchn_op.name,
                               '%s_input:2' % searchn_op.name,
                               '%s_input:3' % searchn_op.name]
        searchn_op.output[:] = []
        # Set quantize algorithm parameters
        batch_num = Configuration().get_global_config('batch_num')

        searchn_helper = AttributeProtoHelper(searchn_op)
        searchn_helper.set_attr_value('batch_num', 'INT', batch_num)
        searchn_helper.set_attr_value('layer_num', 'INT', len(object_layers))
        for index, object_layer in enumerate(object_layers):
            searchn_helper.set_attr_value('object_layer%d' % index, 'STRING',
                                          bytes('%s ' % object_layer, 'utf-8'))
        searchn_helper.set_attr_value(
            'record_file_path', 'STRING',
             bytes("{} ".format(Configuration().get_record_file_path()), 'utf-8'))
        # Add node of SearchN to graph
        searchn_node = graph.add_node(searchn_op, node_index)
        return searchn_node

    @staticmethod
    def get_bypass_act_quant_node(object_node, in_idx=0):
        """
        Function: Find the bypass act quant node of object_node
        Parameters: object_node: target node
        Return: act_quant_node: bypass act quant node of object_node
        """
        object_name = object_node.name
        producer_node, out_idx = object_node.get_producer(in_idx)
        brother_nodes, _ = producer_node.get_consumers(out_idx)
        act_quant_node = None
        # Traverse all brother ops of object_node to find the bypass IFMR/HFMG op
        for peer_node in brother_nodes:
            # The normal case: the brother op is the inserted bypass IFMR/HFMG op
            if peer_node.type in ACT_CALIBRATION_NODE_TYPE and object_name in peer_node.name:
                act_quant_node = peer_node
                break
            # The joint-quant case: the brother op will match "Flatten->Concat->IFMR/HFMG"
            if peer_node.type == 'Flatten':
                child_node = peer_node.get_consumers(0)[0][0]
                if child_node.type == 'Concat':
                    grand_child_node = child_node.get_consumers(0)[0][0]
                    if grand_child_node.type in ACT_CALIBRATION_NODE_TYPE and object_name in grand_child_node.name:
                        act_quant_node = grand_child_node
                        break
        if act_quant_node is None:
            raise RuntimeError('Cannot find "IFMR/HFMG" node for "%s".' % object_name)
        return act_quant_node

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, 'r') as record_read_file:
            pbtxt_string = record_read_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def do_pass(self, graph, object_node):
        """
        Function: Do actual insert searchn layer operation.
        Parameters: graph: graph that contains object node object_node: node to process
        Return: None
        """
        object_name = object_node.name
        act_quant_node = InsertSearchNPass.get_bypass_act_quant_node(object_node)

        # Create SearchN/SearchNv2 and the related input scalew_node
        searchn_node = self.generate_searchn_node(graph, [object_name], act_quant_node.type)
        if object_node.has_attr(ATTR_NODE_TWO_INPUTS) and object_node.get_attr(ATTR_NODE_TWO_INPUTS):
            scalew_node = InsertSearchNPass.get_bypass_act_quant_node(object_node, 1)
        else:
            scalew_node = generate_scalew_node(self.records, graph, object_name)

        # Insert Transpose node to trans CHANNEL_WISE_TYPES nodes’ output to CNHW for data accumulation
        if object_node.type in CHANNEL_WISE_TYPES:
            perm = get_node_perm(object_node)
            transpose_node = generate_transpose_node(graph, object_name, perm)
            graph.add_edge(object_node, 0, transpose_node, 0)
            graph.add_edge(transpose_node, 0, searchn_node, 0)
        else:
            # if 'MatMul' has 'Add' bias, insert SEARCHN after 'Add'
            if object_node.type == 'MatMul' and QuantOpInfo.get_bias_node(object_node) is not None:
                add_node = object_node.get_consumers(0)[0][0]
                graph.add_edge(add_node, 0, searchn_node, 0)
            else:
                graph.add_edge(object_node, 0, searchn_node, 0)

        # link IFMR/HFMG and scalew_node nodes' output to searchn_node
        graph.add_edge(act_quant_node, 0, searchn_node, 1)
        graph.add_edge(scalew_node, 0, searchn_node, 2)

        LOGGER.logd(
            "Insert SearchN layer '{}' to '{}' success!".format(
                searchn_node.name, object_name), 'InsertSearchNPass')
