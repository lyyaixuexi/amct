#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Fakequant bias from int32 to float32.

"""
import numpy as np

from amct_onnx.utils.log import LOGGER
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.vars import QUANTIZABLE_TYPES


class BiasFakequantPass(BaseFusionPass):
    """
    Function: Fakequant bias from int32 to float32
    APIs: match_pattern, do_pass
    """
    def __init__(self, records):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records

    @staticmethod
    def do_pass(graph, object_node):
        """
        Function: Do actual quantization and node's bias is changed to float32.
        Parameters:
            graph: graph structure
            object_node: node to process
        Return: None
        """
        bias_node = QuantOpInfo.get_bias_node(object_node)
        # check whether bias is reused and already done fake quantize
        if bias_node.has_attr('bias_fakequant_done'):
            raise RuntimeError("{} bias_fakequant has been quantized." \
                .format(bias_node.name))
        bias_tensor = QuantOpInfo.get_node_tensor(bias_node)
        bias_helper = TensorProtoHelper(bias_tensor)
        int32_bias = bias_helper.get_data()
        float_bias = int32_bias.astype(np.float32)

        bias_helper.clear_data()
        bias_helper.set_data(float_bias.reshape(-1), 'FLOAT', graph=graph)
        # set bias fake quantize done flag
        bias_node.set_attr('bias_fakequant_done', True)

        LOGGER.logd("Fakequant bias from int32 to float32 for layer '{}' " \
            .format(object_node.name), 'BiasFakequantPass')

    def match_pattern(self, node):
        """
        Function: Match pattern of node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type == "AveragePool":
            return False
        if node.type not in QUANTIZABLE_TYPES:
            return False

        if node.name not in self.records:
            return False

        bias_node = QuantOpInfo.get_bias_node(node)
        if bias_node is None:
            return False

        return True