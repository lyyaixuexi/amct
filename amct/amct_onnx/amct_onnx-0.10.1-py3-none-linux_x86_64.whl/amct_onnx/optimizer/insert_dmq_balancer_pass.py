#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2023. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert dmq_balancer layer couple with layer to be quantized

"""
from google.protobuf import text_format
from onnx import onnx_pb

from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.configuration.configuration import Configuration
from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.attrs_list import ATTR_NODE_TWO_INPUTS
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.utils.weight_quant_api import adjust_conv_weight_shape
from amct_onnx.proto import scale_offset_record_pb2
from amct_onnx.utils.vars import QUANTIZABLE_TYPES


class InsertDMQBalancerPass(BaseFusionPass):
    """
    Function: Insert DMQBalancer layer couple with layer to be quantized
    APIs: match_pattern, do_fusion
    """
    def __init__(self):
        """
        Function: Init InsertActCalibrationPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.record_file_path = Configuration().get_record_file_path()
        self.conf = Configuration()
        self.records = scale_offset_record_pb2.ScaleOffsetRecord()

    def set_up(self):
        """
        Function: read the tensor_balance_factor from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, 'r') as record_read_file:
            pbtxt_string = record_read_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def tear_down(self):
        """
        Function: write the tensor_balance_factor to Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, "w") as record_write_file:
            record_write_file.write(
                text_format.MessageToString(self.records, as_utf8=True))

    def match_pattern(self, node):
        """
        Function: Find node need to insert DMQBalancer
                  layer in graph
        Parameters: node: node in graph
        Return: True: node that need to insert DMQBalancer layer
                False: skip the node
        """
        if node.type not in QUANTIZABLE_TYPES or node.type == 'AveragePool':
            return False
        if node.name not in self.conf.get_quant_config():
            return False
        if not self.conf.get_layer_config(node.name) or \
            not self.conf.get_layer_config(node.name).get('dmq_balancer_param'):
            return False

        # check whether node that has two inputs
        if node.has_attr(ATTR_NODE_TWO_INPUTS) and node.get_attr(ATTR_NODE_TWO_INPUTS):
            return False

        return True

    def generate_dmq_balancer_node(self,
                                   graph,
                                   object_layer,
                                   migration_strength,
                                   channel_num):
        """
        Function: Genereate dmq_balancer node according to input parameters
        Parameters: graph: graph that add dmq_balancer node to
                    object_layer: layer that add dmq_balancer node for
                    act_config: act quant config for a node
                    channel_num: the value of cin
        Return: dmq_balancer_node: generated dmq_balancer node
        """
        dmq_balancer_op = onnx_pb.NodeProto()
        dmq_balancer_op.name = "{}_{}".format(''.join(object_layer), 'dmq_balancer_op')
        dmq_balancer_op.op_type = 'DMQBalancer'
        dmq_balancer_op.domain = 'amct.customop'
        dmq_balancer_op.input[:] = ['%s_input:1' % dmq_balancer_op.name,
                                    '%s_input:2' % dmq_balancer_op.name]
        # Set quantize algorithm parameters
        dmq_balancer_helper = AttributeProtoHelper(dmq_balancer_op)
        dmq_balancer_helper.set_attr_value('migration_strength', 'FLOAT',
                                           migration_strength)
        dmq_balancer_helper.set_attr_value('channel_num', 'INT', channel_num)
        dmq_balancer_helper.set_attr_value('object_layer', 'STRING',
                                            bytes('%s ' % (object_layer), 'utf-8'))
        dmq_balancer_helper.set_attr_value(
            'record_file_path', 'STRING',
            bytes(Configuration().get_record_file_path() + ' ', 'utf-8'))
        # Add node of DMQBalancer to graph
        dmq_balancer_node = graph.add_node(dmq_balancer_op)
        return dmq_balancer_node

    def get_node_act_perm(self, weights):
        """
        Function: get node perm
        Parameters: node: node in graph
        Return: transpose dim
        """
        perm = []
        if len(weights.shape) == 4:
            perm = [1, 0, 2, 3]
        if len(weights.shape) == 5:
            perm = [1, 0, 2, 3, 4]
        return perm

    def do_pass(self, graph, object_node):
        """
        Function: Do actual insert dmq_balancer layer operation.
        Parameters: graph: graph that contains object node
                    object_node: node to process
        Return: None
        """
        object_name = object_node.name
        layer_config = self.conf.get_layer_config(object_name)
        migration_strength = layer_config['dmq_balancer_param']

        # transpose node's weights cin to 0 dimension
        weights_node = QuantOpInfo.get_weight_node(object_node)
        if object_node.has_attr('with_weights_trans') and \
            object_node.get_attr('with_weights_trans'):
            raise RuntimeError(
                "Quantizable node{%s} should directly connected to weight"
                % (object_name))
        weight_tensor = QuantOpInfo.get_node_tensor(weights_node)
        weights_helper = TensorProtoHelper(weight_tensor)
        weights = weights_helper.get_data().copy()
        weights_helper.clear_data()

        attribute_helper = AttributeProtoHelper(object_node.proto)
        if object_node.type == 'Conv':
            weights = adjust_conv_weight_shape(object_node, weights)
        elif object_node.type == 'Gemm' and attribute_helper.get_attr_value('transB') == 1:
            weights = weights.transpose(1, 0)

        channel_num = weights.shape[0]
        weights_helper.set_data(weights.flatten())

        # Insert Transpose node to trans  nodes’ input to CNHW for data
        act_perm = self.get_node_act_perm(weights)
        transpose_node = self.generate_transpose_node(graph, object_name, act_perm)

        # create dmq_balancer node
        dmq_balancer_node = self.generate_dmq_balancer_node(graph, object_name, migration_strength, channel_num)

        graph.insert_parallel_node(transpose_node, 0, object_node, 0)
        graph.add_edge(transpose_node, 0, dmq_balancer_node, 0)
        graph.add_edge(weights_node, 0, dmq_balancer_node, 1)

        record = self.records.record.add()
        record.key = object_name
        record.value.tensor_balance_factor[:] = []
        LOGGER.logd(
            "Insert dmq_balancer layer '{}' to '{}' success!".format(
                dmq_balancer_node.name, object_node.name),
                'InsertDMQBalancerPass')

    def generate_transpose_node(self, graph, layer_name, perm):
        """
        Function: create transpose_node for layer node with layer_name.
        Parameters:
        graph: graph IR.
        layer_name: name of the layer to be modified.
        perm: transpose dim
        Return: scalew_node: generated transpose_node.
        """
        node_proto = onnx_pb.NodeProto()
        node_proto.name = '.'.join([layer_name, 'transpose'])
        node_proto.op_type = 'Transpose'
        node_proto.doc_string = 'transpose for DMQBalancer'
        node_proto.input.extend(
            ['.'.join([layer_name, 'transpose', 'input0'])])
        node_proto.output.extend(
            ['.'.join([layer_name, 'transpose', 'output0'])])

        if perm:
            AttributeProtoHelper(node_proto).set_attr_value('perm', 'INTS', perm)

        transpose_node = graph.add_node(node_proto)

        return transpose_node