#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Add quant and anti-quant to max_pooling and eltwise layer.

"""
from onnx import onnx_pb
from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.fusion_info_utils import add_equivalent_info_attr
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.optimizer.quant_fusion_pass import QuantFusionPass
from amct_onnx.optimizer.insert_quant_pass import construct_quant_node
from amct_onnx.optimizer.insert_quant_pass import construct_anti_quant_node
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
from amct_onnx.utils.vars import MULT_OUTPUT_TYPES
from amct_onnx.utils.vars import CLIBRATION_BIT

construct_anti_quant_node = construct_anti_quant_node


class MultQuantOptimizerPass(BaseFusionPass):
    """
    Function: Fusion quant_layers that from same input and have
              same scale and offset
    APIs: match_pattern, do_pass
    """
    def __init__(self, records):
        """
        Function: Init MultQuantOptimizerPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self._records = records
        self._num_bits = CLIBRATION_BIT
        self._supported_output_node_types = MULT_OUTPUT_TYPES
        self._optimizer_type = ('MaxPool')

    def match_pattern(self, node):
        """
        Function: Find node that have multiple output quant layer
        Parameters: node: node in graph
        Return: True: node that need to do quant layer fusion operation
        """
        if node.type not in self._supported_output_node_types:
            return False
        for output_anchor in node.output_anchors:
            quant_layer_count = 0
            non_quant_layer_count = 0
            for peer_input_anchor in output_anchor.get_peer_input_anchor():
                peer_node_type = peer_input_anchor.node.type
                if peer_node_type == 'AscendQuant':
                    quant_layer_count += 1
                elif peer_node_type not in self._optimizer_type:
                    return False
                else:
                    non_quant_layer_count += 1
            if quant_layer_count and non_quant_layer_count:
                LOGGER.logd('Find node {} can do optimizer'.format(
                    node.name), 'MultQuantOptimizerPass')
                return True

        return False

    def _find_output_need_optimizer(self, node, output_anchor):
        """find object node's peer output that can be optimizer"""
        quant_nodes = []
        non_quant_peer_anchors = []
        for peer_input_anchor in output_anchor.get_peer_input_anchor():
            peer_node = peer_input_anchor.node
            if peer_node.type == "AscendQuant":
                quant_nodes.append(peer_node)
                LOGGER.logd('Find node {} have quant output {}'.format(
                    node.name, peer_node.name), 'MultQuantOptimizerPass')
            elif peer_node.type not in self._optimizer_type:
                LOGGER.logd('Find node {} have unsupprted output {}'.format(
                    node.name, peer_node.name), 'MultQuantOptimizerPass')
                return False, None, None
            else:
                LOGGER.logd('Find node {} have supprted output {}'.format(
                    node.name, peer_node.name), 'MultQuantOptimizerPass')
                non_quant_peer_anchors.append(peer_input_anchor)
        # record quant layer with same scale and offset
        fusion_quant_nodes = QuantFusionPass.find_same_quant_node(
            self._records, quant_nodes)
        if len(fusion_quant_nodes) != 1:
            LOGGER.logd(
                'Node {} with different output activation quantize ' \
                'parameters.'.format(node.name))
            return False, None, None

        nodes = fusion_quant_nodes.get(list(fusion_quant_nodes.keys())[0])
        return True, nodes[0], non_quant_peer_anchors

    def do_pass(self, graph, object_node):
        """
        Function: Do quant layer fusion operation.
        Parameters: graph: graph that contains object node
                    object_node: node to process
        Return: None
        """
        for output_anchor in object_node.output_anchors:
            # record one output_anchor's all consumer quant node
            matched, copied_quant_node, non_quant_peer_anchors = \
                self._find_output_need_optimizer(object_node, output_anchor)
            if not matched:
                continue

            copied_quant_node_name = copied_quant_node.get_attr('object_node')
            for peer_input_anchor in non_quant_peer_anchors:
                peer_node = peer_input_anchor.node
                quant_node, anti_node = self.generate_quant_antiquant_node(
                    graph, peer_node,
                    copied_quant_node_name)
                # Insert Quant and AntiQuant between object node and peer node
                graph.remove_edge(
                    object_node, output_anchor.index,
                    peer_node, peer_input_anchor.index)
                graph.add_edge(object_node, output_anchor.index, quant_node, 0)
                graph.add_edge(quant_node, 0, anti_node, 0)
                graph.add_edge(
                    anti_node, 0, peer_node, peer_input_anchor.index)
                # Record inserted quant node info
                add_equivalent_info_attr(peer_node, [quant_node, anti_node],
                                         new_input=quant_node, new_output=None)

        LOGGER.logd(
            'Do concat optimizer for "{}" success!'.format(object_node.name),
            'MultQuantOptimizerPass')

    def generate_quant_antiquant_node(self,
                                      graph,
                                      peer_node,
                                      copied_quant_node_name):
        """Generate AscendQuant and AscendAntiQuant node in pair
        """
        scale = self._records.get(copied_quant_node_name).get('data_scale')
        offset = self._records.get(copied_quant_node_name).get('data_offset')

        quant_node_proto = construct_quant_node(
            inputs=[peer_node.ori_name + '.quant.input0'],
            outputs=[peer_node.ori_name + '.quant.output0'],
            attrs={
                'scale': 1.0 / scale,
                'offset': offset,
                'quant_bit': self._num_bits
            },
            layer_name=peer_node.ori_name)
        anti_quant_node_proto = construct_anti_quant_node(
            inputs=[peer_node.ori_name + '.quant.input0'],
            outputs=[peer_node.ori_name + '.quant.output0'],
            attrs={
                'scale': scale,
                'offset': offset,
                'quant_bit': self._num_bits
            },
            layer_name=peer_node.ori_name)

        quant_node = graph.add_node(quant_node_proto)
        quant_node.set_attr('object_node', copied_quant_node_name)
        anti_quant_node = graph.add_node(anti_quant_node_proto)
        anti_quant_node.set_attr('object_node', copied_quant_node_name)

        return quant_node, anti_quant_node
