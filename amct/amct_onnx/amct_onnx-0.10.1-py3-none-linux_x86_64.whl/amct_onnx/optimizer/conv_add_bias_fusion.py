#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2023. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Convolution + Add(which Add is bias add) fusion operation

"""


import numpy as np

from amct_onnx.configuration.configuration import Configuration
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.fusion_info_utils import add_fusion_info_attr
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper


class ConvAddBiasFusionPass(BaseFusionPass):
    """
    Function: Do "Convolution" layer and "Add" layer fusion operation
    APIs: match_pattern, do_pass
    """
    def __init__(self, record_helper=None):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.config = Configuration()
        self.record_helper = record_helper
        self.idx_map = dict()
        self.fp_idx = 0
        self.bias_idx = 1

    def match_pattern(self, node):
        """
        Function: Match pattern of "Conv" + "Add" in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type != 'Add':
            return False
        if len(node.input_anchors) != 2:
            raise RuntimeError('Add node should only have 2 input ' \
                'actually have {}'.format(len(node.input_anchors)))
        fp_idx = 0
        bias_idx = 1
        node_conv = node.get_input_anchor(0).get_peer_output_anchor().node
        node_conv_cadi = node.get_input_anchor(1).get_peer_output_anchor().node
        if node_conv.type != 'Conv':
            if node_conv_cadi.type != 'Conv':
                return False
            else:
                node_conv = node_conv_cadi
                fp_idx, bias_idx = bias_idx, fp_idx
        # Conv should not have bias as input
        if len(node_conv.input_anchors) != 2:
            return False
        # If do Conv + Add fusion, conv must can only output to add
        if len(node_conv.output_anchors) != 1 or \
            len(node_conv.get_output_anchor(0).get_peer_input_anchor()) != 1:
            return False
        self.idx_map[node.name] = [fp_idx, bias_idx]
        return True

    def do_pass(self, graph, object_node):
        """
        Function: Do actual "Convolution" layer and "Add" layer
                  fusion operation
        Parameters: graph: graph structure
                    object_node: node to process
        Return: None
        """
        self.fp_idx, self.bias_idx = self.idx_map[object_node.name]
        node_conv = object_node.get_input_anchor(self.fp_idx).get_peer_output_anchor().node
        weights = QuantOpInfo.get_weight_node(node_conv)
        if weights.type not in ['Constant', 'initializer', 'sparse_initializer']:
            LOGGER.logd('Cannot do Conv+Add(bias) fusion, due to conv "%s" has a variable weights "%s"' % (
                node_conv.name, weights.type), 'ConvAddBiasFusionPass')
            return
        weights_shape = QuantOpInfo.get_node_value(weights).shape

        add_bias = object_node.get_input_anchor(self.bias_idx).get_peer_output_anchor().node
        if add_bias.type not in ['Constant', 'initializer', 'sparse_initializer']:
            LOGGER.logd('Cannot do Conv+Add(bias) fusion, due to add "%s" has a variable bias "%s"' % (
                object_node.name, add_bias.type), 'ConvAddBiasFusionPass')
            return

        bias_helper = TensorProtoHelper(QuantOpInfo.get_node_tensor(add_bias))
        bias = bias_helper.get_data()
        if bias.ndim in (4, 5):
            if bias.shape[0] != 1 or bias.shape[1] != weights_shape[0] or bias.shape[2: ] != (1,) * (bias.ndim - 2):
                LOGGER.logd('Cannot do Conv+Add(bias) fusion, due to add "{}" not bias shape:{}'.format(
                    object_node.name, bias.shape), 'ConvAddBiasFusionPass')
                return
            if self.record_helper is not None:
                scale_d, _ = self.record_helper.read_activation_scale_offset(node_conv.name)
                scale_w, _ = self.record_helper.read_weights_scale_offset(node_conv.name)
                if (bias / scale_d / scale_w > np.iinfo(np.int32).max).any():
                    LOGGER.logd(
                        'Cannot do Conv+Add(bias) fusion, due to quantized bias value greater than np.int32 max value')
                    return

            bias = bias.reshape([bias.shape[1]])
            bias_helper.set_data(bias, dims=bias.shape, graph=graph)

        elif bias.ndim == 1 and bias.shape[0] != weights_shape[0]:
            LOGGER.logd('Cannot do Conv+Add(bias) fusion, due to add "{}" not bias shape:{}'.format(
                object_node.name, bias.shape), 'ConvAddBiasFusionPass')
            return

        else:
            LOGGER.logd('Cannot do Conv+Add(bias) fusion, due to add "{}" not bias shape:{}'.format(
                object_node.name, bias.shape), 'ConvAddBiasFusionPass')
            return
        # relink bias_add to conv input 2
        graph.remove_edge(add_bias, 0, object_node, self.bias_idx)
        node_conv.add_input_anchor('%s.bias' % (node_conv.name))
        graph.add_edge(add_bias, 0, node_conv, 2)

        # delete add node
        graph.remove_edge(node_conv, 0, object_node, self.fp_idx)
        peer_output_anchors = object_node.get_output_anchor(0).get_peer_input_anchor().copy()
        for peer_output_anchor in peer_output_anchors:
            graph.remove_edge(object_node, 0, peer_output_anchor.node, peer_output_anchor.index)
            graph.add_edge(node_conv, 0, peer_output_anchor.node, peer_output_anchor.index)
            if peer_output_anchor.node.type == 'graph_output':
                node_conv.get_output_anchor(0).set_name(peer_output_anchor.node.name)
        graph.remove_node(object_node)
        # Record fusion info to convolution node
        add_fusion_info_attr(node_conv, [object_node], object_node)

        LOGGER.logd('Do Conv:"%s" + Add(bias):"%s" fusion success.' % (node_conv.name, object_node.name),
                    'ConvAddBiasFusionPass')
