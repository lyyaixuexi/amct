#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

If gemm transB is true, do transpose offline, and set it to false

"""
import numpy as np

from amct_onnx.utils.log import LOGGER
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.quant_node import QuantOpInfo


class GemmTransBOptimizePass(BaseFusionPass):
    """
    Function: If gemm transB is true, do transpose offline, and set it to false
    APIs: match_pattern, do_pass
    """
    def __init__(self, records):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records

    @staticmethod
    def do_pass(graph, object_node):
        """
        Function: Do actually gemm transb optimize.
        Parameters:
            graph: graph structure
            object_node: node to process
        Return: None
        """
        # in case that weights were reused by multi gemm, do trans only once
        attribute_helper = AttributeProtoHelper(object_node.proto)
        if not attribute_helper.has_attr('transB') or \
                attribute_helper.get_attr_value('transB') != 1:
            LOGGER.logd('OP "%s"\'weights already do transB fold.' % (
                object_node.name))
            return

        if len(object_node.input_anchors) < 2:
            LOGGER.logd('Cannot find weights of "%s".' % (object_node.name),
                        'GemmTransBOptimizePass')
            return
        weight_node = QuantOpInfo.get_weight_node(object_node)
        weight_tensor = QuantOpInfo.get_node_tensor(weight_node)
        weights_helper = TensorProtoHelper(weight_tensor)

        # get data
        weights = weights_helper.get_data()
        weights_helper.clear_data()

        # do transpose
        if weights.ndim != 2:
            raise RuntimeError(
                'The shape of onnx Gemm operator\'s input tensor B should be '
                '(K, N) if transB is 0, or (N, K) if transB is non-zero, but '
                'got from "{}" is {}'.format(object_node.name, weights.shape))

        weights = np.transpose(weights, (1, 0))
        weights_helper.set_data(weights.flatten(),
                                dims=weights.shape,
                                graph=graph)

        weights_anchor = weight_node.get_output_anchor(0)
        for peer_anchor in weights_anchor.get_peer_input_anchor():
            peer_node = peer_anchor.node
            attr_helper = AttributeProtoHelper(peer_node.proto)
            attr_helper.set_attr_value('transB', 'INT', 0)
        LOGGER.logd('Do op "%s" transB fold success.' % (object_node.name))

    def match_pattern(self, node):
        """
        Function: Match pattern of node to do gemm transb optimize
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type != 'Gemm' or node.name not in self.records:
            return False
        attribute_helper = AttributeProtoHelper(node.proto)
        if not attribute_helper.has_attr('transB') or \
                attribute_helper.get_attr_value('transB') != 1:
            return False
        # check all node use this weights must all be transB
        weight_node = QuantOpInfo.get_weight_node(node)
        weights_anchor = weight_node.get_output_anchor(0)
        for peer_anchor in weights_anchor.get_peer_input_anchor():
            peer_node = peer_anchor.node
            if peer_node.type != 'Gemm' or peer_node.name not in self.records:
                return False
            attr_helper = AttributeProtoHelper(peer_node.proto)
            if not attr_helper.has_attr('transB') or \
                    attr_helper.get_attr_value('transB') != 1:
                return False

        return True