#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Fold transpose between quantizable node and weights.

"""
import copy
import numpy as np

from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.fusion_info_utils import add_fusion_info_attr
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.configuration.configuration import Configuration
from amct_onnx.configuration.check import GraphChecker
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.utils.attrs_list import ATTR_NODE_TWO_INPUTS

SUPPORT_TRANS_TYPES = ['Conv', 'Gemm', 'MatMul']
SUPPORT_DIMS = (2, 4, 5)


class TransposeFoldPass(BaseFusionPass):
    """
    Function: Fold transpose between quantizable node and weights
    APIs: match_pattern, do_pass
    """
    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    @staticmethod
    def data_trans_kernel(graph, node):
        """do data transpose"""
        # get data from node
        tensor_helper = TensorProtoHelper(node.proto)
        tensor = tensor_helper.get_data()
        # write transposed data back to node
        tensor_helper.clear_data()
        if tensor.ndim in SUPPORT_DIMS:
            trans_shape = [1, 0, 2, 3, 4]
            trans_shape = trans_shape[:tensor.ndim]
            trans_shape = tuple(trans_shape)
        else:
            LOGGER.logd('Cannot do node "{}" transpose fold, due to shape of '
                        'it is {}'.format(node.name, tensor.shape))
            return False
        tensor = np.transpose(tensor, trans_shape)
        tensor_helper.set_data(tensor.flatten(),
                               dims=tensor.shape,
                               graph=graph)
        return True

    @staticmethod
    def delete_trans_node(graph, trans_node):
        """delete Transpose node from graph"""
        in_anchor = trans_node.get_input_anchor(0)
        produce_anchor = in_anchor.get_peer_output_anchor()
        producer = produce_anchor.node
        graph.remove_edge(producer, produce_anchor.index, trans_node, 0)
        out_anchor = trans_node.get_output_anchor(0)
        consumer_anchors = out_anchor.get_peer_input_anchor().copy()

        for consumer_anchor in consumer_anchors:
            consumer = consumer_anchor.node
            graph.remove_edge(trans_node, 0, consumer, consumer_anchor.index)
            graph.add_edge(producer, produce_anchor.index, consumer,
                           consumer_anchor.index)
        graph.remove_node(trans_node)

    @staticmethod
    def replace_weight(graph, weights_node, trans_node):
        """ Replace trans_node' weights_node to a new_weights_node"""
        # the weights is shared, copy a nwe weight
        weights_op = copy.deepcopy(weights_node.proto)
        weights_op.name = '_'.join([weights_node.name, trans_node.name])
        new_weights_node = graph.add_node(weights_op)

        graph.remove_edge(weights_node, 0, trans_node, 0)
        graph.add_edge(new_weights_node, 0, trans_node, 0)

    def match_pattern(self, node):
        """
        Function: Match pattern of node to do transpose fold optimize
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        # Only do quantizable node optimize
        if node.type not in SUPPORT_TRANS_TYPES or \
                not GraphChecker.check_quantize_type(node):
            return False
        # match config
        if node.name not in Configuration().get_quant_config():
            return False
        # check whether node that has two inputs
        if node.has_attr(ATTR_NODE_TWO_INPUTS) and node.get_attr(ATTR_NODE_TWO_INPUTS):
            return False
        # check whether node that weights or bias has trans
        if node.has_attr('with_weights_trans') and \
                node.get_attr('with_weights_trans'):
            return True
        return False

    def do_pass(self, graph, object_node):
        """
        Function: Do actually transpose fold optimize.
        Parameters:
            graph: graph structure
            object_node: node to process
        Return: None
        """
        _, weight_index, _ = QuantOpInfo.get_quant_index(object_node)
        if not object_node.has_attr('with_weights_trans') or \
                not object_node.get_attr('with_weights_trans'):
            return

        # Step1: do weights transpose fold
        weights_anchor = object_node.get_input_anchor(weight_index)
        weights_trans_node = weights_anchor.get_peer_output_anchor().node
        if weights_trans_node.type != 'Transpose':
            # if weights_trans flag is False, it may fold by another node
            object_node.set_attr('with_weights_trans', False)
        else:
            data_anchor = weights_trans_node.get_input_anchor(0)
            weights_output_anchor = data_anchor.get_peer_output_anchor()
            weights_node = weights_output_anchor.node
            if len(weights_output_anchor.get_peer_input_anchor()) != 1:
                # the weights is shared, copy a nwe weight
                self.replace_weight(graph, weights_node,
                                    weights_trans_node)
            # trans the node
            trans_done = self.data_trans_kernel(graph, weights_node)
            if trans_done:
                self.delete_trans_node(graph, weights_trans_node)
            object_node.set_attr('with_weights_trans', False)

            # Record fusion info to convolution node
            add_fusion_info_attr(weights_node, [weights_trans_node],
                                 weights_trans_node)

        LOGGER.logd('Do node "%s" Transpose fold optimize success.' %
                    (object_node.name))