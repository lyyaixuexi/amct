#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert joint actication quantization pass.

"""


from onnx import onnx_pb

from amct_onnx.utils.log import LOGGER
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.optimizer.eltwise_opt_weights_calibration import AddOptWeightsCalibrationPass
from amct_onnx.optimizer.insert_act_calibration import InsertActCalibrationPass
from amct_onnx.optimizer.insert_act_calibration import INSERT_ACT_CALIBRATION_DONE_FLAG
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper


class AddOptInsertActCalibrationPass(BaseFusionPass):
    """
    Function: Insert ifmr layer couple with layer to be quantized
    APIs: match_pattern, do_pass
    """
    def __init__(self):
        """
        Function: Init AddOptInsertActCalibrationPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    @staticmethod
    def do_pass(graph, union_list):
        """
        Function: apply activation joint-quant to the graph for ops in union_list
        Parameters:
        graph: the model graph IR
        union_list: the op names's list, which will apply joint-quant
        Return: None
        """
        union_nodes = [graph.get_node_by_name(node_name) for node_name in union_list]

        union_layers = [node.name for node in union_nodes]
        union_config_layer_name = graph.get_node_by_name(union_list[0]).name

        act_cali_nodes = InsertActCalibrationPass().generate_act_calibration_node(
            graph, union_layers, union_config_layer_name)
        act_cali_node = act_cali_nodes.get(0)
        concat_op = onnx_pb.NodeProto()
        concat_op.name = '{}_{}'.format('_'.join(union_layers), 'act_calibration_concat')
        concat_op.op_type = 'Concat'
        concat_helper = AttributeProtoHelper(concat_op)
        concat_helper.set_attr_value('axis', 'INT', 1)
        concat_op.input[:] = ['%s_input' % object_layer for object_layer in union_layers]
        concat_op.output[:] = ['%s_output' % concat_op.name]
        concat_node = graph.add_node(concat_op)
        concat_node.set_attr('produce_by_amct', True)

        concat_input_index = 0
        for quant_node in union_nodes:
            quant_node.set_attr(INSERT_ACT_CALIBRATION_DONE_FLAG, True)
            peer_output_anchor = quant_node.get_input_anchor(0).get_peer_output_anchor()

            flatten_op = onnx_pb.NodeProto()
            flatten_op.name = '{}_{}'.format(quant_node.name, 'act_calibration_flatten')
            flatten_op.op_type = 'Flatten'
            flatten_helper = AttributeProtoHelper(flatten_op)
            flatten_helper.set_attr_value('axis', 'INT', 1)
            flatten_op.input[:] = ['%s_input' % flatten_op.name]
            flatten_op.output[:] = ['%s_output' % flatten_op.name]
            flatten_node = graph.add_node(flatten_op)
            flatten_node.set_attr('produce_by_amct', True)

            graph.add_edge(
                peer_output_anchor.node, peer_output_anchor.index,
                flatten_node, 0)
            graph.add_edge(flatten_node, 0, concat_node, concat_input_index)
            concat_input_index += 1

            LOGGER.logd("Insert {} layer '{}' to '{}' success!".format(
                act_cali_node.type, act_cali_node.name, quant_node.name), 'AddOptInsertActCalibrationPass')
        graph.add_edge(concat_node, 0, act_cali_node, 0)
        LOGGER.logi('Insert {} node {} to union layers {} success.'.format(
            act_cali_node.type, act_cali_node.name, union_list), 'AddOptInsertActCalibrationPass')

    def run(self, graph):
        """
        Function: excute AddOptInsertActCalibrationPass
        Parameters:
        graph: the model graph IR
        Return: None
        """
        union_lists = []
        for node in graph.nodes:
            union_list = AddOptWeightsCalibrationPass.match_pattern( \
                node, '{}_{}'.format(INSERT_ACT_CALIBRATION_DONE_FLAG, node.index), \
                True)
            if union_list is not None:
                union_lists.append(union_list)
        for union_list in union_lists:
            self.do_pass(graph, union_list)
        graph.topologic_sort()
