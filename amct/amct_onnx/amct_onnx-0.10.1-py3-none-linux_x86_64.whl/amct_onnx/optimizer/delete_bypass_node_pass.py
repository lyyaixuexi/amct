#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Delete bypass node in graph

"""
from amct_onnx.utils.log import LOGGER
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
from amct_onnx.utils.vars import SHIFT_N_TYPES


DELINK_SRC_TYPE = ('Concat', 'Flatten', 'Transpose', 'Constant')


class DeleteActCalibrationPass(BaseFusionPass):
    """
    Function: Quant weight from float32 to int8
    APIs: match_pattern, do_pass
    """
    def __init__(self, records):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self._records = dict(records)
        self._delete_types = ['IFMR', 'HFMG']

    def match_pattern(self, node):
        """
        Function: Match the node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type in self._delete_types:
            return True

        return False

    def do_pass(self, graph, object_node):
        """
        Function: Do actual quantization and node's weight is changed to int8.
        Parameters:
            graph: graph structure
            object_node: node to process
        Return: None
        """
        # process records
        _validate_node_with_records(object_node, self._records, ['data_scale', 'data_offset'])

        # delink all inputs
        _delink_input_nodes(object_node, graph)

        LOGGER.logd('Delete "%s" from graph success.' % (object_node.name),
                    'DeleteBypassNodePass')

    def tear_down(self):
        """
        tear down function
        """
        records_keys = list(self._records.keys())
        if records_keys:
            raise RuntimeError('Cannot find {} for {} in graph, model and ' \
                               'record file may not match.'.format( \
                                self._delete_types, records_keys))


class DeleteSearchNPass(BaseFusionPass):
    """
    Function: Quant weight from float32 to int8
    APIs: match_pattern, do_pass
    """
    def __init__(self, records, graph):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self._records = dict(records)
        self._delete_types = ['SearchN', 'SearchNv2']
        self._graph = graph

    def match_pattern(self, node):
        """
        Function: Match the node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type in self._delete_types:
            return True

        return False

    def do_pass(self, graph, object_node):
        """
        Function: Do actual quantization and node's weight is changed to int8.
        Parameters:
            graph: graph structure
            object_node: node to process
        Return: None
        """
        # process records
        _validate_node_with_records(object_node, self._records, ['shift_n'])

        # delink all inputs
        _delink_input_nodes(object_node, graph)

        LOGGER.logd('Delete "%s" from graph success.' % (object_node.name),
                    'DeleteBypassNodePass')

    def tear_down(self):
        """
        tear down function
        """
        records_keys = []
        for reocrd_key in self._records.keys():
            layer_type = self._graph.get_node_by_name(reocrd_key.split(':')[0]).type
            if layer_type in SHIFT_N_TYPES:
                records_keys.append(reocrd_key)

        if records_keys:
            raise RuntimeError('Cannot find {} for {} in graph, model and ' \
                               'record file may not match.'.format( \
                                self._delete_types, records_keys))


def _validate_node_with_records(node, records, record_types):
    """
    Function: Check whether the existence of the node in the records
    """
    act_calibration_helper = AttributeProtoHelper(node.proto)
    index = 0
    while True:
        try:
            target_layer = str(act_calibration_helper.get_attr_value('object_layer%d' % index).strip(),
                               encoding='utf-8')
        except RuntimeError:
            break
        # check all delete node should have corresponding layer in record
        target_record = records.get(target_layer, None)
        if target_record is None:
            LOGGER.logd('Cannot find layer {} in record file, it may not excute correctly!'.format(target_layer))
            break
        # check if the record value is empty
        for check_type in record_types:
            if target_record.get(check_type, []) == []:
                raise ValueError('{} of layer {} in record file is empty, it may not '
                                    'excute correctly!'.format(check_type, target_layer))

        records.pop(target_layer)
        index += 1



def _delink_input_nodes(object_node, graph):
    """
    Function: delete all the input links of object_node in the graph.
    """
    del_nodes = [object_node]
    while del_nodes:
        del_node = del_nodes.pop(0)
        for input_anchor in del_node.input_anchors:
            input_index = input_anchor.index
            src_anchor = input_anchor.get_peer_output_anchor()
            graph.remove_edge(src_anchor.node, src_anchor.index, del_node,
                                input_index)
            if src_anchor.node.type in DELINK_SRC_TYPE and not src_anchor.get_peer_input_anchor():
                del_nodes.append(src_anchor.node)
        graph.remove_node(del_node)
