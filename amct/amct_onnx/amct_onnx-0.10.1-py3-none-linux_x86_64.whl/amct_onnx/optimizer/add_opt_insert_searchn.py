#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert joint searchN pass.

"""


from google.protobuf import text_format
from onnx import onnx_pb

from amct_onnx.utils.log import LOGGER
from amct_onnx.configuration.configuration import Configuration
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.optimizer.eltwise_opt_weights_calibration import AddOptWeightsCalibrationPass
from amct_onnx.optimizer.insert_search_n import InsertSearchNPass
from amct_onnx.optimizer.insert_search_n import generate_scalew_node
from amct_onnx.optimizer.insert_search_n import generate_transpose_node
from amct_onnx.optimizer.insert_search_n import get_node_perm
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.proto import scale_offset_record_pb2

from amct_onnx.optimizer.insert_search_n import INSERT_SEARCH_N_DONE_FLAG
from amct_onnx.utils.vars import CHANNEL_WISE_TYPES


class AddOptInsertSearchNLayerPass(BaseFusionPass):
    """
    Function: Insert ifmr layer couple with layer to be quantized
    APIs: match_pattern, do_pass
    """
    def __init__(self):
        """
        Function: Init AddOptInsertSearchNLayerPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = scale_offset_record_pb2.ScaleOffsetRecord()
        self.conf = Configuration()
        self.record_file_path = self.conf.get_record_file_path()

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, 'r') as record_read_file:
            pbtxt_string = record_read_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def do_pass(self, graph, union_list):
        """
        Function: apply joint searchN/searchNV2 to the graph for ops in union_list
        Parameters:
        graph: the model graph IR
        union_list: the op names's list, which will apply joint-quant
        Return: None
        """
        union_nodes = [graph.get_node_by_name(node_name) for node_name in union_list]

        union_layers = [node.name for node in union_nodes]

        # generate concat node for searchN node
        concat_node = _generate_concat_node(graph, union_layers)

        concat_input_index = 0
        for quant_node in union_nodes:
            quant_node.set_attr(INSERT_SEARCH_N_DONE_FLAG, True)
            if quant_node.type in CHANNEL_WISE_TYPES:
                perm = get_node_perm(quant_node)
                peer_node = generate_transpose_node(graph, quant_node.name, perm)
                graph.add_edge(quant_node, 0, peer_node, 0)
            else:
                peer_node = quant_node

            flatten_op = onnx_pb.NodeProto()
            flatten_op.name = '{}_{}'.format(quant_node.name, 'searchn_flatten')
            flatten_op.op_type = 'Flatten'
            flatten_helper = AttributeProtoHelper(flatten_op)
            flatten_helper.set_attr_value('axis', 'INT', 1)
            flatten_op.input[:] = ['%s_input' % flatten_op.name]
            flatten_op.output[:] = ['%s_output' % flatten_op.name]
            flatten_node = graph.add_node(flatten_op)

            graph.add_edge(peer_node, 0, flatten_node, 0)
            graph.add_edge(flatten_node, 0, concat_node, concat_input_index)
            concat_input_index += 1

        object_name = union_nodes[0].name
        act_cali_node = InsertSearchNPass.get_bypass_act_quant_node(union_nodes[0])
        scalew_node = generate_scalew_node(self.records, graph, object_name)
        search_n_node = InsertSearchNPass.generate_searchn_node(
            graph, union_layers, act_cali_node.type)

        graph.add_edge(concat_node, 0, search_n_node, 0)
        graph.add_edge(act_cali_node, 0, search_n_node, 1)
        graph.add_edge(scalew_node, 0, search_n_node, 2)
        LOGGER.logi('Insert {} node {} to union layers {} success.'.format(
            search_n_node.type, search_n_node.name, union_list), 'AddOptInsertSearchNLayerPass')

    def run(self, graph):
        """
        Function: excute AddOptInsertSearchNLayerPass
        Parameters:
        graph: the model graph IR
        Return: None
        """
        self.set_up()
        union_lists = []
        for node in graph.nodes:
            union_list = AddOptWeightsCalibrationPass.match_pattern( \
                node, '{}_{}'.format(INSERT_SEARCH_N_DONE_FLAG, node.index))
            if union_list is not None:
                union_lists.append(union_list)
        for union_list in union_lists:
            self.do_pass(graph, union_list)
        graph.topologic_sort()


def _generate_concat_node(graph, union_layers):
    """
    Function: generate concat node for joint searchN node
    Parameters:
    graph: the model graph IR
    union_layers: union_layers to do
    Return: None
    """
    concat_op = onnx_pb.NodeProto()
    concat_op.name = '{}_{}'.format('_'.join(union_layers), 'searchn_concat')
    concat_op.op_type = 'Concat'
    concat_helper = AttributeProtoHelper(concat_op)
    concat_helper.set_attr_value('axis', 'INT', 1)
    concat_op.input[:] = ['%s_input' % object_layer for object_layer in union_layers]
    concat_op.output[:] = ['%s_output' % concat_op.name]
    concat_node = graph.add_node(concat_op)
    return concat_node
