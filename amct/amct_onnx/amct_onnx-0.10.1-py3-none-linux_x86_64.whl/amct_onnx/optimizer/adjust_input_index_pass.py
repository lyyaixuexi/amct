#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2023. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Adjust add's input index.

"""

from amct_onnx.utils.log import LOGGER
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.utils.quant_node import QuantOpInfo


class AdjustInputIndexPass(BaseFusionPass):
    """
    Function: If mamtul's bias is add's inputA, adjust to inputB
    APIs: match_pattern, do_pass, get_bias_for_matmul
    """
    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    @staticmethod
    def get_bias_for_matmul(matmul_node):
        """
        Function: check matmul real bias
        Parameter: matmul_node
        Return: bias_node
        """
        if matmul_node.type != 'MatMul':
            raise TypeError("only support MatMul but {} is {}.".format(matmul_node.name, matmul_node.type))

        weight_node = QuantOpInfo.get_weight_node(matmul_node)
        if weight_node is None or weight_node.type not in ['initializer', 'Constant']:
            return None

        consumers, _ = matmul_node.get_consumers(0)
        if len(consumers) != 1 or consumers[0].type != 'Add':
            return None
        # get index-0 of add
        bias_node, _ = consumers[0].get_producer(0)
        if bias_node is None or bias_node.type not in ['initializer', 'Constant']:
            return None

        weight_value = QuantOpInfo.get_node_value(weight_node)
        bias_value = QuantOpInfo.get_node_value(bias_node)
        if len(bias_value.shape) != 1 or bias_value.shape[0] != weight_value.shape[1]:
            return None
        return consumers[0]

    def match_pattern(self, node):
        """
        Function: Match pattern of "Matmul" + "add" in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type == 'MatMul' and (AdjustInputIndexPass.get_bias_for_matmul(node) is not None):
            return True
        return False

    def do_pass(self, graph, object_node):
        """
        Function: Do actual "Add" inputA and inputB exchange
        Parameters: graph: graph structure
                    object_node: node to process
        Return: None
        """
        LOGGER.logi("do index adjust for layer: {}".format(object_node.name), 'AdjustInputIndexPass')
        bias_node = AdjustInputIndexPass.get_bias_for_matmul(object_node)
        add_weights_node, _ = bias_node.get_producer(0)
        graph.remove_edge(add_weights_node, 0, bias_node, 0)
        graph.remove_edge(object_node, 0, bias_node, 1)
        graph.add_edge(object_node, 0, bias_node, 0)
        graph.add_edge(add_weights_node, 0, bias_node, 1)