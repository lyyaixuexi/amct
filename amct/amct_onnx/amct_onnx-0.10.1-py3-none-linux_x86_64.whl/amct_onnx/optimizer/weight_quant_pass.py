#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quant weight from float32 to int8.

"""
from amct_onnx.utils.log import LOGGER
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.weight_quant_api import weights_quantize_np
from amct_onnx.utils.weight_quant_api import adjust_deconv_weight_shape
from amct_onnx.utils.attrs_list import ATTR_NODE_TWO_INPUTS

from amct_onnx.utils.vars import QUANTIZABLE_TYPES
from amct_onnx.utils.vars import CLIBRATION_BIT


class WeightQuantPass(BaseFusionPass):
    """
    Function: Quant weight from float32 to int8
    APIs: match_pattern, do_pass, quant_weight
    """
    def __init__(self, records):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records
        self.num_bits = CLIBRATION_BIT

    def match_pattern(self, node):
        """
        Function: Match the node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type not in QUANTIZABLE_TYPES:
            return False
        if node.type == 'AveragePool':
            return False

        if node.name not in self.records:
            return False

        # check whether node that has two inputs
        if node.has_attr(ATTR_NODE_TWO_INPUTS) and node.get_attr(ATTR_NODE_TWO_INPUTS):
            return False

        return True

    def do_pass(self, graph, object_node):
        """
        Function: Do actual quantization and node's weight is changed to int8.
        Parameters:
            graph: graph structure
            object_node: node to process
        Return: None
        """
        weight_node = QuantOpInfo.get_weight_node(object_node)
        # check if current weights is reused, then skip do quantize
        if weight_node.has_attr('weights_quant_done'):
            return
        weight_tensor = QuantOpInfo.get_node_tensor(weight_node)
        weight_helper = TensorProtoHelper(weight_tensor)
        weight = weight_helper.get_data()

        # do weights quantize by cpp kernel function
        scale_w = self.records.get(object_node.name).get('weight_scale')
        offset_w = self.records.get(object_node.name).get('weight_offset')
        if object_node.type == 'ConvTranspose':
            weight = adjust_deconv_weight_shape(object_node, weight)
        int8_weight = weights_quantize_np(weight,
                                          scale_w.flatten().tolist(),
                                          offset_w.flatten().tolist(),
                                          self.num_bits)
        if object_node.type == 'ConvTranspose':
            int8_weight = adjust_deconv_weight_shape(object_node, int8_weight)
        int8_weight = int8_weight.reshape([-1])

        weight_helper.clear_data()
        weight_helper.set_data(int8_weight, 'INT8', graph=graph, is_raw_data=True)

        # set weights quantize done flag
        weight_node.set_attr('weights_quant_done', True)
        LOGGER.logd("Quant weight from int32 to int8 for layer '{}' " \
            "success!".format(object_node.name), 'WeightQuantPass')
