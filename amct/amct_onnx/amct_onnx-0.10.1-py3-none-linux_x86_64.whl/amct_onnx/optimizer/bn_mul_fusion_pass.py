#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

BatchNormalization + Mul fusion operation

"""
import copy

from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.optimizer.conv_bn_fusion_pass import ConvBnFusionPass
from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.fusion_info_utils import add_fusion_info_attr
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
from amct_onnx.utils.vars import CONSTANT_NODE_TYPE


class BnMulFusionPass(BaseFusionPass):
    """
    Function: Do "BatchNormalization" and "Mul" fusion operation
    APIs: match_pattern, do_pass, get_add_beta, delete_add
    """
    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    @staticmethod
    def match_pattern(node):
        """
        Function: Match pattern of "BatchNormalization" + "Mul" in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        # find matched bn node
        if not ConvBnFusionPass.is_fusionable_bn(node):
            return False

        scale_node, _ = node.get_producer(1)
        beta_node, _ = node.get_producer(2)
        if scale_node.type not in CONSTANT_NODE_TYPE or \
                beta_node.type not in CONSTANT_NODE_TYPE:
            LOGGER.logd(
                "{} match_pattern fail for scale/beta is not in {}".format(
                    node.name, CONSTANT_NODE_TYPE), 'BnMulFusionPass')
            return False

        # find only one Mul
        consumers, in_idxes = node.get_consumers(0)
        if len(consumers) != 1 or consumers[0].type != 'Mul':
            LOGGER.logd(
                "{} match_pattern fail for BatchNormalization must has only "
                "one consumer Mul".format(node.name), 'BnMulFusionPass')
            return False
        if in_idxes[0] != 0:
            LOGGER.logd(
                "{} match_pattern fail for BatchNormalization's output must "
                "be Mul's first input".format(node.name), 'BnMulFusionPass')
            return False

        # find Mul's input 1 value(mul_scale)
        mul_node = consumers[0]
        mul_scale, _ = mul_node.get_producer(1)
        if mul_scale.type == 'Unsqueeze':
            mul_scale, _ = mul_scale.get_producer(0)
        if mul_scale.type not in CONSTANT_NODE_TYPE:
            LOGGER.logd(
                "{} match_pattern fail for Mul op's input B is not in "
                "(+Unsqueeze) {}".format(node.name, CONSTANT_NODE_TYPE),
                'BnMulFusionPass')
            return False

        return True

    @staticmethod
    def get_bn_param(bn_node, in_idx):
        """
        Function: get bn's input param, such as scale, beta
        Parameter:
            bn_node: node, type is BatchNormalization
            in_idx: int, input index, which input tu update
        Return:
            param_data: np.array. the vaule of bn_node's input[in_idx]
        """
        param_node, _ = bn_node.get_producer(in_idx)
        param_helper = TensorProtoHelper(QuantOpInfo.get_node_tensor(param_node))
        param_data = param_helper.get_data()

        return param_data

    @staticmethod
    def update_bn_param(graph, bn_node, in_idx, value):
        """
        Function: updatate bn's input param, such as scale, beta.
        Parameter:
            bn_node: node, type is BatchNormalization
            in_idx: int, input index, which input tu update
            value: np.array. the new vaule of bn_node's input[in_idx]
        Return: None
        """
        param_node, param_out_idx = bn_node.get_producer(in_idx)
        consumers, _ = param_node.get_consumers(param_out_idx)
        if len(consumers) > 1:
            graph.remove_edge(param_node, param_out_idx, bn_node, in_idx)
            new_param_op = copy.deepcopy(param_node.proto)
            new_param_op.name = '_'.join([param_node.name, bn_node.name])
            param_node = graph.add_node(new_param_op)
            if not param_node.output_anchors:
                param_node.add_output_anchor(new_param_op.name)
            graph.add_edge(param_node, param_out_idx, bn_node, in_idx)

        scale_helper = TensorProtoHelper(QuantOpInfo.get_node_tensor(param_node))
        scale_helper.clear_data()
        scale_helper.set_data(value)

    @staticmethod
    def get_mul_scale(mul_node):
        """
        Function: get mul's input B value
        Parameter:
            mul_node: node, type is Mul
        Return:
            mul_scale_data: np.array, mul's input B value
        """
        mul_scale, _ = mul_node.get_producer(1)
        axes = None
        if mul_scale.type == 'Unsqueeze':
            axes = AttributeProtoHelper(mul_scale.proto).get_attr_value('axes')
            mul_scale, _ = mul_scale.get_producer(0)
        mul_scale_tensor = QuantOpInfo.get_node_tensor(mul_scale)
        mul_scale_data = TensorProtoHelper(mul_scale_tensor).get_data()
        if axes:
            mul_scale_shape = list(mul_scale_data.shape)
            for axis in axes:
                mul_scale_shape.insert(axis, 1)
            mul_scale_data = mul_scale_data.reshape(mul_scale_shape)

        return mul_scale_data

    @staticmethod
    def delete_mul(graph, mul_node):
        """
        Function: delet mul_node in graph
        Parameters:
            graph: mul_node's graph
            mul_node: Node, to be delete
        Return: None
        """
        graph.delete_node(mul_node, 0, 0)

        unsqueeze_node = None
        mul_scale, _ = mul_node.get_producer(1)
        if mul_scale.type == 'Unsqueeze':
            unsqueeze_node = mul_scale
            mul_scale, _ = unsqueeze_node.get_producer(0)

        graph.delete_node(mul_node, 1, 0)
        graph.remove_node(mul_node)
        if unsqueeze_node:
            unsqueeze_consumers, _ = unsqueeze_node.get_consumers(0)
            if unsqueeze_consumers:
                return
            graph.delete_node(unsqueeze_node, 0, 0)
            graph.remove_node(unsqueeze_node)

        mul_scale_consumers, _ = mul_scale.get_consumers(0)
        if mul_scale_consumers:
            return

        if mul_scale.type in ['initializer', 'sparse_initializer']:
            graph.remove_initializer(mul_scale)
        else:
            graph.remove_node(mul_scale)

    def do_pass(self, graph, object_node):
        """
        Function: Do actual "Convolution" layer and "Add" layer
                  fusion operation
        Parameters: graph: graph structure
                    object_node: node to process
        Return: None
        """
        consumers, _ = object_node.get_consumers(0)
        mul_node = consumers[0]
        LOGGER.logd(
            'Do BatchNormalization:"{}" + Mul:"{}" fusion ...'.format(
                object_node.name, mul_node.name), 'BnMulFusionPass')

        mul_scale_data = self.get_mul_scale(mul_node)
        mul_scale_shape = mul_scale_data.shape
        if len(mul_scale_shape) == 1:
            LOGGER.logd(
                "{} cannot do fusion for shape{} of Mul's input B cannot be "
                "1 dimension".format(object_node.name, mul_scale_shape),
                'BnMulFusionPass')
            return
        for dim, value in enumerate(mul_scale_shape):
            if (dim != 0) and (value != 1):
                LOGGER.logd(
                    "{} cannot do fusion for shape of Mul's input B must be "
                    "1 except dim 0, acctually is {}".format(
                        object_node.name, mul_scale_shape), 'BnMulFusionPass')
                return

        scale_data = self.get_bn_param(object_node, 1)
        beta_data = self.get_bn_param(object_node, 2)
        if scale_data.shape != beta_data.shape:
            raise RuntimeError(
                'BatchNormalization {} scale shape {} is unqual to B shape {}'.
                format(object_node.name, scale_data.shape, beta_data.shape))

        mul_scale_data = mul_scale_data.reshape([-1])
        if mul_scale_data.size != 1 and \
            mul_scale_data.shape != scale_data.shape:
            LOGGER.logd(
                "{} cannot do fusion for shape {} of Mul's input B is not "
                "equal to shape {} of bn's scale".format(
                    object_node.name, mul_scale_data.shape, scale_data.shape),
                'BnMulFusionPass')
            return
        new_scale = scale_data * mul_scale_data
        new_beta = beta_data * mul_scale_data

        self.update_bn_param(graph, object_node, 1, new_scale)
        self.update_bn_param(graph, object_node, 2, new_beta)

        self.delete_mul(graph, mul_node)

        # Record fusion info to convolution node
        add_fusion_info_attr(object_node, [mul_node], mul_node)

        LOGGER.logd(
            'Do BatchNormalization:"{}" + Mul:"{}" fusion success.'.format(
                object_node.name, mul_node.name), 'BnMulFusionPass')