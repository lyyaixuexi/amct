#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2023. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert Mul op for dmq_balancer layer in the graph.

"""
from collections import namedtuple
from google.protobuf import text_format
from onnx import onnx_pb
import numpy as np

from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.configuration.configuration import Configuration
from amct_onnx.proto import scale_offset_record_pb2
from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.utils.attrs_list import ATTR_NODE_TWO_INPUTS
from amct_onnx.utils.vars import QUANTIZABLE_TYPES
from amct_onnx.utils.weight_quant_api import adjust_conv_weight_shape

RAW_DATA_TYPE_SET = (np.float16, )

ActsDMQInfo = namedtuple('ActsDMQInfo',
    ['tensor_balance_factor', 'object_node', 'weight_shape', 'graph', 'type_string'])
FactorInfo = namedtuple('FactorInfo',
    ['layer_name', 'tensor_balance_factor', 'graph', 'type_string', 'reshape_size'])


class ApplyDMQBalancerPass(BaseFusionPass):
    """
    Function: Insert mul op for dmq_balancer layer
    APIs: match_pattern, do_pass
    """
    def __init__(self, record_dict):
        """
        Function: Init ApplyDMQBalancerPass object
        Parameters:
            record_dict: dict including quant factors such as tensor_balance_factor
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.record_dict = record_dict
        self.conf = Configuration()
        self.record_file_path = self.conf.get_record_file_path()

    def match_pattern(self, node):
        """
        Function: Find  node need to insert DMQBalancer
        layer in graph
        Parameters: node: node in graph
        Return: True: node that need to insert DMQBalancer layer; False: skip the node
        """
        if node.type not in QUANTIZABLE_TYPES:
            return False

        if node.type == 'AveragePool':
            return False

        if not self.conf.get_layer_config(node.name) or \
            not self.conf.get_layer_config(node.name).get('dmq_balancer_param'):
            return False

        # check whether node that has two inputs
        if node.has_attr(ATTR_NODE_TWO_INPUTS) and node.get_attr(ATTR_NODE_TWO_INPUTS):
            return False

        return True

    def apply_dmq_scale_to_weight(self, object_node, tensor_balance_factor, weight):
        "apply tensor_balance_factor to weight"
        attribute_helper = AttributeProtoHelper(object_node.proto)

        if object_node.type == 'Conv':
            if len(weight.shape) == 4:
                tensor_balance_factor = tensor_balance_factor.reshape([1, -1, 1, 1])
                weight = adjust_conv_weight_shape(object_node, weight)
                weight = weight.transpose((1, 0, 2, 3))
            else:
                tensor_balance_factor = tensor_balance_factor.reshape([1, -1, 1, 1, 1])
                weight = adjust_conv_weight_shape(object_node, weight)
                weight = weight.transpose((1, 0, 2, 3, 4))
        elif object_node.type == 'ConvTranspose':
            tensor_balance_factor = tensor_balance_factor.reshape([-1, 1, 1, 1])
        elif object_node.type == 'Gemm' and attribute_helper.get_attr_value('transB') == 1:
            tensor_balance_factor = tensor_balance_factor.reshape([1, -1])
        else:
            tensor_balance_factor = tensor_balance_factor.reshape([-1, 1])

        weight = tensor_balance_factor * weight

        if object_node.type == 'Conv':
            if len(weight.shape) == 4:
                weight = weight.transpose((1, 0, 2, 3))
                weight = adjust_conv_weight_shape(object_node, weight)
            else:
                weight = weight.transpose((1, 0, 2, 3, 4))
                weight = adjust_conv_weight_shape(object_node, weight)

        return weight

    def apply_dmq_scale_to_activation(self, act_dmq_info):
        "apply tensor_balance_factor to activation"
        type_string = act_dmq_info.type_string
        graph = act_dmq_info.graph
        tensor_balance_factor = act_dmq_info.tensor_balance_factor
        object_node = act_dmq_info.object_node
        weight_shape = act_dmq_info.weight_shape

        object_name = object_node.name
        # step0: broadcast tensor_balance_factor to activation shape
        if len(weight_shape) == 4:
            reshape_size = [1, len(tensor_balance_factor), 1, 1]
        elif len(weight_shape) == 5:
            reshape_size = [1, len(tensor_balance_factor), 1, 1, 1]
        else:
            reshape_size = [1, len(tensor_balance_factor)]
        tensor_balance_factor = 1.0 / tensor_balance_factor
        # Step1: add a new_node
        factor_info = FactorInfo._make(
            [object_name, tensor_balance_factor, graph, type_string, reshape_size])
        tensor_balance_factor_node = self.generate_factor_node(factor_info)
        mul_node = self.generate_mul_node(object_name, graph)

        # Step2: Relink nodes in th graph
        # remove output links
        input_anchor = object_node.get_input_anchor(0)
        peer_output_anchor = input_anchor.get_peer_output_anchor()
        peer_node = peer_output_anchor.node
        peer_output_anchor_index = peer_output_anchor.index
        graph.remove_edge(peer_node, peer_output_anchor_index,
                          object_node, 0)
        # add links
        graph.add_edge(peer_node, peer_output_anchor_index, mul_node, 0)
        graph.add_edge(tensor_balance_factor_node, 0, mul_node, 1)
        graph.add_edge(mul_node, 0, object_node, 0)

    def do_pass(self, graph, object_node):
        """
        Function: Do actual insert dmq_balancer layer operation.
        Parameters: graph: graph that contains object node object_node: node to process
        Return: None
        """
        object_name = object_node.name

        if not self.record_dict.get(object_name) or \
            not self.record_dict[object_name].get('tensor_balance_factor'):
            raise ValueError("config indicates dmq_balancer in layer: %s, " \
                                "but no tensor_balance_factor found in record." \
                                "please check quant_preprocess and calibration is done!" % object_name)

        tensor_balance_factor = self.record_dict.get(object_name).get('tensor_balance_factor')
        tensor_balance_factor = np.array(tensor_balance_factor, np.float32)

        # apply tensor_balance_factor to weight
        weights_node = QuantOpInfo.get_weight_node(object_node)
        weight_tensor = QuantOpInfo.get_node_tensor(weights_node)
        weights_helper = TensorProtoHelper(weight_tensor)
        weights = weights_helper.get_data()
        weight_shape = weights.shape

        quant_type = weight_tensor.data_type
        type_string = 'FLOAT' if weights.dtype == np.float32 else 'FLOAT16'

        weights = self.apply_dmq_scale_to_weight(
            object_node, tensor_balance_factor, weights).astype(weights.dtype)
        weights_helper.clear_data()
        weights_helper.set_data(weights.flatten())

        # insert scale op to activation
        act_dmq_info = ActsDMQInfo._make(
            [tensor_balance_factor, object_node, weight_shape, graph, type_string])
        self.apply_dmq_scale_to_activation(act_dmq_info)

        LOGGER.logd(
            "Insert DMQBalancer layer to '{}' success!".format(
                object_name), 'ApplyDMQBalancerPass')

    def generate_mul_node(self, layer_name, graph):
        ''' generate mul op'''
        node_proto = onnx_pb.NodeProto()
        node_proto.name = '.'.join([layer_name, 'mul'])
        node_proto.op_type = 'Mul'
        node_proto.doc_string = 'mul of the dmq_balancer'
        node_proto.input.extend([
            '.'.join([layer_name, 'mul', 'input0']),
            '.'.join([layer_name, 'tensor_balance_factor', 'input1'])
        ])
        node_proto.output.extend(
            ['.'.join([layer_name, 'mul', 'output0'])])

        mul_node = graph.add_node(node_proto)

        return mul_node

    def generate_factor_node(self, factor_info):
        ''' generate tensor_balance_factor op'''
        layer_name = factor_info.layer_name
        tensor_balance_factor = factor_info.tensor_balance_factor
        graph = factor_info.graph
        data_type = np.float32 if factor_info.type_string == 'FLOAT' else np.float16

        node_proto = onnx_pb.NodeProto()
        node_proto.name = '.'.join([layer_name, 'tensor_balance_factor'])
        node_proto.op_type = 'Constant'
        node_proto.doc_string = 'tensor_balance_factor'
        node_proto.output.extend(
            ['.'.join([layer_name, 'tensor_balance_factor', 'output0'])])

        AttributeProtoHelper(node_proto).set_attr_value('value', 'TENSOR', None)
        attr = node_proto.attribute[0]
        TensorProtoHelper(attr.t).set_data(
            tensor_balance_factor.astype(data_type),
            type_string=factor_info.type_string,
            dims=factor_info.reshape_size,
            graph=graph)

        tensor_balance_factor_node = graph.add_node(node_proto)

        return tensor_balance_factor_node