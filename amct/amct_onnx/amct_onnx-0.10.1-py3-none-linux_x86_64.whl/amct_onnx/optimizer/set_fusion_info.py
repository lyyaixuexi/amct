#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Save fusion info from configuration to node in graph

"""
from amct_onnx.proto import fusion_pb2
from amct_onnx.common.utils.attrs_list import ATTR_NODE_EQUIVALENT_OBJECT_LAYER
from amct_onnx.common.utils.attrs_list import ATTR_NODE_EQUIVALENT_INPUT
from amct_onnx.common.utils.attrs_list import ATTR_NODE_EQUIVALENT_OUTPUT
from amct_onnx.common.utils.attrs_list import ATTR_NODE_FUSION_INFO
from amct_onnx.common.utils.attrs_list import ATTR_NODE_OUTPUT_NODE
from amct_onnx.configuration.configuration import Configuration


class SetFusionInfoPass():
    """
    Function: Add fusion info from graph to Configuration
    APIs: set_up, tear_down, match_pattern, do_pass, run
    """
    def __init__(self):
        self.fusion_info = fusion_pb2.FusionInfo()
        self.fusion_info.graph.add()

    @staticmethod
    def match_pattern(node):
        """
        Function: Find node has fusion info in graph
        Parameters: node: node in graph
        Return: True: node that has info
                False: skip the node
        """
        is_satisified = 0
        is_satisified += int(node.has_attr(ATTR_NODE_EQUIVALENT_INPUT))
        is_satisified += int(node.has_attr(ATTR_NODE_EQUIVALENT_OUTPUT))
        is_satisified += int(node.has_attr(ATTR_NODE_FUSION_INFO))
        is_satisified += int(node.has_attr(ATTR_NODE_OUTPUT_NODE))
        if not is_satisified:
            return False

        return True

    def set_up(self):
        """
        Function: Do some set up for pass
        Parameter: None
        Return: None
        """

    def tear_down(self):
        """
        Function: Do some set up for pass. Add inner fusion info to
            Configuration
        Parameter: None
        Return: None
        """
        Configuration().add_fusion_info(self.fusion_info)

    def do_pass(self, object_node):
        """
        Function: save fusion info of object_node
        Parameters:
            object_node: matched node
        Return: None
        """
        op_info = self.fusion_info.graph[0].op.add()
        op_info.name = object_node.name
        op_info.type = object_node.type

        def add_attr(node, op_info, key):
            """add node's attr info to op_info """
            if node.has_attr(key):
                value = node.get_attr(key)
                attr = op_info.attr.add()
                attr.key = key
                if isinstance(value, list):
                    attr.value.list.s.extend(value)
                elif isinstance(value, str):
                    attr.value.s = value
        add_attr(object_node, op_info, ATTR_NODE_EQUIVALENT_OBJECT_LAYER)
        add_attr(object_node, op_info, ATTR_NODE_EQUIVALENT_INPUT)
        add_attr(object_node, op_info, ATTR_NODE_EQUIVALENT_OUTPUT)
        add_attr(object_node, op_info, ATTR_NODE_FUSION_INFO)
        add_attr(object_node, op_info, ATTR_NODE_OUTPUT_NODE)

    def run(self, graph):
        """
        Function: Save fusion info for graph
        Parameters:
            graph: Graph
        Return: None
        """
        self.set_up()
        # Step1: match pattern and record first matched node
        matched_nodes = []
        for node in graph.nodes:
            if self.match_pattern(node):
                matched_nodes.append(node)
        # Step2: do each matched node fusion operation
        for node in matched_nodes:
            self.do_pass(node)

        self.tear_down()
