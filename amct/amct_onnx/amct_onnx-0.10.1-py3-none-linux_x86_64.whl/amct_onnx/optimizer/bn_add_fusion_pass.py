#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2023. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

BatchNormalization + Add fusion operation

"""
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.optimizer.bn_mul_fusion_pass import BnMulFusionPass
from amct_onnx.optimizer.conv_bn_fusion_pass import ConvBnFusionPass
from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.fusion_info_utils import add_fusion_info_attr
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
from amct_onnx.utils.vars import CONSTANT_NODE_TYPE


class BnAddFusionPass(BaseFusionPass):
    """
    Function: Do "BatchNormalization" and "Add" fusion operation
    APIs: match_pattern, do_pass, get_add_beta, delete_add
    """
    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.idx_map = dict()
        self.fp_idx = 0
        self.bias_idx = 1
        self.weight_rank = 2

    def match_pattern(self, node):
        """
        Function: Match pattern of "BatchNormalization" + "Add" in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        # find matched bn node
        if not ConvBnFusionPass.is_fusionable_bn(node):
            return False
        conv_node, _ = node.get_producer(0)
        if conv_node.type != 'Conv':
            return False
        self.weight_rank = get_conv_kernel_rank(conv_node)
        scale_node, _ = node.get_producer(1)
        beta_node, _ = node.get_producer(2)
        if beta_node.type not in CONSTANT_NODE_TYPE or \
            scale_node.type not in CONSTANT_NODE_TYPE:
            LOGGER.logd(
                "{} match_pattern fail for scale/beta is not in {}".format(node.name, CONSTANT_NODE_TYPE),
                'BnAddFusionPass')
            return False

        # find only one Add
        consumers, in_idxes = node.get_consumers(0)
        if len(consumers) != 1 or consumers[0].type != 'Add':
            LOGGER.logd(
                "{} match_pattern fail for BatchNormalization must has only "
                "one consumer Add".format(node.name), 'BnAddFusionPass')
            return False

        # find Add's const input value(add_beta)
        fp_idx = 0
        bias_idx = 1
        if in_idxes[0] == 1:
            fp_idx, bias_idx = bias_idx, fp_idx
        add_node = consumers[0]
        add_beta, _ = add_node.get_producer(bias_idx)
        if add_beta.type == 'Unsqueeze':
            add_beta, _ = add_beta.get_producer(0)
        if add_beta.type not in CONSTANT_NODE_TYPE:
            LOGGER.logd(
                "{} match_pattern fail for Add op's const input is not in "
                "(+Unsqueeze) {}".format(node.name, CONSTANT_NODE_TYPE),
                'BnAddFusionPass')
            return False
        self.idx_map[node.name] = [fp_idx, bias_idx]
        return True

    def get_add_beta(self, add_node):
        """
        Function: get add's const input value
        Parameter:
            add_node: node, type is Add
        Return:
            add_beta_data: np.array, add's const input value
        """
        add_beta, _ = add_node.get_producer(self.bias_idx)
        axes = None
        if add_beta.type == 'Unsqueeze':
            axes = AttributeProtoHelper(add_beta.proto).get_attr_value('axes')
            add_beta, _ = add_beta.get_producer(0)
        add_beta_tensor = QuantOpInfo.get_node_tensor(add_beta)
        add_beta_data = TensorProtoHelper(add_beta_tensor).get_data()
        if axes:
            add_beta_shape = list(add_beta_data.shape)
            for axis in axes:
                add_beta_shape.insert(axis, 1)
            add_beta_data = add_beta_data.reshape(add_beta_shape)

        return add_beta_data

    def delete_add(self, graph, add_node):
        """
        Function: delet add_node in graph
        Parameters:
            graph: Graph, add_node's graph
            add_node: Node, to be delete
        Return: None
        """
        graph.delete_node(add_node, self.fp_idx, 0)

        unsqueeze_node = None
        add_beta, _ = add_node.get_producer(self.bias_idx)
        if add_beta.type == 'Unsqueeze':
            unsqueeze_node = add_beta
            add_beta, _ = unsqueeze_node.get_producer(0)

        graph.delete_node(add_node, self.bias_idx, 0)
        graph.remove_node(add_node)
        if unsqueeze_node:
            unsqueeze_consumers, _ = unsqueeze_node.get_consumers(0)
            if unsqueeze_consumers:
                return
            graph.delete_node(unsqueeze_node, 0, 0)
            graph.remove_node(unsqueeze_node)

        add_beta_consumers, _ = add_beta.get_consumers(0)
        if add_beta_consumers:
            return

        if add_beta.type in ['initializer', 'sparse_initializer']:
            graph.remove_initializer(add_beta)
        else:
            graph.remove_node(add_beta)

    def do_pass(self, graph, object_node):
        """
        Function: Do actual "BatchNormalization" and "Add"
                  fusion operation
        Parameters: graph: graph structure
                    object_node: node to process
        Return: None
        """
        self.fp_idx, self.bias_idx = self.idx_map[object_node.name]
        consumers, _ = object_node.get_consumers(0)
        add_node = consumers[0]
        LOGGER.logd(
            'Do BatchNormalization:"{}" + Add:"{}" fusion ...'.format(
                object_node.name, add_node.name), 'BnAddFusionPass')
        # Step1: get add input1 data
        add_beta_data = self.get_add_beta(add_node)
        add_beta_shape = add_beta_data.shape
        if len(add_beta_shape) == 1:
            LOGGER.logd(
                "{} cannot do fusion for shape{} of Add's const input cannot be "
                "1 dimension".format(object_node.name, add_beta_shape),
                'BnAddFusionPass')
            return
        channel_flag = -1 * self.weight_rank - 1
        for dim, value in enumerate(add_beta_shape):
            idx = dim - len(add_beta_shape)
            if (idx != channel_flag) and (value != 1):
                LOGGER.logd(
                    "{} cannot do fusion for shape of Add's const input must be "
                    "equal to cout, acctually shape is {}".format(
                        object_node.name, add_beta_shape), 'BnAddFusionPass')
                return

        # Step2: get bn input1 data
        beta_data = BnMulFusionPass.get_bn_param(object_node, 2)

        add_beta_data = add_beta_data.reshape([-1])
        if add_beta_data.size != 1 and add_beta_data.shape != beta_data.shape:
            LOGGER.logd(
                "{} cannot do fusion for shape {} of Add's const input is not "
                "equal to shape {} of bn's scale".format(
                    object_node.name, add_beta_data.shape, beta_data.shape),
                'BnAddFusionPass')
            return

        # Step3: update bn input1 and delete add node
        new_beta = beta_data + add_beta_data
        BnMulFusionPass.update_bn_param(graph, object_node, 2, new_beta)
        add_consumers, _ = add_node.get_consumers(0)
        for add_consumer in add_consumers:
            if add_consumer.type == 'graph_output':
                object_node.get_output_anchor(0).set_name(add_consumer.name)
        self.delete_add(graph, add_node)

        # Step4: Record fusion info to convolution node
        add_fusion_info_attr(object_node, [add_node], add_node)

        LOGGER.logd(
            'Do BatchNormalization:"{}" + Add:"{}" fusion success.'.format(
                object_node.name, add_node.name), 'BnAddFusionPass')


def get_conv_kernel_rank(node):
    """ Get Conv node's kernel_shape rank"""
    attrs_helper = AttributeProtoHelper(node.proto)
    filter_shape = attrs_helper.get_attr_value('kernel_shape')
    return len(filter_shape)