#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

amct onnx tool configurer
"""
import json
from copy import deepcopy

from amct_onnx.utils.log import LOGGER
from amct_onnx.common.config.config_base import ConfigBase
from amct_onnx.common.utils.util import find_repeated_items
from amct_onnx.common.utils.util import check_no_repeated
from amct_onnx.configuration.check import GraphChecker

from amct_onnx.utils.vars import QUANTIZABLE_TYPES


class Configurer(ConfigBase):
    """Configurer for amct_onnx"""

    @staticmethod
    def _process_updated_name(graph, quant_config, layer_type):
        """Process node that with updated name, and add it to quant_config"""
        for op_name, op_type in layer_type.items():
            if op_type in QUANTIZABLE_TYPES and op_name not in quant_config:
                node = graph.get_node_by_name(op_name)
                if node.has_attr('is_update') and node.get_attr('is_update'):
                    op_common = '%s::common' % (op_type)
                    if op_common in quant_config:
                        quant_config[op_name] = deepcopy(
                            quant_config[op_common])

        for quant_type in QUANTIZABLE_TYPES:
            op_common = '%s::common' % (quant_type)
            if op_common in quant_config:
                del quant_config[op_common]

    def check_quant_tensor_valid(self, graph, quant_tensors):
        '''
        Function: check quant tensor's validation by the graph
        '''
        GraphChecker.check_tensor_quant(graph, quant_tensors)

    def parse_config_file(self, config_file, graph):
        """
        parse config file, check incorrect value, and fill default value.
        Inputs:
            config_file: calibration json config file path
            graph: a graph
        Returns:
            quant_config: calibration quant config dict
        """
        def _detect_repetitive_key_hook(lst):
            '''a hook function for detect repeated key in config file.'''
            keys = [key for key, value in lst]
            repeat_keys = find_repeated_items(keys)
            check_no_repeated(repeat_keys, config_file)
            results = {}
            for key, value in lst:
                results[key] = value
            return results

        with open(config_file, 'r') as fid:
            quant_config = json.load(
                fid, object_pairs_hook=_detect_repetitive_key_hook)

        quant_layers = []
        layer_type = self.graph_querier.get_name_type_dict(graph)

        # add updated node to
        self._process_updated_name(graph, quant_config, layer_type)

        for conf in quant_config:
            if conf in self.root.get_keys():
                continue
            if conf in layer_type and isinstance(quant_config[conf], dict) \
                and quant_config[conf].get('quant_enable', False):
                self.check_activation_symmetric_valid(graph, quant_config[conf], conf)
                quant_layers.append(conf)
        # check quant layer's validation by the graph
        if quant_config.get('tensor_quantize'):
            self.check_quant_tensor_valid(graph, quant_config['tensor_quantize'])
        self.set_param_pool(quant_layers, graph)
        self.set_skip_layers(graph)
        self.root.check(None, quant_config)
        self.root.fill_default(quant_config)

        for conf in list(quant_config):
            if conf in self.root.get_keys():
                continue
            if conf not in quant_layers:
                quant_config.pop(conf)

        LOGGER.logd('quant_config is {}'.format(quant_config), 'Configurer')

        return quant_config