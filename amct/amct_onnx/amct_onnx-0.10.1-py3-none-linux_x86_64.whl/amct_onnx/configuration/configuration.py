#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

amct tool quant configuration class

"""
import os

from amct_onnx.utils.log import LOGGER
from amct_onnx.graph.graph import Graph
from amct_onnx.configuration.check import GraphChecker
from amct_onnx.configuration.check import GraphQuerier
from amct_onnx.common.utils.check_params import check_params
from amct_onnx.common.utils.files import is_valid_name
from amct_onnx.common.config.config_base import GraphObjects
from amct_onnx.common.config.config_base import check_config_quant_enable
from amct_onnx.configuration.configurer import Configurer

from amct_onnx.capacity import CAPACITY
from amct_onnx.utils.vars import CLIBRATION_BIT

# load internal quantize algorithm
import amct_onnx.algo.wts_quant_algo

CONFIGURER = Configurer(
    GraphObjects(graph_querier=GraphQuerier, graph_checker=None), CAPACITY)


class Configuration:
    """
    Function: manage configuration of project including quant_config
              and record_file.
    APIs: get_quant_config, get_layer_config, get_record_file_path;
        create_quant_config, parse_quant_config
    """
    _instance = None
    _initialized = False

    def __new__(cls, *args, **kw):
        if cls._instance is None:
            cls._instance = object.__new__(cls, *args, **kw)
        return cls._instance

    @property
    def inner_fusion_info(self):
        """Get quant fusion info """
        return self._inner_fusion_info

    @staticmethod
    @check_params(config_file=str,
                  graph=Graph,
                  skip_layers=(list, type(None)),
                  batch_num=int,
                  activation_offset=bool,
                  config_defination=(type(None), str))
    def create_quant_config(
            config_file,
            graph,
            skip_layers=None,
            batch_num=1,
            activation_offset=True,
            config_defination=None):
        """
        Function: Create quant config.
        Inputs:
            config_file: a string, the file(including path information) to
                save quant config.
            graph: IR Graph, the graph to be quantized.
            skip_layers: a list, cell names which would not apply quantize,
                the skip layer type should be in ['Conv2D', 'MatMul'].
            batch_num: an integer indicating how many batch of data are used
                for calibration.
            activation_offset: a bool indicating whether there's offset or not
                in quantize activation.
            config_defination: a string, the simple config file path,
                containing the simple quant config according to proto.
        Returns: None
        """
        is_valid_name(config_file, 'config_file')
        GraphChecker.check_quant_behaviours(graph)

        if skip_layers is None:
            skip_layers = []
        if config_defination is not None:
            if len(skip_layers) != 0:
                LOGGER.logw(
                    "When setting 'config_defination' param of "
                    "'create_quant_config' API, 'skip_layers' need to be set "
                    "in simple quant config file!",
                    module_name="Configuration")
            CONFIGURER.create_config_from_proto(config_file, graph,
                                                config_defination)
        else:
            CONFIGURER.create_quant_config(config_file, graph, skip_layers,
                                           batch_num, activation_offset)

    @staticmethod
    @check_params(file_name=str, graph=Graph)
    def parse_quant_config(file_name, graph):
        """parse quantize configuration from config json file"""
        quant_config = CONFIGURER.parse_config_file(file_name, graph)
        check_config_quant_enable(quant_config)
        Configuration.add_global_to_layer(quant_config)
        nuq_config = {}
        for key, val in quant_config.items():
            if not isinstance(val, dict):
                continue
            if val['weight_quant_params']['wts_algo'] == 'nuq_quantize':
                nuq_config[key] = val
        return quant_config, nuq_config

    @staticmethod
    def add_global_to_layer(quant_config):
        """add global quantize parameter to each layer"""
        CONFIGURER.add_global_to_layer(quant_config, CLIBRATION_BIT)

        LOGGER.logd("Add global params to layer's config success!",
                    "Configuration")

    @staticmethod
    def get_layers_name(quant_config):
        """ Get all layers' name from quant_config """
        layers_name = list(quant_config.keys())
        # contains other keys: version, activation_offset,etc
        for item in CONFIGURER.root.get_keys():
            layers_name.remove(item)
        return layers_name

    @check_params(config_file=str, record_file=str, graph=Graph)
    def init(self, config_file, record_file, graph):
        """
        Function: init the Configuration.
        Inputs:
            config_file: a string, the file containing the quant config.
            record_file: a string, the file containing the scale and offset.
            graph: IR Graph
        Returns: None
        """
        self._quant_config, self._nuq_config = self.parse_quant_config(
            os.path.realpath(config_file), graph)
        self._record_file_path = os.path.realpath(record_file)
        self._skip_fusion_layers = self._quant_config.get('skip_fusion_layers')
        self._initialized = True

    def uninit(self):
        '''uninit Configuration Class'''
        self._skip_fusion_layers = None
        self._quant_config = None
        self._initialized = False

    def get_nuq_quant_config(self):
        """
        Function: get quant config.
        """
        if not self._initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self._nuq_config

    def get_record_file_path(self):
        """ get record_file_path. """
        if not self._initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self._record_file_path

    def get_global_config(self, global_params_name):
        """ get global quant config. """
        if not self._initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self._quant_config.get(global_params_name)

    def get_skip_fusion_layers(self):
        """Get layers that need to skip do fusion"""
        if not self._initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self._skip_fusion_layers

    def get_layer_config(self, layer_name):
        """ get one lsyer's quant config. """
        if not self._initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self._quant_config.get(layer_name)

    def get_fusion_switch(self):
        """get global fusion switch state"""
        if not self._initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self._quant_config.get('do_fusion')

    def get_quant_config(self):
        """ get quant config. """
        if not self._initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self._quant_config

    def add_fusion_info(self, fusion_info):
        """Add quant fusion info """
        self._inner_fusion_info = fusion_info

    def delete_fusion_info(self):
        """delete quant fusion info """
        del self._inner_fusion_info
