#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

graph checker and graph quirer

"""

from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.vars import QUANTIZABLE_TYPES
from amct_onnx.utils.vars import CONVERT_QAT_QUANTIZABLE_TYPES
from amct_onnx.utils.vars import AMCT_OPERATIONS
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.capacity import CAPACITY
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.vars import MATMUL_TWO_INPUT
from amct_onnx.utils.attrs_list import ATTR_NODE_TWO_INPUTS
from amct_onnx.utils.vars import QUANT_LAYER_SUFFIX
from amct_onnx.utils.vars import CONSTANT_NODE_TYPE
from amct_onnx.utils.vars import TENSOR_QUANTIZABLE_TYPES

HAS_WIGHT_TYPE = ['Conv', 'Gemm', 'ConvTranspose']


class GraphQuerier():
    '''provide some APIs to query the graph'''
    @staticmethod
    def get_name_type_dict(graph):
        '''get all layer name to type dict'''
        name_type = {}
        for node in graph.nodes:
            name_type[node.name] = node.type
        LOGGER.logd("get name type dict from graph", "Configuration")
        return name_type

    @staticmethod
    def get_support_quant_layer2type(graph):
        '''return supported layer to type map in graph'''
        quant_layers = {}
        for node in graph.nodes:
            if GraphChecker.check_quantize_type(node):
                quant_layers[node.name] = node.type
        LOGGER.logd("get support quant layer2type from graph", "Configuration")
        return quant_layers

    @staticmethod
    def get_support_quant_layers(graph):
        '''return supported quant layers in graph'''
        quant_layers = []
        for node in graph.nodes:
            if GraphChecker.check_quantize_type(node):
                quant_layers.append(node.name)
        LOGGER.logd("get support quant layers from graph", "Configuration")
        return quant_layers


    @staticmethod
    def get_skip_quant_layers(graph):
        '''return need to skip quant layers in graph'''
        skip_quant_layers = []
        for node in graph.nodes:
            if node.has_attr("is_update") and node.get_attr('is_update'):
                if not GraphChecker.check_quantize_type(node):
                    skip_quant_layers.append(node.name)
        LOGGER.logd("get skip quant layers from graph", "Configuration")
        return skip_quant_layers

    @staticmethod
    def get_support_convert_layers(graph):
        '''return supported QAT conversion layers in graph'''
        quantable_layers = []
        for node in graph.nodes:
            if GraphChecker.check_convert_qat_quantize_type(node):
                quantable_layers.append(node.name)
        LOGGER.logd(
            "get convert qat support quant layers from graph", "Configuration")
        return quantable_layers

    @staticmethod
    def get_nuq_quant_layers(graph):
        '''get nuq quant layers'''
        layers = []
        for node in graph.nodes:
            if GraphChecker.check_nuq_quantize_type(node):
                layers.append(node.name)
        return layers

    @staticmethod
    def check_nuq_steps(graph, layer_name, steps):
        '''check if nuq steps is bigger than weight length'''
        node = graph.get_node_by_name(layer_name)
        weight_node = QuantOpInfo.get_weight_node(node)
        weight_length = TensorProtoHelper(weight_node.proto).get_data().size

        if weight_length < steps:
            return False
        return True

    @staticmethod
    def check_op_matching(graph, fused_op_list):
        """
        Function: Check whether the ops in json the ops in the original graph
        Inputs:
            graph: Graph, to be quantized
            fused_op_list: list, the ops parsed from the json file
        """
        # check whether the ops in json the ops in the original graph
        original_graph_ids = graph.node_ids
        for json_op_name in fused_op_list:
            is_quant_op = False
            for quant_suffix in QUANT_LAYER_SUFFIX:
                if quant_suffix in json_op_name:
                    is_quant_op = True
            if is_quant_op:
                continue
            if json_op_name not in original_graph_ids:
                LOGGER.logd(
                    "Op '{}' in the given mapping_file does not exist in the original graph. "\
                    "The mapping_file may not match the original graph, "\
                    "please check!".format(json_op_name))

    @staticmethod
    def get_act_symmetric_limit_types():
        """get type only support activation symmetric"""
        types = []
        return types

    @staticmethod
    def get_act_symmetric_limit_layers(graph):
        """get layer only support activation symmetric"""
        layers = []
        for node in graph.nodes:
            if node.type in ['Conv'] and check_kernel_shape(node, [3]):
                layers.append(node.name)
        return layers

    @staticmethod
    def get_shared_weights(graph, quant_config, quantizable_layers):
        """
        Function: get all weights and corresponding quant layers in graph
        Inputs:
            graph: Graph, to be quantized
            quant_config: a dict, quant config
            quantizable_layers: a list, containing name of layers in
                quant_config
        Returns:
            shared_weight_layers: a dict, key: weight_tensor_name, value: list of layer_name
        """
        shared_weight_layers = dict()
        for layer_name in list(quant_config.keys()):
            if layer_name not in quantizable_layers:
                continue
            node = graph.get_node_by_name(layer_name)
            if node.type == 'AveragePool':
                continue
            weight_tensor_name = QuantOpInfo.get_weight_node(node).name
            if shared_weight_layers.get(weight_tensor_name) is None:
                shared_weight_layers[weight_tensor_name] = [layer_name]
            else:
                shared_weight_layers.get(weight_tensor_name).append(layer_name)

        return shared_weight_layers

    @staticmethod
    def get_support_dmq_balancer_types():
        """get type only support activation symmetric"""
        types = QUANTIZABLE_TYPES
        types.remove('AveragePool')
        return types

    @staticmethod
    def get_support_dmq_balancer_layers(graph):
        """get layer only support activation symmetric"""
        layers = []
        for node in graph.nodes:
            if GraphChecker.check_quantize_type(node) and node.type != 'AveragePool':
                    layers.append(node.name)
        return layers


class GraphChecker():
    """Check the graph."""
    @staticmethod
    def check_quantize_type(node):
        """ check if node in graph can be quantized or not."""
        # check type
        if node.type not in QUANTIZABLE_TYPES:
            return False

        if node.type in ['Conv']:
            # must be 2D or 3D
            if not check_kernel_shape(node, [2, 3]):
                return False

        if node.type in ['ConvTranspose', 'AveragePool']:
            # must be 2D
            if not check_kernel_shape(node, [2]):
                return False

        return GraphChecker.check_special_limit(node)

    @staticmethod
    def check_convert_qat_quantize_type(node):
        """ check if node in graph support convert qat or not."""
        # check type
        if node.type not in CONVERT_QAT_QUANTIZABLE_TYPES:
            return False
        if node.type in ['Conv', 'ConvTranspose']:
            # conv2D conv3D
            if not check_kernel_shape(node, [2, 3]):
                return False
            if node.type == 'ConvTranspose':
                # dilation is 1
                if not _check_dilation(node, ['1', [1, 1]]):
                    return False
        return GraphChecker.check_special_limit(node, is_constant=False)

    @staticmethod
    def check_nuq_quantize_type(node):
        """ check if node can be non uniform quantized or not."""
        # check type
        if node.type not in CAPACITY.get_value('NUQ_QUANTIZABLE_TYPES'):
            return False

        if node.type in ['Conv', 'ConvTranspose']:
            # must be conv2D conv3D
            if not check_kernel_shape(node, [2, 3]):
                return False
            # dilation must be 1
            if not _check_dilation(node, ['1', [1, 1], [1, 1, 1]]):
                return False
            # group must be 1
            if not _check_group(node, ['1', 1]):
                return False

        return GraphChecker.check_special_limit(node)

    @staticmethod
    def check_special_limit(node, is_constant=True):
        """ Check if the node in graph satisfy special limits ro be quantized,
            limits include:
                1. Gemm's transA must be false; alpha and beta must be 1
                2. weight must be constant
                3. MatMul shape must be 2
        """
        # Check Gemm's attribute
        if node.type == 'Gemm':
            if not _check_gemm(node):
                return False

        if not is_constant:
            return True
        if not MATMUL_TWO_INPUT:
            HAS_WIGHT_TYPE.append('MatMul')

        if node.type in HAS_WIGHT_TYPE:
            check_constant = True
            weights_node = QuantOpInfo.get_weight_node(node)
            if weights_node.type not in CONSTANT_NODE_TYPE:
                LOGGER.logw('Cannot support quantize node "%s" without '
                            'constant weights.' % (node.name))
                check_constant = False
            bias_node = QuantOpInfo.get_bias_node(node)
            if bias_node is not None and \
                    bias_node.type not in CONSTANT_NODE_TYPE:
                LOGGER.logw('Cannot support quantize node "%s" without'
                            'constant bias.' % (node.name))
                check_constant = False
            if not check_constant:
                return False

        # check MatMul weights' dim is 1 or 2
        if node.type == 'MatMul':
            if not _check_matmul(node):
                return False

        return True

    @staticmethod
    def check_quant_behaviours(graph):
        """
        Function: Check whether there're quant behaviours in the graph.
            If there're layers defined by AMCT, raise error.
        Inputs:
            graph: Graph, the graph to be checked.
        Return: None
        """
        tools_defined_layers = []
        # find all layers whose type is in AMCT_OPERATIONS in onnx graph
        for node in graph.nodes:
            if node.type in AMCT_OPERATIONS:
                tools_defined_layers.append(node.name)

        if tools_defined_layers:
            raise RuntimeError("The model cannot be quantized for following "\
                "quant layers are in the model %s" % (tools_defined_layers))

    @staticmethod
    def check_convert_behaviours(graph):
        """
        Function: Check whether there're fakequant node in the graph.
        Inputs:
            graph: Graph, the graph to be checked.
        Return: None
        """
        is_satisfied = False
        for node in graph.nodes:
            if node.type in ['QuantizeLinear', 'DequantizeLinear']:
                is_satisfied = True
                break
        if not is_satisfied:
            raise RuntimeError("The model cannot be converted for not finding "\
                "any QuantizeLinear or DequantizeLinear layers in the model")

    @staticmethod
    def check_tensor_quant(graph, quant_tensors):
        """
        Function: Check whether tensor exists in the graph and if
        tensor.op's type is quantizable
        Inputs:
        graph: tf.compat.v1.Graph
        quant_tensors: a list of quant-tensors.
        Raise:
        TypeError: tensor.op's type in quantizable types
        RuntimeError: tensor not found in graph
        """
        for tensor_dict in quant_tensors:
            op_name = tensor_dict.get('layer_name')
            tensor_idx = tensor_dict.get('input_index')
            try:
                op = graph.get_node_by_name(op_name)
            except (ValueError, SyntaxError, KeyError) as e:
                raise RuntimeError(
                    "Operation %s is not found in the given Graph." %
                    (op_name)) from e
            if op.type not in TENSOR_QUANTIZABLE_TYPES:
                raise TypeError(
                    "Type %s is not supported for tensor quantization." % (op.type))
            if tensor_idx >= len(op.input_anchors):
                raise IndexError(
                    "Input index %d is out of range for the operation %s" % (tensor_idx, op_name))


def check_kernel_shape(node, kernel_shape_range):
    """ Check whether the node's kernel_shape satisfy kernel_shape_range"""
    attrs_helper = AttributeProtoHelper(node.proto)
    if attrs_helper.has_attr('kernel_shape'):
        filter_shape = attrs_helper.get_attr_value('kernel_shape')
    else:
        weight_tensor = QuantOpInfo.get_weight_tensor(node)
        filter_shape = weight_tensor.dims
        filter_shape = filter_shape[2:]
    if len(filter_shape) not in kernel_shape_range:
        LOGGER.logd("Layer %s's kernel_shape is %s." %
                    (node.name, filter_shape),
                    module_name="Configuration")
        return False

    return True


def _check_dilation(node, dilation_range):
    """ Check whether the node's dilation satisfy dilation_range"""
    attrs_helper = AttributeProtoHelper(node.proto)
    if not attrs_helper.has_attr('dilations'):
        dilation = '1'
    else:
        dilation = attrs_helper.get_attr_value('dilations')

    if dilation not in dilation_range:
        LOGGER.logd("Layer %s's dilation is %s, range is %s." % (node.name, dilation, dilation_range),
                    "Configuration")
        return False

    return True


def _check_group(node, group_range):
    """ Check whether the Conv node's group satisfy group_range"""
    attrs_helper = AttributeProtoHelper(node.proto)
    if not attrs_helper.has_attr('group'):
        group = '1'
    else:
        group = attrs_helper.get_attr_value('group')

    if group not in group_range:
        LOGGER.logd("Layer %s's group is %s." % (node.name, group),
                    "Configuration")
        return False

    return True


def _check_gemm(node):
    """ Check whether Gemm can be quantized """
    attrs_helper = AttributeProtoHelper(node.proto)
    if attrs_helper.has_attr('transA') and \
            attrs_helper.get_attr_value('transA') == 1:
        LOGGER.logw('Cannot support quantize "Gemm" layer "{}" with '
                    'transA:True.'.format(node.name), "Configuration")
        return False
    if attrs_helper.has_attr('alpha'):
        alpha = attrs_helper.get_attr_value('alpha')
        if alpha != 1.0:
            LOGGER.logw('Cannot support quantize "Gemm" layer "{}" with '
                        'alpha:{}.'.format(node.name, alpha), "Configuration")
            return False
    if attrs_helper.has_attr('beta'):
        beta = attrs_helper.get_attr_value('beta')
        if beta != 1.0:
            LOGGER.logw('Cannot support quantize "Gemm" layer "{}" with '
                        'beta:{}.'.format(node.name, beta), "Configuration")
            return False
    return True


def _check_matmul(node):
    """ Check whether Gemm can be quantized """
    weights_node = QuantOpInfo.get_weight_node(node)
    if weights_node.type not in CONSTANT_NODE_TYPE:
        node.set_attr(ATTR_NODE_TWO_INPUTS, True)
        return True
    weight_tensor = QuantOpInfo.get_node_tensor(weights_node)
    shape = weight_tensor.dims
    if len(shape) != 2:
        LOGGER.logd('Cannot support quantize "MatMul" layer "{}" for weight '
                    'dim({}) is not 2.'.format(node.name, len(shape)),
                    "Configuration")
        return False

    return True
