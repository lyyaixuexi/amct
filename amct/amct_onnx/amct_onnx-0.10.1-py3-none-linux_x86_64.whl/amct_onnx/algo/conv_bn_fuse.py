#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

func FuseConvBN, fuse CONV and BN.

"""
from amct_onnx.common.algo.conv_bn_fuse_base import FuseConvBnBase


class FuseConvBn(FuseConvBnBase):
    """ class FuseConvBn derived from FuseConvBnBase"""
    @staticmethod
    def get_conv_bn_param(conv_params, bn_params):
        conv_weight = conv_params[0]
        conv_bias = conv_params[1]
        bn_mean = bn_params[0]
        bn_variance = bn_params[1]
        bn_epsilon = bn_params[2]

        return conv_weight, conv_bias, bn_mean, bn_variance, bn_epsilon


def fuse_conv_bn(conv_params, bn_params):
    """ fuse conv and bn"""
    return FuseConvBn.fuse_conv_bn(conv_params, bn_params)
