#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

op info base class

"""
from amct_onnx.utils.onnx_node_util import AttributeProtoHelper


class OpsetVersion:
    """ OpsetVersion class"""
    def __init__(self):
        self.v1 = 1
        self.v2 = 2
        self.v3 = 3
        self.v4 = 4
        self.v5 = 5
        self.v6 = 6
        self.v7 = 7
        self.v8 = 8
        self.v9 = 9
        self.v10 = 10
        self.v11 = 11
        self.v12 = 12
        self.v13 = 13
        self.v14 = 14


OPSET = OpsetVersion()


class OpInfoBase:
    """ base class of opinfo"""
    def __init__(self, op_version, node, default_value=None):
        """ init function of OpInfoBase"""
        self.op_version = op_version
        self.node = node
        self.op_proto = node.proto
        self.default_value = default_value
        self.attr_helper = AttributeProtoHelper(node.proto)

    @staticmethod
    def get_attribute_names():
        """ get all the attribute names of this op"""
        raise NotImplementedError(
            "function get_attribute_names not implemented.")

    def has_attribute(self, attr_name):
        """ whether op has attribute named attr_name"""
        return self.attr_helper.has_attr(attr_name)

    def get_attribute_value(self, attr_name):
        """ get the value of attribute named attr_name"""
        attr_value = None
        if self.attr_helper.has_attr(attr_name):
            attr_value = self.attr_helper.get_attr_value(attr_name)
        elif self.default_value is not None and \
                attr_name in self.default_value.keys():
            attr_value = self.default_value[attr_name]
        else:
            raise ValueError("{} does not has attribute name {}".format(
                self.op_version, attr_name))
        return attr_value
