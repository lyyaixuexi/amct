#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

utils for multi-opset version of operater Pad

"""
import numpy as np

from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.parser.opset_context import OpsetContext
from amct_onnx.opset_utils.op_info_base import OpInfoBase
from amct_onnx.opset_utils.op_info_base import OPSET

PADS_INDEX = 1


class PadV1(OpInfoBase):
    """ OpInfo of Pad-1"""
    def __init__(self, node):
        super().__init__(
            'PadV1',
            node,
            {'mode': 'constant', 'value': 0.0})

    @staticmethod
    def get_attribute_names():
        """ get all the attribute names of Pad-1"""
        return ['mode', 'paddings', 'value']

    def get_mode(self):
        """ get value of attribute mode"""
        return str(self.get_attribute_value('mode'),
                   encoding="utf-8")

    def get_pads(self):
        """ get value of attribute pads"""
        return np.array(self.get_attribute_value('paddings'))

    def get_pad_value(self):
        """ get value of attribute value, which is the pad value."""
        return self.get_attribute_value('value')


class PadV2(OpInfoBase):
    """ OpInfo of Pad-2"""
    def __init__(self, node):
        super().__init__(
            'PadV2',
            node,
            {'mode': 'constant', 'value': 0.0})

    @staticmethod
    def get_attribute_names():
        """ get all the attribute names of Pad-2"""
        return ['mode', 'pads', 'value']

    def get_mode(self):
        """ get value of attribute mode"""
        return str(self.get_attribute_value('mode'), encoding="utf-8")

    def get_pads(self):
        """ get value of attribute pads"""
        return np.array(self.get_attribute_value('pads'))

    def get_pad_value(self):
        """ get value of attribute value, which is the pad value."""
        return self.get_attribute_value('value')


class PadV11(OpInfoBase):
    """ OpInfo of Pad-11"""
    def __init__(self, node):
        super().__init__(
            'PadV11',
            node,
            {'mode': 'constant'})

    @staticmethod
    def get_attribute_names():
        """ get all the attribute names of Pad-11"""
        return ['mode']

    def get_mode(self):
        """ get value of attribute mode"""
        return str(self.get_attribute_value('mode'), encoding="utf-8")

    def get_pads(self):
        """ get value of second input pads, which is required."""
        node_pads = self.node.get_input_anchor(
            PADS_INDEX).get_peer_output_anchor().node
        pads = TensorProtoHelper(node_pads.proto.attribute[0].t).get_data()
        return pads

    def get_pad_value(self):
        """ get value of third input constant_value, which is optional.
            when does not have third input and mode is 'constant',
            constant_value is 0
        """
        return _get_constant_value(self.get_mode(), self.node)


class PadV13(PadV11):
    """ OpInfo of Pad-13"""
    def __init__(self, node):
        super().__init__(node)
        self.op_version = 'PadV13'


def _get_constant_value(mode, node):
    """ function to get the value of constant_value"""
    constant_value = 0
    if mode == 'constant':
        if len(node.input_anchors) == 3:
            node_constant_value = node.get_input_anchor(
                2).get_peer_output_anchor().node
            constant_value = TensorProtoHelper(
                node_constant_value.proto).get_data()
        else:
            constant_value = 0.0
    else:
        raise ValueError(
            "Pad is not in constant mode, do not have constant_value")
    return constant_value


class PadUtils:
    """ wrapper of multi opset version of Pad op"""
    def __init__(self, node):
        self.op_pad = self.select_op(OpsetContext().get_version(), node)

    @staticmethod
    def select_op(opset_version, node):
        """ select the specific op according to the opset version"""
        if opset_version == OPSET.v1:
            return PadV1(node)
        if opset_version in [OPSET.v2, OPSET.v3, OPSET.v4, OPSET.v5,
                OPSET.v6, OPSET.v7, OPSET.v8, OPSET.v9, OPSET.v10]:
            return PadV2(node)
        if opset_version in [OPSET.v11, OPSET.v12]:
            return PadV11(node)
        if opset_version in (OPSET.v13, OPSET.v14):
            return PadV13(node)
        raise RuntimeError("Not support opset version {} yet.".format(
            opset_version))

    def get_mode(self):
        """ wrapper of get_mode"""
        return self.op_pad.get_mode()

    def get_pads(self):
        """ wrapper of get_pads"""
        return self.op_pad.get_pads()

    def get_pad_value(self):
        """ wrapper of get_pad_value"""
        return self.op_pad.get_pad_value()

    def has_attribute(self, attr_name):
        """ wrapper of has_attribute"""
        return self.op_pad.has_attribute(attr_name)

    def get_attribute_value(self, attr_name):
        """ wrapper of get_attribute_value"""
        return self.op_pad.get_attribute_value(attr_name)

    def get_attribute_names(self):
        """ wrapper of get_attribute_names"""
        return self.op_pad.get_attribute_names()
