#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

utils for multi-opset version of operater Constant

"""

from amct_onnx.parser.opset_context import OpsetContext
from amct_onnx.opset_utils.op_info_base import OpInfoBase
from amct_onnx.opset_utils.op_info_base import OPSET


class ConstantV1(OpInfoBase):
    """ OpInfo of Constant-1"""
    def __init__(self, node):
        """ init func of class"""
        super().__init__('ConstantV1', node, {})

    @staticmethod
    def get_attribute_names():
        """ get the attribute names of Constant-1"""
        return ['value']


class ConstantV9(OpInfoBase):
    """ OpInfo of Constant-9"""
    def __init__(self, node):
        """ init func of class"""
        super().__init__('ConstantV9', node, {})

    @staticmethod
    def get_attribute_names():
        """ get the attribute names of Constant-9"""
        return ['value']


class ConstantV11(OpInfoBase):
    """ OpInfo of Constant-11"""
    def __init__(self, node):
        """ init func of class"""
        super().__init__('ConstantV11', node, {})

    @staticmethod
    def get_attribute_names():
        """ get the attribute names of Constant-11"""
        return ['sparse_value', 'value']


class ConstantV12(OpInfoBase):
    """ OpInfo of Constant-12"""
    def __init__(self, node):
        """ init func of class"""
        super().__init__('ConstantV12', node, {})

    @staticmethod
    def get_attribute_names():
        """ get the attribute names of Constant-12"""
        return ['sparse_value', 'value', 'value_float', 'value_floats',
                'value_int', 'value_ints', 'value_string', 'value_strings']


class ConstantV13(OpInfoBase):
    """ OpInfo of Constant-13"""
    def __init__(self, node):
        """ init func of class"""
        super().__init__('ConstantV13', node, {})

    @staticmethod
    def get_attribute_names():
        """ get the attribute names of Constant-13"""
        return ['sparse_value', 'value', 'value_float', 'value_floats',
                'value_int', 'value_ints', 'value_string', 'value_strings']


class ConstantUtils:
    """ wrapper of multi opset version of Constant op"""
    def __init__(self, node):
        """ init func of class"""
        self.op_constant = self.select_op(OpsetContext().get_version(), node)

    @staticmethod
    def select_op(opset_version, node):
        """ select the specific op according to the opset version"""
        if opset_version in [OPSET.v1, OPSET.v2, OPSET.v3, OPSET.v4, OPSET.v5,
                             OPSET.v6, OPSET.v7, OPSET.v8]:
            return ConstantV1(node)
        if opset_version in [OPSET.v9, OPSET.v10]:
            return ConstantV9(node)
        if opset_version == OPSET.v11:
            return ConstantV11(node)
        if opset_version == OPSET.v12:
            return ConstantV12(node)
        if opset_version in (OPSET.v13, OPSET.v14):
            return ConstantV13(node)
        raise RuntimeError("Not support opset version {} yet.".format(
            opset_version))

    def has_attribute(self, attr_name):
        """ wrapper of has_attribute"""
        return self.op_constant.has_attribute(attr_name)

    def get_attribute_value(self, attr_name):
        """ wrapper of get_attribute_value"""
        return self.op_constant.get_attribute_value(attr_name)

    def get_attribute_names(self):
        """ wrapper of get_attribute_names"""
        return self.op_constant.get_attribute_names()
