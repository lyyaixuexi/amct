#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

utils for multi-opset version of operater BatchNormalization

"""
import numpy as np

from amct_onnx.parser.opset_context import OpsetContext
from amct_onnx.opset_utils.op_info_base import OpInfoBase
from amct_onnx.opset_utils.op_info_base import OPSET


class BatchNormalizationV1(OpInfoBase):
    """ OpInfo of BatchNormalization-1"""
    def __init__(self, node):
        super().__init__(
            'BatchNormalizationV1',
            node,
            {'epsilon': 1e-05, 'momentum': 0.9, 'spatial': 1, 'is_test': 0})

    @staticmethod
    def get_attribute_names():
        """ get all the attribute names of BatchNormalization-1"""
        return ['epsilon', 'momentum', 'spatial', 'is_test', 'consumed_inputs']

    def get_epsilon(self):
        """ get value of attribute epsilon"""
        return self.get_attribute_value('epsilon')

    def get_momentum(self):
        """ get value of attribute momentum"""
        return np.array(self.get_attribute_value('momentum'))


class BatchNormalizationV6(OpInfoBase):
    """ OpInfo of BatchNormalization-6"""
    def __init__(self, node):
        super().__init__(
            'BatchNormalizationV6',
            node,
            {'epsilon': 1e-05, 'momentum': 0.9, 'spatial': 1, 'is_test': 0})

    @staticmethod
    def get_attribute_names():
        """ get all the attribute names of BatchNormalization-6"""
        return ['epsilon', 'momentum', 'spatial', 'is_test']

    def get_epsilon(self):
        """ get value of attribute epsilon"""
        return self.get_attribute_value('epsilon')

    def get_momentum(self):
        """ get value of attribute momentum"""
        return np.array(self.get_attribute_value('momentum'))


class BatchNormalizationV7(OpInfoBase):
    """ OpInfo of BatchNormalization-7"""
    def __init__(self, node):
        super().__init__(
            'BatchNormalizationV7',
            node,
            {'epsilon': 1e-05, 'momentum': 0.9, 'spatial': 1})

    @staticmethod
    def get_attribute_names():
        """ get all the attribute names of BatchNormalization-7"""
        return ['epsilon', 'momentum', 'spatial']

    def get_epsilon(self):
        """ get value of attribute epsilon"""
        return self.get_attribute_value('epsilon')

    def get_momentum(self):
        """ get value of attribute momentum"""
        return np.array(self.get_attribute_value('momentum'))


class BatchNormalizationV9(OpInfoBase):
    """ OpInfo of BatchNormalization-9"""
    def __init__(self, node):
        super().__init__(
            'BatchNormalizationV9',
            node,
            {'epsilon': 1e-05, 'momentum': 0.9})

    @staticmethod
    def get_attribute_names():
        """ get all the attribute names of BatchNormalization-9"""
        return ['epsilon', 'momentum']

    def get_epsilon(self):
        """ get value of attribute epsilon"""
        return self.get_attribute_value('epsilon')

    def get_momentum(self):
        """ get value of attribute momentum"""
        return np.array(self.get_attribute_value('momentum'))


class BatchNormalizationV14(OpInfoBase):
    """ OpInfo of BatchNormalization-14"""
    def __init__(self, node):
        super().__init__(
            'BatchNormalizationV14',
            node,
            {'epsilon': 1e-05, 'momentum': 0.9, 'training_mode': 0})

    @staticmethod
    def get_attribute_names():
        """ get all the attribute names of BatchNormalization-14"""
        return ['epsilon', 'momentum', 'training_mode']

    def get_epsilon(self):
        """ get value of attribute epsilon"""
        return self.get_attribute_value('epsilon')

    def get_momentum(self):
        """ get value of attribute momentum"""
        return np.array(self.get_attribute_value('momentum'))


class BatchNormalizationUtils:
    """ wrapper of multi opset version of BatchNormalization op"""
    def __init__(self, node):
        self.op_bn = self.select_op(OpsetContext().get_version(), node)

    @staticmethod
    def select_op(opset_version, node):
        """ select the specific op according to the opset version"""
        if opset_version in [OPSET.v1, OPSET.v2, OPSET.v3, OPSET.v4, OPSET.v5]:
            return BatchNormalizationV1(node)
        if opset_version == OPSET.v6:
            return BatchNormalizationV6(node)
        if opset_version in [OPSET.v7, OPSET.v8]:
            return BatchNormalizationV7(node)
        if opset_version in [OPSET.v9, OPSET.v10, OPSET.v11, OPSET.v12,
                OPSET.v13]:
            return BatchNormalizationV9(node)
        if opset_version == OPSET.v14:
            return BatchNormalizationV14(node)
        raise RuntimeError("Not support opset version {} yet.".format(
            opset_version))

    def get_momentum(self):
        """ wrapper of get_mode"""
        return self.op_bn.get_momentum()

    def get_epsilon(self):
        """ wrapper of get_pads"""
        return self.op_bn.get_epsilon()

    def has_attribute(self, attr_name):
        """ wrapper of has_attribute"""
        return self.op_bn.has_attribute(attr_name)

    def get_attribute_value(self, attr_name):
        """ wrapper of get_attribute_value"""
        return self.op_bn.get_attribute_value(attr_name)

    def get_attribute_names(self):
        """ wrapper of get_attribute_names"""
        return self.op_bn.get_attribute_names()
