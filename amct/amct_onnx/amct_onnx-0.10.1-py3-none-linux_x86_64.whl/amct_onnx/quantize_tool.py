#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Top APIs of AMCT_ONNX tool for user

"""

import os

from amct_onnx.utils.log import LOGGER
from amct_onnx.common.utils.check_params import check_params
from amct_onnx.common.utils import files as files_util
from amct_onnx.common.utils.record_file_operator import \
    save_nuq_quant_layer_names
from amct_onnx.common.config.config_base import check_config_dmq_balancer
from amct_onnx.parser.parser import Parser

import amct_onnx.optimizer as opt
from amct_onnx.configuration.configuration import Configuration
from amct_onnx.configuration.configuration import GraphChecker
from amct_onnx.configuration.configuration import GraphQuerier
from amct_onnx.parser.parse_record_file import RecordFileParser
from amct_onnx.utils.save import save_onnx_model
from amct_onnx.utils.save import generate_onnx_file_name
from amct_onnx.utils.save import split_dir_prefix


@check_params(config_file=str,
              model_file=str,
              skip_layers=(list, type(None)),
              batch_num=int,
              activation_offset=bool,
              config_defination=(type(None), str),
              updated_model=(type(None), str))
def create_quant_config(
        config_file,
        model_file,
        skip_layers=None,
        batch_num=1,
        activation_offset=True,
        config_defination=None,
        updated_model=None):
    """
    Function: Create quantize configuration json file for amct_onnx tool
    Parameter: config_file: file path of quantize configuration json file
               model_file: user mode instance of Torch.nn.Module
               skip_layers: list of layers that not do quantize, default empty
               batch_num: number of batch that used for calibration
               activation_offset: whether activation quantize with offset
               config_defination: simply config file from user to set
               updated_model: a file path to store model with name updated.
    Return: None
    """
    # cope inputs
    config_file = os.path.realpath(config_file)
    # parse to graph
    graph = Parser.parse_net_to_graph(model_file, updated_model is not None)
    GraphChecker.check_quant_behaviours(graph)

    # create config file for quantizetion
    Configuration.create_quant_config(config_file,
                                      graph,
                                      skip_layers,
                                      batch_num,
                                      activation_offset,
                                      config_defination)
    if updated_model is not None:
        LOGGER.logi('Update onnx model:', 'create_quant_config')
        save_onnx_model(graph, updated_model)
    LOGGER.logi('Create quant config file %s success.' % (config_file),
                'create_quant_config')


@check_params(config_file=str,
              record_file=str,
              model_file=str,
              modified_onnx_file=str)
def quantize_preprocess(
        config_file,
        record_file,
        model_file,
        modified_onnx_file):
    """
    Function: Modify user's model for calibration in inference process.
    Parameter: config_file: quantize configuration json file
               model_file: user onnx model's model file
               record_file: temporary file to store tensor_balance_factor
               modified_onnx_file: a string, the file export from model after
               fusion.
    Return: None
    """
    files_util.is_valid_name(config_file, 'config_file')
    files_util.is_valid_name(record_file, 'record_file')
    config_file = os.path.realpath(config_file)
    if not os.path.exists(config_file):
        raise OSError('file (%s) does not exist!' % config_file)
    modified_onnx_file = os.path.realpath(modified_onnx_file)
    record_file = files_util.create_empty_file(record_file, check_exist=True)

    # parse to graph
    graph = Parser.parse_net_to_graph(model_file)
    GraphChecker.check_quant_behaviours(graph)

    # check dmq_balancer config
    Configuration().init(config_file, record_file, graph)
    quant_config = Configuration().get_quant_config()
    check_config_dmq_balancer(quant_config)
    disable_dmq_balancer_for_shared_wts(graph, quant_config)

    # BN fusion
    optimizer = opt.GraphOptimizer()
    optimizer.add_pass(opt.TransposeFoldPass())
    optimizer.add_pass(opt.ConvAddBiasFusionPass())
    if Configuration().get_fusion_switch():
        optimizer.add_pass(opt.BnMulFusionPass())
        optimizer.add_pass(opt.BnAddFusionPass())
        optimizer.add_pass(opt.ConvBnFusionPass())
    # do dmq_balancer
    optimizer.add_pass(opt.InsertDMQBalancerPass())
    optimizer.do_optimizer(graph)

    save_onnx_model(graph, modified_onnx_file)


def disable_dmq_balancer_for_shared_wts(graph, quant_config):
    """
    Function:
    remove dmq_balancer_param from quant_config if layer's weight is shared weight.
    """
    layers_name = Configuration.get_layers_name(quant_config)
    shared_weight = GraphQuerier.get_shared_weights(graph, quant_config, layers_name)
    for shared_weight_layers in shared_weight.values():
        if len(shared_weight_layers) == 1:
            continue
        for layer in shared_weight_layers:
            quant_config.get(layer).pop('dmq_balancer_param')


@check_params(config_file=str,
              model_file=str,
              modified_onnx_file=str,
              record_file=str)
def quantize_model(config_file,
                   model_file,
                   modified_onnx_file,
                   record_file):
    """
    Function: Modify user's model for calibration in inference process.
    Parameter: config_file: quantize configuration json file
               model_file: user onnx model's model file
               modified_onnx_file: a string, the file export from model after
               fusion.
               record_file: temporary file to store scale and offset
    Return: None
    """
    config_file = os.path.realpath(config_file)
    modified_onnx_file = os.path.realpath(modified_onnx_file)

    graph = Parser.parse_net_to_graph(model_file)
    GraphChecker.check_quant_behaviours(graph)

    Configuration().init(config_file, record_file, graph)
    quant_config = Configuration().get_quant_config()
    joint_quant = quant_config['joint_quant']

    # check tensor_balance_factor in record if config indicates dmq_balancer
    records = check_dmq_balancer(graph, quant_config, record_file)

    # fuse and export modified onnx
    optimizer = opt.GraphOptimizer()
    optimizer.add_pass(opt.TransposeFoldPass())
    optimizer.add_pass(opt.AdjustInputIndexPass())
    optimizer.add_pass(opt.ConvAddBiasFusionPass())
    if Configuration().get_fusion_switch():
        optimizer.add_pass(opt.BnMulFusionPass())
        optimizer.add_pass(opt.BnAddFusionPass())
        optimizer.add_pass(opt.ConvBnFusionPass())
    # dmq_balancer
    optimizer.add_pass(opt.ApplyDMQBalancerPass(records))
    # weight quant
    if joint_quant:
        optimizer.add_pass(opt.AddOptWeightsCalibrationPass())
    optimizer.add_pass(opt.WeightsCalibrationPass())
    # activation calibation
    if joint_quant:
        optimizer.add_pass(opt.AddOptInsertActCalibrationPass())
    optimizer.add_pass(opt.InsertActCalibrationPass())
    # search_n
    if joint_quant:
        optimizer.add_pass(opt.AddOptInsertSearchNLayerPass())
    optimizer.add_pass(opt.InsertSearchNPass())
    # fusion info
    optimizer.add_pass(opt.SetFusionInfoPass())
    optimizer.do_optimizer(graph)

    save_onnx_model(graph, modified_onnx_file)


def check_dmq_balancer(graph, quant_config, record_file):
    """
    Function: check tensor_balance_factor in record if config indicates dmq_balancer
    Inputs:
        graph: onnx Graph IR.
        quant_config: a dict, quant config parsed from config_file.
        record_file: a string, the name of file recording quantization factor.
    Returns:
        None
    """
    dmq_balancer_enable = False
    for key, _ in quant_config.items():
        if not isinstance(quant_config[key], dict):
            continue
        if quant_config[key].get("dmq_balancer_param"):
            dmq_balancer_enable = True
            break
    if dmq_balancer_enable:
        if os.path.exists(record_file):
            record_parser = RecordFileParser(record_file, graph, 'quantize_graph')
        if not os.path.exists(record_file) or record_parser.is_records_empty():
            raise RuntimeError(
                "config_file indicates dmq_balancer, but record_file is empty. "
                "please check quant_preprocess and calibration is done!"
            )
        records, _ = record_parser.parse()
        return records
    else:
        record_file = files_util.create_empty_file(record_file, check_exist=True)
        return {}


@check_params(modified_onnx_file=str,
              record_file=str,
              save_path=str)
def save_model(modified_onnx_file,
               record_file,
               save_path):
    """
    Function: save modified_onnx_file to fakequant_onnx_file and
        deploy_onnx_file.
    Parameter:
        modified_onnx_file: a string, the file export from quantize_model
        record_file: a string, path of file containing the scale and offset.
        save_path: a string, the path where to store model and model's name.
    Return: None
    """
    # check inputs
    files_util.is_valid_name(modified_onnx_file, 'modified_onnx_file')
    files_util.is_valid_name(record_file, 'record_file')
    modified_onnx_file = os.path.realpath(modified_onnx_file)
    record_file = os.path.realpath(record_file)
    graph = Parser.parse_net_to_graph(modified_onnx_file)

    # parse record_file
    record_parser = RecordFileParser(record_file, graph, modified_onnx_file)
    if record_parser.is_records_empty():
        raise RuntimeError(
            "record_file is empty, no layers to be quantized. "
            "please ensure calibration is finished by checking information!")

    records, _ = record_parser.parse()
    RecordFileParser.cmp_config(records)

    # save nuq quant layer names
    nuq_config = Configuration().get_nuq_quant_config()
    file_name = save_nuq_quant_layer_names(nuq_config, save_path)
    if file_name:
        LOGGER.logi('Non uniform quant layer record is saved in {}.'.format(file_name))
    optimizer = opt.GraphOptimizer()
    optimizer.add_pass(opt.UpdateFusionInfoPass())
    optimizer.add_pass(opt.DeleteSearchNPass(records, graph))
    optimizer.add_pass(opt.DeleteActCalibrationPass(records))
    optimizer.do_optimizer(graph)
    inner_save_model(graph, records, save_path)


def inner_save_model(graph, records, save_path):
    """
    Function: inner method of save_model, save quantized model from original model
    Parameter:
        graph: graph of original model
        records: record parsed from record file
        save_path: a string, the path where to store model and model's name.
    Return: None
    """
    save_dir, save_prefix = split_dir_prefix(save_path)
    files_util.create_path(save_dir)
    # generate and save deploy model
    optimizer = opt.GraphOptimizer()
    optimizer.add_pass(opt.GemmTransBOptimizePass(records))
    optimizer.add_pass(opt.InsertQuantPass(records))
    optimizer.add_pass(opt.InsertDequantPass(records))
    optimizer.add_pass(opt.MultQuantOptimizerPass(records))
    optimizer.add_pass(opt.QuantFusionPass(records))
    optimizer.add_pass(opt.WeightQuantPass(records))
    optimizer.add_pass(opt.BiasQuantPass(records))
    # generate fusion json
    gen_fusion_json_pass = opt.GenFusionJsonPass()
    gen_fusion_json_pass.set_dump_file_dir(save_dir, save_prefix)
    optimizer.add_pass(gen_fusion_json_pass)
    optimizer.do_optimizer(graph)
    deploy_file = generate_onnx_file_name(save_dir, save_prefix, 'Deploy')
    save_onnx_model(graph, deploy_file)

    # generate and save fakequant model
    optimizer = opt.GraphOptimizer()
    optimizer.add_pass(opt.UpdateAscendOpPass())
    optimizer.add_pass(opt.WeightFakequantPass(records))
    optimizer.add_pass(opt.BiasFakequantPass(records))
    optimizer.do_optimizer(graph)
    deploy_file = generate_onnx_file_name(save_dir, save_prefix, 'Fakequant')
    save_onnx_model(graph, deploy_file)
