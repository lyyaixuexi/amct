#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

amct_onnx command line tool core funtions.

"""

import os
import sys
import importlib

import onnxruntime as ort

import amct_onnx as amct
import amct_onnx.cmd_line_tools.parser_args as parser_args
import amct_onnx.common.cmd_line_utils.arguments_handler as args_handler
from amct_onnx.common.cmd_line_utils.data_handler import tmp_dir
from amct_onnx.common.cmd_line_utils.data_handler import delete_tmp_dir
import amct_onnx.common.cmd_line_utils.data_handler as data_handler
from amct_onnx.parser.parser import Parser
from amct_onnx.configuration.configuration import Configuration


class Evaluator(amct.CalibrationEvaluatorBase):
    '''
    Evaluator: default evaluator.
    '''
    def __init__(self, args_var):
        super().__init__()
        self.args_var = args_var

    def calibration(self, modified_model):
        '''
        Function: calibration
        modified_model: quantized model
        '''
        ort_session = ort.InferenceSession(modified_model, amct.AMCT_SO)
        for data_map in data_handler.load_data(
                self.args_var.input_shape,
                self.args_var.data_dir,
                self.args_var.data_types,
                self.args_var.batch_num):
            _ = ort_session.run(None, data_map)


def calibration_function(args_var):
    '''
    Function: run amct calibration process
    Arguments:
        args_var: the parsed arguments to run calibration
    Return: None
    '''

    args_handler.calibration_args_checker(args_var)

    tmp = tmp_dir()
    config_file = os.path.join(tmp, 'quant_config.json')
    record_file = os.path.join(tmp, 'record.txt')
    updated_model = os.path.join(tmp, 'updated_model.onnx')

    try:
        amct.create_quant_config(
            config_file=config_file,
            model_file=args_var.model,
            batch_num=args_var.batch_num,
            config_defination=args_var.calibration_config,
            updated_model=updated_model)
        graph = Parser.parse_net_to_graph(args_var.model, updated_model is not None)

        args_var.batch_num = int(Configuration.parse_quant_config(config_file, graph)[0]['batch_num'])

        if args_var.evaluator is not None:
            if not os.path.exists(args_var.evaluator):
                raise RuntimeError("evaluator file '{}' not exists!".format(args_var.evaluator))
            evaluator_path, evaluator_file = os.path.split(args_var.evaluator)
            sys.path.append(evaluator_path)
            evaluator = importlib.import_module(evaluator_file.split('.')[0])

            evaluator = evaluator.customize_evaluator
        else:
            evaluator = Evaluator(args_var)

        if check_dmq_balancer(graph, config_file):
            modified_model = os.path.join(tmp, 'modified_model.onnx')
            amct.quantize_preprocess(
                model_file=updated_model,
                modified_onnx_file=modified_model,
                config_file=config_file,
                record_file=record_file)
            evaluator.calibration(modified_model)

        modified_model = os.path.join(tmp, 'modified_model.onnx')
        amct.quantize_model(
            model_file=updated_model,
            modified_onnx_file=modified_model,
            config_file=config_file,
            record_file=record_file)

        evaluator.calibration(modified_model)

        amct.save_model(
            modified_onnx_file=modified_model,
            record_file=record_file,
            save_path=args_var.save_path)
    finally:
        delete_tmp_dir(tmp)


def convert_function(args_var):
    '''
    Function: run amct convert model process
    Arguments:
        args_var: the parsed arguments to run calibration
    Return: None
    '''
    tmp = tmp_dir()
    record_file = os.path.join(tmp, 'record.txt')
    try:
        amct.convert_qat_model(
            model_file=args_var.model,
            save_path=args_var.save_path,
            record_file=record_file)
    finally:
        delete_tmp_dir(tmp)


def check_dmq_balancer(graph, config_file):
    quant_config, _ = Configuration.parse_quant_config(config_file, graph)
    dmq_balancer_enable = False
    for key, _ in quant_config.items():
        if not isinstance(quant_config[key], dict):
            continue
        if quant_config[key].get("dmq_balancer_param"):
            dmq_balancer_enable = True
            break
    return dmq_balancer_enable


def main():
    '''
    Function: main function for amct_onnx command line tools.
    '''
    args = parser_args.ParserArgs()
    args_var = args.parse_args()

    if args_var.command == 'calibration':
        calibration_function(args_var)
    elif args_var.command == 'convert':
        convert_function(args_var)


if __name__ == '__main__':
    main()
