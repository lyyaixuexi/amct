#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

amct_onnx command line tool user arguments parsing class.

"""

import argparse

import amct_onnx.common.cmd_line_utils.arguments_handler as args_handler


class ParserArgs:
    """
    Function: argument parser class for amct_onnx command line tool.
    interface:
        parse_args: parse the user arguments.
    """
    def __init__(self):
        # create the top-level parser
        self.parser = argparse.ArgumentParser(description='amct_onnx command line tools.',
            formatter_class=args_handler.AMCTHelpFormatter)
        self.subparsers = self.parser.add_subparsers(required=True, dest='command', metavar='command',
            help='The command option for amct_onnx specifies the function to be executed,'
            ' which can be either of calibration or convert.')

        # create the parser for calibration mode
        self._add_calibration_paser()
        # create the parser for convert_model mode
        self._get_convert_model_paser()
        self.args_var = None

    def parse_args(self):
        """
        Function: Parse the user arguments.
        """
        self.args_var = self.parser.parse_args()
        return self.args_var

    def _add_calibration_paser(self):
        '''
        Function: Add calibration arguments if the calibration option is set.
        '''
        calibration_parser = self.subparsers.add_parser(
            'calibration', formatter_class=args_handler.AMCTHelpFormatter,
            help='Run calibration-based Post-training Quantization. '
            'For more detailed usage, please run amct_onnx calibration --help.')
        required_group = calibration_parser.add_argument_group('required arguments')
        optional_group = calibration_parser.add_argument_group('optional arguments')

        args_handler.Model(required_group)
        args_handler.SavePath(required_group)

        args_handler.InputsShapes(optional_group)
        args_handler.DataPaths(optional_group)
        args_handler.DataTypes(optional_group)

        args_handler.EvaluatorPath(optional_group)
        args_handler.ConfigFilePath(optional_group)
        args_handler.BatchNum(optional_group)


    def _get_convert_model_paser(self):
        '''
        Function: Add convert model arguments if the convert option is set.
        '''
        convert_parser = self.subparsers.add_parser(
            'convert', formatter_class=args_handler.AMCTHelpFormatter,
            help='Convert ONNX QAT model to Ascend quantized model. '
            'For more detailed usage, please run amct_onnx convert --help.')
        required_group = convert_parser.add_argument_group('required arguments')

        args_handler.Model(required_group)
        args_handler.SavePath(required_group)
