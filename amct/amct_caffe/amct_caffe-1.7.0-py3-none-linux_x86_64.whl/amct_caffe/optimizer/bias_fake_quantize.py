#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Fake Quantize bias to int32->float32.

"""
import numpy as np
from google.protobuf import text_format
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.optimizer.bias_quantize import BiasQuantizePass
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.configuration.retrain_config import RetrainConfig
from amct_caffe.configuration.check import GraphChecker
from amct_caffe.utils.log import LOGGER


class BiasFakeQuantizePass(BaseFusionPass):
    """
    Function: the pass to quantize pass.
    APIs: set_up, match_pattern, do_pass
    """
    def __init__(self, retrain=False):
        BaseFusionPass.__init__(self)
        self.records = caffe_pb2.ScaleOffsetRecord()
        if retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()

    def set_up(self):
        """
        Function: read the node's scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        record_file_path = self.conf.get_record_file_path()
        with open(record_file_path, 'r') as record_file:
            pbtxt_string = record_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def match_pattern(self, node):
        """
        Function: Find the layer's bias need to be fake_quantize.
        Inputs:
            node: the node to be matched.
        Returns: None
        """
        # match type and config
        if node.type != 'LSTMQuant' and \
            not GraphChecker.check_quantize_type(node):
            return False

        if node.name not in self.conf.get_quant_config():
            return False
        # match bias_blob
        if len(node.get_all_data()) < 2:
            return False

        return True

    def do_pass(self, graph, object_node):
        """
        Function: do bias fake_quantize operation.
        Inputs:
            graph: IR Graph, the graph to be quantized.
            object_node: matched node
        Returns: None
        """
        # find fake_bias_blob
        if len(object_node.get_all_data()) >= 2:
            bias_blob = object_node.get_data(1)
        else:
            raise RuntimeError('Cannot find bias in layer:{}'.format(
                object_node.name))
        # get bias' information and clear blob
        if bias_blob.int32_data:
            quantized_data = np.array(bias_blob.int32_data, np.float32)
        else:
            raise RuntimeError('Get bias data from layer {} failed.'.format(
                object_node.name))
        # read information for quantization
        scale_d, scale_w = BiasQuantizePass.get_scale_for_bias_quantize(
            self.records, object_node, quantized_data.size)
        if len(scale_w) != 1 and quantized_data.size != len(scale_w):
            raise RuntimeError("The scale_w's length[{}] cannot match bias' " \
                "length[{}].".format(len(scale_w), quantized_data.size))
        deq_scale = [item * scale_d for item in scale_w]

        # quantize the bias to range of int32
        if len(deq_scale) == 1:
            dequantized_bias = [bias * deq_scale[0] \
                for bias in quantized_data]
        else:
            dequantized_bias = [quantized_data[index] * deq_scale[index] \
                for index in range(len(deq_scale))]

        # save quant_bias in blob
        bias_blob.ClearField('int32_data')
        bias_blob.data.MergeFrom(dequantized_bias)

        LOGGER.logd('Do layer:\'{}\' bias fake_quantize success!'\
                    .format(object_node.name), 'BiasFakeQuantizePass')
