#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Check record scale and offset file.

"""
from google.protobuf import text_format
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.configuration.retrain_config import RetrainConfig
from amct_caffe.configuration.init_config_from_record import check_record_key
from amct_caffe.utils.log import LOGGER


class CheckRecordScaleOffsetPass(BaseFusionPass):
    """
    Function: the pass to check record scale and offset file.
    APIs: set_up, set_save_type, match_pattern
    """
    def __init__(self, retrain=False):
        BaseFusionPass.__init__(self)
        self.save_type = None
        self.records = caffe_pb2.ScaleOffsetRecord()
        if retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()

    def run(self, graph):
        record_file = self.conf.get_record_file_path()
        if not self._check_kernel(record_file, graph):
            LOGGER.loge('Check scale and offset record file {} failed'.format(
                record_file))
            LOGGER.loge('There may be something wrong while doing calibration')
            LOGGER.loge('Please check caffe log')
            raise RuntimeError('Check file {} failed.'.format(record_file))

        LOGGER.logi('Check record file:{} success!'.format(record_file))

    def _check_kernel(self, record_file, graph):
        with open(record_file, 'r') as read_file:
            pbtxt_string = read_file.read()
            text_format.Merge(pbtxt_string, self.records)
        if not self.records.record:
            LOGGER.loge('Cannot find record in records file: {}'.format(
                record_file))
            return False
        for record in self.records.record:
            if not record.HasField('key'):
                LOGGER.loge('Cannot find "key" in record file')
                return False

            matched, target_node, _ = check_record_key(record.key, graph)
            if not matched:
                return False
            if not record.HasField('value'):
                LOGGER.loge('Cannot find "value" in record file of {}'.format(
                    record.key))
                return False

            def _check_record(key, record_value):
                """Check record value must have scale_d, offset_d,
                   scale_w, offset_w
                """
                check_content = [record_value.HasField('scale_d'),
                                 record_value.HasField('offset_d'),
                                 record_value.scale_w,
                                 record_value.offset_w]

                check_dict = {0: 'scale_d', 1: 'offset_d',
                              2: 'scale_w', 3: 'offset_w'}
                check_list = [check_dict.get(i) for i in range(len(check_dict)) if not check_content[i]]
                if check_list:
                    LOGGER.loge('Cannot find {} of layer:{}'.format(
                        ','.join(check_list), key))
                    return False
                return True
            if target_node.name in self.conf.get_quant_config():
                if not _check_record(record.key, record.value):
                    return False
        return True
