#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

init file for optimizer module

"""
from .graph_optimizer import GraphOptimizer
from .base_fusion_pass import BaseFusionPass
from .check_bn_state_pass import CheckBNStatePass
from .scale_conv_fusion_pass import ScaleConvFusionPass
from .bn_conv_fusion_pass import BnConvFusionPass
from .conv_bn_fusion_pass import ConvBnFusionPass
from .conv_scale_fusion_pass import ConvScaleFusionPass
from .fc_bn_fusion_pass import FcBnFusionPass
from .fc_scale_fusion_pass import FcScaleFusionPass
from .eltwise_opt_weights_calibration import EltwiseOptWeightsCalibrationPass
from .weights_calibration import WeightsCalibrationPass
from .lstm_weights_calibration import LstmWeightsCalibrationPass
from .insert_dequant_layer import InsertDeQuantLayerPass
from .eltwise_opt_insert_act_cali_layer import EltwiseOptInsertActCaliLayerPass
from .insert_act_calibration_layer import InsertActCalibrationLayerPass
from .lstm_calibration_replace import LSTMCalibrationReplacePass
from .eltwise_opt_insert_searchn_layer import EltwiseOptInsertSearchNLayerPass
from .insert_searchn_layer import InsertSearchNLayerPass
from .insert_retrain_layer import InsertRetrainLayersPass
from .retrain_insert_searchn_layer import RetrainInsertSearchNLayerPass
from .check_record_scale_offset import CheckRecordScaleOffsetPass
from .delete_bypass_layer import DeleteBypassLayerPass
from .delete_retrain_layer import DeleteRetrainLayersPass
from .insert_quant_layer import InsertQuantLayerPass
from .lstm_insert_quant_layer import LstmInsertQuantLayerPass
from .mult_output_with_quant_optimizer import MultQuantOptimizerPass
from .quant_fusion_pass import QuantFusionPass
from .record_scale_offset import RecordScaleOffsetPass
from .lstm_record_scale_offset import LstmRecordScaleOffsetPass
from .weights_quantize import WeightsQuantizePass
from .lstm_weights_quantize import LstmWeightsQuantizePass
from .bias_quantize import BiasQuantizePass
from .gen_fusion_json import GenFusionJsonPass
from .lstm_weights_fake_quantize import LstmWeightsFakeQuantizePass
from .weights_fake_quantize import WeightsFakeQuantizePass
from .bias_fake_quantize import BiasFakeQuantizePass
from .reflash_top_name_pass import ReflashTopNamePass
from .concat_joint_quant_optimize_pass import ConcatJointQuantOptiPass

__all__ = [
    'GraphOptimizer',
    'BaseFusionPass',
    'CheckBNStatePass',
    'ScaleConvFusionPass',
    'BnConvFusionPass',
    'ConvBnFusionPass',
    'ConvScaleFusionPass',
    'FcBnFusionPass',
    'FcScaleFusionPass',
    'EltwiseOptWeightsCalibrationPass',
    'WeightsCalibrationPass',
    'LstmWeightsCalibrationPass',
    'InsertDeQuantLayerPass',
    'EltwiseOptInsertActCaliLayerPass',
    'InsertActCalibrationLayerPass',
    'LSTMCalibrationReplacePass',
    'EltwiseOptInsertSearchNLayerPass',
    'InsertSearchNLayerPass',
    'InsertRetrainLayersPass',
    'RetrainInsertSearchNLayerPass',
    'CheckRecordScaleOffsetPass',
    'DeleteBypassLayerPass',
    'DeleteRetrainLayersPass',
    'InsertQuantLayerPass',
    'LstmInsertQuantLayerPass',
    'MultQuantOptimizerPass',
    'QuantFusionPass',
    'RecordScaleOffsetPass',
    'LstmRecordScaleOffsetPass',
    'WeightsQuantizePass',
    'LstmWeightsQuantizePass',
    'BiasQuantizePass',
    'GenFusionJsonPass',
    'LstmWeightsFakeQuantizePass',
    'WeightsFakeQuantizePass',
    'BiasFakeQuantizePass',
    'ReflashTopNamePass',
    'ConcatJointQuantOptiPass',
]
