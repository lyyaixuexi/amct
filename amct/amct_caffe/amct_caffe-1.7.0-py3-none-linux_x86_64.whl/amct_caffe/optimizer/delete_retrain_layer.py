#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert quant layer before layer to be quantized

"""
from google.protobuf import text_format
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error
from amct_caffe.utils.log import LOGGER
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.retrain_config import RetrainConfig
from amct_caffe.common.utils.record_file_operator import \
        record_activation_scale_offset

NUM_BIT = 8
EPS = 1e-6


class DeleteRetrainLayersPass(BaseFusionPass):
    """
    Function: Insert quant layer before layer to be quantized
    APIs: match_pattern, do_fusion
    """
    def __init__(self):
        """
        Function: Init InsertQuantLayerPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = caffe_pb2.ScaleOffsetRecord()
        self.record_file_path = RetrainConfig.get_record_file_path()

    @staticmethod
    def _get_blob_data(blob):
        if blob.data:
            return blob.data
        if blob.double_data:
            return blob.double_data
        raise RuntimeError("No data in blob")

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, 'r') as record_read_file:
            pbtxt_string = record_read_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def tear_down(self):
        """
        Function: write the scale and offset to Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, "w") as record_write_file:
            record_write_file.write(text_format.MessageToString(
                self.records, as_utf8=True))

    def match_pattern(self, node):
        """
        Function: Find 'Convolution' or 'InnerProduct' node need to quantized
                  in graph
        Parameters: node: node in graph
        Return: True: node that need to insert quant layer
                False: skip the node
        """

        if node.type in ('ActivationQAT', 'WeightQAT',
                         'RecordQuantizeFactor', 'RetrainSearchN'):
            LOGGER.logd('match layer: {}'.format(node.name),
                        'DeleteRetrainLayers')
            return True
        return False

    def do_pass(self, graph, object_node):
        """
        Function: Do actual insert quant layer operation.
        Parameters: graph: graph that contains object node
                    object_node: index of object node
        Return: None
        """
        LOGGER.logd('handle layer: {}'.format(object_node.name),
                    'DeleteRetrainLayers')
        if object_node.type == 'ActivationQAT':
            self._handle_act_qat(object_node)

        peer_output_anchor = object_node.get_input_anchor(0).\
                get_peer_output_anchor()
        peer_node = peer_output_anchor.node

        peer_output_anchor_index = peer_output_anchor.index
        graph.remove_edge(peer_node, peer_output_anchor_index,
                          object_node, 0)

        if object_node.output_anchors:
            output_peer_anchor = object_node.get_output_anchor(0)
            peer_input_anchor_indexes = []
            output_peer_nodes = []
            peer_input_anchors = output_peer_anchor.get_peer_input_anchor()
            for peer_input_anchor in peer_input_anchors:
                output_peer_node = peer_input_anchor.node
                peer_input_anchor_indexes.append(peer_input_anchor.index)
                output_peer_nodes.append(output_peer_node)

            i = 0
            for peer_input_anchor_index in peer_input_anchor_indexes:
                output_peer_node = output_peer_nodes[i]
                graph.remove_edge(object_node, 0,
                                  output_peer_node,
                                  peer_input_anchor_index)

                # connect layer
                graph.add_edge(
                    peer_node,
                    peer_output_anchor_index,
                    output_peer_node,
                    peer_input_anchor_index)
                i = i + 1

        graph.remove_node(object_node.name)
        LOGGER.logd("Delete node '{}'success!".format(
            object_node.name), 'DeleteRetrainLayer')

    def _handle_act_qat(self, object_node):
        name = object_node.name
        suffix_len = len('activation_qat_layer')
        clip_min_blob = object_node.get_data(1)
        clip_max_blob = object_node.get_data(0)
        clip_min = self._get_blob_data(clip_min_blob)[0]
        clip_max = self._get_blob_data(clip_max_blob)[0]
        node_keys = name[: len(name) - suffix_len - 1].split('-')
        clip_max = max(clip_max, 0)
        clip_min = min(clip_min, 0)
        scale_d = (clip_max - clip_min) / float(pow(2, NUM_BIT) - 1) + EPS
        offset_d = -round(clip_min / scale_d) - pow(2, NUM_BIT-1)
        for node_key in node_keys:
            record_activation_scale_offset(
                self.records,
                node_key,
                scale_d,
                offset_d)
