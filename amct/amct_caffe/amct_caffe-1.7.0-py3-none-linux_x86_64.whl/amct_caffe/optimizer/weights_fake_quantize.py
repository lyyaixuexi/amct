#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Fake Quantize bias to int32->float32.

"""
import numpy as np
from google.protobuf import text_format
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.configuration.retrain_config import RetrainConfig
from amct_caffe.utils.weight_quant_api import get_weights_blob_info
from amct_caffe.common.utils.record_file_operator import \
    read_weights_scale_offset
from amct_caffe.configuration.check import GraphChecker
from amct_caffe.utils.log import LOGGER

from amct_caffe.optimizer.weights_calibration import SKIP_LAYER_TYPES


class WeightsFakeQuantizePass(BaseFusionPass):
    """
    Function: the pass to quantize pass.
    APIs: set_up, match_pattern, do_pass
    """
    def __init__(self, is_retrain=False):
        BaseFusionPass.__init__(self)
        self.records = caffe_pb2.ScaleOffsetRecord()
        if is_retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()

    def set_up(self):
        """
        Function: read the node's scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        record_file_path = self.conf.get_record_file_path()
        with open(record_file_path, 'r') as record_file:
            pbtxt_string = record_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def match_pattern(self, node):
        """
        Function: Find the layer's weights need to be fake_quantize.
        Inputs:
            node: the node to be matched.
        Returns: None
        """
        # match type and config
        if node.type in SKIP_LAYER_TYPES:
            return False
        if not GraphChecker.check_quantize_type(node) or \
            node.name not in self.conf.get_quant_config():
            return False
        if node.type == 'Pooling':
            return False

        return True

    def do_pass(self, graph, object_node):
        """
        Function: do weights fake_quantize operation.
        Inputs:
            graph: IR Graph, the graph to be quantized.
            object_node: matched node
        Returns: None
        """
        # find fake_bias_blob
        weights_blob, weights_shape, weights_dtype, weights_data = \
            get_weights_blob_info(object_node, 0, True)

        if weights_dtype == 'int8':
            quantized_data = np.frombuffer(weights_data, np.int8).reshape(
                weights_shape)
        else:
            raise RuntimeError('Get quantize weights data from layer {} '\
                'failed.'.format(object_node.name))

        # read information for quantization
        scale_w, offset_w = read_weights_scale_offset(
            self.records, object_node.name)
        if len(scale_w) != len(offset_w):
            raise RuntimeError('{} scale_w length:{} not equal to ' \
                'offset_w length:{}'.format( \
                object_node.name, len(scale_w), len(offset_w)))

        if object_node.type == 'Deconvolution':
            quantized_data = quantized_data.transpose((1, 0, 2, 3))
            group_size = object_node.proto.convolution_param.group
            if group_size > 1:
                if len(scale_w) % group_size != 0:
                    raise RuntimeError('In group "Deconvolution", scale_w must can be exact divided by group')
                per_channel_length = len(scale_w) // group_size
                scale_w = scale_w[: per_channel_length]
                offset_w = offset_w[: per_channel_length]

        if len(scale_w) != 1 and len(scale_w) != quantized_data.shape[0]:
            raise RuntimeError('If channel_wise, length of quantize ' \
                'parameter {} should equal to channel out {}'.format( \
                len(scale_w), quantized_data.shape[0]))

        def _fake_quant_kernel(quantized_data, scale_w, offset_w):
            """Dequantize int8 data to float32
            """
            scale_w = np.array(scale_w, np.float32).reshape((-1, 1, 1, 1))
            offset_w = np.array(offset_w, np.float32).reshape((-1, 1, 1, 1))

            dequantized_data = \
                (quantized_data.astype(np.float32) - offset_w) * scale_w
            return dequantized_data

        dequantized_data = _fake_quant_kernel(quantized_data,
                                              scale_w, offset_w)

        if object_node.type == 'Deconvolution':
            dequantized_data = dequantized_data.transpose((1, 0, 2, 3))

        # write dequantied data back
        weights_blob.data.MergeFrom(dequantized_data.flatten())

        LOGGER.logd('Do layer:\'{}\' weights fake_quantize success!'\
                    .format(object_node.name), 'WeightsFakeQuantizePass')
