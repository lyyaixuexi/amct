#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Delete bypass layers in graph

"""
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.utils.log import LOGGER

_MODULE_NAME = 'DeleteBypassLayer'


class DeleteBypassLayerPass(BaseFusionPass):
    """
    Function: Delete bypass layers in graph
    APIs: match_pattern, do_pass
    """
    def __init__(self, types):
        """
        Function: Init object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self._types = types

    def match_pattern(self, node):
        """
        Function: Find node to delete in graph
        Parameters: node: node in graph
        Return: True: node that need to be deleted
                False: skip the node
        """
        if node.type not in self._types:
            return False
        return True

    def do_pass(self, graph, object_node):
        """
        Function: Do actual delete ifmr layer operation.
        Parameters: graph: graph that contains object node
                    object_node: node to process
        Return: None
        """
        input_anchors = object_node.input_anchors

        for input_anchor in input_anchors:
            peer_output_anchor = input_anchor.get_peer_output_anchor()
            peer_node = peer_output_anchor.node
            peer_output_anchor_index = peer_output_anchor.index
            graph.remove_edge(peer_node, peer_output_anchor_index,
                              object_node, input_anchor.index)

        graph.remove_node(object_node.name)
        LOGGER.logd("Delete layer '{}'(type '{}') success!".format(
            object_node.name, object_node.type), _MODULE_NAME)
