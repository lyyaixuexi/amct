#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert retrain_search_n layer behind the layers to be quantized

"""
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.configuration.check import GraphChecker
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.retrain_config import RetrainConfig
from amct_caffe.optimizer.conv_scale_fusion_pass import ConvScaleFusionPass
from amct_caffe.configuration.init_config_from_record import \
    get_shape_from_pooling_layer


class RetrainInsertSearchNLayerPass(BaseFusionPass):
    """
    Function: Insert search_n layer behind the layer to be quantized
    APIs: match_pattern, do_pass
    """
    def __init__(self):
        """
        Function: Init RetrainInsertSearchNLayerPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    @staticmethod
    def match_pattern(node):
        """
        Function: Find node need to insert RetrainSearchN
                  layer in graph
        Parameters: node: node in graph
        Return: True: node that need to insert search_n layer
                False: skip the node
        """
        # match type
        if node.type == 'LSTM':
            return False
        if not GraphChecker.check_quantize_type(node):
            return False
        # match config
        if node.name not in RetrainConfig().get_quant_config():
            return False
        return True

    @staticmethod
    def _weights_qat_subprocess(producer, params):
        """Subprocess when direct with WeightQAT"""
        params[2] = producer.proto.param[0].name
        grand_input_anchor = producer.get_input_anchor(0)
        grand_producer = grand_input_anchor.get_peer_output_anchor().node
        if grand_producer.type != 'ActivationQAT':
            raise TypeError('Producer of {}[{}] must be "ActivationQAT",' \
                ' but is {}[{}]'.format(producer.name, producer.type, \
                grand_producer.name, grand_producer.type))
        if not grand_producer.proto.param:
            clip_max = grand_producer.proto.param.add()
            clip_max.name = '%s_clip_max' % (grand_producer.name)
            clip_min = grand_producer.proto.param.add()
            clip_min.name = '%s_clip_min' % (grand_producer.name)
        else:
            grand_producer.proto.param[0].name = \
                '%s_clip_max' % (grand_producer.name)
            grand_producer.proto.param[1].name = \
                '%s_clip_min' % (grand_producer.name)
        params[0] = grand_producer.proto.param[0].name
        params[1] = grand_producer.proto.param[1].name

    @staticmethod
    def _activation_qat_subprocess(producer, params):
        """Subprocess when direct with ActivationQAT"""
        if not producer.proto.param:
            clip_max = producer.proto.param.add()
            clip_max.name = '%s_clip_max' % (producer.name)
            clip_min = producer.proto.param.add()
            clip_min.name = '%s_clip_min' % (producer.name)
        else:
            producer.proto.param[0].name = '%s_clip_max' % (producer.name)
            producer.proto.param[1].name = '%s_clip_min' % (producer.name)
        params[0] = producer.proto.param[0].name
        params[1] = producer.proto.param[1].name

    @staticmethod
    def _bn_scale_node_subprocess(bn_node, scale_node, params):
        """If with BatchNorm or Scale, process share weights and record"""
        if bn_node is not None:
            bn_layer = bn_node.proto
            if not bn_layer.param:
                mean = bn_layer.param.add()
                mean.name = '%s_mean' % (bn_node.name)
            else:
                bn_layer.param[0].name = '%s_mean' % (bn_node.name)

            if len(bn_layer.param) < 2:
                variance = bn_layer.param.add()
                variance.name = '%s_variance' % (bn_node.name)
            else:
                bn_layer.param[1].name = '%s_variance' % (bn_node.name)

            if len(bn_layer.param) < 3:
                scale_factor = bn_layer.param.add()
                scale_factor.name = '%s_scale_factor' % (bn_node.name)
            else:
                bn_layer.param[2].name = '%s_scale_factor' % (bn_node.name)

            params[len(params)] = bn_layer.param[1].name
            params[len(params)] = bn_layer.param[2].name

        if scale_node is not None:
            scale_layer = scale_node.proto
            if not scale_layer.param:
                scale = scale_layer.param.add()
                scale.name = '%s_scale' % (scale_node.name)
            else:
                scale_layer.param[0].name = '%s_scale' % (scale_node.name)
            params[len(params)] = scale_layer.param[0].name

    @staticmethod
    def _set_record_search_param(layer_param, object_node,
                                 bn_node, scale_node):
        """Set record_quantize_factor_param for RecordQuantizeFactor"""
        # set record_quantize_factor_param.activation_qat_param
        layer_param.activation_qat_param.object_layer = object_node.name
        layer_param.activation_qat_param.record_file_path = \
            RetrainConfig().get_record_file_path()
        # set record_quantize_factor_param.weights_qat_param
        layer_param.weights_qat_param.channel_wise = \
            RetrainConfig().get_retrain_config(
                object_node.name)['retrain_weight_config']['channel_wise']
        if object_node.type != 'Pooling':
            weights_shape = GraphChecker.get_blob_shape(
                object_node.get_data(0))
        else:
            k_h, k_w = get_shape_from_pooling_layer(object_node.proto)
            weights_shape = [1, 1, k_h, k_w]
        layer_param.weights_qat_param.cout = weights_shape[0]
        layer_param.weights_qat_param.cin = weights_shape[1]
        if len(weights_shape) == 4:
            layer_param.weights_qat_param.h = weights_shape[2]
            layer_param.weights_qat_param.w = weights_shape[3]
        layer_param.weights_qat_param.layer_type = object_node.type
        # set record_quantize_factor_param others
        layer_param.with_batch_norm = bn_node is not None
        layer_param.with_scale = scale_node is not None
        if bn_node is not None:
            layer_param.eps = bn_node.proto.batch_norm_param.eps

    @staticmethod
    def generated_record_node(graph,
                              object_node,
                              output_flag,
                              bn_node=None,
                              scale_node=None):
        """Function: Generate RecordQuantizeFactor node according to target
                     node to be quantized.
           Parameters: graph: graph that add RecordQuantizeFactor node to
                       object_node: node that link with RetrainSearchN node
           Return: record_quantize_factor_node: generated RecordQuantizeFactor
                                                node
        """
        # Get Activation QAT and Weights QAT node of object_node
        input_anchor = object_node.get_input_anchor(0)
        producer = input_anchor.get_peer_output_anchor().node

        # Prepare for share weights
        params = {}
        if producer.type == 'WeightQAT':
            RetrainInsertSearchNLayerPass._weights_qat_subprocess(
                producer, params)
        elif producer.type == 'ActivationQAT':
            if object_node.type != 'Pooling':
                raise TypeError('Producer of {}[{}] cannot be {}[{}]'.format(
                    object_node.name, object_node.type,
                    producer.name, producer.type))
            RetrainInsertSearchNLayerPass._activation_qat_subprocess(
                producer, params)

        RetrainInsertSearchNLayerPass._bn_scale_node_subprocess(
            bn_node, scale_node, params)

        # generate RecordQuantizeFactor layer
        record_quantize_factor_layer = caffe_pb2.LayerParameter()
        record_quantize_factor_layer.name = '%s_record_quantize_factor' % (
            object_node.name)
        record_quantize_factor_layer.type = 'RecordQuantizeFactor'
        record_quantize_factor_layer.bottom[:] = ['%s_input0' % (
            record_quantize_factor_layer.name)]
        record_quantize_factor_layer.top[:] = ['%s_input0' % (
            record_quantize_factor_layer.name)]
        params_length = len(params)
        for i in range(params_length):
            tmp_param = record_quantize_factor_layer.param.add()
            tmp_param.name = params.get(i)
        RetrainInsertSearchNLayerPass._set_record_search_param(
            record_quantize_factor_layer.record_quantize_factor_param,
            object_node, bn_node, scale_node)

        # Add node of RetrainSearchN to graph
        if scale_node is not None:
            target_node = scale_node
        elif bn_node is not None:
            target_node = bn_node
        else:
            target_node = object_node
        if not output_flag:
            record_quantize_factor_node = graph.add_node(
                record_quantize_factor_layer, -1)
        else:
            record_quantize_factor_node = graph.add_node(
                record_quantize_factor_layer, target_node.index + 1)
        return record_quantize_factor_node

    @staticmethod
    def generate_retrain_search_n_node(graph, nodes, output_flag=False):
        """
        Function: Genereate RetrainSearchN node according to input parameters
        Parameters: graph: graph that add RetrainSearchN node to
                    nodes: nodes to link with RetrainSearchN node
        Return: search_n_node: generated RetrainSearchN node
        """
        if output_flag and len(nodes) != 1:
            raise RuntimeError("When used as output layer, "
                               "Search N node can only has one input node.")

        search_n_layer = caffe_pb2.LayerParameter()

        # Set basic info
        nodes_names = [node.name for node in nodes]
        search_n_layer.name = "{}_{}".format(
            '_'.join(nodes_names), 'search_n_layer')
        search_n_layer.type = 'RetrainSearchN'
        search_n_layer.include.add().phase = caffe_pb2.Phase.TEST
        bottom_names = [node.name for node in nodes]
        search_n_layer.bottom.extend(bottom_names)
        if output_flag:
            search_n_layer.top.extend(bottom_names)

        quant_config = RetrainConfig().get_quant_config()
        search_n_layer.search_n_param.batch_num = quant_config['batch_num']
        search_n_layer.search_n_param.layer_name.extend(nodes_names)

        nodes_types = [node.type for node in nodes]
        search_n_layer.search_n_param.layer_type.extend(nodes_types)
        search_n_layer.search_n_param.record_file_path = \
            RetrainConfig().get_record_file_path()

        # Add node of RetrainSearchN to graph
        search_n_node = graph.add_node(search_n_layer)
        return search_n_node

    @staticmethod
    def _is_output_node(object_node):
        output_anchor = object_node.get_output_anchor(0)
        return not output_anchor.get_peer_input_anchor()

    @staticmethod
    def _clear_inpalce_node(object_node, bn_node, scale_node, output_flag):
        inplace_flag = False
        if scale_node is not None:
            target_node = scale_node
        elif bn_node is not None:
            target_node = bn_node
        else:
            target_node = object_node

        if not output_flag:
            # If not output node, need to identify whether have inplace mode
            out_anchor = target_node.get_output_anchor(0)
            out_name = out_anchor.name
            peer_in_anchors = out_anchor.get_peer_input_anchor()
            for input_anchor in peer_in_anchors:
                peer_node = input_anchor.node
                peer_node_output_anchors = peer_node.output_anchors
                for anchor in peer_node_output_anchors:
                    if anchor.name == out_name:
                        inplace_flag = True
                        anchor.clear_reused_info()
            if inplace_flag:
                if target_node is scale_node and \
                        bn_node.get_output_anchor(0).get_reused_info() is None:
                    bn_node.get_output_anchor(0).set_name(
                        '%s_search_n_no_inplace' % out_name)
                else:
                    object_node.get_output_anchor(0).clear_reused_info()
                    object_node.get_output_anchor(0).set_name(
                        '%s_search_n_no_inplace' % out_name)

    def do_pass(self, graph, object_node):
        """
        Function: Do actual insert search_n layer operation.
        Parameters: graph: graph that contains object node
                    object_node: node to process
        Return: None
        """

        bn_node = None
        scale_node = None
        if object_node.type == 'Convolution' and \
            len(object_node.get_output_anchor(0).get_peer_input_anchor()) == 1:
            output_anchor = object_node.get_output_anchor(0)
            consumer = output_anchor.get_peer_input_anchor()[0].node
            if consumer.type == 'BatchNorm':
                bn_node = consumer
                grand_output_anchor = bn_node.get_output_anchor(0)
                if len(grand_output_anchor.get_peer_input_anchor()) == 1:
                    grand_consumer = \
                        grand_output_anchor.get_peer_input_anchor()[0].node
                    if grand_consumer.type == 'Scale' and \
                        ConvScaleFusionPass.check_matched_scale_layer(
                                grand_consumer):
                        scale_node = grand_consumer
            elif consumer.type == 'Scale' and \
                ConvScaleFusionPass.check_matched_scale_layer(consumer):
                scale_node = consumer

        if scale_node is not None:
            target_node = scale_node
        elif bn_node is not None:
            target_node = bn_node
        else:
            target_node = object_node
        output_flag = self._is_output_node(target_node)

        record_quantize_factor_node = \
            self.generated_record_node(
                graph, object_node, output_flag, bn_node, scale_node)
        search_n_node = self.generate_retrain_search_n_node(
            graph, [object_node], output_flag)

        self._clear_inpalce_node(object_node, bn_node, scale_node, output_flag)

        peer_in_anchors = []
        output_anchor = target_node.get_output_anchor(0)
        for peer_in_anchor in output_anchor.get_peer_input_anchor():
            peer_in_anchors.append(peer_in_anchor)
        for peer_in_anchor in peer_in_anchors:
            # dis-link target_node to its consumer
            graph.remove_edge(
                target_node, 0,
                peer_in_anchor.node, peer_in_anchor.index)
            # add link between record_quantize_factor_node to
            # target_node's consumer
            graph.add_edge(
                record_quantize_factor_node, 0,
                peer_in_anchor.node, peer_in_anchor.index)
        # add link between target_node to record_quantize_factor_node
        graph.add_edge(target_node, 0,
                       record_quantize_factor_node, 0)
        # add link between record_quantize_factor_node to search_n_node
        graph.add_edge(record_quantize_factor_node, 0,
                       search_n_node, 0)
        graph.topologic_sort()
