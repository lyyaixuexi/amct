#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert search_n layer behind the layers to be quantized

"""
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.configuration.check import GraphChecker
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.configuration import Configuration

INSERT_SEARCHN_DONE_FLAG = 'eltwise_opt_insert_n'


class InsertSearchNLayerPass(BaseFusionPass):
    """
    Function: Insert search_n layer behind the layer to be quantized
    APIs: match_pattern, do_pass
    """
    def __init__(self):
        """
        Function: Init InsertSearchNLayerPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    @staticmethod
    def match_pattern(node):
        """
        Function: Find node need to insert SearchN
                  layer in graph
        Parameters: node: node in graph
        Return: True: node that need to insert search_n layer
                False: skip the node
        """
        # match type
        if node.type in ['LSTM']:
            return False
        if not GraphChecker.check_quantize_type(node):
            return False
        # match config
        if node.name not in Configuration().get_quant_config():
            return False
        # eltwise optimization was done before this pass
        if node.has_attr(INSERT_SEARCHN_DONE_FLAG):
            return False
        return True

    @staticmethod
    def generate_search_n_node(graph, nodes, output_flag=False):
        """
        Function: Genereate SearchN node according to input parameters
        Parameters: graph: graph that add SearchN node to
                    nodes: nodes to link with SearchN node
        Return: search_n_node: generated SearchN node
        """
        if output_flag and len(nodes) != 1:
            raise RuntimeError("When used as output layer, "
                               "Search N node can only has one input node.")

        search_n_layer = caffe_pb2.LayerParameter()

        # Set basic info
        nodes_names = [node.name for node in nodes]
        search_n_layer.name = "{}_{}".format(
            '_'.join(nodes_names), 'search_n_layer')
        search_n_layer.type = 'SearchN'

        bottom_names = [node.name for node in nodes]
        search_n_layer.bottom.extend(bottom_names)
        if output_flag:
            search_n_layer.top.extend(bottom_names)

        quant_config = Configuration().get_quant_config()
        search_n_layer.search_n_param.batch_num = quant_config.get('batch_num')
        search_n_layer.search_n_param.layer_name.extend(nodes_names)

        nodes_types = [node.type for node in nodes]
        search_n_layer.search_n_param.layer_type.extend(nodes_types)
        search_n_layer.search_n_param.record_file_path = \
            Configuration().get_record_file_path()

        # Add node of SearchN to graph
        if not output_flag:
            search_n_node = graph.add_node(search_n_layer, -1)
        else:
            search_n_node = graph.add_node(
                search_n_layer, nodes[0].index + 1)
        return search_n_node

    @staticmethod
    def generate_search_n_v2_node(graph, nodes, output_flag=False):
        """
        Function: Genereate SearchNV2 node according to input parameters
        Parameters: graph: graph that add SearchNV2 node to
                    nodes: nodes to link with SearchNV2 node
        Return: search_n_node: generated SearchNV2 node
        """
        if output_flag and len(nodes) != 1:
            raise RuntimeError("When used as output layer, "
                               "SearchNV2 node can only has one input node.")

        search_n_v2_layer = caffe_pb2.LayerParameter()

        # Set basic info
        nodes_names = [node.name for node in nodes]
        search_n_v2_layer.name = "{}_{}".format(
            '_'.join(nodes_names), 'search_n_v2_layer')
        search_n_v2_layer.type = 'SearchNV2'

        bottom_names = [node.name for node in nodes]
        bottom_names.append("{}_scale_d".format(search_n_v2_layer.name))
        search_n_v2_layer.bottom.extend(bottom_names)
        bottom_names.pop()
        if output_flag:
            search_n_v2_layer.top.extend(bottom_names)

        quant_config = Configuration().get_quant_config()
        search_n_v2_layer.search_n_param.batch_num = quant_config.get('batch_num')
        search_n_v2_layer.search_n_param.layer_name.extend(nodes_names)

        nodes_types = [node.type for node in nodes]
        search_n_v2_layer.search_n_param.layer_type.extend(nodes_types)
        search_n_v2_layer.search_n_param.record_file_path = \
            Configuration().get_record_file_path()

        # Add node of SearchN to graph
        if not output_flag:
            search_n_node = graph.add_node(search_n_v2_layer, -1)
        else:
            search_n_node = graph.add_node(
                search_n_v2_layer, nodes[0].index + 1)
        return search_n_node


    @staticmethod
    def _is_output_node(object_node):
        output_anchor = object_node.get_output_anchor(0)
        return not output_anchor.get_peer_input_anchor()

    def do_pass(self, graph, object_node):
        """
        Function: Do actual insert SearchN/SearchNV2 layer operation.
        Parameters: graph: graph that contains object node
                    object_node: node to process
        Return: None
        """
        output_flag = self._is_output_node(object_node)

        inplace_flag = False
        if not output_flag:
            output_anchor = object_node.get_output_anchor(0)
            output_name = output_anchor.name
            peer_input_anchors = output_anchor.get_peer_input_anchor()
            for input_anchor in peer_input_anchors:
                peer_node = input_anchor.node
                peer_node_output_anchors = peer_node.output_anchors
                for anchor in peer_node_output_anchors:
                    if anchor.get_reused_info() is not None or \
                            anchor.name == output_name:
                        inplace_flag = True
                        anchor.clear_reused_info()
            if inplace_flag:
                output_anchor.set_name(output_name + '_search_n_no_inplace')
                output_anchor.clear_reused_info()
        quant_config = Configuration().get_layer_config(object_node.name)
        act_config = quant_config['activation_quant_params']
        # when activation calibration algo is hfmg, use searchNV2
        act_algo = act_config.get('act_algo', 'ifmr')
        if act_algo == 'hfmg':
            search_n_node = self.generate_search_n_v2_node(
                graph, [object_node], output_flag)
            if not object_node.has_attr("act_cali_layer_name"):
                raise ValueError("Cannot find attr act_cali_layer_name in node {}".format(object_node.name))
            act_cali_layer_name = object_node.get_attr("act_cali_layer_name")
            act_cali_node = graph.get_node_by_name(act_cali_layer_name)
            graph.add_edge(object_node, 0, search_n_node, 0)
            graph.add_edge(act_cali_node, 0, search_n_node, 1)
        else:
            search_n_node = self.generate_search_n_node(
                graph, [object_node], output_flag)
            graph.add_edge(object_node, 0, search_n_node, 0)
        if output_flag:
            graph.topologic_sort()
