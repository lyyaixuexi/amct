#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Fake Quantize bias to int32->float32.

"""
import numpy as np
from google.protobuf import text_format
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.common.utils.record_file_operator import \
    read_weights_scale_offset
from amct_caffe.optimizer.lstm_calibration_replace import identify_lstm_state
from amct_caffe.utils.weight_quant_api import get_weights_blob_info
from amct_caffe.utils.log import LOGGER


class LstmWeightsFakeQuantizePass(BaseFusionPass):
    """
    Function: the pass to quantize pass.
    APIs: set_up, match_pattern, do_pass
    """
    def __init__(self):
        BaseFusionPass.__init__(self)
        self.records = caffe_pb2.ScaleOffsetRecord()

    @staticmethod
    def match_pattern(node):
        """
        Function: Find the lstm layer's weights need to be fake_quantize.
        Inputs:
            node: the node to be matched.
        Returns: None
        """
        # match type and config
        if node.type != 'LSTMQuant':
            return False
        if node.name not in Configuration().get_quant_config():
            return False

        return True

    def set_up(self):
        """
        Function: read the node's scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        record_file_path = Configuration().get_record_file_path()
        with open(record_file_path, 'r') as record_file:
            pbtxt_string = record_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def do_pass(self, graph, object_node):
        """
        Function: do lstm layers' weights fake_quantize operation.
        Inputs:
            graph: IR Graph, the graph to be quantized.
            object_node: matched node
        Returns: None
        """
        static_input, _ = identify_lstm_state(object_node)
        # LSTM layer blobs [weights_x, bias, weights_static, weights_h]
        # weights_x contains: weights_x_blob, weights_x_shape,
        #                     weights_x_dtype, weights_x_data
        weights_x = get_weights_blob_info(object_node, 0, True)
        if static_input:
            # weights_s contains: weights_s_blob, weights_s_shape,
            #                     weights_s_dtype, weights_s_data
            weights_s = get_weights_blob_info(object_node, 2, True)
            # weights_h contains: weights_h_blob, weights_h_shape,
            #                     weights_h_dtype, weights_h_data
            weights_h = get_weights_blob_info(object_node, 3, True)
        else:
            weights_h = get_weights_blob_info(object_node, 2, True)

        self._fake_quantize_kernel('{}_X'.format(object_node.name),
                                   weights_x)
        self._fake_quantize_kernel('{}_H'.format(object_node.name),
                                   weights_h)
        if static_input:
            self._fake_quantize_kernel('{}_S'.format(object_node.name),
                                       weights_s)

        LOGGER.logd('Do layer:\'{}\' weights fake_quantize success!'\
                    .format(object_node.name), 'LstmWeightsFakeQuantizePass')

    def _fake_quantize_kernel(self, record_name, weights):
        """Do lstm layers weights fake quantize
        """
        weights_blob = weights[0]
        weights_shape = weights[1]
        weights_dtype = weights[2]
        weights_data = weights[3]

        if weights_dtype != 'int8':
            raise TypeError('Do weights fake quantize must from int8 data.')

        int8_data = np.frombuffer(weights_data, np.int8)
        int8_data = int8_data.reshape(4, 1,
                                      weights_shape[0] // 4, weights_shape[1])

        # Because each weights in lstm combined by 4 fc layer, so it's
        # quantize parameter length should be 4
        scale_w, offset_w = read_weights_scale_offset(
            self.records, record_name)
        if len(scale_w) != 4 or len(offset_w) != 4:
            raise RuntimeError('LSTM layer weights {} should have 4 quantize' \
                ' parameter.'.format(record_name))
        # Do weights fake_quantize
        scale_w = np.array(scale_w, np.float32).reshape((-1, 1, 1, 1))
        offset_w = np.array(offset_w, np.float32).reshape((-1, 1, 1, 1))
        dequantized_data = (int8_data.astype(np.float32) - offset_w) * scale_w

        weights_blob.data.MergeFrom(dequantized_data.flatten())
