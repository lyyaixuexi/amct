#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Convolution + Scale fusion operation

"""
import numpy as np

from amct_caffe.configuration.check import GraphChecker
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.configuration.retrain_config import RetrainConfig
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.utils.log import LOGGER
from amct_caffe.operation.conv_scale_fuse import fuse_conv_scale
from amct_caffe.optimizer.conv_bn_fusion_pass import ConvBnFusionPass
from amct_caffe.optimizer.conv_bn_fusion_pass import adjust_deconv_weight_shape
from amct_caffe.utils.attrs_list import ATTR_NODE_FUSION_INFO
from amct_caffe.utils.attrs_list import ATTR_NODE_OUTPUT_NODE

SUPPORT_TYPES = ['Convolution', 'Deconvolution']


class ConvScaleFusionPass(BaseFusionPass):
    """
    Function: Do "Convolution" layer and "Scale" layer fusion operation
    APIs: match_pattern, do_pass, get_np_array_from_scale
    """
    def __init__(self, retrain=False):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        if retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()

    @staticmethod
    def check_matched_scale_layer(node_scale):
        """Check if scale layer support fusion with conv
        """
        matched = True
        if node_scale.proto.HasField('scale_param'):
            if node_scale.proto.scale_param.HasField('axis'):
                if node_scale.proto.scale_param.axis != 1 and \
                    node_scale.proto.scale_param.axis != -3:
                    matched = False
            if node_scale.proto.scale_param.HasField('num_axes'):
                if node_scale.proto.scale_param.num_axes != 1:
                    matched = False

        return matched

    @staticmethod
    def get_np_array_from_scale(blob_scale, blob_beta):
        """
        Function: Trans scale and beta from caffe_proto.blob to numpy.array
        Parameters: blob_scale: scale that in caffe_proto.blob format
                    blob_beta: beta that in caffe_proto.blob format
        Return: scale_array scale that in numpy.array format
                beta_array: beta that in numpy.array format
        """
        # Get array of scale from blob
        if len(blob_scale.shape.dim) != 1:
            raise RuntimeError('Scale scale\' shape should be 1 dims: N')
        array_scale = None
        if blob_scale.data:
            array_scale = np.array(blob_scale.data, dtype=np.float32)
        elif blob_scale.double_data:
            array_scale = np.array(blob_scale.double_data, dtype=np.float64)
        else:
            raise RuntimeError('Cannot find data in scale blob')
        array_scale.shape = tuple(blob_scale.shape.dim)
        # Get array of beta from blob
        array_beta = None
        if blob_beta is not None:
            if len(blob_beta.shape.dim) != 1:
                raise RuntimeError('Scale beta\' shape should be 1 dims: N')
            if blob_beta.data:
                array_beta = np.array(blob_beta.data, dtype=np.float32)
            elif blob_beta.double_data:
                array_beta = np.array(blob_beta.double_data, dtype=np.float64)
            else:
                raise RuntimeError('Cannot find data in beta blob')
            array_beta.shape = tuple(blob_beta.shape.dim)

        return array_scale, array_beta

    @staticmethod
    def __do_weights_bias_fuison(node_conv, node_scale):
        """
        Function: Do conv+scale weights and bias fuison
        Parameters: node_conv: "Convolution" node
                    node_scale: "Scale" node
        Return: None
        """
        if not node_scale.get_all_data():
            raise RuntimeError('Scale at least should at least have one blobs')
        blob_scale = node_scale.get_data(0)
        blob_beta = None
        if len(node_scale.get_all_data()) == 2:
            blob_beta = node_scale.get_data(1)

        if not node_conv.get_all_data():
            raise RuntimeError('Convolution at least should have one blob')
        conv_weights = node_conv.get_data(0)
        conv_bias = None
        if len(node_conv.get_all_data()) > 1:
            conv_bias = node_conv.get_data(1)

        array_weights, array_bias = \
            ConvBnFusionPass.get_np_array_from_conv(conv_weights, conv_bias)
        array_scale, array_beta = \
            ConvScaleFusionPass.get_np_array_from_scale(blob_scale, blob_beta)

        if node_conv.type == 'Deconvolution':
            array_weights = adjust_deconv_weight_shape(node_conv,
                                                       array_weights)
        fused_weights, fused_bias = \
            fuse_conv_scale(array_weights, array_bias, array_scale, array_beta)
        if node_conv.type == 'Deconvolution':
            fused_weights = adjust_deconv_weight_shape(node_conv,
                                                       fused_weights)
        weights_shape = GraphChecker.get_blob_shape(conv_weights)
        fused_weights.shape = (weights_shape[0] *
                               weights_shape[1] *
                               weights_shape[2] *
                               weights_shape[3])
        if fused_bias is not None:
            if node_conv.type == 'Convolution':
                fused_bias.shape = (weights_shape[0])
            elif node_conv.type == 'Deconvolution':
                fused_bias.shape = (fused_bias.size)

        ConvBnFusionPass.write_fused_weights_bias_back(node_conv, \
            conv_weights, fused_weights, conv_bias, fused_bias)

    def match_pattern(self, node):
        """
        Function: Match pattern of "Convolution" + "Scale" in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type != 'Scale':
            return False
        if len(node.input_anchors) != 1:
            return False

        peer_output_anchor = node.get_input_anchor(0).get_peer_output_anchor()
        peer_node = peer_output_anchor.node
        if peer_node.type not in SUPPORT_TYPES or \
            peer_node.name in self.conf.get_skip_fusion_layers():
            return False
        if len(peer_node.output_anchors) != 1:
            return False
        if len(peer_node.get_output_anchor(0).get_peer_input_anchor()) != 1:
            return False
        return self.check_matched_scale_layer(node)

    def do_pass(self, graph, object_node): # pylint: disable=R0914
        """
        Function: Do actual "Convolution" layer and "Scale" layer
                  fusion operation
        Parameters: graph: graph structure
                    object_node: node to process
        Return: None
        """
        # Step1: remove edge of Scale
        node_scale = object_node
        # remove output links
        if len(node_scale.output_anchors) != 1:
            raise RuntimeError("Scale should only have 1 output, actually " \
                "have {}".format(len(node_scale.output_anchors)))
        scale_peer_input_anchors = node_scale.get_output_anchor(0). \
            get_peer_input_anchor()
        scale_peer_input_nodes = []
        scale_peer_input_indexes = []
        for input_anchor in scale_peer_input_anchors:
            scale_peer_input_nodes.append(input_anchor.node)
            scale_peer_input_indexes.append(input_anchor.index)
        for index in range(len(scale_peer_input_anchors)):
            graph.remove_edge(node_scale, 0, \
                scale_peer_input_nodes[index], \
                scale_peer_input_indexes[index])
        # remove input links
        if len(node_scale.input_anchors) != 1:
            raise RuntimeError("Scale should only have 1 output, actually " \
                "have {}".format(len(node_scale.input_anchors)))
        scale_input_anchor = node_scale.get_input_anchor(0)
        scale_peer_output_anchor = scale_input_anchor.get_peer_output_anchor()
        node_conv = scale_peer_output_anchor.node
        if scale_peer_output_anchor.index != 0:
            raise RuntimeError("Conv or deconv output bn index should be 0, " \
                "actually is {}".format(scale_peer_output_anchor.index))
        graph.remove_edge(node_conv, 0, node_scale, 0)
        # Step2: Add link from conv to scale_peer_input_node
        for index, element in enumerate(scale_peer_input_nodes):
            graph.add_edge(node_conv, 0, element, \
                scale_peer_input_indexes[index])
        # Step3: Do conv + scale weights/bias fusion
        ConvScaleFusionPass.__do_weights_bias_fuison(node_conv, node_scale)
        # Step4: Record fusion info to Conv node
        if not node_conv.has_attr(ATTR_NODE_FUSION_INFO):
            node_conv.set_attr(ATTR_NODE_FUSION_INFO, [node_conv.name])
        scale_name = node_scale.name
        node_conv.get_attr(ATTR_NODE_FUSION_INFO).append(scale_name)
        node_conv.set_attr(ATTR_NODE_OUTPUT_NODE, scale_name)

        # Step5: Set the conv node's output name with scale's output name
        scale_output_name = node_scale.get_output_anchor(0).name
        node_conv.get_output_anchor(0).set_name(scale_output_name)
        # Step6: remove node of bn from graph
        node_scale_name = node_scale.name
        LOGGER.logd("Remove node {} from graph".format(node_scale_name), \
            'ConvScaleFusionPass')
        graph.remove_node(node_scale_name)
        LOGGER.logd('Do conv:\'{}\' + scale:\'{}\' fuison success!'.format(
            node_conv.name, node_scale_name), 'ConvScaleFusionPass')
