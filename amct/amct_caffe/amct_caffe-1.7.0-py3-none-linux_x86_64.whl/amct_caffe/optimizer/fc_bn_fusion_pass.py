#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

InnerProduct + BatchNorm fusion operation

"""
import numpy as np

from amct_caffe.configuration.check import GraphChecker
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.utils.log import LOGGER
from amct_caffe.optimizer.conv_bn_fusion_pass import ConvBnFusionPass
from amct_caffe.operation.conv_bn_fuse import fuse_conv_bn


from amct_caffe.utils.attrs_list import ATTR_NODE_FUSION_INFO
from amct_caffe.utils.attrs_list import ATTR_NODE_OUTPUT_NODE


class FcBnFusionPass(BaseFusionPass):
    """
    Function: Do "InnerProduct" layer and "BatchNorm" layer fusion operation
    APIs: match_pattern, do_pass, get_np_array_from_conv,
          get_np_array_from_bn, write_fused_weights_bias_back
    """
    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    @staticmethod
    def get_np_array_from_fc(blob_weights, blob_bias):
        """
        Function: Trans weights and bias from caffe_proto.blob to numpy.array
        Parameters: blob_weights: weights that in caffe_proto.blob format
                    blob_bias: bias that in caffe_proto.blob format
        Return: weights_array： weights that in numpy.array format
                bias_array: bias that in numpy.array format
        """
        # Get array of weights from blob
        weights_shape = list(GraphChecker.get_blob_shape(blob_weights))
        if len(weights_shape) == 2:
            weights_shape.extend([1, 1])
        if blob_weights.data:
            weights_array = np.array(blob_weights.data, \
                dtype=np.float32).reshape(weights_shape)
        elif blob_weights.double_data:
            weights_array = np.array(blob_weights.double_data,
                                     dtype=np.float64).reshape(weights_shape)
        else:
            raise RuntimeError('Cannot find data in weights blob')
        # Get array of bias from blob
        bias_array = None
        if blob_bias is not None:
            if len(blob_bias.shape.dim) != 1:
                raise RuntimeError("InnerProduct bias\' shape should be " \
                    "1 dims: N")
            if blob_bias.data:
                bias_array = np.array(blob_bias.data, dtype=np.float32)
            elif blob_bias.double_data:
                bias_array = np.array(blob_bias.double_data, dtype=np.float64)
            else:
                raise RuntimeError('Cannot find data in bias blob')

        return weights_array, bias_array

    @staticmethod
    def _do_weights_bias_fuison(node_fc, node_bn):
        """
        Function: Do fc+bn weights and bias fuison
        Parameters: node_fc: "InnerProduct" node
                    node_bn: "BatchNorm" node
        Return: None
        """
        if len(node_bn.get_all_data()) < 3:
            raise RuntimeError('BatchNorm at least should have three blobs')
        epsilon = node_bn.proto.batch_norm_param.eps
        blob_scale_factor = node_bn.get_data(2)
        if len(blob_scale_factor.shape.dim) != 1 or \
            blob_scale_factor.shape.dim[0] != 1:
            raise RuntimeError('BatchNorm scale factor should be one')
        if blob_scale_factor.data:
            scale_factor = blob_scale_factor.data[0]
        else:
            scale_factor = blob_scale_factor.double_data[0]

        if not node_fc.get_all_data():
            raise RuntimeError('InnerProduct at least should have one blob')
        blob_weights = node_fc.get_data(0)
        blob_bias = None
        if len(node_fc.get_all_data()) > 1:
            blob_bias = node_fc.get_data(1)

        weights_array, bias_array = \
            FcBnFusionPass.get_np_array_from_fc(blob_weights, blob_bias)
        mean_array, variance_array = \
            ConvBnFusionPass.get_np_array_from_bn(node_bn.get_data(0),
                                                  node_bn.get_data(1))
        fused_weights, fused_bias = \
            fuse_conv_bn([weights_array, bias_array],
                         [mean_array, variance_array, scale_factor, epsilon])

        ConvBnFusionPass.write_fused_weights_bias_back(node_fc, \
            blob_weights, fused_weights, blob_bias, fused_bias)

    def do_pass(self, graph, object_node):
        """
        Function: Do actual "InnerProduct" layer and "BatchNorm" layer
                  fusion operation
        Parameters: graph: graph structure
                    object_node: node to process
        Return: None
        """
        # Step1: remove edge of BatchNorm
        # remove output links
        if len(object_node.output_anchors) != 1:
            raise RuntimeError("BatchNorm should only have 1 output, " \
                "actually have {}".format( \
                len(object_node.output_anchors)))
        bn_peer_input_anchors = object_node.get_output_anchor(0). \
            get_peer_input_anchor()
        bn_peer_input_nodes = []
        bn_peer_input_indexes = []
        for input_anchor in bn_peer_input_anchors:
            bn_peer_input_nodes.append(input_anchor.node)
            bn_peer_input_indexes.append(input_anchor.index)
        for index, element in enumerate(bn_peer_input_nodes):
            graph.remove_edge(object_node, 0, element,
                              bn_peer_input_indexes[index])
        # remove input links
        bn_input_anchor = object_node.get_input_anchor(0)
        bn_peer_output_anchor = bn_input_anchor.get_peer_output_anchor()
        node_fc = bn_peer_output_anchor.node
        graph.remove_edge(node_fc, 0, object_node, 0)
        # Step3: Add link from conv to bn_peer_input_node
        for index, element in enumerate(bn_peer_input_nodes):
            graph.add_edge(node_fc, 0, element,
                           bn_peer_input_indexes[index])
        # Step4: Do conv + bn weights/bias fusion
        self._do_weights_bias_fuison(node_fc, object_node)
        # Step5: Record fusion info to convolution node
        if not node_fc.has_attr(ATTR_NODE_FUSION_INFO):
            node_fc.set_attr(ATTR_NODE_FUSION_INFO, [node_fc.name])
        node_fc.get_attr(ATTR_NODE_FUSION_INFO).append(
            object_node.name)
        node_fc.set_attr(ATTR_NODE_OUTPUT_NODE, object_node.name)

        # Step6: Set the fc node's output name with scale's output name
        bn_output_name = object_node.get_output_anchor(0).name
        node_fc.get_output_anchor(0).set_name(bn_output_name)

        # Step7: Remove node of bn from graph
        node_bn_name = object_node.name
        LOGGER.logd("Remove node {} from graph".format(node_bn_name), \
            'FcBnFusionPass')
        graph.remove_node(node_bn_name)
        LOGGER.logd('Do fc:"{}" + bn:"{}" fuison success!'.format(
            node_fc.name, object_node.name), 'FcBnFusionPass')

    def match_pattern(self, node):
        """
        Function: Match pattern of "InnerProduct" + "BatchNorm" in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type != 'BatchNorm':
            return False
        if len(node.input_anchors) != 1:
            raise RuntimeError('BatchNorm node should only have 1 output ' \
                'actually have {}'.format(len(node.input_anchors)))
        peer_output_anchor = node.get_input_anchor(0).get_peer_output_anchor()
        peer_node = peer_output_anchor.node
        if peer_node.name in Configuration().get_skip_fusion_layers():
            return False
        if peer_node.type != 'InnerProduct' or \
            len(peer_output_anchor.get_peer_input_anchor()) != 1:
            return False
        if peer_node.proto.inner_product_param.axis != 1 \
                or peer_node.proto.inner_product_param.transpose:
            return False
        return True
