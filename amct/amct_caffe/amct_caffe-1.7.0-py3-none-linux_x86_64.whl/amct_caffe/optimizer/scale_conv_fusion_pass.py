#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Scale + Convolution fusion operation

"""
import numpy as np

from amct_caffe.configuration.configuration import Configuration
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.operation.conv_scale_fuse import fuse_scale_conv
from amct_caffe.optimizer.conv_bn_fusion_pass import ConvBnFusionPass
from amct_caffe.optimizer.conv_scale_fusion_pass import ConvScaleFusionPass
from amct_caffe.utils.log import LOGGER
from amct_caffe.utils.attrs_list import ATTR_NODE_FUSION_INFO
from amct_caffe.utils.attrs_list import ATTR_NODE_OUTPUT_NODE


class ScaleConvFusionPass(BaseFusionPass):
    """
    Function: Do "Scale" layer and "Convolution" layer fusion operation
    APIs: match_pattern, do_pass
    """
    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    @staticmethod
    def match_pattern(node):
        """
        Function: Match pattern of "Scale" + "Convolution" in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type != 'Scale' or len(node.input_anchors) != 1:
            return False

        if len(node.output_anchors) != 1:
            raise RuntimeError('Scale node should only have 1 output ' \
                'actually have {}'.format(len(node.output_anchors)))
        peer_input_anchors = node.get_output_anchor(0).get_peer_input_anchor()
        if len(peer_input_anchors) != 1:
            return False

        # Scale + Convolution fusion only support Convolution without pad
        conv_node = peer_input_anchors[0].node
        if conv_node.type != 'Convolution' or \
            conv_node.name in Configuration().get_skip_fusion_layers():
            return False
        for pad in conv_node.proto.convolution_param.pad:
            if pad > 0:
                return False
        if conv_node.proto.convolution_param.pad_h > 0 or \
           conv_node.proto.convolution_param.pad_w > 0:
            return False

        return ConvScaleFusionPass.check_matched_scale_layer(node)

    @staticmethod
    def _get_per_group_cin_cout(conv_group, scale_shape, weights_shape):
        """Calculate Cout and Cin per group length
        """
        if len(scale_shape) != 1 or scale_shape[0] == 0:
            raise RuntimeError('Scale parameters shape must be vector')
        scale_length = scale_shape[0]
        if scale_length % conv_group != 0:
            raise RuntimeError('Scale length[{}] must be multiple ' \
                'of conv group[{}]'.format(scale_length, conv_group))
        cin_group_length = scale_length / conv_group
        if cin_group_length != weights_shape[1]:
            raise RuntimeError('Each group Scale length[{}] should ' \
                'be equal to conv weights Cin[{}]'.format(cin_group_length, \
                    weights_shape[1]))

        if weights_shape[0] % conv_group != 0:
            raise RuntimeError('Group conv weights Cout[{}] must be ' \
                'multiple of conv group[{}]'.format(weights_shape[0], \
                    conv_group))
        cout_group_length = weights_shape[0] / conv_group

        return int(cout_group_length), int(cin_group_length)

    @staticmethod
    def _do_weights_bias_fuison(node_scale, node_conv):
        """
        Function: Do scale+conv weights and bias fuison
        Parameters: node_scale: "Scale" node
                    node_conv: "Convolution" node
        Return: None
        """

        if not node_conv.get_all_data():
            raise RuntimeError('Convolution at least should have one blob')
        conv_weights = node_conv.get_data(0)
        conv_bias = None
        if len(node_conv.get_all_data()) > 1:
            conv_bias = node_conv.get_data(1)

        if not node_scale.get_all_data():
            raise RuntimeError('Scale at least should at least have one blobs')
        blob_scale = node_scale.get_data(0)
        blob_beta = None
        if len(node_scale.get_all_data()) == 2:
            blob_beta = node_scale.get_data(1)

        array_scale, array_beta = \
            ConvScaleFusionPass.get_np_array_from_scale(blob_scale, blob_beta)
        array_weights, array_bias = \
            ConvBnFusionPass.get_np_array_from_conv(conv_weights, conv_bias)


        def _scale_conv_fusion_kernel(node_conv, array_scale, array_beta,
                                      array_weights, array_bias):
            """Do Scale and Convolution layer parameters fusion.
            """
            conv_group = node_conv.proto.convolution_param.group
            per_cout, per_cin = ScaleConvFusionPass._get_per_group_cin_cout(
                conv_group, array_scale.shape, array_weights.shape)
            fused_weights = np.zeros(array_weights.shape, array_weights.dtype)
            # if wether conv nor scale have bias, there is no fused bias
            fused_bias = None
            if array_beta is not None or array_bias is not None:
                fused_bias = np.zeros(array_weights.shape[0],
                                      array_weights.dtype)

            for i in range(conv_group):
                fuse_param = [None] * 4
                fuse_param[0] = array_weights[i * per_cout:(i + 1) * per_cout,
                                              :, :, :]
                fuse_param[1] = None if array_bias is None else array_bias[i * per_cout:(i + 1) * per_cout]
                fuse_param[2] = array_scale[i * per_cin:(i + 1) * per_cin]
                fuse_param[3] = None if array_beta is None else array_beta[i * per_cin:(i + 1) * per_cin]

                fused_weights[i * per_cout:(i + 1) * per_cout, :, :, :], \
                    per_fused_bias = fuse_scale_conv(fuse_param[0],
                                                     fuse_param[1],
                                                     fuse_param[2],
                                                     fuse_param[3])
                if per_fused_bias is not None and fused_bias is not None:
                    fused_bias[i * per_cout:(i + 1) * per_cout] = \
                        per_fused_bias
            ConvBnFusionPass.write_fused_weights_bias_back(
                node_conv, conv_weights, fused_weights.flatten(),
                conv_bias, fused_bias)

        # Consider conv maybe group conv, to uniform calculate procedure,
        # split scale params and conv params by conv group size
        _scale_conv_fusion_kernel(node_conv, array_scale, array_beta,
                                  array_weights, array_bias)

    def do_pass(self, graph, object_node):
        """
        Function: Do actual "Scale" layer and "Convolution" layer
                  fusion operation
        Parameters: graph: graph structure
                    object_node: node to process
        Return: None
        """
        # Step1: remove edge of Scale
        node_scale = object_node
        # remove output links
        scale_peer_output_anchor = node_scale.get_input_anchor(0). \
            get_peer_output_anchor()
        graph.remove_edge(scale_peer_output_anchor.node,
                          scale_peer_output_anchor.index,
                          node_scale,
                          0)
        # remove output links
        peer_anchors = node_scale.get_output_anchor(0).get_peer_input_anchor()
        node_conv = peer_anchors[0].node
        graph.remove_edge(node_scale, 0,
                          node_conv, 0)
        # Step2: Add link from Scale producer to Convolution
        graph.add_edge(scale_peer_output_anchor.node,
                       scale_peer_output_anchor.index,
                       node_conv,
                       0)
        # Step3: Do conv + scale weights/bias fusion
        self._do_weights_bias_fuison(node_scale, node_conv)
        # Step4: Record fusion info to Conv node
        if not node_conv.has_attr(ATTR_NODE_FUSION_INFO):
            node_conv.set_attr(ATTR_NODE_FUSION_INFO, [node_conv.name])
        node_conv.get_attr(ATTR_NODE_FUSION_INFO).insert(
            0, node_scale.name)
        if not node_conv.has_attr(ATTR_NODE_OUTPUT_NODE):
            node_conv.set_attr(ATTR_NODE_OUTPUT_NODE, node_conv.name)
        # Step5: remove node of bn from graph
        node_scale_name = node_scale.name
        LOGGER.logd("Remove node {} from graph".format(node_scale_name), \
            'ScaleConvFusionPass')
        graph.remove_node(node_scale_name)
        LOGGER.logd('Do scale:\'{}\' + conv:\'{}\' fuison success!'.format(
            node_scale_name, node_conv.name), 'ScaleConvFusionPass')
