#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace orignal LSTM layer to LSTMCalibration layer.
"""
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.configuration.check import GraphChecker
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.utils.log import LOGGER


def identify_lstm_state(node):
    """
    Function: Identify lstm layer state: whether have static input, and whether
              expose hidden
    Parameters: node: lstm layer node to identified
    Return: static_input: True: lstm node have static input
                          False: lstm node have no static input
            expose_hidden: True: lstm expose hidden input
                           False: lstm don't expose hidden input
    """
    if node.type not in ('LSTM', 'LSTMQuant'):
        raise RuntimeError('Only can identify lstm layer state, {} ' \
            'is not supported'.format(node.type))
    if not node.proto.HasField('recurrent_param'):
        raise RuntimeError('LSTM supported must have recurrent_param.')

    input_num = len(node.input_anchors)
    output_num = len(node.output_anchors)
    expose_hidden = node.proto.recurrent_param.expose_hidden

    node_state = '{}_{}_{}'.format(expose_hidden, input_num, output_num)
    lstm_state = {
        'False_2_1': False,
        'False_3_1': True,
        'True_4_3': False,
        'True_5_3': True
    }
    if lstm_state.get(node_state) is None:
        raise RuntimeError('Unsupport lstm state with {} input ' \
            ' {} output and expose_hidden = {}'.format(
                input_num, output_num, expose_hidden))
    return lstm_state.get(node_state), expose_hidden


class LSTMCalibrationReplacePass(BaseFusionPass):
    """
    Function: Replace orignal LSTM layer to LSTMCalibration layer with IFMR and
              SearchN layer inserted
    APIs: match_pattern, do_pass
    """
    def __init__(self):
        """
        Function: Init LSTMCalibrationReplacePass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    @staticmethod
    def match_pattern(node):
        """
        Function: Find LSTM layer need to replace to LSTMCalibration
                  layer in graph
        Parameters: node: node in graph
        Return: True: node that need to replace
                False: skip the node
        """
        # match type
        if node.type != 'LSTM':
            return False
        if not GraphChecker.check_quantize_type(node):
            return False
        # match config
        if node.name not in Configuration().get_quant_config():
            return False
        return True

    @staticmethod
    def _generate_ifmr_param(config_layer_name, object_layers):
        quant_config = Configuration().get_layer_config(config_layer_name)
        act_config = quant_config['activation_quant_params']

        ifmr_param = caffe_pb2.IFMRParameter()
        ifmr_param.batch_num = act_config['batch_num']
        ifmr_param.with_offset = act_config['with_offset']

        ifmr_param.search_range_start = act_config['search_range_start']
        ifmr_param.search_range_end = act_config['search_range_end']
        ifmr_param.search_step = act_config['search_step']
        ifmr_param.max_percentile = act_config['max_percentile']
        ifmr_param.min_percentile = act_config['min_percentile']

        ifmr_param.object_layer[:] = object_layers
        ifmr_param.record_file_path = \
            Configuration().get_record_file_path()
        return ifmr_param

    @staticmethod
    def _generate_search_n_param(config_layer_name, object_layers):
        quant_config = Configuration().get_layer_config(config_layer_name)
        act_config = quant_config['activation_quant_params']

        search_n_param = caffe_pb2.SearchNParameter()
        search_n_param.batch_num = act_config['batch_num']
        search_n_param.layer_name[:] = object_layers
        search_n_param.layer_type[:] = \
            ['LSTM{}'.format(layer[-2:]) for layer in object_layers]
        search_n_param.record_file_path = \
            Configuration().get_record_file_path()
        return search_n_param

    def do_pass(self, graph, object_node):
        """
        Function: Do actual replace to LSTMCalibration.
        Parameters: graph: graph that contains object node
                    object_node: node to process
        Return: None
        """
        static_input, _ = identify_lstm_state(object_node)
        object_node.update_type('LSTMCalibration')
        lstm_layer = object_node.proto

        # Add IFMR to input_x and input_h
        xh_layer_names = ['{}_X'.format(object_node.name),
                          '{}_H'.format(object_node.name)]
        lstm_layer.lstm_calibration_param.ifmr_param.CopyFrom(
            self._generate_ifmr_param(lstm_layer.name, xh_layer_names))
        lstm_layer.lstm_calibration_param.search_n_param.CopyFrom(
            self._generate_search_n_param(lstm_layer.name, \
            xh_layer_names))

        if static_input:
            s_layer_names = ['{}_S'.format(lstm_layer.name)]
            lstm_layer.lstm_calibration_param.static_ifmr_param.CopyFrom(
                self._generate_ifmr_param(lstm_layer.name, s_layer_names))
            lstm_layer.lstm_calibration_param.static_search_n_param. \
                CopyFrom(self._generate_search_n_param(lstm_layer.name, \
                s_layer_names))
        LOGGER.logd('Do replace "{}" to "LSTMCalibration" layer success.' \
            ''.format(object_node.name), 'LSTMCalibrationReplacePass')
