#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quantize weight by calibration.

"""
import numpy as np
from google.protobuf import text_format
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.configuration.retrain_config import RetrainConfig
from amct_caffe.configuration.check import GraphChecker
from amct_caffe.utils.weight_quant_api import get_weights_blob_info
from amct_caffe.utils.weight_quant_api import weight_calibration_blob
from amct_caffe.utils.weight_quant_api import weight_calibration_np
from amct_caffe.utils.weight_quant_api import write_back_weight_blob
from amct_caffe.utils.log import LOGGER
from amct_caffe.utils.dump import Dumper
from amct_caffe.common.utils.record_file_operator import \
    record_weights_scale_offset, read_shift_bits, record_shift_bits
from amct_caffe.configuration.init_config_from_record import \
    get_shape_from_pooling_layer

from amct_caffe.utils.dump import DUMPER_DICT
SKIP_LAYER_TYPES = ['LSTM', 'LSTMQuant', 'LSTMCalibration']
CALIBRATION_DONE_FLAG = 'eltwise_opt_calibration'


class WeightsCalibrationPass(BaseFusionPass):
    """
    Function: the pass to quantize bias by Calibration.
    APIs: set_up, tear_down, match_pattern, do_pass
    """
    def __init__(self, retrain=False):
        BaseFusionPass.__init__(self)
        self.records = caffe_pb2.ScaleOffsetRecord()
        if retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()

        self.record_file_path = self.conf.get_record_file_path()

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, 'r') as record_read_file:
            pbtxt_string = record_read_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def tear_down(self):
        """
        Function: write the scale and offset to Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, "w") as record_write_file:
            record_write_file.write(text_format.MessageToString(
                self.records, as_utf8=True))


    def match_pattern(self, node):
        """
        Function: Find the layer to be quantized.
        Inputs:
            node: the node to be matched.
        Returns: None
        """
        # match type
        if node.name not in self.conf.get_quant_config():
            return False
        if node.type in SKIP_LAYER_TYPES:
            return False
        if not GraphChecker.check_quantize_type(node):
            return False
        # eltwise optimization was done before this pass
        if node.has_attr(CALIBRATION_DONE_FLAG):
            return False
        return True

    def do_pass(self, graph, object_node):
        """
        Function: do quantize operation.
        Inputs:
            graph: IR Graph, the graph to be quantized.
            object_node: node to process
        Returns: None
        """
        # if quantized node is pooling, only calculate scale_w according
        # to it's kernel size
        if object_node.type == 'Pooling':
            offset = [0]
            kernel_h, kernel_w = get_shape_from_pooling_layer(
                object_node.proto)
            scale = [1 / float(kernel_h * kernel_w)]
            record_weights_scale_offset(self.records,
                                        object_node.name,
                                        scale,
                                        offset)
            return
        # find weights_blob
        weights_blob, weights_shape, weights_dtype, weights_data = \
            get_weights_blob_info(object_node)

        DUMPER_DICT['{}_weights'.format(object_node.name)] = \
            Dumper('{}_weights.log'.format(object_node.name))
        DUMPER_DICT.get('{}_weights'.format(object_node.name)).\
            dumpd(['weights before quantize:'])
        DUMPER_DICT.get('{}_weights'.format(object_node.name)).\
            dumpd(weights_data, len(weights_data))

        # get weights' information for quantization
        layer_config = self.conf.get_layer_config(object_node.name)
        wts_param = layer_config.get('weight_quant_params')

        # do weights calibration, if is "Deconvolution", transpose channel out
        # axis to 0
        if object_node.type == 'Deconvolution':
            weights_numpy = np.array(weights_data).reshape(weights_shape)
            weights_numpy = weights_numpy.transpose((1, 0, 2, 3))
            scale, offset = weight_calibration_np(weights_numpy, wts_param)
            weights_numpy = weights_numpy.transpose((1, 0, 2, 3))
            write_back_weight_blob(
                weights_blob, weights_dtype, weights_numpy.flatten())
            if object_node.proto.convolution_param.group > 1:
                scale = scale * object_node.proto.convolution_param.group
                offset = offset * object_node.proto.convolution_param.group
                # align the width of searchn with scale_w
                # because weight cali is later than inference in qat
                if isinstance(self.conf, RetrainConfig):
                    shift_bit = read_shift_bits(self.records, object_node.name)
                    shift_bit = shift_bit * object_node.proto.convolution_param.group
                    record_shift_bits(self.records, object_node.name, shift_bit)
        else:
            scale, offset = weight_calibration_blob(
                weights_blob, weights_shape, weights_dtype, weights_data,
                wts_param)

        # save the quantize information
        record_weights_scale_offset(
            self.records, object_node.name, scale, offset)

        LOGGER.logi('Do layer \'{}[{}]\' weights calibration success!'\
                    .format(object_node.name, wts_param['wts_algo']), \
                    'WeightsCalibrationPass')
