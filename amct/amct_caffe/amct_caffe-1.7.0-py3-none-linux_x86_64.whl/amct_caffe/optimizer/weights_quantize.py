#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quantize weight to int8.


"""
from google.protobuf import text_format
import numpy as np

try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.configuration.retrain_config import RetrainConfig
from amct_caffe.configuration.check import GraphChecker
from amct_caffe.utils.log import LOGGER
from amct_caffe.utils.dump import Dumper
from amct_caffe.utils.dump import DUMPER_DICT
from amct_caffe.common.utils.record_file_operator import \
    read_weights_scale_offset
from amct_caffe.utils.weight_quant_api import weights_quantize_np
from amct_caffe.utils.weight_quant_api import weights_quantize_blob
from amct_caffe.utils.weight_quant_api import get_weights_blob_info

from amct_caffe.optimizer.weights_calibration import SKIP_LAYER_TYPES
MAX_QUANT_VALUE = 127
MIN_QUANT_VALUE = -128


class WeightsQuantizePass(BaseFusionPass):
    """
    Function: the pass to quantize bias.
    APIs: set_up, match_pattern, do_pass
    """
    def __init__(self, is_retrain=False):
        BaseFusionPass.__init__(self)
        if is_retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()
        self.records = caffe_pb2.ScaleOffsetRecord()

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.conf.get_record_file_path(), 'r') as record_file:
            pbtxt_string = record_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def do_pass(self, graph, object_node):
        """
        Function: do quantize operation.
        Inputs:
            graph: IR Graph, the graph to be quantized.
            object_node: node to process
        Returns: None
        """
        # find weights_blob
        weights_blob, weights_shape, _, weights_data = \
            get_weights_blob_info(object_node, is_clear=True)

        # get weights' information for quantization
        layer_config = self.conf.get_layer_config(object_node.name)
        wts_param = layer_config.get('weight_quant_params')
        num_bits = wts_param['num_bits']
        scale_w, offset_w = read_weights_scale_offset(self.records,
                                                      object_node.name)
        # quantize weights to int8
        if object_node.type == 'Deconvolution':
            weights_numpy = np.array(weights_data).reshape(weights_shape)
            weights_numpy = weights_numpy.transpose((1, 0, 2, 3))
            int8_data = weights_quantize_np(weights_numpy, scale_w,
                                            offset_w, num_bits)
            int8_data = int8_data.transpose((1, 0, 2, 3)).flatten()
            weights_blob.int8_data = bytes(int8_data)
        else:
            weights_blob.int8_data = weights_quantize_blob(
                weights_data, scale_w, offset_w, num_bits)

        # Do quantized weights dump
        dumper_name = '{}_weights'.format(object_node.name)
        if dumper_name not in DUMPER_DICT:
            DUMPER_DICT[dumper_name] = Dumper('{}.log'.format(dumper_name))
        int8_data = np.frombuffer(weights_blob.int8_data, np.int8)
        DUMPER_DICT[dumper_name].dumpd(['weights after quantize:'])
        DUMPER_DICT[dumper_name].dumpd(int8_data.tolist(), int8_data.shape[0])
        LOGGER.logd('Do layer:\'{}\' weights quantize success!'\
                    .format(object_node.name), 'WeightsQuantizePass')

    def match_pattern(self, node):
        """
        Function: Find the layer to be quantized.
        Inputs:
            node: the node to be matched.
        Returns: None
        """
        # match type
        if node.type in SKIP_LAYER_TYPES:
            return False
        if node.type == 'Pooling':
            return False
        if not GraphChecker.check_quantize_type(node):
            return False
        # match config
        if node.name not in self.conf.get_quant_config():
            return False

        return True
