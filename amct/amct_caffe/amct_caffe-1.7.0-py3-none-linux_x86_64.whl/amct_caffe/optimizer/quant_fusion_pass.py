#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Fusion quant_layers that from same input and have same scale and offset

"""
import numpy as np
from google.protobuf import text_format

try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.utils.log import LOGGER
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.configuration.retrain_config import RetrainConfig
from amct_caffe.common.utils.record_file_operator import \
    read_activation_scale_offset
from amct_caffe.utils.attrs_list import ATTR_NODE_EQUIVALENT_OBJECT_LAYER


class QuantFusionPass(BaseFusionPass):
    """
    Function: Fusion quant_layers that from same input and have
              same scale and offset
    APIs: match_pattern, do_pass
    """
    def __init__(self, retrain=False):
        """
        Function: Init QuantFusionPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = caffe_pb2.ScaleOffsetRecord()
        if retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()

    @staticmethod
    def encode_scale_offset(scale, offset):
        """encode scale and offset to unique key"""
        float_scale = np.float32(scale)
        uint32_scale = np.frombuffer(float_scale, np.uint32)

        int32_offset = np.int32(offset)
        uint32_offset = np.frombuffer(int32_offset, np.uint32)

        encode_result = np.uint64(0)
        encode_result = np.uint64(uint32_scale) << np.uint32(32) | np.uint64(
            uint32_offset)

        return str(encode_result)

    @staticmethod
    def find_same_quant_node(records, quant_node_list):
        """find quant node with same scale and offset"""
        fusion_quant_nodes = {}
        for node in quant_node_list:
            scale_d, offset_d = read_activation_scale_offset(records, \
                node.proto.quant_param.object_layer)
            encode_id = QuantFusionPass.encode_scale_offset(scale_d, offset_d)
            if encode_id not in fusion_quant_nodes:
                fusion_quant_nodes[encode_id] = [node]
            else:
                fusion_quant_nodes.get(encode_id).append(node)
        return fusion_quant_nodes

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.conf.get_record_file_path(), 'r') as record_file:
            pbtxt_string = record_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def match_pattern(self, node):
        """
        Function: Find node that have multiple output quant layer
        Parameters: node: node in graph
        Return: True: node that need to do quant layer fusion operation
        """
        for output_anchor in node.output_anchors:
            quant_layer_count = 0
            for peer_input_anchor in output_anchor.get_peer_input_anchor():
                if peer_input_anchor.node.type == "Quant":
                    quant_layer_count += 1
            if quant_layer_count > 1:
                return True

        return False

    def do_pass(self, graph, object_node):
        """
        Function: Do quant layer fusion operation.
        Parameters: graph: graph that contains object node
                    object_node: node to process
        Return: None
        """
        for output_anchor in object_node.output_anchors:
            # record one output_anchor's all consumer quant node
            quant_node_list = []
            for peer_input_anchor in output_anchor.get_peer_input_anchor():
                if peer_input_anchor.node.type == "Quant":
                    quant_node_list.append(peer_input_anchor.node)
            # record quant layer with same scale and offset
            fusion_quant_nodes = self.find_same_quant_node(
                self.records, quant_node_list)
            # do quant fusion
            for _, nodes in fusion_quant_nodes.items():
                if len(nodes) < 2:
                    continue
                # retain first quant node, remove the rest
                if nodes[0].has_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER):
                    nodes[0].set_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER, '')
                for node in nodes[1:]:
                    # remove input edge at first
                    graph.remove_edge(object_node, \
                        output_anchor.index, node, 0)
                    # relink from node -> consumer to first_node -> consumer
                    peers = node.get_output_anchor(0).get_peer_input_anchor()
                    for peer_input_anchor in peers:
                        dst_node = peer_input_anchor.node
                        dst_anchor_index = peer_input_anchor.index
                        graph.remove_edge(node, 0, \
                            dst_node, dst_anchor_index)
                        graph.add_edge(nodes[0], 0, \
                            dst_node, dst_anchor_index)
                    graph.remove_node(node.name)
                    LOGGER.logd("Remove node {} from graph".format(
                        node.name), 'QuantFusionPass')

        LOGGER.logd('Do fusion same quant layer from \'{}\' success!'\
                    .format(object_node.name), 'QuantFusionPass')
