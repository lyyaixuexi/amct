#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

check BN use_global_stats is True

"""

from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass


class CheckBNStatePass(BaseFusionPass):
    """
    Function: check BN use_global_stats is True
    APIs: match_pattern, do_pass

    """
    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    def match_pattern(self, node):
        """
        Function: Match pattern "BatchNorm" in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type != 'BatchNorm':
            return False
        return True


    def do_pass(self, graph, object_node):
        """
        Function: check bn state
        Parameters: graph: graph structure
                    object_node: node to process
        Return: None
        """
        # Step1: remove edge of BatchNorm
        node_bn = object_node
        bn_layer = node_bn.proto

        if not bn_layer.HasField('batch_norm_param'):
            return
        if not bn_layer.batch_norm_param.HasField('use_global_stats'):
            return

        use_global_stats = bn_layer.batch_norm_param.use_global_stats
        if not use_global_stats:
            raise RuntimeError(
                'AMCT toolkit base on test model, BatchNorm layer'
                'use_global_stats should be True but is {}'.format(
                    use_global_stats))
