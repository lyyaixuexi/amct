#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Record scale and offset in layer Quant and layer Dequant.

"""
import numpy as np
from google.protobuf import text_format
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.configuration.configuration import Configuration
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.retrain_config import RetrainConfig
from amct_caffe.utils.log import LOGGER
from amct_caffe.common.utils.record_file_operator import \
    read_weights_scale_offset
from amct_caffe.common.utils.record_file_operator import \
    read_activation_scale_offset
from amct_caffe.common.utils.record_file_operator import read_shift_bits

from amct_caffe.utils.attrs_list import ATTR_NODE_TARGET_LAYER
RECORD_NODE_TYPE = ('Quant', 'DeQuant', 'AntiQuant')


class RecordScaleOffsetPass(BaseFusionPass):
    """
    Function: the pass to record scale and offset in layer Quant and layer
              Dequant.
    APIs: set_up, set_save_type, match_pattern, do_pass
    """
    def __init__(self, retrain=False):
        BaseFusionPass.__init__(self)
        self.save_type = None
        self.records = caffe_pb2.ScaleOffsetRecord()
        if retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()

    @staticmethod
    def match_pattern(node):
        """
        Function: Find the Quant layer or DeQuant layer.
        Inputs:
            node: the node to be matched.
        Returns: None
        """
        if node.type not in RECORD_NODE_TYPE:
            return False
        return True

    @staticmethod
    def add_blob(object_node, data_type, data_length, data):
        """Add blob of data to object node, according to data_type and
           data_length.
        """
        new_blob = caffe_pb2.BlobProto()
        new_blob.shape.dim.extend([data_length])
        if data_type == "double":
            new_blob.double_data.extend(data.tolist())
        if data_type == "float":
            new_blob.data.extend(data.tolist())
        if data_type == "uint64":
            new_blob.uint64_data.extend(data.tolist())
        object_node.add_data(new_blob)

    @staticmethod
    def fuse_dequant_param(deq_scale, offset_w,
                           shift_bits, scale_length):
        """Fused dequant scale, offset_w and shift_bits to uint64 data
        """
        float32_deq_scale = np.array(deq_scale, np.float32)
        uint32_deq_scale = np.frombuffer(float32_deq_scale, np.uint32)

        int8_offset_w = np.array(offset_w, np.int8)
        uint8_offset_w = np.frombuffer(int8_offset_w, np.uint8)

        if shift_bits:
            uint8_shift_n = np.array(shift_bits, np.uint8)
        else:
            uint8_shift_n = np.zeros(scale_length, dtype=np.uint8)

        # fuse parameter
        # |-----------------|47:40|--------|39:32|--------|31:0|
        #                  offset_w [8]    shift_N [8]    deq_scale [32]
        quant_param = np.zeros(scale_length, dtype=np.uint64)
        for index in range(scale_length):
            quant_param[index] = uint8_offset_w[index]
            quant_param[index] = (quant_param[index] << np.uint32(8))\
                                    + uint8_shift_n[index]
            quant_param[index] = (quant_param[index] << np.uint32(32))\
                                    + uint32_deq_scale[index]
        return quant_param

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.conf.get_record_file_path(), 'r') as record_file:
            pbtxt_string = record_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def set_save_type(self, save_type):
        """
        Function: set save_type.
        Inputs: save_type:a string indicating the type, including "Deploy" or
                "Fakequant"
        Returns: None
        """
        if save_type not in ("Deploy", "Fakequant"):
            raise TypeError("Only support 'Deploy' and 'Fakequant', "\
                            "but get {}.".format(save_type))
        self.save_type = save_type

    def do_pass(self, graph, object_node):
        """
        Function: do quantize operation.
        Inputs:
            graph: IR Graph, the graph to be quantized.
            object_node: node to process
        Returns: None
        """
        if self.save_type is None:
            raise RuntimeError("Please set save_type by call set_save_type().")

        del object_node.get_all_data()[:]

        if object_node.get_all_data():
            raise RuntimeError('While doing scale and offset record, '\
                               'layer {} already have something in ' \
                               'blob'.format(object_node.name))

        if object_node.type in ('Quant', 'AntiQuant'):
            if object_node.has_attr(ATTR_NODE_TARGET_LAYER):
                quant_layer_name = object_node.get_attr(ATTR_NODE_TARGET_LAYER)
            else:
                quant_layer_name = object_node.proto.quant_param.object_layer
            scale_d, offset_d = read_activation_scale_offset(
                self.records, quant_layer_name)
            # Set quantize info to layer parameter
            if object_node.type == 'Quant':
                object_node.proto.quant_param.scale = 1 / scale_d
            else:
                object_node.proto.quant_param.scale = scale_d
            uint8_offset = np.frombuffer(np.int8(offset_d), np.uint8)
            object_node.proto.quant_param.offset = bytes(uint8_offset)

            object_node.set_attr(ATTR_NODE_TARGET_LAYER, quant_layer_name)
            object_node.proto.quant_param.ClearField('object_layer')
            if self.save_type == "Deploy":
                object_node.proto.quant_param.ClearField('with_offset')
            else:
                object_node.proto.quant_param.with_offset = True
        else:

            # record dequant parameters to DeQuant layer
            self._record_dequant_layer(object_node)
        LOGGER.logd('Do record scale and offset to layer \'{}\' success!'\
                    .format(object_node.name), 'RecordScaleOffsetPass')

    def _record_dequant_layer(self, object_node):
        """Record quantize parameter to 'DeQuant' layer
        """
        # read parameters for quantization from records
        if object_node.has_attr(ATTR_NODE_TARGET_LAYER):
            quant_layer = object_node.get_attr(ATTR_NODE_TARGET_LAYER)
        else:
            quant_layer = object_node.proto.dequant_param.object_layer
        scale_d, _ = read_activation_scale_offset(
            self.records, quant_layer)
        scale_w, offset_w = read_weights_scale_offset(
            self.records, quant_layer)
        shift_bits = read_shift_bits(self.records, quant_layer)

        if scale_w:
            scale_length = len(scale_w)
        else:
            raise RuntimeError("The scale_w is None.")

        # Calculate deq_scale equal (scale_d * scale_w)
        deq_scale = []
        for index in range(scale_length):
            deq_scale.append(scale_w[index] * scale_d)

        if self.save_type == "Deploy":
            # fuse parameter
            fused_param = self.fuse_dequant_param(
                deq_scale, offset_w, shift_bits, scale_length)
            # save in blob
            RecordScaleOffsetPass.add_blob(
                object_node, "uint64", scale_length, fused_param)
            object_node.set_attr(ATTR_NODE_TARGET_LAYER, \
                object_node.proto.dequant_param.object_layer)
            object_node.proto.ClearField('dequant_param')
        else:
            # Set quantize info to layer parameter
            object_node.proto.dequant_param.need_calibration = False
            if len(deq_scale) > 1:
                object_node.proto.dequant_param.channel_wise = True
            else:
                object_node.proto.dequant_param.channel_wise = False
            object_node.proto.dequant_param.ClearField('batch_num')
            object_node.proto.dequant_param.ClearField(
                'object_layer')

            # save deq_scale(float32) in scale_blob(float)
            RecordScaleOffsetPass.add_blob(
                object_node, "float", scale_length, np.array(
                    deq_scale, np.float32))

            # save N() in n_blob(float)
            if shift_bits:
                RecordScaleOffsetPass.add_blob(
                    object_node, "float", scale_length,
                    np.array(shift_bits, np.uint8))
            else:
                RecordScaleOffsetPass.add_blob(
                    object_node, "float", scale_length,
                    np.zeros(scale_length, dtype=np.uint8))

            # save offset_w(int8) in offset_blob(float)
            RecordScaleOffsetPass.add_blob(
                object_node, "float", scale_length, np.array(
                    offset_w, np.float32))
