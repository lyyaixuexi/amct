#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quantize lstm layer's weights to int8.


"""
from google.protobuf import text_format
import numpy as np

try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.configuration.configuration import Configuration
from amct_caffe.configuration.check import GraphChecker
from amct_caffe.utils.dump import Dumper
from amct_caffe.utils.dump import DUMPER_DICT
from amct_caffe.optimizer.lstm_calibration_replace import identify_lstm_state
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.common.utils.record_file_operator import \
    read_weights_scale_offset
from amct_caffe.utils.weight_quant_api import weights_quantize_blob
from amct_caffe.utils.weight_quant_api import get_weights_blob_info
from amct_caffe.utils.log import LOGGER


class LstmWeightsQuantizePass(BaseFusionPass):
    """
    Function: the pass to quantize lstm weights.
    APIs: set_up, match_pattern, do_pass
    """
    def __init__(self):
        BaseFusionPass.__init__(self)
        self.records = caffe_pb2.ScaleOffsetRecord()

    @staticmethod
    def match_pattern(node):
        """
        Function: Find the layer to be quantized.
        Inputs:
            node: the node to be matched.
        Returns: None
        """
        # match type
        if node.type == 'LSTMCalibration' and \
            node.name in Configuration().get_quant_config():
            node.update_type('LSTM')
        if node.type != 'LSTM':
            return False
        if not GraphChecker.check_quantize_type(node) or \
            node.name not in Configuration().get_quant_config():
            return False

        return True

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(Configuration().get_record_file_path(), 'r') as record_file:
            pbtxt_string = record_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def do_pass(self, graph, object_node):
        """
        Function: do quantize operation.
        Inputs:
            graph: IR Graph, the graph to be quantized.
            object_node: node to process
        Returns: None
        """
        # find weights_blob
        static_input, _ = identify_lstm_state(object_node)
        # LSTM layer blobs [weights_x, bias, weights_static, weights_h]
        # weights_x contains: weights_x_blob, weights_x_shape,
        #                     weights_x_dtype, weights_x_data
        weights_x = get_weights_blob_info(object_node, 0, True)
        if static_input:
            # weights_s contains: weights_s_blob, weights_s_shape,
            #                     weights_s_dtype, weights_s_data
            weights_s = get_weights_blob_info(object_node, 2, True)
            # weights_h contains: weights_h_blob, weights_h_shape,
            #                     weights_h_dtype, weights_h_data
            weights_h = get_weights_blob_info(object_node, 3, True)
        else:
            weights_h = get_weights_blob_info(object_node, 2, True)

        layer_config = Configuration().get_layer_config(object_node.name)
        wts_param = layer_config.get('weight_quant_params')
        num_bits = wts_param['num_bits']

        def __quantize_kernel(records, record_name, weights, num_bits):
            # quantize weights to int8
            scale_w, offset_w = read_weights_scale_offset(records, record_name)
            weights['weights_blob'].int8_data = weights_quantize_blob(
                weights['weights_data'], scale_w, offset_w, num_bits)


        def __dump_quantized_weights_data(dumper_name, weights_blob):
            if dumper_name not in DUMPER_DICT:
                DUMPER_DICT[dumper_name] = Dumper('{}.log'.format(
                    dumper_name))
            int8_data = np.frombuffer(weights_blob.int8_data, np.int8)
            DUMPER_DICT[dumper_name].dumpd(['weights after quantize:'])
            DUMPER_DICT[dumper_name].dumpd(
                int8_data.tolist(), int8_data.shape[0])

        __quantize_kernel(self.records, '{}_X'.format(
            object_node.name), \
            {'weights_blob': weights_x[0], 'weights_data': weights_x[3]}, \
            num_bits)
        dumper_name = '{}_weights_x'.format(object_node.name)
        __dump_quantized_weights_data(dumper_name, weights_x[0])

        __quantize_kernel(self.records, '{}_H'.format(
            object_node.name), \
            {'weights_blob': weights_h[0], 'weights_data': weights_h[3]}, \
            num_bits)
        dumper_name = '{}_weights_h'.format(object_node.name)
        __dump_quantized_weights_data(dumper_name, weights_h[0])

        if static_input:
            __quantize_kernel(self.records, '{}_S'.format(
                object_node.name), \
                {'weights_blob': weights_s[0], 'weights_data': weights_s[3]}, \
                num_bits)
            dumper_name = '{}_weights_s'.format(object_node.name)
            __dump_quantized_weights_data(dumper_name, weights_s[0])

        LOGGER.logd('Do layer:\'{}\' weights quantize success!'\
                    .format(object_node.name), 'LstmWeightsQuantizePass')

        object_node.update_type('LSTMQuant')
        object_node.proto.ClearField('lstm_calibration_param')
        LOGGER.logi('Replace lstm layer {} type to "LSTMQuant".'.format(
            object_node.name))
