#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert quant layer before layer to be quantized

"""
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error
from amct_caffe.utils.log import LOGGER
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.retrain_config import RetrainConfig as Rconf
from amct_caffe.configuration.check import GraphChecker


class InsertRetrainLayersPass(BaseFusionPass):
    """
    Function: Insert quant layer before layer to be quantized
    APIs: match_pattern, do_fusion
    """
    QUANTIZABLE = ['Convolution', 'InnerProduct', 'Deconvolution', 'Pooling']
    MULT_OUTPUT_TYPES = ['Concat']

    def __init__(self):
        """
        Function: Init Retrain Layer
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.op_group_map = {}
        self.group_num = 0
        self.group_info = {}

    @staticmethod
    def _build_data_node(object_node, config, names):
        ''' inner method '''
        # build a data layer
        layer = caffe_pb2.LayerParameter()
        # Set basic info
        concat_name = '-'.join(names)
        layer.retrain_data_quant_param.object_layer = concat_name
        layer.retrain_data_quant_param.record_file_path =\
                Rconf.get_record_file_path()
        layer.name = '{}_{}'.format(concat_name, 'activation_qat_layer')
        layer.type = 'ActivationQAT'
        layer.bottom.extend(['{}_{}'.format(layer.name, 'input0')])
        layer.top.extend(['{}_{}'.format(concat_name, 'output0')])
        # Set quantize algorithm parameters
        if 'clip_max' in config.keys() and 'clip_min' in config.keys():
            layer.retrain_data_quant_param.clip_max = config['clip_max']
            layer.retrain_data_quant_param.clip_min = config['clip_min']
            layer.retrain_data_quant_param.ifmr_init = False
        else:
            layer.retrain_data_quant_param.ifmr_init = True
        if 'fixed_min' in config.keys():
            layer.retrain_data_quant_param.fixed_min =\
                    config['fixed_min']

        input_anchor = object_node.get_input_anchor(0)
        peer_output_anchor = input_anchor.get_peer_output_anchor()
        peer_node = peer_output_anchor.node
        second_peer_node = None
        try:
            if hasattr(peer_node, 'get_input_anchor'):
                peer_input_anchor = peer_node.get_input_anchor(0)
                second_output_anchor = peer_input_anchor.\
                        get_peer_output_anchor()
                second_peer_node = second_output_anchor.node
        except RuntimeError:
            pass

        if peer_node.type in ('ReLU') or\
            (second_peer_node and second_peer_node.type in 'ReLU'):
            if 'fixed_min' not in config.keys():
                layer.retrain_data_quant_param.fixed_min = True
                param = caffe_pb2.ParamSpec()
                layer.param.extend([param])
                param1 = caffe_pb2.ParamSpec()
                param1.decay_mult = 0
                layer.param.extend([param1])
                layer.retrain_data_quant_param.clip_min = 0
                LOGGER.logd("retrain config after ReLu: force fixed_min and\
                    clip_min = 0 for layer {}".format(object_node.name))
        return layer

    @staticmethod
    def _build_weights_node(obj_node, weights_config):
        ''' inner method '''
        #build weight quant layer
        layer = caffe_pb2.LayerParameter()
        # Set basic info
        layer.name = '{}_{}'.format(obj_node.name, 'layer')
        layer.type = 'WeightQAT'
        layer.retrain_weight_quant_param.layer_type = obj_node.type
        layer.bottom.extend(['{}_{}'.format(obj_node.name, 'input0')])
        layer.top.extend(['{}_{}'.format(obj_node.name, 'output0')])
        # Set quantize algorithm parameters=
        param = obj_node.proto.param
        if not param:
            para_tmp = caffe_pb2.ParamSpec()
            param.extend([para_tmp])
        param[0].name = layer.name
        layer.param.extend(param)
        weights_blob = obj_node.get_data(0)
        weights_shape = GraphChecker.get_blob_shape(weights_blob)
        layer.retrain_weight_quant_param.cout = weights_shape[0]
        layer.retrain_weight_quant_param.cin = weights_shape[1]
        layer.retrain_weight_quant_param.channel_wise =\
                weights_config['channel_wise']
        if len(weights_shape) == 4:
            layer.retrain_weight_quant_param.h = weights_shape[2]
            layer.retrain_weight_quant_param.w = weights_shape[3]
        return layer

    @staticmethod
    def get_parent_node(object_node):
        ''' inner method '''
        input_anchor = object_node.get_input_anchor(0)
        peer_output_anchor = input_anchor.get_peer_output_anchor()
        peer_node = peer_output_anchor.node
        peer_output_anchor_index = peer_output_anchor.index
        return peer_output_anchor_index, peer_node

    def need_retrain(self, node):
        ''' inner method '''
        if not GraphChecker.check_quantize_type(node):
            return False
        if node.type in self.QUANTIZABLE and \
                Rconf().retrain_enable(node.name):
            return True
        return False

    def match_co_retrain_pattern(self, node):
        ''' inner method '''
        input_anchor = node.get_input_anchor(0)
        peer_output_anchor = input_anchor.get_peer_output_anchor()
        input_anchors = peer_output_anchor.get_peer_input_anchor()
        #need solo retrain
        if len(input_anchors) == 1:
            return True
        # already record in co-retrain group, no need to store
        if node.name in self.op_group_map.keys():
            return True

        lgroups = []
        for input_anchor in input_anchors:
            consumer = input_anchor.node
            consumer_conf = Rconf().get_retrain_config(consumer.name)
            if self.need_retrain(consumer):
                for l_g in lgroups:
                    name = self.group_info.get(l_g).get('members')[0]
                    conf = Rconf().get_retrain_config(name)
                    # if already has group
                    if consumer_conf['retrain_data_config'] ==\
                            conf['retrain_data_config']:
                        self.op_group_map[consumer.name] = l_g
                        group_content = self.group_info.get(l_g)
                        group_content['members'].append(consumer.name)
                        LOGGER.logd(
                            'Add %s to %d co-retrain group'
                            % (consumer.name, l_g),
                            'retrain layer')
                        break
                if consumer.name not in self.op_group_map.keys():
                    # build new group
                    self.group_num += 1
                    self.group_info[self.group_num] = {}
                    group_content = self.group_info.get(self.group_num)
                    group_content['done'] = False
                    group_content['members'] = []
                    self.op_group_map[consumer.name] = self.group_num
                    group_content['members'].append(consumer.name)
                    lgroups.append(self.group_num)
                    LOGGER.logd(
                        'Add %s new co-retraining group: %d' %
                        (consumer.name, self.group_num),
                        'retrain layer')

        return True

    def match_pattern(self, node):
        """
        Function: Find 'Convolution' or 'InnerProduct' node need to quantized
                  in graph
        Parameters: node: node in graph
        Return: True: node that need to insert quant layer
                False: skip the node
        """
        if self.need_retrain(node):
            if self.match_co_retrain_pattern(node):
                return True
        return False

    def do_pass(self, graph, object_node):
        """
        Function: Do actual insert quant layer operation.
        Parameters: graph: graph that contains object node
                    object_node: index of object node
        Return: None
        """
        if object_node.name in self.op_group_map.keys():
            group_num = self.op_group_map.get(object_node.name)
            if not self.group_info.get(group_num).get('done'):
                self._do_act_retrain_pass(graph, object_node)
                self.group_info.get(group_num)['done'] = True
        else:
            self._do_act_retrain_pass(graph, object_node)
        #Average Pooling do not need weight retrain
        if object_node.type == 'Pooling':
            return
        _, data_retrain_node = self.get_parent_node(object_node)
        retrain_config = Rconf().get_retrain_config(object_node.name)
        weights_config = retrain_config['retrain_weight_config']
        weight_qat_layer = self._build_weights_node(
            object_node,
            weights_config)
        # Add node of quant to graph
        weight_retrain_node = graph.add_node(weight_qat_layer)

        if len(object_node.input_anchors) != 1:
            raise RuntimeError("Convolution/InnerProduct should only have 1 " \
                "input, actually have ", len(object_node.input_anchors))
        graph.remove_edge(data_retrain_node, 0, object_node, 0)
        graph.add_edge(
            data_retrain_node,
            0,
            weight_retrain_node,
            0)
        LOGGER.logd("Add edge from {}[{}] to {}[{}]".\
            format(data_retrain_node.name, 0, weight_retrain_node.name, 0))

        graph.add_edge(weight_retrain_node, 0, object_node, 0)
        LOGGER.logd("Add edge from {}[{}] to {}[{}]".\
            format(weight_retrain_node.name, 0, object_node.name, 0))

    def _do_act_retrain_pass(self, graph, object_node):
        ''' inner method '''
        name = object_node.name
        name_list = [name]
        if object_node.name in self.op_group_map.keys():
            group_num = self.op_group_map.get(object_node.name)
            name_list = self.group_info.get(group_num).get('members')

        retrain_config = Rconf().get_retrain_config(name)
        data_config = retrain_config['retrain_data_config']

        activation_qat_layer = self._build_data_node(
            object_node,
            data_config,
            name_list)
        # Add node of quant to graph
        data_retrain_node = graph.add_node(activation_qat_layer)

        peer_output_anchor_index, peer_node = self.get_parent_node(object_node)
        for name in name_list:
            graph.remove_edge(
                peer_node,
                peer_output_anchor_index,
                graph.get_node_by_name(name),
                0)
            LOGGER.logd("Remove edge from {}[{}] to {}[{}]".format(
                peer_node.name, peer_output_anchor_index, name, 0))

        # add link from peer node to data_quant_layer
        graph.add_edge(peer_node, peer_output_anchor_index,
                       data_retrain_node, 0)
        LOGGER.logd("Add edge from {}[{}] to {}[{}]".format(peer_node.name, \
            peer_output_anchor_index, data_retrain_node.name, 0))
        for name in name_list:
            graph.add_edge(data_retrain_node, 0,
                           graph.get_node_by_name(name), 0)
