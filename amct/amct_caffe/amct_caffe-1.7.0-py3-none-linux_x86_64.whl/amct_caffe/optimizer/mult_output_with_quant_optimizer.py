#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Add quant and anti-quant to max_pooling and eltwise layer.

"""
from google.protobuf import text_format

try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.utils.log import LOGGER
from amct_caffe.configuration.retrain_config import RetrainConfig
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.optimizer.quant_fusion_pass import QuantFusionPass


MAX_FLAG = caffe_pb2.PoolingParameter.PoolMethod.MAX
SUPPORTED_OUTPUT_NODE_TYPES = ('Concat')


class MultQuantOptimizerPass(BaseFusionPass):
    """
    Function: Fusion quant_layers that from same input and have
              same scale and offset
    APIs: match_pattern, do_pass
    """
    def __init__(self, retrain=False):
        """
        Function: Init MultQuantOptimizerPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        if retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()
        self.records = caffe_pb2.ScaleOffsetRecord()
        self.optimizer_layer = ('Pooling')

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.conf.get_record_file_path(), 'r') as record_file:
            pbtxt_string = record_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def match_pattern(self, node):
        """
        Function: Find node that have multiple output quant layer
        Parameters: node: node in graph
        Return: True: node that need to do quant layer fusion operation
        """
        if node.type not in SUPPORTED_OUTPUT_NODE_TYPES:
            return False
        for output_anchor in node.output_anchors:
            quant_layer_count = 0
            non_quant_layer_count = 0
            for peer_input_anchor in output_anchor.get_peer_input_anchor():
                peer_node_type = peer_input_anchor.node.type
                if peer_node_type == 'Quant':
                    LOGGER.logd('Find node {} have quant output'.format(
                        node.name), 'MultQuantOptimizerPass')
                    quant_layer_count += 1
                elif peer_node_type not in self.optimizer_layer:
                    LOGGER.logd('Find node {} have {} output'.format(
                        node.name, self.optimizer_layer),
                                'MultQuantOptimizerPass')
                    return False
                else:
                    non_quant_layer_count += 1
            if quant_layer_count and non_quant_layer_count:
                LOGGER.logd('Find node {} can do optimizer'.format(
                    node.name), 'MultQuantOptimizerPass')
                return True

        return False

    def find_output_need_optimizer(self, node, output_anchor):
        """find object node's peer output that can be optimizer"""
        matched = True
        quant_node_list = []
        non_quant_peer_anchors = []
        for peer_input_anchor in output_anchor.get_peer_input_anchor():
            peer_node = peer_input_anchor.node
            if peer_node.type == "Quant":
                quant_node_list.append(peer_node)
                LOGGER.logd('Find node {} have quant output {}'.format(
                    node.name, peer_node.name),
                            'MultQuantOptimizerPass')
            elif peer_node.type not in self.optimizer_layer:
                matched = False
                LOGGER.logd('Find node {} have unsupprted output {}'.format(
                    node.name, peer_node.name),
                            'MultQuantOptimizerPass')
                break
            elif peer_node.type == 'Pooling' and \
                peer_node.proto.pooling_param.pool != MAX_FLAG:
                matched = False
                LOGGER.logd('Find node {} have unsupprted output {}'.format(
                    node.name, peer_node.name),
                            'MultQuantOptimizerPass')
            else:
                LOGGER.logd('Find node {} have supprted output {}'.format(
                    node.name, peer_node.name),
                            'MultQuantOptimizerPass')
                non_quant_peer_anchors.append(peer_input_anchor)
        # record quant layer with same scale and offset
        fusion_quant_nodes = QuantFusionPass.find_same_quant_node(
            self.records, quant_node_list)
        if len(fusion_quant_nodes) != 1:
            LOGGER.logd('Node {} with different output activation quantize ' \
                'parameters.'.format(node.name))
            return False, None, None

        nodes = fusion_quant_nodes.get(list(fusion_quant_nodes.keys())[0])
        return matched, nodes[0], non_quant_peer_anchors

    def generate_quant_node(self, graph, target_node, object_layer):
        """Generate 'Quant' node according to target node info and
           object_layer info.
        """
        # Step1: Generate a LayerParameter object of quant layer,
        #        and add node to graph
        quant_layer = caffe_pb2.LayerParameter()
        # Set basic info
        quant_layer.name = '{}_{}'.format(target_node.name, 'quant_layer')
        quant_layer.type = 'Quant'
        quant_layer.bottom.extend(['{}_{}'.format(quant_layer.name, 'input0')])
        quant_layer.top.extend(['{}_{}'.format(quant_layer.name, 'output0')])
        # Set quantize algorithm parameters
        act_param = self.conf.get_layer_config(object_layer).get('activation_quant_params')
        if act_param is None or act_param.get('asymmetric') is None:
            quant_layer.quant_param.with_offset = self.conf.get_quant_config()['activation_offset']
        else:
            quant_layer.quant_param.with_offset = act_param.get('asymmetric')
        quant_layer.quant_param.object_layer = '{}'.format(object_layer)
        # Add node of quant to graph
        quant_node = graph.add_node(quant_layer)
        return quant_node

    def generate_anti_quant_node(self, graph, target_node, object_layer):
        """Generate 'AntiQuant' node according to target node info and
           object_layer info.
        """
        # Step1: Generate a LayerParameter object of dequant layer,
        #        and add node to graph
        anti_quant_layer = caffe_pb2.LayerParameter()
        # Set basic info
        anti_quant_layer.name = '{}_{}'.format(
            target_node.name,
            'anti_quant_layer')
        anti_quant_layer.type = 'AntiQuant'
        anti_quant_layer.bottom.extend(['{}_{}'.format(
            anti_quant_layer.name,
            'input0')])
        anti_quant_layer.top.extend(['{}_{}'.format(
            anti_quant_layer.name,
            'output0')])
        # Set dequantize algorithm parameters
        act_param = self.conf.get_layer_config(object_layer).get('activation_quant_params')
        if act_param is None or act_param.get('asymmetric') is None:
            anti_quant_layer.quant_param.with_offset = self.conf.get_quant_config()['activation_offset']
        else:
            anti_quant_layer.quant_param.with_offset = act_param.get('asymmetric')
        anti_quant_layer.quant_param.object_layer = '{}'.format(object_layer)
        # Add dequant node to graph
        anti_quant_node = graph.add_node(anti_quant_layer)
        return anti_quant_node

    def do_pass(self, graph, object_node):
        """
        Function: Do quant layer fusion operation.
        Parameters: graph: graph that contains object node
                    object_node: node to process
        Return: None
        """
        for output_anchor in object_node.output_anchors:
            # record one output_anchor's all consumer quant node
            matched, quant_node, non_quant_peer_anchors = \
                self.find_output_need_optimizer(object_node, output_anchor)
            if not matched:
                continue
            # Judge whether max_pooling is global pooling
            for peer_input_anchor in non_quant_peer_anchors:
                peer_node = peer_input_anchor.node
                if peer_node.type == "Pooling":
                    if peer_node.proto.pooling_param.global_pooling:
                        matched = False
                        break
            if not matched:
                continue

            object_layer = quant_node.proto.quant_param.object_layer
            for peer_input_anchor in non_quant_peer_anchors:
                peer_node = peer_input_anchor.node
                quant_node = self.generate_quant_node(
                    graph, peer_node, object_layer)
                anti_quant_node = self.generate_anti_quant_node(
                    graph, peer_node, object_layer)

                # Insert Quant and AntiQuant between object node and peer node
                graph.remove_edge(object_node, output_anchor.index,
                                  peer_node, peer_input_anchor.index)
                graph.add_edge(object_node, output_anchor.index,
                               quant_node, 0)
                graph.add_edge(quant_node, 0,
                               anti_quant_node, 0)
                graph.add_edge(anti_quant_node, 0,
                               peer_node, peer_input_anchor.index)

        LOGGER.logd('Do fusion same quant layer from \'{}\' success!'\
                    .format(object_node.name),
                    'MultQuantOptimizerPass')
