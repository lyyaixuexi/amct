#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quantize eltwise opt convolution weights by calibration.

"""
import numpy as np
from google.protobuf import text_format
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.utils.weight_quant_api import get_weights_blob_info
from amct_caffe.utils.weight_quant_api import weight_calibration_np
from amct_caffe.utils.log import LOGGER
from amct_caffe.utils.dump import Dumper
from amct_caffe.utils.dump import DUMPER_DICT
from amct_caffe.common.utils.record_file_operator import \
    record_weights_scale_offset
from amct_caffe.configuration.check import _check_dilation
from amct_caffe.configuration.check import _check_group
from amct_caffe.configuration.check import _check_weight
from amct_caffe.configuration.check import QUANT_TYPES
from amct_caffe.optimizer.weights_calibration import CALIBRATION_DONE_FLAG

QUANTIZABLE_TYPES = ('Convolution', 'InnerProduct', 'Deconvolution')
ELTWISE_OPTIMIZABLE_TYPES = ('Convolution')
SUPPORTED_BYPASS_TYPES = ('ReLU')
ELTWISE_OPTIMIZER_DONE_FLAG = 'eltiwse_optimizer_done'
ELTWISE_ADD = caffe_pb2.EltwiseParameter.EltwiseOp.SUM


def check_eltwise_opt_type(node):
    """ check if node can be eltwise optimized or not."""
    # check type
    if node.type not in ELTWISE_OPTIMIZABLE_TYPES:
        return False
    if node.name not in Configuration().get_quant_config():
        return False
    # check invalid inputs
    if len(node.input_anchors) != 1:
        raise RuntimeError(
            "{} layer({}) should have 1 input but actually {} inputs.".\
            format(
                node.type, node.name,
                len(node.input_anchors)))
    # Check only conv that single output to Eltwise can do union quantize
    if len(node.get_output_anchor(0).get_peer_input_anchor()) != 1:
        return False

    if node.type == 'Convolution':
        # must be conv2D
        if not _check_weight(node, 4):
            return False
        # dilation must eq 1 and group must eq 1
        if not _check_dilation(node, ([], [1], [1, 1])) or \
            not _check_group(node, 1):
            return False
    return True


def is_quant_params_same(node_names):
    """ check whether the input quant params the same"""
    # get weights' information for quantization
    if len(node_names) <= 1:
        return True
    head_node_name = node_names[0]

    head_layer_config = Configuration().get_layer_config(
        head_node_name)
    head_wts_param = head_layer_config.get('weight_quant_params')
    head_act_param = head_layer_config.get('activation_quant_params')

    for node_name in node_names[1:]:
        layer_config = Configuration().get_layer_config(node_name)
        wts_param = layer_config.get('weight_quant_params')
        act_param = layer_config.get('activation_quant_params')
        # if param not the same skip this pass
        if head_wts_param != wts_param or head_act_param != act_param:
            LOGGER.logi('Unable to do eltwise optimize layer {} and {} ' \
                        ' with different quant params'.format( \
                        head_node_name, \
                        node_name),
                        'EltwiseOptWeightsCalibrationPass')
            return False
    return True


def _add_union_quant_node(node, union_list):
    """Add node that can do union quantize
    """
    if not check_eltwise_opt_type(node):
        return False
    if not union_list:
        union_list.append(node.name)
        return True
    head_node_name = union_list[0]
    if not union_list.count(node.name) and \
        is_quant_params_same([head_node_name, node.name]):
        union_list.append(node.name)
        return True
    return False


class EltwiseOptWeightsCalibrationPass(BaseFusionPass):
    """
    Function: the pass to quantize eltwsie + conv2d by Calibration.
    APIs: set_up, tear_down, match_pattern, do_pass
    """
    def __init__(self):
        BaseFusionPass.__init__(self)
        self.records = caffe_pb2.ScaleOffsetRecord()
        self.record_file_path = Configuration().get_record_file_path()

    @staticmethod
    def dump_data(node, weights_data):
        """
        Function: dump to data of node's weights
        Inputs:
            node: the node to be matched.
            weights_data: the weights data of input node
        Returns: None
        """
        DUMPER_DICT['{}_weights'.format(node.name)] = \
            Dumper('{}_weights.log'.format(node.name))
        DUMPER_DICT.get('{}_weights'.format(node.name)).\
            dumpd(['weights before quantize:'])
        DUMPER_DICT.get('{}_weights'.format(node.name)).\
            dumpd(weights_data, len(weights_data))

    @staticmethod
    def match_pattern(node,    # pylint: disable=W0221
                      done_attr,
                      do_eltwise_quant=False):
        """match pattern that can do eltwize optimizer: start with eltwise
           that has two conv input, end to eltwise node that all output node
           can be quantized, if one eltwise has unquantifiable output (except
           eltwise node) then whole pattern cannot do optimizer.

        """
        if node.type != 'Eltwise':
            return None

        is_support, _ = \
            EltwiseOptWeightsCalibrationPass._check_eltwise(node)
        if not is_support:
            LOGGER.logd('Eltwise node "{}" not support do optimize'.format(
                node.name))
            return None

        # Check input node to eltwise, must all be quantizable conv node
        input_nodes = \
            EltwiseOptWeightsCalibrationPass._get_eltwise_input_nodes(node)
        for input_node in input_nodes:
            if not check_eltwise_opt_type(input_node):
                LOGGER.logd('Exist not support input node "{}" to "{}"'.format(
                    input_node.name, node.name))
                return None

        if not is_quant_params_same( \
            [input_node.name for input_node in input_nodes]):
            return None
        return EltwiseOptWeightsCalibrationPass._match_pattern_kernel(
            node, done_attr, do_eltwise_quant)

    @staticmethod
    def _check_requants16_optimze(input_nodes, union_list):
        """If all input_nodes is Convolution, then check if one from eltwise,
           then should add another node.
        """
        peer_output_nodes = []
        for input_node in input_nodes:
            if input_node.type != 'Convolution':
                return
            input_anchor = input_node.get_input_anchor(0)
            peer_output_anchor = input_anchor.get_peer_output_anchor()
            peer_output_nodes.append(peer_output_anchor.node)

        for index, peer_node in enumerate(peer_output_nodes):
            if peer_node.type in SUPPORTED_BYPASS_TYPES:
                input_anchor = peer_node.get_input_anchor(0)
                grand_peer_anchor = input_anchor.get_peer_output_anchor()
                grand_peer_node = grand_peer_anchor.node
                peer_output_nodes[index] = grand_peer_node

        for peer_output_node in peer_output_nodes:
            EltwiseOptWeightsCalibrationPass._check_requants16_optimze_kernel(
                peer_output_node, input_nodes, union_list)

    @staticmethod
    def _check_requants16_optimze_kernel(producer_node,
                                         input_nodes,
                                         union_list):
        """Add requants16 optimze union quant node to union_list"""
        if producer_node.type in ('Eltwise', 'Pooling'):
            output_anchor = producer_node.get_output_anchor(0)
            if len(output_anchor.get_peer_input_anchor()) == 1:
                consumer_node = output_anchor.get_peer_input_anchor()[0].node
                if consumer_node.type in SUPPORTED_BYPASS_TYPES:
                    output_anchor = consumer_node.get_output_anchor(0)
            for peer_input_anchor in output_anchor.get_peer_input_anchor():
                consumer_node = peer_input_anchor.node
                if consumer_node not in input_nodes:
                    _add_union_quant_node(consumer_node, union_list)

    @staticmethod
    def _match_pattern_kernel(head_node, done_attr, do_eltwise_quant):
        """start do pattern search"""
        union_list = []
        candidate_eltwise = [head_node]
        while candidate_eltwise:
            current_node = candidate_eltwise.pop(0)
            is_support, next_eltwise = \
                EltwiseOptWeightsCalibrationPass._check_eltwise(current_node)
            if not is_support:
                return None
            input_nodes = \
                EltwiseOptWeightsCalibrationPass._get_eltwise_input_nodes(
                    current_node)
            if not union_list and do_eltwise_quant:
                EltwiseOptWeightsCalibrationPass._check_requants16_optimze(
                    input_nodes, union_list)

            for input_node in input_nodes:
                # If input node exise eltwise or equivalent node, need
                # check whether it be unioned
                if input_node.type == 'Eltwise' or \
                    input_node.type in SUPPORTED_BYPASS_TYPES:
                    if not input_node.has_attr(done_attr):
                        LOGGER.logi('Exist unsupport pattern start with "{}"' \
                                    ' because layer "{}"'.format( \
                                    head_node.name, input_node.name))
                        return None
                elif not _add_union_quant_node(input_node, union_list):
                    return None
            current_node.set_attr(done_attr, True)
            output_anchor = current_node.get_output_anchor(0)
            for peer_anchor in output_anchor.get_peer_input_anchor():
                if peer_anchor.node.type in SUPPORTED_BYPASS_TYPES:
                    peer_anchor.node.set_attr(done_attr, True)
            candidate_eltwise.extend(next_eltwise)
        return union_list

    @staticmethod
    def _get_eltwise_input_nodes(node_eltwise):
        """Get and return eltwise node's two input node
        """
        # get left input node
        eltwise_input_nodes = []
        for input_anchor in node_eltwise.input_anchors:
            peer_output_anchor = input_anchor.get_peer_output_anchor()
            input_node = peer_output_anchor.node
            eltwise_input_nodes.append(input_node)

        return eltwise_input_nodes

    @staticmethod
    def _check_eltwise_property(node_eltwise):
        """Check basic eltwise layer's info"""
        # Eltwise must be multi input and single output
        if len(node_eltwise.input_anchors) < 2:
            raise RuntimeError('Eltwise node at least have two output, but ' \
                '{} has {}'.format(node_eltwise.name, \
                    len(node_eltwise.input_anchors)))
        if len(node_eltwise.output_anchors) != 1:
            raise RuntimeError('Eltwise node can only have one output, but ' \
                '{} has {}'.format(node_eltwise.name, \
                    len(node_eltwise.output_anchors)))
        # Only support eltwise add do s16 optimize
        if node_eltwise.proto.eltwise_param.operation != ELTWISE_ADD:
            LOGGER.logd('Eltwise {} of operation:{} not support.'.format(
                node_eltwise.name,
                node_eltwise.proto.eltwise_param.operation))
            return False
        return True

    @staticmethod
    def _check_eltwise(node_eltwise):
        """Check if eltiwse node exist unquantifiable output (except
           eltwise node)
        """
        if not EltwiseOptWeightsCalibrationPass._check_eltwise_property(
                node_eltwise):
            LOGGER.logd('Eltwise {} not support do S16 optimize.'.format(
                node_eltwise.name))
            return False, None
        # Check eltwise layer's output node
        next_eltwise = []
        output_anchor = node_eltwise.get_output_anchor(0)
        peer_anchors = output_anchor.get_peer_input_anchor()
        # If Eltwise output to bypass node(ReLU), Check bypass node's output
        if len(peer_anchors) == 1 and \
            peer_anchors[0].node.type in SUPPORTED_BYPASS_TYPES:
            peer_node = peer_anchors[0].node
            output_anchors = peer_node.output_anchors
            if len(output_anchors) != 1:
                raise RuntimeError('Node "{}" can only have one output,' \
                    ' but has {}'.format(peer_node.name, \
                        len(peer_node.output_anchors)))
            peer_anchors = output_anchors[0].get_peer_input_anchor()
        found_quant_node = False
        for peer_anchor in peer_anchors:
            # If consumer node contains eltwise, add it to infected list,
            # but when consumer have "done" flag, means it already infected
            # by others, skip it.
            peer_node = peer_anchor.node
            if peer_node.type == 'Eltwise':
                next_eltwise.append(peer_node)
            elif peer_node.type in QUANTIZABLE_TYPES and \
                peer_node.name in Configuration().get_quant_config():
                # Eltwise optimize need have quantize node after it, but
                # Pooling is not supported.
                found_quant_node = True
            # If eltwise's consumer contains unsupport layer, then
            # all infected elwise cannot do union quantize.
            elif peer_node.type not in QUANT_TYPES:
                LOGGER.logd('Exist not support layer "{}" after Eltwise ' \
                            '"{}"'.format(peer_node.name, \
                            node_eltwise.name))
                return False, None
        if not found_quant_node:
            LOGGER.logd('Cannot find quantize node after Eltwise:{}'.format(
                node_eltwise.name))
            return False, None
        return True, next_eltwise

    def run(self, graph):
        self.set_up()
        union_lists = []
        for node in graph.nodes:
            union_list = self.match_pattern(node, '{}_{}'.format(
                ELTWISE_OPTIMIZER_DONE_FLAG, node.index))
            if union_list is not None:
                union_lists.append(union_list)
        for union_list in union_lists:
            self.do_pass(graph, union_list)
        self.tear_down()

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, 'r') as file_record_read:
            pbtxt_string = file_record_read.read()
            text_format.Merge(pbtxt_string, self.records)

    def tear_down(self):
        """
        Function: write the scale and offset to Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, "w") as file_record_read:
            file_record_read.write(text_format.MessageToString(
                self.records, as_utf8=True))

    def do_pass(self, graph, union_list): # pylint: disable=W0221
        # find weights_blob
        if len(union_list) <= 1:
            return

        data_record = {}
        concated_weights = self._packet_union_quantize_conv_weights(
            graph, union_list, data_record)
        if concated_weights is None:
            return

        concated_shape = concated_weights.shape
        concated_weights = concated_weights.reshape(
            [concated_shape[0], 1, 1, concated_shape[1]])
        # Get first node's weights quantize parameter as whole concated
        # weights' quantize parameter
        layer_config = Configuration().get_layer_config(union_list[0])
        wts_param = layer_config.get('weight_quant_params')
        scale, offset = weight_calibration_np(concated_weights, wts_param)

        concated_weights.shape = concated_shape
        split_index = 0
        for node_name in union_list:
            record_weights_scale_offset(self.records, node_name, scale, offset)
            blob_shape = data_record.get(node_name).get('shape')
            current_split_index = blob_shape[1] * blob_shape[2] * blob_shape[3]

            data_record.get(node_name).get('blob').data.MergeFrom(
                concated_weights[:, split_index:(split_index + \
                current_split_index)].flatten())
            split_index += current_split_index

        LOGGER.logi('Do layers {} union weights calibration success.'.format( \
                    union_list), 'EltwiseOptWeightsCalibrationPass')

    def _packet_union_quantize_conv_weights(self,
                                            graph,
                                            union_list,
                                            data_record):
        """packet all need do union quantize conv layers' weights to 1 concated
           numpy array
        """
        # Set first node as base node to concate
        head_node_name = union_list[0]
        head_node = graph.get_node_by_name(head_node_name)
        head_node.set_attr(CALIBRATION_DONE_FLAG, True)
        # get first node blob data, and set as base concated weights
        # head_blob_info contains: head_blob, head_shape, head_dtype, head_data
        head_blob_info = get_weights_blob_info(head_node, 0, True)
        self.dump_data(head_node, head_blob_info[3])
        data_record[head_node_name] = {
            "blob": head_blob_info[0],
            "shape": head_blob_info[1],
        }
        concated_weights = np.array(head_blob_info[3], np.float64).reshape(
            head_blob_info[1][0],
            head_blob_info[1][1] * head_blob_info[1][2] * head_blob_info[1][3])

        for node_name in union_list[1:]:
            current_node = graph.get_node_by_name(node_name)
            current_node.set_attr(CALIBRATION_DONE_FLAG, True)
            # current_blob_info contains: current_blob, current_shape,
            #                             current_dtype, current_data
            current_blob_info = get_weights_blob_info(current_node, 0, True)
            current_shape = current_blob_info[1]
            self.dump_data(current_node, current_blob_info[3])
            data_record[node_name] = {
                "blob": current_blob_info[0],
                "shape": current_shape
            }
            current_weights = \
                np.array(current_blob_info[3], np.float64).reshape(
                    current_shape[0],
                    current_shape[1] * current_shape[2] * current_shape[3])

            if not is_quant_params_same([head_node_name, node_name]):
                LOGGER.logi('Union quantize node {} and {} params not ' \
                    'same'.format(head_node_name, node_name))
                return None

            if concated_weights.shape[0] != current_weights.shape[0]:
                LOGGER.logi('Union weights {}{} shape diff from {}'.format(
                    node_name, current_weights.shape, concated_weights.shape))
                return None
            concated_weights = np.concatenate(
                (concated_weights, current_weights), axis=1)
        return concated_weights