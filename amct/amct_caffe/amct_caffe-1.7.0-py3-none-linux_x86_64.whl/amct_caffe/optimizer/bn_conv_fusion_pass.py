#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

BatchNorm + Convolution fusion operation

"""
import numpy as np

from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.optimizer.conv_bn_fusion_pass import ConvBnFusionPass
from amct_caffe.operation.conv_bn_fuse import fuse_bn_conv
from amct_caffe.utils.log import LOGGER
from amct_caffe.utils.attrs_list import ATTR_NODE_FUSION_INFO
from amct_caffe.utils.attrs_list import ATTR_NODE_OUTPUT_NODE


class BnConvFusionPass(BaseFusionPass):
    """
    Function: Do "BatchNorm" layer and "Convolution" layer fusion operation
    APIs: match_pattern, do_pass, write_fused_weights_bias_back
    """
    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    @staticmethod
    def match_pattern(node):
        """
        Function: Match pattern of "Convolution" + "BatchNorm" in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type != 'BatchNorm':
            return False
        if len(node.output_anchors) != 1:
            raise RuntimeError('BatchNorm node should only have 1 output ' \
                'actually have {}'.format(len(node.output_anchors)))
        peer_input_anchors = node.get_output_anchor(0).get_peer_input_anchor()
        if len(peer_input_anchors) != 1:
            return False

        # BatchNorm + Convolution fusion only support Convolution without pad
        conv_node = peer_input_anchors[0].node
        if conv_node.type != 'Convolution' or \
            conv_node.name in Configuration().get_skip_fusion_layers():
            return False
        if conv_node.proto.convolution_param.pad_h > 0 or \
           conv_node.proto.convolution_param.pad_w > 0:
            return False
        for pad in conv_node.proto.convolution_param.pad:
            if pad > 0:
                return False

        return True

    @staticmethod
    def _get_per_group_cin_cout(conv_group, bn_shape, weights_shape):
        """Calculate Cout and Cin per group length
        """
        if len(bn_shape) != 1 or bn_shape[0] == 0:
            raise RuntimeError('BatchNorm parameters shape must be vector')
        bn_length = bn_shape[0]
        if bn_length % conv_group != 0:
            raise RuntimeError('BatchNorm length[{}] must be multiple ' \
                'of conv group[{}]'.format(bn_length, conv_group))
        cin_group_length = bn_length / conv_group
        if cin_group_length != weights_shape[1]:
            raise RuntimeError('Each group BatchNorm length[{}] should ' \
                'be equal to conv weights Cin[{}]'.format(
                    cin_group_length, weights_shape[1]))

        if weights_shape[0] % conv_group != 0:
            raise RuntimeError('Group conv weights Cout[{}] must be ' \
                'multiple of conv group[{}]'.format(
                    weights_shape[0], conv_group))
        cout_group_length = weights_shape[0] / conv_group

        return int(cout_group_length), int(cin_group_length)

    @staticmethod
    def _do_weights_bias_fuison(node_bn, node_conv):
        """
        Function: Do bn+conv weights and bias fuison
        Parameters: node_bn: "BatchNorm" node
                    node_conv: "Convolution" node
        Return: None
        """

        if len(node_bn.get_all_data()) < 3:
            raise RuntimeError('BatchNorm at least should have three blobs')
        factor_blob = node_bn.get_data(2)
        if len(factor_blob.shape.dim) != 1 or \
            factor_blob.shape.dim[0] != 1:
            raise RuntimeError('BatchNorm scale factor should be one')
        if factor_blob.data:
            scale_factor = factor_blob.data[0]
        else:
            scale_factor = factor_blob.double_data[0]

        if not node_conv.get_all_data():
            raise RuntimeError('Convolution at least should have one blob')
        blob_weights = node_conv.get_data(0)
        blob_bias = None
        if len(node_conv.get_all_data()) > 1:
            blob_bias = node_conv.get_data(1)

        mean_array, variance_array = \
            ConvBnFusionPass.get_np_array_from_bn(node_bn.get_data(0),
                                                  node_bn.get_data(1))
        weights_array, bias_array = \
            ConvBnFusionPass.get_np_array_from_conv(blob_weights, blob_bias)


        def _bn_conv_fusion_kernel(nodes, weights_array, bias_array,
                                   mean_array, variance_array):
            """Do BatchNorm and Convolution parameters fusion
            """
            node_conv = nodes[0]
            node_bn = nodes[1]
            conv_group = node_conv.proto.convolution_param.group
            per_cout, per_cin = BnConvFusionPass._get_per_group_cin_cout(
                conv_group, mean_array.shape, weights_array.shape)
            fused_weights = np.zeros(weights_array.shape, weights_array.dtype)
            fused_bias = np.zeros(weights_array.shape[0], weights_array.dtype)
            if bias_array is None:
                bias_array = np.zeros(weights_array.shape[0],
                                      weights_array.dtype)
            for i in range(conv_group):
                fused_w, fused_b = fuse_bn_conv([mean_array[i * per_cin:(i + 1) * per_cin], \
                        variance_array[i * per_cin:(i + 1) * per_cin], \
                        scale_factor, \
                        node_bn.proto.batch_norm_param.eps], \
                        [weights_array[i * per_cout:(i + 1) * per_cout, \
                        :, :, :], \
                        bias_array[i * per_cout:(i + 1) * per_cout]])
                fused_weights[i * per_cout:(i + 1) * per_cout, :, :, :, ] = fused_w
                fused_bias[i * per_cout:(i + 1) * per_cout] = fused_b
            ConvBnFusionPass.write_fused_weights_bias_back(
                node_conv, blob_weights, fused_weights.flatten(), blob_bias,
                fused_bias)

        # Consider conv maybe group conv, to uniform calculate procedure,
        # split bn params and conv params by conv group size
        _bn_conv_fusion_kernel([node_conv, node_bn], weights_array, bias_array,
                               mean_array, variance_array)

    def do_pass(self, graph, object_node):
        """
        Function: Do actual "Convolution" layer and "BatchNorm" layer
                  fusion operation
        Parameters: graph: graph structure
                    object_node: node to process
        Return: None
        """
        # Step1: remove edge of BatchNorm
        node_bn = object_node
        # remove BatchNorm node input link
        if len(node_bn.input_anchors) != 1:
            raise RuntimeError("BatchNorm should only have 1 input, " \
                "actually have {}".format(len(node_bn.input_anchors)))
        bn_peer_output_anchor = node_bn.get_input_anchor(0). \
            get_peer_output_anchor()
        graph.remove_edge(bn_peer_output_anchor.node,
                          bn_peer_output_anchor.index,
                          node_bn,
                          0)
        # remove BatchNorm node output links
        peer_anchor = node_bn.get_output_anchor(0).get_peer_input_anchor()[0]
        node_conv = peer_anchor.node
        graph.remove_edge(node_bn, 0,
                          node_conv, 0)
        # Step2: Add link from BatchNorm producer to Convolution
        graph.add_edge(bn_peer_output_anchor.node,
                       bn_peer_output_anchor.index,
                       node_conv,
                       0)
        # Step3: Do bn + conv weights/bias fusion
        self._do_weights_bias_fuison(node_bn, node_conv)
        # Step4: Record fusion info to convolution node
        if not node_conv.has_attr(ATTR_NODE_FUSION_INFO):
            node_conv.set_attr(ATTR_NODE_FUSION_INFO, [node_conv.name])
        node_conv.get_attr(ATTR_NODE_FUSION_INFO).insert(
            0, node_bn.name)
        if not node_conv.has_attr(ATTR_NODE_OUTPUT_NODE):
            node_conv.set_attr(ATTR_NODE_OUTPUT_NODE, node_conv.name)
        # Step5: Remove node of bn from graph
        LOGGER.logd('Do BN:\'{}\' + Conv:\'{}\' fuison success!'.format(
            node_bn.name, node_conv.name), 'BnConvFusionPass')
        graph.remove_node(node_bn.name)
