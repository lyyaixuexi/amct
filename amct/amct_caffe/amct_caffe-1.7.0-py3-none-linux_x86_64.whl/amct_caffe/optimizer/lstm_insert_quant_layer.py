#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert quant layer for lstm layer

"""

from amct_caffe.utils.log import LOGGER
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.configuration.check import GraphChecker
from amct_caffe.optimizer.lstm_calibration_replace import identify_lstm_state
from amct_caffe.optimizer.insert_quant_layer import InsertQuantLayerPass


class LstmInsertQuantLayerPass(BaseFusionPass):
    """
    Function: Insert quant layer before lstm layer to be quantized
    APIs: match_pattern, do_pass
    """
    def __init__(self):
        """
        Function: Init LstmInsertQuantLayerPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    @staticmethod
    def match_pattern(node):
        """
        Function: Find 'LSTM' node need to quantized in graph
        Parameters: node: node in graph
        Return: True: node that need to insert quant layer
                False: skip the node
        """
        # match config
        if node.type == 'LSTMCalibration' and \
            node.name in Configuration().get_quant_config():
            node.update_type('LSTM')
        if node.type != 'LSTM':
            return False
        if node.name not in Configuration().get_quant_config() or \
            not GraphChecker.check_quantize_type(node):
            return False
        return True

    def do_pass(self, graph, object_node):
        """
        Function: Do actual insert quant layer operation.
        Parameters: graph: graph that contains object node
                    object_node: node to process
        Return: None
        """
        static_input, _ = identify_lstm_state(object_node)

        InsertQuantLayerPass().insert_quant_layer_kernel(
            graph, object_node, '{}_X'.format(object_node.name), 0)
        # Set shape info to quant node
        if static_input:
            InsertQuantLayerPass().insert_quant_layer_kernel(
                graph, object_node, '{}_S'.format(object_node.name), 2)

        LOGGER.logd("Insert quant layer before '{}' " \
            "success!".format(object_node.name), 'LstmInsertQuantLayerPass')
