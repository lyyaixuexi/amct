#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert quant layer before layer to be quantized

"""
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.utils.log import LOGGER
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.retrain_config import RetrainConfig
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.configuration.check import GraphChecker

from amct_caffe.utils.attrs_list import ATTR_NODE_EQUIVALENT_OBJECT_LAYER
from amct_caffe.utils.attrs_list import ATTR_NODE_EQUIVALENT_INPUT
from amct_caffe.optimizer.weights_calibration import SKIP_LAYER_TYPES


class InsertQuantLayerPass(BaseFusionPass):
    """
    Function: Insert quant layer before layer to be quantized
    APIs: match_pattern, do_pass
    """
    def __init__(self, retrain=False):
        """
        Function: Init InsertQuantLayerPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.retrain = retrain
        if retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()

    def match_pattern(self, node):
        """
        Function: Find 'Convolution' or 'InnerProduct' node need to quantized
                  in graph
        Parameters: node: node in graph
        Return: True: node that need to insert quant layer
                False: skip the node
        """
        # match config
        if node.type in SKIP_LAYER_TYPES:
            return False
        if node.name not in self.conf.get_quant_config():
            return False
        if len(node.input_anchors) != 1:
            raise RuntimeError("Convolution/InnerProduct layer should only " \
                "have one input, actually is {}".format( \
                len(node.input_anchors)))
        # match type
        if not GraphChecker.check_quantize_type(node):
            return False
        return True


    def insert_quant_layer_kernel(self, graph, node, object_layer_name,
                                  input_index):
        """Kernel function of insert quant layer to node
           input[input_index]
        """
        # Step1: Generate a LayerParameter object of quant layer,
        #        and add node to graph
        quant_layer = caffe_pb2.LayerParameter()
        # Set basic info
        quant_layer.name = '{}_{}_{}'.format(node.name, input_index,
                                             'quant_layer')
        quant_layer.type = 'Quant'
        quant_layer.bottom.extend(['{}_{}'.format(quant_layer.name,
                                                  'input0')])
        quant_layer.top.extend(['{}_{}'.format(quant_layer.name,
                                               'output0')])
        # Set quantize algorithm parameters=
        act_param = self.conf.get_layer_config(node.name).get('activation_quant_params')
        if act_param is None or act_param.get('asymmetric') is None:
            quant_layer.quant_param.with_offset = self.conf.get_quant_config()['activation_offset']
        else:
            quant_layer.quant_param.with_offset = act_param.get('asymmetric')
        quant_layer.quant_param.object_layer = object_layer_name
        # Add node of quant to graph
        quant_node = graph.add_node(quant_layer)
        # Record inserted quant node info
        quant_node.set_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER,
                            node.name)
        node.set_attr(ATTR_NODE_EQUIVALENT_INPUT, quant_node.name)
        # Step2: Insert Node between target node and it's peer_output_node
        # remove link between target node and it's peer_output_node
        input_anchor = node.get_input_anchor(input_index)
        peer_output_anchor = input_anchor.get_peer_output_anchor()
        peer_node = peer_output_anchor.node
        peer_output_anchor_index = peer_output_anchor.index
        graph.remove_edge(peer_node, peer_output_anchor_index,
                          node, input_index)
        # add link from peer node to quant_node
        graph.add_edge(peer_node, peer_output_anchor_index,
                       quant_node, 0)
        # add link from quant_node to conv/fc node
        graph.add_edge(quant_node, 0, node, input_index)
        LOGGER.logd("Insert quant layer '{}' before '{}' " \
            "success!".format(quant_node.name, node.name), \
                              'InsertQuantLayerPass')
        return quant_node

    def do_pass(self, graph, object_node):
        """
        Function: Do actual insert quant layer operation.
        Parameters: graph: graph that contains object node
                    object_node: node to process
        Return: None
        """
        # Step1: Generate a LayerParameter object of quant layer,
        #        and add node to graph
        self.insert_quant_layer_kernel(
            graph, object_node, object_node.name, 0)
