#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quantize bias to int32.

"""
import numpy as np

from google.protobuf import text_format
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.configuration.configuration import Configuration
from amct_caffe.configuration.retrain_config import RetrainConfig
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.check import GraphChecker
from amct_caffe.utils.weight_quant_api import get_weights_blob_info
from amct_caffe.common.utils.record_file_operator import \
    read_weights_scale_offset
from amct_caffe.common.utils.record_file_operator import \
    read_activation_scale_offset
from amct_caffe.utils.log import LOGGER
from amct_caffe.utils.dump import Dumper


class BiasQuantizePass(BaseFusionPass):
    """
    Function: the pass to quantize pass.
    APIs: set_up, match_pattern, do_pass
    """
    def __init__(self, retrain=False):
        BaseFusionPass.__init__(self)
        self.records = caffe_pb2.ScaleOffsetRecord()
        if not retrain:
            self.conf = Configuration()
        else:
            self.conf = RetrainConfig()

    @staticmethod
    def get_scale_for_bias_quantize(records, object_node, bias_length):
        """get scale for bias quantize """
        if object_node.type == 'LSTMQuant':
            scale_w, _ = read_weights_scale_offset(records, '{}_X'.format(
                object_node.name))
            scale_w_array = np.zeros((4, bias_length // 4), np.float64)
            for index in range(4):
                scale_w_array[index, :] = scale_w[index]
            scale_w = (scale_w_array.flatten()).tolist()
            scale_d, _ = read_activation_scale_offset(records, '{}_X'.format(
                object_node.name))
        else:
            scale_w, _ = read_weights_scale_offset(records, object_node.name)
            scale_d, _ = read_activation_scale_offset(
                records, object_node.name)
        return scale_d, scale_w

    @staticmethod
    def quantize_bias(object_node, float_bias, float_scale):
        """
        Function: quantize bias.
        Inputs:
            float_bias: the bias to be quantized.
            float_scale: the deq_scale.
        Returns:
            int_bias: the bias quantized.
        """
        int_bias = round(float_bias / float_scale)
        left_bound = -2**31
        right_bound = 2**31-1
        if int_bias < left_bound or int_bias > right_bound:
            LOGGER.loge('Quantized bias {} of layer "{}" exceed int32 ' \
                'range:[{}, {}], please add it to skip layer.'.format(
                    int_bias, object_node.name,
                    left_bound, right_bound))
            raise RuntimeError('Do bias quantize failed.')
        return int_bias

    def do_pass(self, graph, object_node):
        """
        Function: do quantize operation.
        Inputs:
            graph: IR Graph, the graph to be quantized.
            object_node: node to process
        Returns: None
        """
        # find bias_blob
        bias_blob, _, _, bias_data = get_weights_blob_info(
            object_node, 1, True)
        # read information for quantization
        scale_d, scale_w = self.get_scale_for_bias_quantize(
            self.records, object_node, len(bias_data))

        if len(scale_w) != 1 and len(bias_data) != len(scale_w):
            raise RuntimeError("The scale_w's length[{}] cannot match bias' "\
                "length[{}].".format(len(scale_w), len(bias_data)))
        deq_scale = [item * scale_d for item in scale_w]
        # Dump bias before quantize
        dumper = Dumper('{}_bias.log'.format(object_node.name))
        dumper.dumpd(['bias before quantize:'])
        dumper.dumpd(bias_data, len(bias_data))

        # quantize the bias to range of int32
        if len(deq_scale) == 1:
            quant_bias = [self.quantize_bias(object_node, bias, deq_scale[0])
                          for bias in bias_data]
        else:
            quant_bias = [self.quantize_bias(object_node, bias_data[index], \
                          deq_scale[index]) \
                          for index in range(len(deq_scale))]

        # save quant_bias in blob
        quant_bias = np.array(quant_bias, np.int32)
        bias_blob.int32_data.MergeFrom(quant_bias.tolist())
        dumper.dumpd(['bias after quantize:'])
        dumper.dumpd(bias_blob.int32_data, len(bias_blob.int32_data))

        LOGGER.logd('Do layer:\'{}\' bias quantize success!'\
                    .format(object_node.name), 'BiasQuantizePass')

    def match_pattern(self, node):
        """
        Function: Find the layer to be quantized.
        Inputs:
            node: the node to be matched.
        Returns: None
        """
        # match type
        if node.type != 'LSTMQuant' and \
            not GraphChecker.check_quantize_type(node):
            return False
        # match config
        if node.name not in self.conf.get_quant_config():
            return False
        # match bias_blob
        if len(node.get_all_data()) < 2:
            return False

        return True

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.conf.get_record_file_path(), 'r') as record_file:
            pbtxt_string = record_file.read()
            text_format.Merge(pbtxt_string, self.records)
