#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Do lstm quantize weight by calibration.

"""
import numpy as np
from google.protobuf import text_format
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.configuration.check import GraphChecker
from amct_caffe.utils.weight_quant_api import weight_calibration_np
from amct_caffe.utils.weight_quant_api import weight_calibration_blob
from amct_caffe.utils.weight_quant_api import write_back_weight_blob
from amct_caffe.utils.log import LOGGER
from amct_caffe.utils.dump import Dumper
from amct_caffe.utils.dump import DUMPER_DICT
from amct_caffe.common.utils.record_file_operator import \
    record_weights_scale_offset
from amct_caffe.optimizer.lstm_calibration_replace import identify_lstm_state
from amct_caffe.utils.weight_quant_api import get_weights_blob_info


class LstmWeightsCalibrationPass(BaseFusionPass):
    """
    Function: the pass to quantize lstm layer's weights by Calibration.
    APIs: set_up, tear_down, match_pattern, do_pass
    """
    def __init__(self):
        BaseFusionPass.__init__(self)
        self.records = caffe_pb2.ScaleOffsetRecord()
        self.records_file_path = Configuration().get_record_file_path()

    @staticmethod
    def match_pattern(node):
        """
        Function: Find the layer to be quantized.
        Inputs:
            node: the node to be matched.
        Returns: None
        """
        # match type
        if node.type != 'LSTM':
            return False
        if not GraphChecker.check_quantize_type(node) or \
            node.name not in Configuration().get_quant_config():
            return False
        return True

    @staticmethod
    def _concat_weights_x_h(weights_x_data, weights_x_shape,
                            weights_h_data, weights_h_shape):
        """Do weights_x and weights_h concatenate in last dimension
        """
        if len(weights_x_shape) != 2 or len(weights_h_shape) != 2:
            raise RuntimeError('weights_x, weights_h should be 2 dims shape')
        if weights_x_shape[0] != weights_h_shape[0] or \
            weights_x_shape[0] % 4 != 0:
            raise RuntimeError(' weights_x and weights_h should be sampe ' \
                'in cout dim, and cout should can be exact division by 4')
        weights_x_array = (np.array(weights_x_data, np.float64))
        weights_x_array = weights_x_array.reshape((
            4, 1, weights_x_shape[0] // 4, weights_x_shape[1]))
        weights_h_array = (np.array(weights_h_data, np.float64))
        weights_h_array = weights_h_array.reshape((
            4, 1, weights_h_shape[0] // 4, weights_h_shape[1]))
        concated_weights_x = np.concatenate((weights_x_array, weights_h_array),
                                            axis=3)
        return concated_weights_x

    @staticmethod
    def _get_wts_param(node):
        # get weights' information for quantization
        layer_config = Configuration().get_layer_config(node.name)
        wts_param = layer_config.get('weight_quant_params')
        wts_param['channel_wise'] = True
        return wts_param

    @staticmethod
    def dumper_kernel(dump_name, dump_data):
        """Dumpe weights before quantize
        """
        DUMPER_DICT['{}'.format(dump_name)] = Dumper('{}.log'.format(
            dump_name))
        DUMPER_DICT.get('{}'.format(dump_name)).\
            dumpd(['weights before quantize:'])
        DUMPER_DICT.get('{}'.format(dump_name)).\
            dumpd(dump_data, len(dump_data))

    def do_pass(self, graph, object_node):
        """
        Function: do quantize operation.
        Inputs:
            graph: IR Graph, the graph to be quantized.
            object_node: node to process
        Returns: None
        """
        # get lstm node status
        static_input, _ = identify_lstm_state(object_node)
        # find weights_blob
        # LSTM layer blobs [weights_x, bias, weights_static, weights_h]
        weights_x_blob, weights_x_shape, weights_x_dtype, weights_x_data = \
            get_weights_blob_info(object_node, 0, False)
        weights_h_blob, weights_h_shape, weights_h_dtype, weights_h_data = \
            get_weights_blob_info(object_node, 3 if static_input else 2, False)
        if weights_x_dtype != weights_h_dtype:
            raise RuntimeError('Dtype in single node must be same, but in ' \
                'node {} x is {}, h is {}'.format( \
                object_node.name, weights_x_dtype, weights_h_dtype))
        self.dumper_kernel(
            '{}_weights_x'.format(object_node.name), weights_x_data)
        self.dumper_kernel(
            '{}_weights_h'.format(object_node.name), weights_h_data)
        # concate lstm layer's weights x and weights h to do union calibration
        concated_x = self._concat_weights_x_h(
            weights_x_data, weights_x_shape, weights_h_data, weights_h_shape)

        self._calibration_kernel(object_node, concated_x)
        # split united weights to weights x and weights h, and write back
        write_back_weight_blob(weights_x_blob, weights_x_dtype, \
            (concated_x[:, :, :, :weights_x_shape[1]]).flatten())
        write_back_weight_blob(weights_h_blob, weights_h_dtype, \
            (concated_x[:, :, :, weights_x_shape[1]:]).flatten())

        if static_input:
            self._static_input_weighs_calibration(object_node, self.records)

        LOGGER.logd('Do layer \'{}\' weights calibration success!' \
                    .format(object_node.name), 'LstmWeightsCalibrationPass')

    def set_up(self):
        """
        Function: get the scale and offset record from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.records_file_path, 'r') as read_file:
            pbtxt_string = read_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def tear_down(self):
        """
        Function: write the scale and offset to Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.records_file_path, "w") as write_file:
            write_file.write(text_format.MessageToString(
                self.records, as_utf8=True))

    def _calibration_kernel(self, object_node, concated_x):
        """do weights calibration and save record scale, offset"""
        scale, offset = weight_calibration_np(concated_x,
                                              self._get_wts_param(object_node))
        record_weights_scale_offset(
            self.records, '{}_X'.format(object_node.name), scale, offset)
        record_weights_scale_offset(
            self.records, '{}_H'.format(object_node.name), scale, offset)

    def _static_input_weighs_calibration(self, node, records):
        """Do lstm layer static_input's weights calibration
        """
        weights_s_blob, weights_s_shape, weights_s_dtype, weights_s_data = \
            get_weights_blob_info(node, 2, False)
        if weights_s_shape[0] % 4 != 0:
            raise RuntimeError('weights_s_shape[0]:{} should can be ' \
                'exact division by 4.'.format(weights_s_shape[0]))
        self.dumper_kernel(
            '{}_weights_s'.format(node.name), weights_s_data)
        weights_s_shape = (4, 1, weights_s_shape[0] // 4,
                           weights_s_shape[1])
        scale, offset = weight_calibration_blob(weights_s_blob, \
            weights_s_shape, weights_s_dtype, weights_s_data, \
            self._get_wts_param(node))

        record_weights_scale_offset(
            records, '{}_S'.format(node.name), scale, offset)
