#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

insert ifmr layer for Concat joint quant optimize convolution layer.

"""

from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.utils.log import LOGGER
from amct_caffe.configuration.check import GraphChecker
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.optimizer.insert_act_calibration_layer import InsertActCalibrationLayerPass
from amct_caffe.optimizer.insert_act_calibration_layer import INSERT_ACT_CALI_DONE_FLAG
from amct_caffe.optimizer.weights_calibration import SKIP_LAYER_TYPES


class ConcatJointQuantOptiPass(BaseFusionPass):
    """
    Function: Insert ifmr layer couple with layer to be quantized
    APIs: match_pattern, do_pass
    """
    def __init__(self):
        """
        Function: Init ConcatJointQuantOptiPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self._joint_list = {}

    @staticmethod
    def _match_single_node(node):
        """match single quantizable node
        """
        if node.type in SKIP_LAYER_TYPES or \
            not GraphChecker.check_quantize_type(node):
            return False
        # match config
        if node.name not in Configuration().get_quant_config() or \
            node.has_attr(INSERT_ACT_CALI_DONE_FLAG):
            return False
        return True

    @staticmethod
    def is_quant_params_same(node_names):
        """ check whether the input quant params the same
        """
        if len(node_names) <= 1:
            return True
        head_node_name = node_names[0]

        # get activation quantize information for quantization
        head_layer_config = Configuration().get_layer_config(
            head_node_name)
        head_act_param = head_layer_config.get('activation_quant_params')

        for node_name in node_names[1:]:
            layer_config = Configuration().get_layer_config(node_name)
            act_param = layer_config.get('activation_quant_params')
            # if param not the same skip this pass
            if head_act_param != act_param:
                LOGGER.logi('Unable to do concat optimize layer {} and {} ' \
                            ' with different quant params'.format( \
                            head_node_name, \
                            node_name),
                            'ConcatJointQuantOptiPass')
                return False
        return True

    def match_pattern(self, node):
        """
        Function: Find quantizable node need to do concat optimize insert IFMR
                  layer in graph
        Parameters: node: node in graph
        Return: True: node that need to insert ifmr layer
                False: skip the node
        """
        if not self._match_single_node(node):
            return False

        try:
            producer = node.get_input_anchor(0).get_peer_output_anchor().node
        except (RuntimeError, AttributeError):
            LOGGER.logd('Cannot get producer of %s' % node.name, 'ConcatJointQuantOptiPass')
            return False
        # find producer of current node, if Concat then do optimize
        if producer.type != 'Concat':
            return False
        concat_producers = (input_anchor.get_peer_output_anchor().node \
                            for input_anchor in producer.input_anchors)

        joint_list = self.find_brother_ops(node, producer, concat_producers)
        if len(joint_list) > 1 and self.is_quant_params_same([node.name for node in joint_list]):
            self._joint_list[node.name] = joint_list
            LOGGER.logd('Find brother_op of "{}" {} can do joint quant.'.format(
                node.name, [brother_op.name for brother_op in joint_list]), 'ConcatJointQuantOptiPass')
            return True
        return False

    def do_pass(self, graph, object_node):
        """Do ConcatJointQuantOptiPass optimize
        """
        LOGGER.logd('Now do optimize for node:"%s"' % object_node.name, 'ConcatJointQuantOptiPass')
        union_nodes = self._joint_list.get(object_node.name)
        for node in union_nodes:
            if node.has_attr(INSERT_ACT_CALI_DONE_FLAG):
                LOGGER.logi('Node {} in concat joint list {} already done.'.format(
                    node.name, [node.name for node in union_nodes]))
                return
        union_layers = [node.name for node in union_nodes]
        union_config_layer_name = union_nodes[0].name

        quant_config = Configuration().get_layer_config(union_config_layer_name)
        act_config = quant_config['activation_quant_params']
        act_algo = act_config.get('act_algo', 'ifmr')
        if act_algo == 'hfmg':
            act_cali_node = InsertActCalibrationLayerPass.generate_hfmg_node(
                graph, union_layers, union_config_layer_name)
        else:
            act_cali_node = InsertActCalibrationLayerPass.generate_ifmr_node(
                graph, union_layers, union_config_layer_name)

        act_cali_input_index = 0
        for quant_node in union_nodes:
            quant_node.set_attr(INSERT_ACT_CALI_DONE_FLAG, True)
            input_anchor = quant_node.get_input_anchor(0)
            peer_output_anchor = input_anchor.get_peer_output_anchor()

            graph.add_edge(
                peer_output_anchor.node,
                peer_output_anchor.index,
                act_cali_node,
                act_cali_input_index)
            act_cali_input_index += 1
            LOGGER.logd(
                "Insert {} layer '{}' to '{}' success!".format(
                    act_algo,
                    act_cali_node.name,
                    quant_node.name),
                'ConcatJointQuantOptiPass')
        LOGGER.logi('Insert {} node {} to union layers {} success.'.format(
            act_algo, act_cali_node.name, union_layers), 'ConcatJointQuantOptiPass')

    def find_brother_ops(self, node, producer, concat_producers):
        """Find quantizable brother op by producer "concat"
        """
        brother_ops = []
        for concat_producer in concat_producers:
            brother_ops.extend(
                [peer_anchor.node for peer_anchor in concat_producer.get_output_anchor(0).get_peer_input_anchor()])
        joint_list = [node]
        for brother_op in brother_ops:
            if brother_op != producer:
                if not self._match_single_node(brother_op):
                    LOGGER.logd('Exist unsupport quantize node %s in concat joint of "%s"'
                                % (brother_op.name, producer.name))
                    return []
                joint_list.append(brother_op)
        return joint_list
