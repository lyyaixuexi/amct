#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

insert searchN layer for eltwise optimize convolution layer.

"""

from amct_caffe.configuration.configuration import Configuration
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.optimizer.insert_searchn_layer import InsertSearchNLayerPass
from amct_caffe.optimizer.eltwise_opt_weights_calibration import \
    EltwiseOptWeightsCalibrationPass
from amct_caffe.utils.log import LOGGER

from amct_caffe.optimizer.insert_searchn_layer import INSERT_SEARCHN_DONE_FLAG


class EltwiseOptInsertSearchNLayerPass(BaseFusionPass):
    """
    Function: Insert searchN layer couple with layer to be quantized
    APIs: match_pattern, do_pass
    """
    def __init__(self):
        """
        Function: Init EltwiseOptInsertSearchNLayerPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    def do_pass(self, graph, union_list): # pylint: disable=W0221
        union_nodes = \
            [graph.get_node_by_name(node_name) for node_name in union_list]


        union_config_layer_name = graph.get_node_by_name(union_list[0]).name
        quant_config = Configuration().get_layer_config(union_config_layer_name)
        act_config = quant_config['activation_quant_params']
        act_algo = act_config.get('act_algo', 'ifmr')

        search_n_type = None
        if act_algo == 'hfmg':
            searchn_node = InsertSearchNLayerPass.generate_search_n_v2_node(
                graph, union_nodes)
            search_n_type = 'SearchNV2'
        else:
            searchn_node = InsertSearchNLayerPass.generate_search_n_node(
                graph, union_nodes)
            search_n_type = 'SearchN'
        searchn_node_input_index = 0
        for quant_node in union_nodes:
            quant_node.set_attr(INSERT_SEARCHN_DONE_FLAG, True)
            quant_output_anchor = quant_node.get_output_anchor(0)

            graph.add_edge(
                quant_output_anchor.node,
                quant_output_anchor.index,
                searchn_node,
                searchn_node_input_index)
            searchn_node_input_index += 1
        if act_algo == 'hfmg':
            object_node = union_nodes[0]
            if not object_node.has_attr("act_cali_layer_name"):
                raise ValueError("Cannot find attr act_cali_layer_name in node {}".format(object_node.name))
            act_cali_layer_name = object_node.get_attr("act_cali_layer_name")
            act_cali_node = graph.get_node_by_name(act_cali_layer_name)
            graph.add_edge(act_cali_node, 0, searchn_node, searchn_node_input_index)

        LOGGER.logi(
            "Insert {} layer '{}' to {} success!".format(
                search_n_type, searchn_node.name, union_list),
            'EltwiseOptInsertSearchNLayerPass')

    def run(self, graph):
        union_lists = []
        for node in graph.nodes:
            union_list = EltwiseOptWeightsCalibrationPass.match_pattern(
                node, '{}_{}'.format(INSERT_SEARCHN_DONE_FLAG, node.index))
            if union_list is not None:
                union_lists.append(union_list)
        for union_list in union_lists:
            self.do_pass(graph, union_list)
        graph.topologic_sort()
