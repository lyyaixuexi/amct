#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

reflash top name of quantizable node

"""

from amct_caffe.configuration.check import GraphChecker
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.configuration.retrain_config import RetrainConfig
from amct_caffe.optimizer.weights_calibration import SKIP_LAYER_TYPES



class ReflashTopNamePass(BaseFusionPass):
    """
    Function: reflash top name of quantizable node
    APIs: match_pattern, do_fusion
    """
    def __init__(self, is_retrain):
        """
        Function: Init ReflashTopNamePass object
        Parameters: None
        Return: None
        """
        self.is_retrain = is_retrain
        BaseFusionPass.__init__(self)



    def match_pattern(self, node):
        """
        Function: Find 'Convolution' or 'InnerProduct' node need to reflash top
                  name
        Parameters: node: node in graph
        Return: True: node that need to reflash top name
                False: skip the node
        """
        # match type
        if node.type in SKIP_LAYER_TYPES:
            return False
        if not GraphChecker.check_quantize_type(node):
            return False
        # match config
        if not self.is_retrain:
            if node.name not in Configuration().get_quant_config():
                return False
        else:
            if node.name not in RetrainConfig().get_quant_config():
                return False
        return True

    def do_pass(self, graph, object_node):
        """
        Function: reflash top name
        Parameters: graph: graph that contains object node
                    object_node: node to process
        Return: None
        """
        searchn_suffix = "_search_n_no_inplace"
        output_anchor = object_node.get_output_anchor(0)
        output_name = output_anchor.name
        if output_name.endswith(searchn_suffix):
            output_anchor.set_name(output_name[:-len(searchn_suffix)])
