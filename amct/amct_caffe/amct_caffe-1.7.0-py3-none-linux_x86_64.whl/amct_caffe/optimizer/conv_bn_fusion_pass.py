#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Convolution + BatchNorm fusion operation

"""
import numpy as np
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.configuration.check import GraphChecker
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.configuration.retrain_config import RetrainConfig
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.utils.log import LOGGER
from amct_caffe.operation.conv_bn_fuse import fuse_conv_bn
from amct_caffe.utils.attrs_list import ATTR_NODE_FUSION_INFO
from amct_caffe.utils.attrs_list import ATTR_NODE_OUTPUT_NODE

CONV_BN_FUSION_TYPES = ['Convolution', 'Deconvolution']


class ConvBnFusionPass(BaseFusionPass):
    """
    Function: Do "Convolution" layer and "BatchNorm" layer fusion operation
    APIs: match_pattern, do_pass, get_np_array_from_conv,
          get_np_array_from_bn, write_fused_weights_bias_back
    """
    def __init__(self, retrain=False):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        if retrain:
            self.conf = RetrainConfig()
        else:
            self.conf = Configuration()

    @staticmethod
    def write_fused_weights_bias_back(node,
                                      blob_weights,
                                      fused_weights,
                                      blob_bias,
                                      fused_bias):
        """
        Function: Write fused weights, bias to node
        Parameters: node: target node to write fused weights, bias back
                    blob_weights: weights that in caffe_proto.blob format
                    fused_weights: fused weights that in numpy.array format
                    blob_bias: bias that in caffe_proto.blob format
                    fused_bias: fused bias that in numpy.array format
        Return: None
        """
        dtype = 'data'
        if blob_weights.data:
            blob_weights.data[:] = fused_weights.flatten().tolist()
        else:
            dtype = 'double_data'
            blob_weights.double_data[:] = fused_weights.flatten().tolist()

        if fused_bias is not None:
            fused_bias_data = fused_bias.flatten().tolist()
            if blob_bias is not None:
                if blob_bias.data:
                    blob_bias.data[:] = fused_bias_data
                else:
                    blob_bias.double_data[:] = fused_bias_data
            else:
                blob_bias = caffe_pb2.BlobProto()
                blob_bias.shape.dim.MergeFrom([len(fused_bias_data)])
                if dtype == 'data':
                    blob_bias.data.MergeFrom(fused_bias_data)
                else:
                    blob_bias.double_data.MergeFrom(fused_bias_data)
                node.add_data(blob_bias)
                if node.type in CONV_BN_FUSION_TYPES:
                    node.proto.convolution_param.bias_term = True
                elif node.type == 'InnerProduct':
                    node.proto.inner_product_param.bias_term = True
                else:
                    raise TypeError('Not support do type "{}" write weights, '
                                    'bias back.'.format(node.type))

    @staticmethod
    def get_np_array_from_conv(blob_weights, blob_bias):
        """
        Function: Trans weights and bias from caffe_proto.blob to numpy.array
        Parameters: blob_weights: weights that in caffe_proto.blob format
                    blob_bias: bias that in caffe_proto.blob format
        Return: weights_array： weights that in numpy.array format
                bias_array: bias that in numpy.array format
        """
        # Get array of weights from blob
        if len(GraphChecker.get_blob_shape(blob_weights)) != 4:
            raise RuntimeError("Convolution weights\' shape should be " \
                "4 dims: N,C,H,W")
        weights_array = None
        if blob_weights.data:
            weights_array = np.array(blob_weights.data, dtype=np.float32)
        elif blob_weights.double_data:
            weights_array = np.array(blob_weights.double_data,
                                     dtype=np.float64)
        else:
            raise RuntimeError('Cannot find data in weights blob')
        weights_array.shape = tuple(GraphChecker.get_blob_shape(blob_weights))
        # Get array of bias from blob
        bias_array = None
        if blob_bias is not None:
            if len(blob_bias.shape.dim) != 1:
                raise RuntimeError("Convolution bias\' shape should be " \
                    "1 dims: N")
            if blob_bias.data:
                bias_array = np.array(blob_bias.data, dtype=np.float32)
            elif blob_bias.double_data:
                bias_array = np.array(blob_bias.double_data, dtype=np.float64)
            else:
                raise RuntimeError('Cannot find data in bias blob')
            bias_array.shape = tuple(blob_bias.shape.dim)

        return weights_array, bias_array

    @staticmethod
    def get_np_array_from_bn(blob_mean, blob_variance):
        """
        Function: Trans mean and variance from caffe_proto.blob to numpy.array
        Parameters: blob_mean: mean that in caffe_proto.blob format
                    blob_variance: variance that in caffe_proto.blob format
        Return: mean_array mean that in numpy.array format
                variance_array: variance that in numpy.array format
        """
        # Get array of mean from blob
        if len(blob_mean.shape.dim) != 1:
            raise RuntimeError('BatchNorm mean\' shape should be [N]')
        mean_array = None
        if blob_mean.data:
            mean_array = np.array(blob_mean.data, dtype=np.float32)
        elif blob_mean.double_data:
            mean_array = np.array(blob_mean.double_data, dtype=np.float64)
        else:
            raise RuntimeError('Cannot find data in mean blob')
        mean_array.shape = tuple(blob_mean.shape.dim)
        # Get array of variance from blob
        if len(blob_variance.shape.dim) != 1:
            raise RuntimeError('BatchNorm variance\' shape should be [N]')
        variance_array = None
        if blob_variance.data:
            variance_array = np.array(blob_variance.data, dtype=np.float32)
        elif blob_variance.double_data:
            variance_array = np.array(blob_variance.double_data,
                                      dtype=np.float64)
        else:
            raise RuntimeError('Cannot find data in variance blob')
        variance_array.shape = tuple(blob_variance.shape.dim)

        return mean_array, variance_array

    @staticmethod
    def __do_weights_bias_fuison(node_conv, node_bn):
        """
        Function: Do conv+bn weights and bias fuison
        Parameters: node_conv: "Convolution" node
                    node_bn: "BatchNorm" node
        Return: None
        """
        if not node_conv.get_all_data():
            raise RuntimeError('%s at least should have one blob' %
                               (node_conv.type))
        blob_weights = node_conv.get_data(0)
        blob_bias = None
        if len(node_conv.get_all_data()) > 1:
            blob_bias = node_conv.get_data(1)

        if len(node_bn.get_all_data()) < 3:
            raise RuntimeError('BatchNorm at least should have three blobs')
        blob_scale_factor = node_bn.get_data(2)
        if len(blob_scale_factor.shape.dim) != 1 or \
            blob_scale_factor.shape.dim[0] != 1:
            raise RuntimeError('BatchNorm scale factor should be one')
        if blob_scale_factor.data:
            scale_factor = blob_scale_factor.data[0]
        else:
            scale_factor = blob_scale_factor.double_data[0]
        epsilon = node_bn.proto.batch_norm_param.eps

        weights_array, bias_array = \
            ConvBnFusionPass.get_np_array_from_conv(blob_weights, blob_bias)
        mean_array, variance_array = \
            ConvBnFusionPass.get_np_array_from_bn(node_bn.get_data(0),
                                                  node_bn.get_data(1))
        if node_conv.type == 'Deconvolution':
            weights_array = adjust_deconv_weight_shape(node_conv,
                                                       weights_array)
        fused_weights, fused_bias = \
            fuse_conv_bn([weights_array, bias_array],
                         [mean_array, variance_array, scale_factor, epsilon])
        if node_conv.type == 'Deconvolution':
            fused_weights = adjust_deconv_weight_shape(node_conv,
                                                       fused_weights)

        weights_shape = GraphChecker.get_blob_shape(blob_weights)

        fused_weights.shape = (weights_shape[3] *
                               weights_shape[2] *
                               weights_shape[1] *
                               weights_shape[0])
        if node_conv.type == 'Convolution':
            fused_bias.shape = (weights_shape[0])
        elif node_conv.type == 'Deconvolution':
            fused_bias.shape = (fused_bias.size)

        ConvBnFusionPass.write_fused_weights_bias_back(node_conv, \
            blob_weights, fused_weights, blob_bias, fused_bias)

    def do_pass(self, graph, object_node): # pylint: disable=R0914
        """
        Function: Do actual "Convolution" layer and "BatchNorm" layer
                  fusion operation
        Parameters: graph: graph structure
                    object_node: node to process
        Return: None
        """
        # Step1: remove edge of BatchNorm
        node_bn = object_node
        # remove output links
        if len(node_bn.output_anchors) != 1:
            raise RuntimeError("BatchNorm should only have 1 output, " \
                "actually have {}".format(len(node_bn.output_anchors)))
        bn_peer_input_anchors = node_bn.get_output_anchor(0). \
            get_peer_input_anchor()
        bn_peer_input_nodes = []
        bn_peer_input_indexes = []
        for input_anchor in bn_peer_input_anchors:
            bn_peer_input_nodes.append(input_anchor.node)
            bn_peer_input_indexes.append(input_anchor.index)
        for index, element in enumerate(bn_peer_input_nodes):
            graph.remove_edge(node_bn, 0, element,
                              bn_peer_input_indexes[index])
        # remove input links
        if len(node_bn.input_anchors) != 1:
            raise RuntimeError("BatchNorm should only have 1 output, " \
                "actually have {}".format(len(node_bn.input_anchors)))
        bn_input_anchor = node_bn.get_input_anchor(0)
        bn_peer_output_anchor = bn_input_anchor.get_peer_output_anchor()
        node_conv = bn_peer_output_anchor.node
        bn_peer_output_anchor_index = bn_peer_output_anchor.index
        if bn_peer_output_anchor_index != 0:
            raise RuntimeError('Conv or deconv output index should be 0, ' \
                'actually is ', bn_peer_output_anchor_index)
        graph.remove_edge(node_conv, 0, node_bn, 0)
        # Step3: Add link from conv to bn_peer_input_node
        for index, element in enumerate(bn_peer_input_nodes):
            graph.add_edge(node_conv, 0, element,
                           bn_peer_input_indexes[index])
        # Step4: Do conv + bn weights/bias fusion
        ConvBnFusionPass.__do_weights_bias_fuison(node_conv, node_bn)
        # Step5: Record fusion info to convolution node
        if not node_conv.has_attr(ATTR_NODE_FUSION_INFO):
            node_conv.set_attr(ATTR_NODE_FUSION_INFO, [node_conv.name])
        node_conv.get_attr(ATTR_NODE_FUSION_INFO).append(node_bn.name)
        node_conv.set_attr(ATTR_NODE_OUTPUT_NODE, node_bn.name)

        # Step6: set the conv output anchor name  with BN's input anchor name
        bn_output_name = node_bn.get_output_anchor(0).name
        node_conv.get_output_anchor(0).set_name(bn_output_name)
        # Step7: Remove node of bn from graph
        type_map = {"Convolution": "conv", "Deconvolution": "deconv"}
        LOGGER.logd(
            'Do {}:\'{}\' + bn:\'{}\' fuison success!'.format(
                type_map.get(node_conv.type), node_conv.name, node_bn.name),
            'ConvBnFusionPass')

        graph.remove_node(node_bn.name)

    def match_pattern(self, node):
        """
        Function: Match pattern of "Convolution" + "BatchNorm" in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type != 'BatchNorm':
            return False
        if len(node.input_anchors) != 1:
            raise RuntimeError('BatchNorm node should only have 1 output ' \
                'actually have {}'.format(len(node.input_anchors)))
        peer_output_anchor = node.get_input_anchor(0).get_peer_output_anchor()
        conv_node = peer_output_anchor.node
        # If do Conv + BN fusion, conv must can only output to bn
        if len(conv_node.output_anchors) != 1 or \
            len(conv_node.get_output_anchor(0).get_peer_input_anchor()) != 1:
            return False
        if conv_node.type not in CONV_BN_FUSION_TYPES or \
            conv_node.name in self.conf.get_skip_fusion_layers():
            return False
        return True


def adjust_deconv_weight_shape(node_deconv, weights_array):
    """Adjust deconv's weights' shape to fit fuse_conv_bn function """
    group = node_deconv.proto.convolution_param.group

    weight_shape = weights_array.shape
    new_shape = tuple([group, -1] + list(weight_shape)[1:])
    weights_array = np.reshape(weights_array, new_shape)

    weights_array = np.transpose(weights_array, (0, 2, 1, 3, 4))

    weight_shape = weights_array.shape
    new_shape = tuple([-1] + list(weight_shape)[2:])
    weights_array = np.reshape(weights_array, new_shape)

    return weights_array
