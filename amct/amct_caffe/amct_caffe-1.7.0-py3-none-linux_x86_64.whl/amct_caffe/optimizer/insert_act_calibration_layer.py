#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert ifmr/hfmg layer couple with layer to be quantized

"""
try:
    from caffe.proto import caffe_pb2
except ImportError:
    import caffe_pb2

from amct_caffe.configuration.check import GraphChecker
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.utils.log import LOGGER
from amct_caffe.optimizer.weights_calibration import SKIP_LAYER_TYPES

INSERT_ACT_CALI_DONE_FLAG = 'eltwise_opt_insert_ifmr'


class InsertActCalibrationLayerPass(BaseFusionPass):
    """
    Function: Insert ifmr/hfmg layer couple with layer to be quantized
    APIs: match_pattern, do_fusion
    """
    def __init__(self, need_dump=False, dump_dir=''):
        """
        Function: Init InsertActCalibrationLayerPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.need_dump = need_dump
        self.dump_dir = dump_dir

    @staticmethod
    def match_pattern(node):
        """
        Function: Find 'Convolution' or 'InnerProduct' node need to insert
                IFMR/HFMG layer in graph
        Parameters: node: node in graph
        Return: True: node that need to insert ifmr/hfmg layer
                False: skip the node
        """
        # match type
        if node.type in SKIP_LAYER_TYPES:
            return False
        if not GraphChecker.check_quantize_type(node):
            return False
        # match config
        if node.name not in Configuration().get_quant_config():
            return False
        if node.has_attr(INSERT_ACT_CALI_DONE_FLAG):
            return False
        return True

    @staticmethod
    def generate_ifmr_node(graph,
                           object_layers,
                           config_layer_name,
                           node_index=None,
                           need_dump=False,
                           dump_dir=''):
        """
        Function: Genereate IFMR node according to input parameters
        Parameters: graph: graph that add IFMR node to
                    object_layers: layer that add IFMR node for
                    config_layer_name: name for get quantize parameter
                                       from config
        Return: ifmr_node: generated IFMR node
        """
        if not isinstance(object_layers, list) or not object_layers:
            raise RuntimeError('Input object_layers must be a non-empty list')
        if node_index is not None and len(object_layers) != 1:
            raise RuntimeError("When inserted at specified position, " \
                "ifmr node can only has one input.")

        ifmr_layer = caffe_pb2.LayerParameter()
        # Set basic info
        ifmr_layer.name = "{}_{}".format('_'.join(object_layers), 'ifmr_layer')
        ifmr_layer.type = 'IFMR'
        for index, _ in enumerate(object_layers):
            ifmr_layer.bottom.extend(["{}_input{}".format(
                ifmr_layer.name, index)])
        # Set quantize algorithm parameters
        quant_config = Configuration().get_layer_config(config_layer_name)
        act_config = quant_config['activation_quant_params']

        ifmr_layer.ifmr_param.batch_num = act_config['batch_num']
        ifmr_layer.ifmr_param.with_offset = act_config['with_offset']
        # only auto calibration need to dump ifmr stored data
        ifmr_layer.ifmr_param.need_dump = need_dump
        ifmr_layer.ifmr_param.dump_dir = dump_dir

        ifmr_layer.ifmr_param.search_range_start = \
            act_config['search_range_start']
        ifmr_layer.ifmr_param.search_range_end = act_config['search_range_end']
        ifmr_layer.ifmr_param.search_step = act_config['search_step']
        ifmr_layer.ifmr_param.max_percentile = act_config['max_percentile']
        ifmr_layer.ifmr_param.min_percentile = act_config['min_percentile']

        ifmr_layer.ifmr_param.object_layer[:] = object_layers
        ifmr_layer.ifmr_param.record_file_path = \
            Configuration().get_record_file_path()
        # Add node of IFMR to graph
        ifmr_node = graph.add_node(ifmr_layer, node_index)
        return ifmr_node


    @staticmethod
    def generate_hfmg_node(graph,
                           object_layers,
                           config_layer_name,
                           node_index=None,
                           need_dump=False,
                           dump_dir=''):
        """
        Function: Genereate HFMG node according to input parameters
        Parameters: graph: graph that add HFMG node to
                    object_layers: layer that add HFMG node for
                    config_layer_name: name for get quantize parameter
                                       from config
        Return: hfmg_node: generated HFMG node
        """
        if not isinstance(object_layers, list) or not object_layers:
            raise RuntimeError('Input object_layers must be a non-empty list')
        if node_index is not None and len(object_layers) != 1:
            raise RuntimeError("When inserted at specified position, " \
                "hfmg node can only has one input.")

        hfmg_layer = caffe_pb2.LayerParameter()
        # Set basic info
        hfmg_layer.name = "{}_{}".format('_'.join(object_layers), 'hfmg_layer')
        hfmg_layer.type = 'HFMG'
        for index, _ in enumerate(object_layers):
            hfmg_layer.bottom.extend(["{}_input{}".format(
                hfmg_layer.name, index)])
        hfmg_layer.top.extend(["{}_output_0".format(hfmg_layer.name)])
        # Set quantize algorithm parameters
        quant_config = Configuration().get_layer_config(config_layer_name)
        act_config = quant_config['activation_quant_params']

        hfmg_layer.hfmg_param.batch_num = act_config['batch_num']
        hfmg_layer.hfmg_param.with_offset = act_config['with_offset']
        # only auto calibration need to dump data
        hfmg_layer.hfmg_param.need_dump = need_dump
        hfmg_layer.hfmg_param.dump_dir = dump_dir
        hfmg_layer.hfmg_param.nbins = act_config['num_of_bins']
        hfmg_layer.hfmg_param.object_layer[:] = object_layers
        hfmg_layer.hfmg_param.record_file_path = \
            Configuration().get_record_file_path()
        # Add node of hfmg to graph
        hfmg_node = graph.add_node(hfmg_layer, node_index)
        return hfmg_node


    def do_pass(self, graph, object_node):
        """
        Function: Do actual insert ifmr/hfmg layer operation.
        Parameters: graph: graph that contains object node
                    object_node: node to process
        Return: None
        """
        if len(object_node.input_anchors) != 1:
            raise RuntimeError("Convolution/InnerProduct should only have 1 " \
                "input, actually have ", len(object_node.input_anchors))

        # Insert node behind conv/fc's peer_output_node
        object_input_anchor = object_node.get_input_anchor(0)
        peer_output_anchor = object_input_anchor.get_peer_output_anchor()
        peer_output_node = peer_output_anchor.node
        peer_output_anchor_index = peer_output_anchor.index
        quant_config = Configuration().get_layer_config(object_node.name)
        act_config = quant_config['activation_quant_params']
        # default activation calibration algorithm is IFMR
        act_algo = act_config.get('act_algo', 'ifmr')
        if act_algo == 'hfmg':
            act_cali_node = self.generate_hfmg_node(graph,
                                                [object_node.name],
                                                object_node.name,
                                                object_node.index,
                                                self.need_dump,
                                                self.dump_dir)
        else:
            act_cali_node = self.generate_ifmr_node(graph,
                                                [object_node.name],
                                                object_node.name,
                                                object_node.index,
                                                self.need_dump,
                                                self.dump_dir)
        object_node.set_attr('act_cali_layer_name', act_cali_node.name)
        graph.add_edge(peer_output_node, peer_output_anchor_index, \
            act_cali_node, 0)
        LOGGER.logd("Insert {} layer '{}' to '{}' success!".format(act_algo,
            act_cali_node.name, object_node.name),
            'InsertActCalibrationLayerPass')

    def run(self, graph):
        """
        Function: Insert ifmr/hfmg node to graph
        Parameters: graph: graph that contains object node
        Return: None
        """
        self.set_up()
        # Step1: match pattern and record first matched node
        matched_node = []
        for node in graph.nodes:
            if self.match_pattern(node):
                matched_node.append(node)
        # Step2: do each matched node fusion operation
        for node in matched_node:
            self.do_pass(graph, node)
            graph.topologic_sort()
        self.tear_down()
