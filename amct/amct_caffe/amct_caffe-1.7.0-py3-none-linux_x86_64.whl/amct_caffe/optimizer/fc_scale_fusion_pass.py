#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

InnerProduct + Scale fusion operation

"""
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.utils.log import LOGGER
from amct_caffe.operation.conv_scale_fuse import fuse_conv_scale
from amct_caffe.optimizer.conv_bn_fusion_pass import ConvBnFusionPass
from amct_caffe.optimizer.conv_scale_fusion_pass import ConvScaleFusionPass
from amct_caffe.optimizer.fc_bn_fusion_pass import FcBnFusionPass

from amct_caffe.utils.attrs_list import ATTR_NODE_FUSION_INFO
from amct_caffe.utils.attrs_list import ATTR_NODE_OUTPUT_NODE


class FcScaleFusionPass(BaseFusionPass):
    """
    Function: Do "InnerProduct" layer and "Scale" layer fusion operation
    APIs: match_pattern, do_pass, get_np_array_from_scale
    """
    def __init__(self):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    @staticmethod
    def _do_weights_bias_fuison(node_fc, node_scale):
        """
        Function: Do fc+scale weights and bias fuison
        Parameters: node_fc: "InnerProduct" node
                    node_scale: "Scale" node
        Return: None
        """
        if not node_fc.get_all_data():
            raise RuntimeError('InnerProduct "{}" at least should have 1 ' \
                'blob, actually zero.'.format(node_fc.name))
        blob_weights = node_fc.get_data(0)
        blob_bias = None
        if len(node_fc.get_all_data()) > 1:
            blob_bias = node_fc.get_data(1)

        if not node_scale.get_all_data():
            raise RuntimeError('Scale "{}" should at least have 1 blobs,' \
                ' actually zero.'.format(node_scale.name))
        blob_scale = node_scale.get_data(0)
        blob_beta = None
        if len(node_scale.get_all_data()) > 1:
            blob_beta = node_scale.get_data(1)

        array_weights, array_bias = \
            FcBnFusionPass.get_np_array_from_fc(blob_weights, blob_bias)
        array_scale, array_beta = \
            ConvScaleFusionPass.get_np_array_from_scale(blob_scale, blob_beta)
        fused_weights, fused_bias = \
            fuse_conv_scale(array_weights, array_bias, array_scale, array_beta)
        ConvBnFusionPass.write_fused_weights_bias_back(node_fc, \
            blob_weights, fused_weights, blob_bias, fused_bias)

    def match_pattern(self, node):
        """
        Function: Match pattern of "InnerProduct" + "Scale" in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type != 'Scale' or len(node.input_anchors) != 1:
            return False

        peer_output_anchor = node.get_input_anchor(0).get_peer_output_anchor()
        peer_node = peer_output_anchor.node
        if peer_node.type != 'InnerProduct' or \
            len(peer_output_anchor.get_peer_input_anchor()) != 1:
            return False
        if peer_node.name in Configuration().get_skip_fusion_layers():
            return False
        if peer_node.proto.inner_product_param.axis != 1 \
                or peer_node.proto.inner_product_param.transpose:
            return False
        return ConvScaleFusionPass.check_matched_scale_layer(node)

    def do_pass(self, graph, object_node):
        """
        Function: Do actual "InnerProduct" layer and "Scale" layer
                  fusion operation
        Parameters: graph: graph structure
                    object_node: node to process
        Return: None
        """
        # Step1: remove edge of Scale
        # remove output links
        if len(object_node.output_anchors) != 1:
            raise RuntimeError("Scale should only have 1 output, actually " \
                "have {}".format(len(object_node.output_anchors)))
        scale_peer_input_anchors = object_node.get_output_anchor(0). \
            get_peer_input_anchor()
        scale_peer_input_nodes = []
        scale_peer_input_indexes = []
        for input_anchor in scale_peer_input_anchors:
            scale_peer_input_nodes.append(input_anchor.node)
            scale_peer_input_indexes.append(input_anchor.index)
        for index in range(len(scale_peer_input_anchors)):
            graph.remove_edge(object_node, 0, \
                scale_peer_input_nodes[index], \
                scale_peer_input_indexes[index])
        # remove input links
        scale_input_anchor = object_node.get_input_anchor(0)
        scale_peer_output_anchor = scale_input_anchor.get_peer_output_anchor()
        node_fc = scale_peer_output_anchor.node
        graph.remove_edge(node_fc, 0, object_node, 0)
        # Step2: Add link from fc to scale_peer_input_node
        for index, element in enumerate(scale_peer_input_nodes):
            graph.add_edge(node_fc, 0, element, \
                scale_peer_input_indexes[index])
        # Step3: Do fc + scale weights/bias fusion
        self._do_weights_bias_fuison(node_fc, object_node)
        # Step4: Record fusion info to Conv node
        if not node_fc.has_attr(ATTR_NODE_FUSION_INFO):
            node_fc.set_attr(ATTR_NODE_FUSION_INFO, [node_fc.name])
        scale_name = object_node.name
        node_fc.get_attr(ATTR_NODE_FUSION_INFO).append(scale_name)
        node_fc.set_attr(ATTR_NODE_OUTPUT_NODE, scale_name)

        # Step5: Set the fc node's output name with scale's output name
        scale_output_name = object_node.get_output_anchor(0).name
        node_fc.get_output_anchor(0).set_name(scale_output_name)
        # Step6: remove node of bn from graph
        node_scale_name = object_node.name
        LOGGER.logd("Remove node {} from graph".format(node_scale_name), \
            'FcScaleFusionPass')
        graph.remove_node(node_scale_name)
        LOGGER.logd('Do fc:"{}" + scale:"{}" fuison success!'.format(
            node_fc.name, node_scale_name), 'FcScaleFusionPass')
