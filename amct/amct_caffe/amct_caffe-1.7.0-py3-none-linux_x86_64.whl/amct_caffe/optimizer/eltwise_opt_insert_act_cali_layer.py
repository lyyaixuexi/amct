#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

insert ifmr/hfmg layer for eltwise optimize convolution layer.

"""

from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.utils.log import LOGGER
from amct_caffe.configuration.configuration import Configuration
import amct_caffe.optimizer as opt
from amct_caffe.optimizer.insert_act_calibration_layer import INSERT_ACT_CALI_DONE_FLAG


class EltwiseOptInsertActCaliLayerPass(BaseFusionPass):
    """
    Function: Insert ifmr/hfmg layer couple with layer to be quantized
    APIs: match_pattern, do_pass
    """
    def __init__(self):
        """
        Function: Init EltwiseOptInsertActCaliLayerPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    def do_pass(self, graph, union_list):
        """
        Function: EltwiseOptInsertActCaliLayerPass do pass
        Parameters: graph: graph object
        union_list: the nodes need union calibration
        Return: None
        """
        union_nodes = \
            [graph.get_node_by_name(node_name) for node_name in union_list]

        union_layers = [node.name for node in union_nodes]
        union_config_layer_name = graph.get_node_by_name(union_list[0]).name

        quant_config = Configuration().get_layer_config(union_config_layer_name)
        act_config = quant_config['activation_quant_params']
        act_algo = act_config.get('act_algo', 'ifmr')
        if act_algo == 'hfmg':
            act_cali_node = opt.InsertActCalibrationLayerPass.generate_hfmg_node(
                graph, union_layers, union_config_layer_name)
        else:
            act_cali_node = opt.InsertActCalibrationLayerPass.generate_ifmr_node(
                graph, union_layers, union_config_layer_name)

        act_cali_node_input_index = 0
        for quant_node in union_nodes:
            quant_node.set_attr(INSERT_ACT_CALI_DONE_FLAG, True)
            quant_node.set_attr('act_cali_layer_name', act_cali_node.name)
            input_anchor = quant_node.get_input_anchor(0)
            peer_output_anchor = input_anchor.get_peer_output_anchor()

            graph.add_edge(
                peer_output_anchor.node,
                peer_output_anchor.index,
                act_cali_node,
                act_cali_node_input_index)
            act_cali_node_input_index += 1
            LOGGER.logd(
                "Insert {} layer '{}' to '{}' success!".format(
                    act_algo,
                    act_cali_node.name,
                    quant_node.name),
                'EltwiseOptInsertActCaliLayerPass')
        LOGGER.logi('Insert {} node {} to union layers {} success.'.format(
            act_algo, act_cali_node.name, union_list),
            'EltwiseOptInsertActCaliLayerPass')

    def run(self, graph):
        union_lists = []
        for node in graph.nodes:
            union_list = opt.EltwiseOptWeightsCalibrationPass.match_pattern( \
                node, '{}_{}'.format(INSERT_ACT_CALI_DONE_FLAG, node.index), \
                True)
            if union_list is not None:
                union_lists.append(union_list)
        for union_list in union_lists:
            self.do_pass(graph, union_list)
        graph.topologic_sort()
