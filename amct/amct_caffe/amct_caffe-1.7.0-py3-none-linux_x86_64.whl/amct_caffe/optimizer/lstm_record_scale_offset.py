#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Repace quantized LSTM type to LSTMQuant and record scale, offset to it.
"""
import numpy as np

from google.protobuf import text_format
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.configuration.configuration import Configuration
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.optimizer.lstm_calibration_replace import identify_lstm_state
from amct_caffe.optimizer.record_scale_offset import RecordScaleOffsetPass
from amct_caffe.common.utils.record_file_operator import \
    read_weights_scale_offset
from amct_caffe.common.utils.record_file_operator import \
    read_activation_scale_offset
from amct_caffe.common.utils.record_file_operator import read_shift_bits
from amct_caffe.utils.log import LOGGER


class LstmRecordScaleOffsetPass(BaseFusionPass):
    """
    Function: The pass to repace quantized LSTM type to LSTMQuant
              and record scale, offset to it.
    APIs: set_up, set_save_type, match_pattern, do_pass
    """
    def __init__(self):
        BaseFusionPass.__init__(self)
        self.save_type = None
        self.records = caffe_pb2.ScaleOffsetRecord()

    @staticmethod
    def match_pattern(node):
        """
        Function: Find the Quant layer or DeQuant layer.
        Inputs:
            node: the node to be matched.
        Returns: None
        """
        if node.type != 'LSTMQuant':
            return False
        # match type
        if node.name not in Configuration().get_quant_config():
            return False
        return True

    @staticmethod
    def _get_scale_deq_offset_w(records, target_name):
        """Get weights' scale and offset from records according to
           target_name.
        """
        scale_d, _ = read_activation_scale_offset(
            records, target_name)
        scale_ws, offset_ws = read_weights_scale_offset(
            records, target_name)
        scale_deq = [scale_w*scale_d for scale_w in scale_ws]
        return scale_deq, offset_ws

    def set_save_type(self, save_type):
        """
        Function: set save_type.
        Inputs: save_type: A string indicating the type,
                          including "Deploy" or "Fakequant"
        Returns: None
        """
        if save_type not in ("Fakequant", "Deploy"):
            raise TypeError("Only support 'Deploy' and 'Fakequant', "\
                            "but get {}.".format(save_type))
        self.save_type = save_type

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(Configuration().get_record_file_path(), 'r') as record_file:
            pbtxt_string = record_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def do_pass(self, graph, object_node):
        """
        Function: do quantize operation.
        Inputs:
            graph: IR Graph, the graph to be quantized.
            object_node: node to process
        Returns: None
        """
        if self.save_type is None:
            raise RuntimeError("Please set save_type by call set_save_type().")
        static_input, _ = identify_lstm_state(object_node)

        # Reset LSTMQuant layer parameter
        object_node.proto.ClearField('lstm_quant_param')
        object_node.proto.ClearField('quant_param')

        original_weights_num = 4 if static_input else 3
        del object_node.get_all_data()[original_weights_num:]

        self._record_dequant_x_params(object_node, self.records,
                                      self.save_type)
        self._record_dequant_h_params(object_node, self.records,
                                      self.save_type)

        if static_input:
            self._record_dequant_s_params(object_node,
                                          self.records,
                                          self.save_type)

        LOGGER.logd('Do record scale and offset to layer "{}" success!'\
                    .format(object_node.name), 'LstmRecordScaleOffsetPass')

    def _record_dequant_x_params(self, node, records, save_type):
        """Get input_X and weights_X scale, offset parameters,
           and calculate deq_scale_X
        """
        scale_x_name = '{}_X'.format(node.name)
        scale_x_deq, offset_x_ws = self._get_scale_deq_offset_w(
            records, scale_x_name)
        shift_bits = read_shift_bits(records, scale_x_name)
        if save_type == 'Fakequant':
            dequant_param = node.proto.lstm_quant_param.w_x_dequant_param
            dequant_param.deqscale[:] = scale_x_deq
            if shift_bits:
                dequant_param.shift_bit[:] = shift_bits
            else:
                dequant_param.shift_bit[:] = np.zeros(len(scale_x_deq),
                                                      np.float32)
            dequant_param.offset[:] = offset_x_ws
            dequant_param.layer_type = 'LSTM_X'
        else:
            fused_quant_param = RecordScaleOffsetPass().fuse_dequant_param(
                scale_x_deq, offset_x_ws, shift_bits, len(scale_x_deq))
            RecordScaleOffsetPass.add_blob(
                node, 'uint64', len(scale_x_deq), fused_quant_param)

    def _record_dequant_h_params(self, node, records, save_type):
        """Get input_H and weights_H scale, offset parameters, and
           calculate deq_scale_H
        """
        scale_h_name = '{}_H'.format(node.name)
        scale_h_d, offset_h_d = read_activation_scale_offset(records,
                                                             scale_h_name)
        scale_h_deq, offset_h_ws = self._get_scale_deq_offset_w(
            records, scale_h_name)
        uint8_offset = np.frombuffer(np.int8(offset_h_d), np.uint8)
        shift_bits = read_shift_bits(records, scale_h_name)
        if save_type == 'Fakequant':
            quant_param = node.proto.lstm_quant_param.w_h_quant_param
            quant_param.scale = 1 / scale_h_d
            quant_param.offset = bytes(uint8_offset)

            dequant_param = node.proto.lstm_quant_param.w_h_dequant_param
            dequant_param.deqscale[:] = scale_h_deq
            if shift_bits:
                dequant_param.shift_bit[:] = shift_bits
            else:
                dequant_param.shift_bit[:] = np.zeros(len(scale_h_deq),
                                                      np.float32)
            dequant_param.offset[:] = offset_h_ws
            dequant_param.layer_type = 'LSTM_H'
        else:
            node.proto.quant_param.scale = 1 / scale_h_d
            node.proto.quant_param.offset = bytes(uint8_offset)

    def _record_dequant_s_params(self, node, records, save_type):
        """Get input_S and weights_S scale, offset parameters, and
           calculate deq_scale_S
        """
        scale_s_name = '{}_S'.format(node.name)
        scale_s_deq, offset_s_ws = self._get_scale_deq_offset_w(
            records, scale_s_name)
        shift_bits = read_shift_bits(records, scale_s_name)
        if save_type == 'Fakequant':
            static_dequant_param = \
                node.proto.lstm_quant_param.w_x_static_dequant_param
            static_dequant_param.deqscale[:] = scale_s_deq
            if shift_bits:
                static_dequant_param.shift_bit[:] = shift_bits
            else:
                static_dequant_param.shift_bit[:] = np.zeros(
                    len(scale_s_deq), np.float32)
            static_dequant_param.offset[:] = offset_s_ws
            static_dequant_param.layer_type = 'LSTM_S'
        else:
            fused_s_param = RecordScaleOffsetPass().fuse_dequant_param(
                scale_s_deq, offset_s_ws, shift_bits, len(scale_s_deq))
            RecordScaleOffsetPass.add_blob(
                node, 'uint64', len(scale_s_deq), fused_s_param)
