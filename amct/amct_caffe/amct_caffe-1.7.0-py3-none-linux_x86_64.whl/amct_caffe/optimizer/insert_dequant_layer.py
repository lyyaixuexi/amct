#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert dequant layer after layer to be quantized

"""
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.configuration.check import GraphChecker
from amct_caffe.utils.log import LOGGER
from amct_caffe.optimizer.base_fusion_pass import BaseFusionPass
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.configuration.retrain_config import RetrainConfig

from amct_caffe.utils.attrs_list import ATTR_NODE_EQUIVALENT_OBJECT_LAYER
from amct_caffe.utils.attrs_list import ATTR_NODE_EQUIVALENT_OUTPUT
from amct_caffe.optimizer.weights_calibration import SKIP_LAYER_TYPES


class InsertDeQuantLayerPass(BaseFusionPass):
    """
    Function: Insert dequant layer after layer to be quantized
    APIs: match_pattern, do_pass
    """
    def __init__(self, retrain=False):
        """
        Function: Init object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        if retrain:
            self.retrain = True
            self.conf = RetrainConfig()
        else:
            self.retrain = False
            self.conf = Configuration()

    def match_pattern(self, node):
        """
        Function: Find 'Convolution' or 'InnerProduct' node need to quantized
                  in graph
        Parameters: node: node in graph
        Return: True: node that need to insert dequant layer
                False: skip the node
        """
        # match config
        if node.type in SKIP_LAYER_TYPES:
            return False
        if node.name not in self.conf.get_quant_config():
            return False
        # match type
        if not GraphChecker.check_quantize_type(node):
            return False
        if len(node.output_anchors) != 1:
            raise RuntimeError("Convolution/InnerProduct layer should only " \
                "have one output, actually is {}".format( \
                len(node.output_anchors)))
        return True

    def do_pass(self, graph, object_node):
        """
        Function: Do actual insert dequant layer operation.
        Parameters: graph: graph that contains object node
                    object_node: node to process
        Return: None
        """
        # Step1: Generate a LayerParameter object of dequant layer,
        #        and add node to graph
        dequant_layer = caffe_pb2.LayerParameter()
        # Set basic info
        dequant_layer.name = '{}_{}'.format(object_node.name,
                                            'dequant_layer')
        dequant_layer.type = 'DeQuant'
        dequant_layer.bottom.extend(['{}_{}'.format(dequant_layer.name,
                                                    'input0')])
        dequant_layer.top.extend(['{}_{}'.format(dequant_layer.name,
                                                 'input0')])
        # Set dequantize algorithm parameters
        dequant_layer.dequant_param.need_calibration = True
        quant_config = self.conf.get_quant_config()
        if self.retrain:
            layer_config = self.conf.get_layer_config(object_node.name)
            weight_quant = layer_config.get('weight_quant_params')
        else:
            weight_quant = \
                quant_config[object_node.name]['weight_quant_params']
        if weight_quant['wts_algo'] == 'arq_quantize':
            dequant_layer.dequant_param.channel_wise = \
                weight_quant['channel_wise']
        elif weight_quant['wts_algo'] == 'nuq_quantize':
            dequant_layer.dequant_param.channel_wise = \
                object_node.type == 'Convolution'
        dequant_layer.dequant_param.object_layer = \
            object_node.name
        dequant_layer.dequant_param.batch_num = \
            quant_config['batch_num']
        # Add dequant node to graph
        dequant_node = graph.add_node(dequant_layer)
        # Record inserted dequant node info
        dequant_node.set_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER,
                              object_node.name)
        object_node.set_attr(ATTR_NODE_EQUIVALENT_OUTPUT, dequant_node.name)
        # Step2: Insert Node between conv/fc node and it's peer_input_node
        output_anchor = object_node.get_output_anchor(0)
        if output_anchor.get_peer_input_anchor():
            peer_nodes = []
            peer_indexes = []
            for peer_input_anchor in output_anchor.get_peer_input_anchor():
                peer_nodes.append(peer_input_anchor.node)
                peer_indexes.append(peer_input_anchor.index)

            for index, element in enumerate(peer_nodes):
                graph.remove_edge(object_node, 0, element,
                                  peer_indexes[index])
                # add link from dequant_node to conv/fc output node
                graph.add_edge(dequant_node, 0, element, \
                    peer_indexes[index])

        graph.add_edge(object_node, 0, dequant_node, 0)

        LOGGER.logd('Insert dequant layer \'{}\' after \'{}\' success!'.format(
            dequant_node.name, object_node.name), 'InsertDeQuantLayerPass')
