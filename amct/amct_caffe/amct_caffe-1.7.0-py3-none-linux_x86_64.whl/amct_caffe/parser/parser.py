#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Parse user caffe model file to Graph

"""
import os
from google.protobuf import text_format

try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.graph.graph import Graph
from amct_caffe.utils.log import LOGGER


class Parser():
    """
    Function: Parse user caffe model file to Graph
    APIs: read_net_from_proto, load_user_model, parse_net_to_graph
    """
    def __init__(self, model_file, weights_file):
        """
        Function: init object
        Parameter:
            model_file : the caffe model file
            weights_file : the caffe weights file
        Return: None
        """
        self.__net = Parser.load_user_model(model_file, weights_file)

    @staticmethod
    def read_proto_from_binary(proto_file):
        """
        Function: Read caffe.NetParaneter from binary file
        Parameter: proto_file
        Return: caffe.NetParameter
        """
        proto_file = os.path.realpath(proto_file)
        net = caffe_pb2.NetParameter()
        with open(proto_file, 'rb') as proto_binary_file:
            pbtxt_string = proto_binary_file.read()
            try:
                net.ParseFromString(pbtxt_string)
            except Exception as exception:
                raise RuntimeError(
                    'Read proto from binary file:{} failed, {}'. \
                    format(proto_file, exception)) from exception
            else:
                LOGGER.logd('Parse proto from binary file success!')

        if net.layers:
            raise RuntimeError("Unsupported V1LayerParameter, you may use " \
                "caffe tool upgrade_net_proto_binary to upgrade your %s" % \
                               os.path.basename(proto_file))
        return net

    @staticmethod
    def read_proto_from_txt(proto_file):
        """
        Function: Read caffe.NetParaneter from txt file
        Parameter: proto_file : the proto_file with prototxt format
        Return: caffe.NetParameter
        """
        proto_file = os.path.realpath(proto_file)
        net = caffe_pb2.NetParameter()
        with open(proto_file, 'r') as prototxt_file:
            pbtxt_string = prototxt_file.read()
            try:
                text_format.Merge(pbtxt_string, net)
            except Exception as exception:
                raise RuntimeError('Read proto from txt file:{} failed, {}'. \
                    format(proto_file, exception)) from exception
            LOGGER.logd('Parse proto from txt file success!')

        if net.layers:
            raise RuntimeError(
                "Unsupported V1LayerParameter, you may use caffe tool "
                "upgrade_solver_proto_text to upgrade your %s" %
                os.path.basename(proto_file))
        return net

    @staticmethod
    def load_user_model(net_file, weights_file):
        """
        Function: Load caffe model from prototxt file and caffemodel file
        Parameter:
            net_file : the caffe model prototxt file
            weights_file : the caffe weight file
        Return: Caffe model
        """
        LOGGER.logi(
            "Doing load_user_model ...", 'Parser')
        LOGGER.logi(
            "Start read model from file \'{}\' ...".format(net_file), 'Parser')
        model = Parser.read_proto_from_txt(net_file)
        LOGGER.logi(
            "Read model from file done.", 'Parser')
        LOGGER.logi(
            "Start read weights from file \'{}\' ...". \
            format(weights_file), 'Parser')
        weights = Parser.read_proto_from_binary(weights_file)
        LOGGER.logi("Read weights from file done.", 'Parser')
        for layer in model.layer:
            LOGGER.logd("Load layer:{}".format(layer.name))
            if layer.blobs:
                raise RuntimeError(
                    "There should not have weights data in model file")
            for weights_layer in weights.layer:
                if layer.name == weights_layer.name:
                    if weights_layer.blobs:
                        for blob in weights_layer.blobs:
                            copy_blob = layer.blobs.add()
                            copy_blob.CopyFrom(blob)
                    break
        return model

    def parse_net_to_graph(self, skip_train_phase=True):
        """
        Function: Parser caffe model to Graph
        Parameter: None
        Return: Graph
        """
        return Graph(self.__net, skip_train_phase)
