#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

amct_caffe command line tool core funtions.

"""

import os
import sys
import importlib

import caffe

import amct_caffe as amct
import amct_caffe.cmd_line_tools.parser_args as parser_args
import amct_caffe.common.cmd_line_utils.arguments_handler as args_handler
from amct_caffe.common.cmd_line_utils.data_handler import tmp_dir
from amct_caffe.common.cmd_line_utils.data_handler import delete_tmp_dir
import amct_caffe.common.cmd_line_utils.data_handler as data_handler
from amct_caffe.configuration.configuration import Configuration


class Evaluator(amct.CalibrationEvaluatorBase):
    '''
    Evaluator: default evaluator.
    '''
    def __init__(self, args_var):
        self.args_var = args_var
        super().__init__()

    def calibration(self, modified_model, modified_weights):
        '''
        Function: calibration
        '''
        net = caffe.Net(modified_model, modified_weights, caffe.TEST)
        for data_map in data_handler.load_data(
                self.args_var.input_shape,
                self.args_var.data_dir,
                self.args_var.data_types,
                self.args_var.batch_num):

            _ = net.forward(**data_map)


def main():
    '''
    Function: main function for amct_caffe command line tools.
    '''
    args = parser_args.ParserArgs()
    args_var = args.parse_args()


    args_handler.calibration_args_checker(args_var)

    try:
        tmp = tmp_dir()

        config_file = os.path.join(tmp, 'quant_config.json')
        record_file = os.path.join(tmp, 'record.txt')

        amct.create_quant_config(
            config_file=config_file,
            model_file=args_var.model,
            weights_file=args_var.weights,
            batch_num=args_var.batch_num,
            config_defination=args_var.calibration_config)

        graph = amct.init(
            config_file=config_file,
            model_file=args_var.model,
            weights_file=args_var.weights,
            scale_offset_record_file=record_file)

        modified_model = os.path.join(tmp, 'modified_model.prototxt')
        modified_weights = os.path.join(tmp, 'modified_model.caffemodel')

        if args_var.gpu_id is not None:
            caffe.set_mode_gpu()
            caffe.set_device(args_var.gpu_id)
            amct.set_gpu_mode()
        else:
            caffe.set_mode_cpu()

        amct.quantize_model(
            graph=graph,
            modified_model_file=modified_model,
            modified_weights_file=modified_weights)

        args_var.batch_num = int(Configuration.parse_quant_config(config_file, graph)[0]['batch_num'])

        evaluator = Evaluator(args_var)
        if args_var.evaluator is not None:
            if not os.path.exists(args_var.evaluator):
                raise RuntimeError("evaluator file '{}' not exists!".format(args_var.evaluator))
            evaluator_path, evaluator_file = os.path.split(args_var.evaluator)
            sys.path.append(evaluator_path)
            evaluator = importlib.import_module(evaluator_file.split('.')[0])

            evaluator = evaluator.customize_evaluator

        evaluator.calibration(modified_model, modified_weights)

        amct.save_model(
            graph=graph,
            save_type='Both',
            save_path=args_var.save_path)
    finally:
        delete_tmp_dir(tmp)


if __name__ == '__main__':
    main()
