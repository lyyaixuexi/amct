#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Class Dumper offer methods to dump quantize messages to file

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import stat
import time
import traceback
from pathlib import Path

from amct_caffe.utils.log import LOG_FILE_SET_ENV
from amct_caffe.common.utils.log_base import LOGGING_LEVEL_MAP
from amct_caffe.common.utils.log_base import LOG_FILE_DIR
from amct_caffe.common.utils import files as files_util

DUMPER_DICT = {}
DUMP_FILE_MOD = stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP


class Dumper():
    """
    Function：Dump debug，info，warning，error level file
    API：dumpn, dumpd, dumpi, dumpw, dumpe
    """

    def __init__(self, dump_file):
        """
        Function：Create dumper，and init dumper condition
        Parameter: dump_file: dump file name
        Return:None
        """
        # Get loging level from env
        # Default dump level set to INFO
        self._current_dir = os.getcwd()
        self._numeric_level = LOGGING_LEVEL_MAP.get('INFO')
        env_dist = os.environ
        if LOG_FILE_SET_ENV in env_dist:
            dump_level = env_dist[LOG_FILE_SET_ENV]
            dump_level = dump_level.upper()
            if dump_level not in LOGGING_LEVEL_MAP:
                raise RuntimeError(
                    '{} is not a legal log level'.format(dump_level))
            self._numeric_level = LOGGING_LEVEL_MAP[dump_level]
        # Init dump file
        dump_file = dump_file.replace('/', '%2F')
        self._dump_file = os.path.join(
            self._current_dir, LOG_FILE_DIR, dump_file)
        file_dir = os.path.split(self._dump_file)[0]
        files_util.create_path(file_dir)
        if Path(self._dump_file).exists():
            with open(self._dump_file, 'w') as dump_data_file:
                dump_data_file.write('')
            os.chmod(self._dump_file, DUMP_FILE_MOD)

    def dumpd(self, input_array, length=1):
        """Dump 'Debug' level messages
           Inputs: input_array: messages that to be dumped
                   length: messages number
           Return: None
        """
        if self._numeric_level <= LOGGING_LEVEL_MAP.get('DEBUG'):
            self._write_file('DEBUG', input_array, length)

    def dumpi(self, input_array, length=1):
        """Dump 'Info' level messages
           Inputs: input_array: messages that to be dumped
                   length: messages number
           Return: None
        """
        if self._numeric_level <= LOGGING_LEVEL_MAP.get('INFO'):
            self._write_file('INFO', input_array, length)

    def dumpw(self, input_array, length=1):
        """Dump 'Warning' level messages
           Inputs: input_array: messages that to be dumped
                   length: messages number
           Return: None
        """
        if self._numeric_level <= LOGGING_LEVEL_MAP.get('WARNING'):
            self._write_file('WARNING', input_array, length)

    def dumpe(self, input_array, length=1):
        """Dump 'Error' level messages
           Inputs: input_array: messages that to be dumped
                   length: messages number
           Return: None
        """
        if self._numeric_level <= LOGGING_LEVEL_MAP.get('ERROR'):
            self._write_file('ERROR', input_array, length)

    def _write_file(self, dump_level, input_array, length):
        """Write dump messages to file
           Inputs: dump_level: Setted dump level, could be 'Error', 'Warning',
                               'Info', 'Debug', 'Notice'
                   input_array: messages that to be dumped
                   length: messages number
            Return: None

        """
        with open(self._dump_file, 'a+') as dump_data_file:
            time_now = int(round(time.time() * 1000))
            time_stamp = time.strftime('%Y-%m-%d %H:%M:%S',
                                       time.localtime(time_now / 1000))
            stack = traceback.extract_stack()
            dump_data_file.write('{}[{}][{}][{}][{}]\n'.format(
                time_stamp,
                dump_level,
                stack[-3][0],
                stack[-3][2],
                stack[-3][1]))
            for i in range(length):
                dump_data_file.write('{} '.format(input_array[i]))
            dump_data_file.write('\n')
        os.chmod(self._dump_file, DUMP_FILE_MOD)
