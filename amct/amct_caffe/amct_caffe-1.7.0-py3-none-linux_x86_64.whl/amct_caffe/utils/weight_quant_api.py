#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Ctypes APIs for arq_quant algorithm

"""
import collections
from array import array

from amct_caffe.lib.load_library import Load
from amct_caffe.lib.load_library import DeviceMode
from amct_caffe.lib.load_library import CPU_MODE
from amct_caffe.lib.load_library import GPU_MODE
from amct_caffe.configuration.check import GraphChecker
from amct_caffe.common.algo.weight_quant_api import WtsPtqBase
from amct_caffe.operation.wts_quant_algo import WEIGHTS_QUANT_ALGO


WeightsBlobInfo = collections.namedtuple('WeightsBlobInfo',
                                         ['weights_blob', 'weights_shape', 'weights_dtype', 'weights_data'])


class WtsPtq(WtsPtqBase):
    """ Weight post-training-quantize python interface"""
    def __init__(self):
        if DeviceMode().mode == CPU_MODE:
            device_mode = 'CPU'
        elif DeviceMode().mode == GPU_MODE:
            device_mode = 'GPU'
        else:
            raise RuntimeError('Not supported device mode "{}"'.format( \
                            DeviceMode().mode))
        super().__init__(device_mode, Load())


def weight_calibration_np(numpy_data, wts_param):
    '''do calibration for np weight '''
    return WtsPtq().weight_calibration_np(numpy_data, wts_param,
                                          WEIGHTS_QUANT_ALGO)


def weight_calibration_blob(weights_blob, weights_shape, weights_dtype,
                            weights_data, wts_param):
    """
    Function: warpper of arq_quant_blob_data and nuq_quant_blob_data
    Parameter: weight_blob: data to be quantized as blob
            weights_shape: shape of data to quantize
            weights_dtype: type of data to quantize, only support "float"
                            or "double"
            weights_data: blob data to quantize
            wts_param: weight quantize algorithm parameter
    Return: scale: scale of input data
            offset: offset of input data
    """
    array_data = array('d', weights_data)
    scale, offset = WtsPtq().weights_calibration_kernel(
        array_data, weights_shape, wts_param, WEIGHTS_QUANT_ALGO)
    write_back_weight_blob(weights_blob, weights_dtype, array_data)
    return scale, offset


def weights_quantize_np(numpy_data, scale, offset, num_bits=8):
    '''quant data to int for np weight '''
    return WtsPtq().weights_quantize_np(numpy_data, scale, offset, num_bits)


def weights_quantize_blob(weights_data, scale, offset, num_bits=8):
    """
    Function: warpper of weights quantize of blob
    Parameter: blob_data: data to be quantized as blob data
            scale: scale of input data
            offset: offset of input data
    Return: int8_data: quantized int8 data
    """
    array_data = array('d', weights_data)
    int8_data = WtsPtq().weights_quantize_kernel(array_data, scale, offset,
                                                 num_bits)
    return int8_data


def write_back_weight_blob(blob, dtype, data):
    """ writhe data back to weight blob."""
    if dtype == 'float':
        blob.ClearField('data')
        blob.data.MergeFrom(data)
    elif dtype == 'double':
        blob.ClearField('double_data')
        blob.double_data.MergeFrom(data)
    else:
        raise TypeError('Not support write dtype {} to blob'.format(dtype))


def get_weights_blob_info(object_node, weights_index=0, is_clear=False):
    """ Get weights' info and cope with data. """
    # find weights_blob
    if weights_index >= len(object_node.get_all_data()):
        raise RuntimeError('Cannot find weights[{}] in layer:{}'.format(
            weights_index, object_node.name))
    weights_blob = object_node.get_data(weights_index)
    # get weights' information and clear blob
    weights_shape = tuple(GraphChecker.get_blob_shape(weights_blob))
    if weights_blob.data:
        # the weight is float
        weights_dtype = 'float'
        weights_data = weights_blob.data
        if is_clear:
            weights_blob.ClearField('data')
    elif weights_blob.double_data:
        # the weight is double
        weights_dtype = 'double'
        weights_data = weights_blob.double_data
        if is_clear:
            weights_blob.ClearField('double_data')
    elif weights_blob.HasField('int8_data'):
        weights_dtype = 'int8'
        weights_data = weights_blob.int8_data
        if is_clear:
            weights_blob.ClearField('int8_data')
    else:
        raise RuntimeError('Get weights data from layer {} failed.' \
                           .format(object_node.name))

    return WeightsBlobInfo(weights_blob, weights_shape, weights_dtype, weights_data)
