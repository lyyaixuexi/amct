#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

the auto non uniform helper

"""
import time
import collections
from functools import wraps

from amct_caffe.utils.log import LOGGER


def time_info(func):
    """ get the running time of a function"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        LOGGER.logi("*****************************************************")
        LOGGER.logi("#>Func name: {}".format(func.__name__))
        LOGGER.logi("#>Cost time: {}".format(
            AutoNuqHelper.get_time_of_nuq(end - start)))
        LOGGER.logi("*****************************************************")
        return result
    return wrapper



class AutoNuqLayer: # pylint: disable=R0903
    """" the class of auto nuq layer"""
    def __init__(self, name, step):
        self.name = name
        self.step = step
        self.sensitivity = collections.OrderedDict()

    def __repr__(self):
        return "name: {}, step: {}, sensitivity: {}".format(
            self.name, self.step, self.sensitivity)



class AutoNuqHelper: # pylint: disable=R0902
    """ the helper for auto nuq API"""
    def __init__(self, quant_config):

        self.steps = {
            'arq': 256,
            'nuq_32': 32,
            'nuq_16': 16}

        self.find_steps = {
            256: "arq",
            32: "nuq_32",
            16: "nuq_16"}

        self.steps_status = {
            'arq': False,
            'nuq_32': False,
            'nuq_16': False}

        self.original_cfg = quant_config
        self.nuq_16_cfg = collections.OrderedDict()
        self.nuq_32_cfg = collections.OrderedDict()
        self.arq_cfg = collections.OrderedDict()

        self.ref_models = collections.OrderedDict()
        self.ref_records = collections.OrderedDict()

    @staticmethod
    def get_time_of_nuq(seconds):
        """ convert seconds to time [hours:minutes:seconds] """
        mins, second = divmod(seconds, 60)
        hour, mins = divmod(mins, 60)
        return '{} hours, {} minutes, {:.2f} seconds'.format(
            int(hour), int(mins), second)

    def get_steps(self):
        """ get the steps"""
        return self.steps

    def get_nuq_16_status(self):
        """ get the status of global nuq 16"""
        return self.steps_status.get('nuq_16')

    def get_nuq_32_status(self):
        """ get the status of global nuq 32"""
        return self.steps_status.get('nuq_32')

    def get_arq_status(self):
        """ get the status of global arq"""
        return self.steps_status.get('arq')

    def get_weights_data(self, layer_step_key, layer_name):
        """" get the weights data of layer step of layer name."""
        return self.ref_models[layer_step_key].get_node_by_name(
            layer_name).get_all_data()[0]

    def get_layer_record(self, layer_step_key, layer_name):
        """" get the records of layer step of layer name."""
        records = self.ref_records[layer_step_key].record
        for record in records:
            if record.key == layer_name:
                return record
        return None
