#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

the auto non uniform strategy

"""
import copy
import collections
from enum import Enum
from enum import unique
from amct_caffe.capacity import CAPACITY
ENABLE_CHANNEL_WISE_TYERS = CAPACITY.get_value("CHANNEL_WISE_TYPES")

DEFAULT_ARQ_PARAMS = {
    "wts_algo": "arq_quantize",
    'num_bits': 8,
    "with_offset": False
}

DEFAULT_NUQ_PARAMS = {
    'wts_algo': 'nuq_quantize',
    'num_of_iteration': 0,
    'num_bits': 8,
    "with_offset": False
}

NUQ_STEP_32 = 32
NUQ_STEP_16 = 16


@unique
class SearchMode(Enum):
    '''enumeration of search state'''
    NotInitial = 0
    GoUp = 1
    GoDown = 2


class NuqLayerState: # pylint: disable=too-few-public-methods
    '''layer state'''
    def __init__(self, layer_name, step, sens):
        self.layer_name = layer_name
        self.step = step
        self.sens = sens

    def __lt__(self, other):
        if self.sens < other.sens:
            return True
        return False


class AutoNuqStrategy: # pylint: disable=too-few-public-methods
    '''search strategy base object'''
    def __init__(self, graph, evaluator, quant_config, nuq_layers):
        self.graph = graph
        self.evaluator = evaluator
        self.original_cfg = quant_config
        self.cos_sim = collections.OrderedDict()
        self.nuq_layers = nuq_layers
        self.original_metric = None

    def get_quant_config(self, key):
        """ get the global quant config"""
        key_func_map = {
            'arq': self._get_arq_config,
            'nuq_32': self._get_nuq_32_config,
            'nuq_16': self._get_nuq_16_config
        }
        return key_func_map.get(key)()

    def _generate_arq_params(self, layer_name):
        config = copy.deepcopy(DEFAULT_ARQ_PARAMS)
        config['channel_wise'] = self.graph.get_node_by_name(
            layer_name).type in ENABLE_CHANNEL_WISE_TYERS
        return config

    def _get_arq_config(self):
        arq_cfg = copy.deepcopy(self.original_cfg)
        for layer_name in self.nuq_layers:
            arq_cfg[layer_name][
                'weight_quant_params'] = self._generate_arq_params(layer_name)
        return arq_cfg

    def _get_nuq_16_config(self):
        nuq_16_cfg = copy.deepcopy(self.original_cfg)
        for layer_name in self.nuq_layers:
            nuq_16_cfg[layer_name]['weight_quant_params'] = copy.deepcopy(
                DEFAULT_NUQ_PARAMS)
            nuq_16_cfg[layer_name]['weight_quant_params']['num_steps'] = \
                NUQ_STEP_16
        return nuq_16_cfg

    def _get_nuq_32_config(self):
        nuq_32_cfg = copy.deepcopy(self.original_cfg)
        for layer_name in self.nuq_layers:
            nuq_32_cfg[layer_name]['weight_quant_params'] = copy.deepcopy(
                DEFAULT_NUQ_PARAMS)
            nuq_32_cfg[layer_name]['weight_quant_params']['num_steps'] = \
                NUQ_STEP_32
        return nuq_32_cfg


class AutoNuqStrategyBisection(AutoNuqStrategy):
    '''Bisection search strategy implemention'''
    def __init__(self, graph, evaluator, quant_config, nuq_layers):
        self.left_bound = None
        self.right_bound = None
        self.return_config = None
        self.search_range = None
        super(AutoNuqStrategyBisection,
              self).__init__(graph, evaluator, quant_config, nuq_layers)

    def initial_strategy(self, cos_sim, original_metric, nuq_base_metric):
        '''initial search stratege'''
        self.original_metric = original_metric
        self.cos_sim = cos_sim
        if self.evaluator.is_satisfied(self.original_metric, nuq_base_metric):
            self.left_bound = self._get_nuq_16_config()
            self.right_bound = self._get_nuq_32_config()
            self.search_range = 'nuq16_nuq32'
        else:
            self.left_bound = self._get_nuq_32_config()
            self.right_bound = self._get_arq_config()
            self.search_range = 'nuq32_arq'

    def get_next_quant_config(self, current_metric):
        '''get next quant config'''
        if self.return_config is None:
            cur_config = self._generate_new_config(SearchMode.GoDown)
            self.return_config = cur_config
            if cur_config is None:
                return self.right_bound, True
            return cur_config, False

        if self.evaluator.is_satisfied(self.original_metric, current_metric):
            direction = SearchMode.GoDown
            self.right_bound = self.return_config
        else:
            direction = SearchMode.GoUp
            self.left_bound = self.return_config
        cur_config = self._generate_new_config(direction)
        self.return_config = cur_config
        if cur_config is None:
            return self.right_bound, True
        return cur_config, False

    def _generate_new_config(self, direction):
        diff_layers = self._get_diff_layers()
        # left bound and right bound is too close to generate new config
        if len(diff_layers) <= 1:
            return None

        step_dict = {
            SearchMode.GoDown: {
                'nuq16_nuq32': 16,
                'nuq32_arq': 32
            },
            SearchMode.GoUp: {
                'nuq16_nuq32': 32,
                'nuq32_arq': 256
            }
        }
        target_step = step_dict.get(direction).get(self.search_range)
        layer_state_list = []
        for layer_name in diff_layers:
            layer_state_list.append(
                NuqLayerState(layer_name, target_step,
                              self.cos_sim[target_step][layer_name]))

        reverse_flag = direction == SearchMode.GoDown
        layer_state_list.sort(reverse=reverse_flag)

        if direction == SearchMode.GoUp:
            cur_cfg = copy.deepcopy(self.left_bound)
        else:
            cur_cfg = copy.deepcopy(self.right_bound)

        change_layer_num = len(diff_layers) // 2
        for index in range(change_layer_num):
            layer_name = layer_state_list[index].layer_name
            if target_step == 256:
                cur_cfg[layer_name][
                    'weight_quant_params'] = self._generate_arq_params(
                        layer_name)
            else:
                cur_cfg[layer_name]['weight_quant_params'] = copy.deepcopy(
                    DEFAULT_NUQ_PARAMS)
                cur_cfg[layer_name]['weight_quant_params'][
                    'num_steps'] = target_step
        return cur_cfg

    def _get_nuq32_layers(self, config):
        nuq32_layers = []
        for layer_name in self.nuq_layers:
            if config[layer_name]['weight_quant_params'][
                    'wts_algo'] == 'nuq_quantize':
                if config[layer_name]['weight_quant_params'][
                        'num_steps'] == NUQ_STEP_32:
                    nuq32_layers.append(layer_name)

        return nuq32_layers

    def _get_diff_layers(self):
        diff_layers = set()
        left_nuq32 = self._get_nuq32_layers(self.left_bound)
        right_nuq32 = self._get_nuq32_layers(self.right_bound)
        if len(left_nuq32) > len(right_nuq32):
            diff_layers = set(left_nuq32) - set(right_nuq32)
        else:
            diff_layers = set(right_nuq32) - set(left_nuq32)

        return list(diff_layers)
