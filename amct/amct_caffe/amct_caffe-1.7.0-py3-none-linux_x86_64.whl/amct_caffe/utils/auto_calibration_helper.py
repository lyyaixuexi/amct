#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

the auto calibration helper

"""

import os
import stat
from collections import OrderedDict
import numpy as np
from google.protobuf import text_format

import caffe  # pylint: disable=import-error

try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

import amct_caffe.optimizer as opt
from amct_caffe.optimizer.graph_optimizer import GraphOptimizer
from amct_caffe.operation.save_model import save_caffe_model
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.graph.graph import Graph
from amct_caffe.parser.parser import Parser
from amct_caffe.common.utils import files as files_util
from amct_caffe.operation.save_model import extract_net
from amct_caffe.common.utils.check_params import check_params
from amct_caffe.utils.log import LOGGER
from amct_caffe.lib.load_library import DeviceMode
from amct_caffe.lib.load_library import CPU_MODE
from amct_caffe.lib.load_library import GPU_MODE


def pretty_print(cos_sim_record):
    """ formate the print info"""
    for key, value in cos_sim_record.items():
        LOGGER.logi('{} : {} '.format(
            key, value), 'AutoCalibrationHelper')


def run_model(input_data, model_file, weights_file):
    """ run the model with the input data"""
    model_file = os.path.realpath(model_file)
    weights_file = os.path.realpath(weights_file)
    net = caffe.Net(model_file, weights_file, caffe.TEST)
    forward_kwargs = {'data': input_data}
    blobs_out = net.forward(**forward_kwargs)
    return blobs_out['output']


def parse_blob_to_np(file_path):
    """ Parse the dump blob binary file into numpy array dataformat"""
    real_file_path = os.path.realpath(file_path)
    files_util.check_file_path(real_file_path, 'feature_map_dump_file')
    with open(real_file_path, 'rb') as infile:
        blob = caffe_pb2.BlobProto()
        blob.MergeFromString(infile.read())
    np_data = caffe.io.blobproto_to_array(blob)
    return np_data


class AutoCalibrationHelper: # pylint: disable=R0902
    """ The helper class for auto calibration"""
    def __init__(self, # pylint: disable=R0913
                 fused_model_file,
                 fused_weights_file,
                 fq_model_file,
                 fq_weights_file,
                 quant_layers,
                 scale_offset_record_file,
                 amct_log_dir,
                 sensivity):
        """ init func of class AutoCalibrationHelper"""
        self.fused_model_file = fused_model_file
        self.fused_weights_file = fused_weights_file
        self.fq_model_file = fq_model_file
        self.fq_weights_file = fq_weights_file

        self.quant_layers = quant_layers
        self.scale_offset_record_file = scale_offset_record_file
        self.amct_log_dir = amct_log_dir
        self.history_record = OrderedDict()
        self.cosine_similarity_records = OrderedDict()
        self.single_layer_model_file = os.path.join(
            os.path.realpath(amct_log_dir), 'single_layer.prototxt')
        self.fq_single_layer_model_file = os.path.join(
            os.path.realpath(amct_log_dir), 'fake_quant_single_layer.prototxt')
        self.dump_files_list = []
        self.sensivity = sensivity
        self._init_graph()

    @staticmethod
    def save_prototxt_file(dump_model, file_path):
        """ Save the net to prototxt file"""
        #save in .prototxt
        files_util.create_file_path(file_path)
        dump_model = extract_net(dump_model)
        with open(file_path, "w") as file_model:
            file_model.write(
                text_format.MessageToString(dump_model, as_utf8=True))
        # set permission 640
        os.chmod(file_path, stat.S_IRUSR + stat.S_IWUSR + stat.S_IRGRP)
        LOGGER.logi(
            "The model_file is saved in %s" % (file_path),
            module_name='AutoCalibrationHelper')

    @staticmethod
    def add_input_layer(input_shape): # pylint: disable=R0201
        """ add the input layer to the caffe net"""
        net = caffe_pb2.NetParameter()
        input_layer = net.layer.add()
        input_param = caffe_pb2.InputParameter()
        shape = caffe_pb2.BlobShape()
        shape.dim.MergeFrom(input_shape)
        input_param_shape = input_param.shape.add()
        input_param_shape.CopyFrom(shape)
        input_layer.name = 'data'
        input_layer.type = 'Input'
        input_layer.top.MergeFrom(('data',))
        input_layer.input_param.CopyFrom(input_param)
        return net

    def find_fm_file_path(self, layer_name):
        """ find the dumped feature map blob binary files in amct_log_dir"""
        fm_file_list = []
        layer_name_prefix = '{}_{}'.format(layer_name.replace('/', '_'), 'ifmr_layer')
        log_dir = os.path.realpath(self.amct_log_dir)
        file_list = os.listdir(log_dir)
        for file_name in file_list:
            if file_name.startswith(layer_name_prefix):
                fm_file_list.append(os.path.join(log_dir, file_name))
        return fm_file_list

    def calc_ranking_info(self):
        """ calculate the cosine  similarity of single layer model and
            fake quant single layer model
        """
        real_amct_log_dir = os.path.realpath(self.amct_log_dir)
        if not os.path.isdir(real_amct_log_dir):
            raise RuntimeError('amct_log dir {} does not exists!'.format(real_amct_log_dir))

        for layer_name in self.quant_layers:
            fm_file_list = self.find_fm_file_path(layer_name)
            if len(fm_file_list) == 0:
                raise RuntimeError("Can not find dump file for layer {}".format(layer_name))
            cos_sim_list = []
            for fm_file_path in fm_file_list:
                np_feature_map = parse_blob_to_np(fm_file_path)
                # generate single layer model
                single_layer_net = self.generate_single_model(
                    layer_name, np_feature_map.shape)
                fake_single_layer_net = self.generate_fake_single_model(
                    layer_name, np_feature_map.shape)

                original_output = run_model(
                    np_feature_map, single_layer_net, self.fused_weights_file)
                fake_quant_output = run_model(
                    np_feature_map, fake_single_layer_net, self.fq_weights_file)
                cos_sim = self.sensivity.compare(
                    original_output.flatten(), fake_quant_output.flatten())
                cos_sim_list.append(cos_sim)

            self.cosine_similarity_records[layer_name] = np.mean(cos_sim_list)
            LOGGER.logi("******** sensitivity of layer {} is {} ********".format(
                layer_name, np.mean(cos_sim_list)))
        LOGGER.logi('******** sensitivity_records ******** ', 'AutoCalibrationHelper')
        pretty_print(self.cosine_similarity_records)

        return self.cosine_similarity_records

    def generate_single_model(self, layer_name, input_shape):
        """ generate the single layer prototxt file """
        graph = self.original_graph.deep_copy()
        net = self.add_input_layer(input_shape)
        object_node = None
        for node in graph.nodes:
            if node.name == layer_name:
                object_node = node
        if object_node is None:
            raise RuntimeError(
                'Can not find the node {} in graph.'.format(layer_name))
        object_layer = net.layer.add()
        object_layer.CopyFrom(object_node.dump_proto())
        object_layer.ClearField('bottom')
        object_layer.bottom.MergeFrom(('data',))
        object_layer.ClearField('top')
        object_layer.top.MergeFrom(('output',))
        AutoCalibrationHelper.save_prototxt_file(
            net, self.single_layer_model_file)
        return self.single_layer_model_file

    def generate_fake_single_model(self, layer_name, input_shape):
        """ generate the single fake quant layer prototxt file """
        graph = self.fq_graph.deep_copy()
        net = self.add_input_layer(input_shape)
        object_node = None
        dequant_node = None
        for node in graph.nodes:
            if node.name == layer_name:
                object_node = node
        if object_node is None:
            raise RuntimeError(
                'Can not find the node {} in graph.'.format(layer_name))
        quant_node = object_node.get_input_anchor(
            0).get_peer_output_anchor().node

        peer_input_anchors = object_node.get_output_anchor(
            0).get_peer_input_anchor()
        for peer_input_anchor in peer_input_anchors:
            if peer_input_anchor.node.type == 'DeQuant':
                dequant_node = peer_input_anchor.node
        if dequant_node is None:
            raise RuntimeError(
                'Can not find the dequant of node {} in graph.'.format(
                    layer_name))
        quant_layer = net.layer.add()
        quant_layer.CopyFrom(quant_node.dump_proto())
        quant_layer.ClearField('bottom')
        quant_layer.bottom.MergeFrom(('data',))

        object_layer = net.layer.add()
        object_layer.CopyFrom(object_node.dump_proto())
        dequant_layer = net.layer.add()
        dequant_layer.CopyFrom(dequant_node.dump_proto())
        dequant_layer.ClearField('top')
        dequant_layer.top.MergeFrom(('output',))
        AutoCalibrationHelper.save_prototxt_file(
            net, self.fq_single_layer_model_file)
        return self.fq_single_layer_model_file

    def _init_graph(self):
        """ do some initialization work of parsing model into graph."""
        files_util.check_file_path(self.fused_model_file, 'fused_model_file')
        files_util.check_file_path(self.fused_weights_file, 'fused_weights_file')
        files_util.check_file_path(self.fq_model_file, 'fq_model_file')
        files_util.check_file_path(self.fq_weights_file, 'fq_weights_file')
        # parse the original model
        parser = Parser(self.fused_model_file, self.fused_weights_file)
        self.original_graph = parser.parse_net_to_graph()
        # parse the fake quant model
        parser = Parser(self.fq_model_file, self.fq_weights_file)
        self.fq_graph = parser.parse_net_to_graph()


@check_params(
    graph=Graph,
    fused_model_file=str,
    fused_weights_file=str)
def inner_fuse_model(graph, fused_model_file, fused_weights_file):
    """
    Function: Modify graph, do conv+bn+scale fusion, weights calibration,
              insert IFMR layer and DeQuantLayer to each to be quantized layer,
              and save fused graph to caffe model.
    Parameter: graph: graph structure parsed from user caffe model
               fused_model_file: fused caffe model's model file path
               fused_weights_file: fused caffe model's weights file path
    Return: None
    """
    fuse_optimizer = GraphOptimizer()
    # only do the fusion pass
    if Configuration().get_fusion_switch():
        fuse_optimizer.add_pass(opt.CheckBNStatePass())
        fuse_optimizer.add_pass(opt.ScaleConvFusionPass())
        fuse_optimizer.add_pass(opt.BnConvFusionPass())
        fuse_optimizer.add_pass(opt.ConvBnFusionPass())
        fuse_optimizer.add_pass(opt.ConvScaleFusionPass())
        fuse_optimizer.add_pass(opt.FcBnFusionPass())
        fuse_optimizer.add_pass(opt.FcScaleFusionPass())
    fuse_optimizer.do_optimizer(graph)
    save_caffe_model(graph, fused_model_file, fused_weights_file)


@check_params(
    graph=Graph,
    modified_model_file=str,
    modified_weights_file=str)
def inner_quantize_model(graph,
                         modified_model_file,
                         modified_weights_file,
                         temp_dir):
    """
    Function: Modify graph, do conv+bn+scale fusion, weights calibration,
              insert IFMR layer and DeQuantLayer to each to be quantized layer,
              and save modified graph to caffe model, dump ifmr feature map;
    Parameter: graph: graph structure parsed from user caffe model
               modified_model_file: modified caffe model's model file path
               modified_weights_file: modified caffe model's weights file path
    Return: None
    """
    real_temp_dir = os.path.realpath(temp_dir)
    mode_dict = {CPU_MODE: 'CPU', GPU_MODE: 'GPU'}
    LOGGER.logi('Do weight calibration in {} mode'.format(
        mode_dict.get(DeviceMode().mode)), 'auto_calibration')

    quantize_optimizer = GraphOptimizer()
    if Configuration().get_fusion_switch():
        quantize_optimizer.add_pass(opt.CheckBNStatePass())
        quantize_optimizer.add_pass(opt.ScaleConvFusionPass())
        quantize_optimizer.add_pass(opt.BnConvFusionPass())
        quantize_optimizer.add_pass(opt.ConvBnFusionPass())
        quantize_optimizer.add_pass(opt.ConvScaleFusionPass())
        quantize_optimizer.add_pass(opt.FcBnFusionPass())
        quantize_optimizer.add_pass(opt.FcScaleFusionPass())
    quantize_optimizer.add_pass(opt.LstmWeightsCalibrationPass())
    quantize_optimizer.add_pass(opt.WeightsCalibrationPass())
    # ifmr need to dump ifmr stored data
    quantize_optimizer.add_pass(opt.InsertActCalibrationLayerPass(True, real_temp_dir))
    quantize_optimizer.add_pass(opt.LSTMCalibrationReplacePass())
    quantize_optimizer.add_pass(opt.InsertSearchNLayerPass())
    quantize_optimizer.do_optimizer(graph)
    save_caffe_model(graph, modified_model_file, modified_weights_file)
