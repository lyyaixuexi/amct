#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Data structure of graph which contains caffe model info

"""
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error


from amct_caffe.common.graph_base.graph_base import GraphBase
from amct_caffe.graph.node import Node
from amct_caffe.graph.data_node import DataNode
from amct_caffe.utils.log import LOGGER


class Graph(GraphBase):
    """
    Function: Data structure of graph which contains caffe model info
    APIs: init_graph, nodes, topologic_sort, add_edge, remove_edge,
          add_node, add_data_node, remove_node, get_node, dump_proto,
          deep_copy
    """
    def __init__(self, net, skip_train_phase=True):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        super().__init__(net)
        self._net = net
        self._init_graph(skip_train_phase)

    @property
    def net(self):
        """
        Function: Get NetParameter stored in graph
        Parameter: None
        Return: net in graph
        """
        return self._net

    @staticmethod
    def _init_identify_phase_train_layer(layer):
        if layer.HasField('phase') and layer.phase == caffe_pb2.TRAIN:
            LOGGER.logi('Layer {} is in TRAIN phase, skiped.'.format( \
                layer.name), 'Graph')
            return True
        skiped_flag = False
        for include in layer.include:
            if include.HasField('phase') and \
                include.phase == caffe_pb2.TRAIN:
                LOGGER.logi('Layer {} is in TRAIN phase, skiped.'.format( \
                    layer.name), 'Graph')
                skiped_flag = True
                break
        return skiped_flag

    def add_node(self, layer, index=None):
        """
        Function: Add node that constructed from layer to graph
        Parameter: None
        Return: Node that be added
        """
        node_id = self._decorate_node_name(layer.name)
        layer.name = node_id
        node = Node(node_id, len(self._nodes), layer)
        if index is None:
            self._nodes.insert(0, node)
        else:
            self._nodes.insert(index, node)

        return node

    def add_data_node(self, data_name):
        """
        Function: Add data node that constructed from name to graph
        Parameter: None
        Return: Node that be added
        """
        data_node = DataNode(len(self._data_nodes), data_name)
        self._data_nodes.append(data_node)
        return self._data_nodes[-1]

    def remove_node(self, node_name):
        """
        Function: Remove data node from graph by name
        Parameter: None
        Return: None
        """
        for index in range(len(self._nodes)):
            if self._nodes[index].name == node_name:
                del self._nodes[index]
                break

    def dump_proto(self):
        """
        Function: Dump graph to caffe.proto::NetParameter object
        Parameter: None
        Return: caffe.proto::NetParameter object
        """
        LOGGER.logi('Doing whole model dump...', module_name='Graph')
        self.topologic_sort()
        net = caffe_pb2.NetParameter()
        net.CopyFrom(self._net)
        for node in self._nodes:
            layer = net.layer.add()
            layer.CopyFrom(node.dump_proto())
        return net

    def deep_copy(self):
        """
        Function: Make a copy of current graph
        Parameter: None
        Return: Graph's copy
        """
        # Copy basic NetPrameter from existing graph
        copy_net = caffe_pb2.NetParameter()
        copy_net.CopyFrom(self._net)
        copy_graph = Graph(copy_net)
        # Copy each node/data_node from existing graph
        for node in self._nodes:
            copy_layer = caffe_pb2.LayerParameter()
            copy_layer.CopyFrom(node.dump_proto())
            copy_node = copy_graph.add_node(copy_layer)
            copy_node.set_attrs(node.attrs)

        for data_node in self._data_nodes:
            copy_graph.add_data_node(data_node.name)
        # Copy links from existing graph
        for data_node in self._data_nodes:
            for output_anchor in data_node.output_anchors:
                src_node = copy_graph.get_node_by_name(data_node.name)
                src_index = output_anchor.index
                for input_anchor in output_anchor.get_peer_input_anchor():
                    dst_node = copy_graph.get_node_by_name(
                        input_anchor.node.name)
                    dst_index = input_anchor.index
                    copy_graph.add_edge(src_node, src_index, dst_node,
                                        dst_index)

        for node in self._nodes:
            for output_anchor in node.output_anchors:
                src_index = output_anchor.index
                src_node = copy_graph.get_node_by_name(node.name)
                for input_anchor in output_anchor.get_peer_input_anchor():
                    dst_node = copy_graph.get_node_by_name(
                        input_anchor.node.name)
                    dst_index = input_anchor.index
                    copy_graph.add_edge(src_node, src_index, dst_node,
                                        dst_index)
        return copy_graph

    def _decorate_node_name(self, node_name):
        """decorate node_name to generate unique node_id"""
        node_id = node_name
        dec_index = 1
        while node_id in self._node_ids:
            node_id = '{}{}'.format(node_name, dec_index)
            dec_index += 1
        self._node_ids.append(node_id)
        return node_id

    def _init_data_nodes(self, output_record):
        """init all data nodes from net"""
        for input_data in self._net.input:
            output_record[input_data] = len(self._data_nodes), -1
            self._data_nodes.append(DataNode(len(self._data_nodes), \
                                              input_data))

    def _init_graph(self, skip_train_phase=True):
        """
        Function: Parse input caffe model, and construct digraph that can
                  present caffe model.
        Parameter: None
        Return: None
        """
        output_record = {}
        self._init_data_nodes(output_record)

        for layer in self._net.layer:
            # Skip layers that used in phase TRAIN
            if skip_train_phase and \
                Graph._init_identify_phase_train_layer(layer):
                continue

            LOGGER.logd('Init layer of {}'.format(layer.name), 'Graph')
            bottoms = layer.bottom
            tops = layer.top
            node_id = self._decorate_node_name(layer.name)
            node = Node(node_id, len(self._nodes), layer)
            # Add edge according to bottom info
            for index, bottom in enumerate(bottoms):
                if str(bottom) not in output_record:
                    raise RuntimeError("Cannot find input:{} of " \
                        "layer:{}".format(str(bottom), layer.name))
                node_index, output_index = output_record[str(bottom)]
                # Add edge between node
                src_node = None
                if output_index == -1:
                    if node_index >= len(self._data_nodes):
                        raise RuntimeError('Get data node {} out of range' \
                            .format(node_index))
                    src_node = self._data_nodes[node_index]
                    output_index = 0
                else:
                    if node_index >= len(self._nodes):
                        raise RuntimeError('Get node {} out of range'.format(
                            node_index))
                    src_node = self._nodes[node_index]

                dst_anchor = node.get_input_anchor(index)
                # Add edge from src node [output_index] to current node[index]
                LOGGER.logd('Add edge from {}[{}] to {}[{}]'.format(
                    src_node.name, output_index,
                    node.name, index), 'Graph')
                dst_anchor.add_link(src_node.get_output_anchor(output_index))
                src_node.get_output_anchor(output_index).add_link(dst_anchor)
            # Record output info according to current layer's top
            for index, top in enumerate(tops):
                output_record[str(top)] = [len(self._nodes), index]
            self._nodes.append(node)
        # After distribute layer info, clear self.net's layer info,
        # remain net's info
        self._net.ClearField('layer')
