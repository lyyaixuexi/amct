#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Data structure of data node which contains caffe input info

"""
from amct_caffe.common.graph_base.data_node_base import DataNodeBase
from amct_caffe.graph.anchor import OutputAnchor


class DataNode(DataNodeBase):
    """
    Function: Data structure of data node which contains caffe input info
    APIs: is_data_node, index, name, get_output_anchor, get_output_anchors
    """
    def __init__(self, index, data_name):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        super().__init__(index, data_name)
        self._init__io()

    def __repr__(self):
        return '< {}, outputs:{}>'.format(
            self._data_name,
            [x.name for x in self._output_anchors])

    def _init__io(self):
        """
        Function: Construct output anchor to node
        Parameter: None
        Return: None
        """
        self._output_anchors.append(OutputAnchor(self, 0, self._data_name))
