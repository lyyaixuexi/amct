#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Data structure of node which contains LayerParameter info

"""
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.common.graph_base.node_base import NodeBase
from amct_caffe.graph.anchor import InputAnchor
from amct_caffe.graph.anchor import OutputAnchor


class Node(NodeBase):
    """
    Function: Data structure of node which contains LayerParameter info
    APIs: is_data_node, index, set_index, name, type, layer, get_input_anchor,
          get_input_anchors, get_output_anchor, get_output_anchors,
          get_data, get_all_data, set_data, set_all_data, add_data,
          dump_proto
    """
    def __init__(self, node_id, node_index, node_proto):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        super().__init__(node_id, node_index, node_proto)
        self._basic_info['type'] = node_proto.type
        self._data = []
        # Init inputs, outputs info form layer
        self._init_bottom_info()
        self._init_top_info()
        self._node_proto.ClearField('top')
        self._node_proto.ClearField('bottom')
        # Extract parametes from layer.blobs
        for blob in self._node_proto.blobs:
            self._data.append(blob)
        self._node_proto.ClearField('blobs')

    def get_data(self, index):
        """
        Function: Get data by index
        Parameter: None
        Return: Data
        """
        if index >= len(self._data):
            raise RuntimeError('Node:{} get {} data out of range'.format(
                self._basic_info.get('name'), index))
        return self._data[index]

    def get_all_data(self):
        """
        Function: Get current node's all data
        Parameter: None
        Return: Data
        """
        return self._data

    def set_data(self, index, data):
        """
        Function: Set data by index
        Parameter: None
        Return: None
        """
        if index >= len(self._data):
            raise RuntimeError('Node:{} get {} data out of range'.format(
                self._basic_info.get('name'), index))
        self._data[index].CopyFrom(data)

    def set_all_data(self, all_data):
        """
        Function: Set all data in node
        Parameter: None
        Return: None
        """
        if len(self._data) != len(all_data):
            raise RuntimeError("Input all_data length {} not equal node's " \
                "all_data length{}".format(len(all_data), len(self._data)))
        for index, element in enumerate(all_data):
            self._data[index].CopyFrom(element)

    def add_data(self, data):
        """
        Function: Add one data to node
        Parameter: None
        Return: None
        """
        self._data.append(data)

    def update_type(self, new_type):
        """
        Function: Update node's type
        Parameter: new_type, string
        Returns: None
        """
        self._node_proto.type = new_type
        self._basic_info['type'] = self._node_proto.type

    def dump_proto(self):
        """
        Function: Dump node to caffe.proto::LayerParameter object
        Parameter: None
        Return: caffe.proto::LayerParameter object
        """
        layer = caffe_pb2.LayerParameter()
        layer.CopyFrom(self._node_proto)
        # Add blobs info to layer
        for data in self._data:
            blob = layer.blobs.add()
            blob.CopyFrom(data)
        # Add bottom input info to layer
        for input_anchor in self._input_anchors:
            peer_node = input_anchor.get_peer_output_anchor().node
            peer_index = input_anchor.get_peer_output_anchor().index

            if peer_index >= len(peer_node.output_anchors):
                raise RuntimeError("Get {} output from {} failed, out of " \
                    "range".format(peer_index, peer_node.name))
            peer_anchor_name = peer_node.get_output_anchor(peer_index).name
            layer.bottom.append(peer_anchor_name)
            input_anchor.set_name(peer_anchor_name)
        # Add top output info to layer
        for output_index in range(len(self._output_anchors)):
            reused_input_index = \
                self._output_anchors[output_index].get_reused_info()
            if reused_input_index is not None:
                layer.top.append(layer.bottom[reused_input_index])
                self._output_anchors[output_index].set_name(
                    layer.bottom[reused_input_index])
            else:
                layer.top.append(self._output_anchors[output_index].name)
        return layer

    def _init_bottom_info(self):
        """
        Function: Parse bottom info from layer, and construct input anchor
                  to node
        Parameter: None
        Return: None
        """
        for index in range(len(self._node_proto.bottom)):
            self._input_anchors.append(InputAnchor(self, index, \
                self._node_proto.bottom[index]))

    def _init_top_info(self):
        """
        Function: Parse top info from layer, and construct output anchor
                  to node
        Parameter: None
        Return: None
        """
        for index in range(len(self._node_proto.top)):
            reused_input_index = None
            one_of_top = self._node_proto.top[index]
            for input_index in range(len(self._node_proto.bottom)):
                if one_of_top == self._node_proto.bottom[input_index]:
                    reused_input_index = input_index
                    break
            self._output_anchors.append(OutputAnchor(self, index, \
                self._node_proto.top[index], reused_input_index))
