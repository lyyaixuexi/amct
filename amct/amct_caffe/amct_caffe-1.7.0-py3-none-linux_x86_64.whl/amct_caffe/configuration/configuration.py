#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Create quantize config file and parse config file.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import functools
from pathlib import Path

from amct_caffe.graph.graph import Graph
from amct_caffe.utils.log import LOGGER
from amct_caffe.configuration.check import GraphChecker
from amct_caffe.configuration.check import GraphQuerier
from amct_caffe.common.utils.check_params import check_params
from amct_caffe.common.utils.files import is_valid_name
from amct_caffe.common.utils.files import create_empty_file
from amct_caffe.common.config.config_base import ConfigBase
from amct_caffe.common.config.config_base import GraphObjects
from amct_caffe.common.config.config_base import check_config_quant_enable
from amct_caffe.configuration.init_config_from_record import \
    init_config_from_record

# load internal quantize algorithm
import amct_caffe.operation.wts_quant_algo # pylint: disable=W0611

from amct_caffe.capacity import CAPACITY

CLIBRATION_BIT = 8

CONFIGURER = ConfigBase(
    GraphObjects(graph_querier=GraphQuerier, graph_checker=None), CAPACITY)


class Configuration(): # pylint: disable=attribute-defined-outside-init
    """
    Function: manage configuration of project including quant_config
              and record_file.
    APIs: get_quant_config, get_layer_config, get_record_file_path;
        create_quant_config, parse_quant_config
    """
    __instance = None

    def __new__(cls, *args, **kw):
        if cls.__instance is None:
            cls.__instance = object.__new__(cls, *args, **kw)
        return cls.__instance

    @staticmethod
    @check_params(config_file=str,
                  graph=Graph,
                  skip_layers=(list, type(None)),
                  batch_num=int,
                  activation_offset=bool,
                  config_defination=(type(None), str))
    def create_quant_config(config_file, # pylint: disable=too-many-arguments
                            graph,
                            skip_layers=None,
                            batch_num=1,
                            activation_offset=True,
                            config_defination=None):
        """
        Function: Create quant config.
        Inputs:
            config_file: a string, the file(including path information) to
                save quant config.
            graph: IR Graph, the graph to be quantized.
            skip_layers: a list, layer names which would not apply quantize,
                the skip layer type should be in ['Conv2D', 'InnerProduct'].
            batch_num: an integer indicating how many batch of data are used
                for calibration.
            activation_offset: a bool indicating whether there's offset or not
                in quantize activation.
            config_defination: a string, the file containing the simple
                quant config according to proto.
        Returns: None
        """
        is_valid_name(config_file, 'config_file')
        GraphChecker.check_quant_behaviours(graph)

        if skip_layers is None:
            skip_layers = []
        if config_defination is None:
            CONFIGURER.create_quant_config(config_file, graph, skip_layers,
                                           batch_num, activation_offset)
        else:
            if len(skip_layers) != 0:
                LOGGER.logw(
                    "When using config_defination param of "
                    "create_quant_config, skip_layers need to be set "
                    "in simple quant config file!",
                    module_name="Configuration")
            CONFIGURER.create_config_from_proto(config_file, graph,
                                                config_defination)

    @staticmethod
    def add_global_to_layer(quant_config):
        """add global quantize parameter to each layer"""
        CONFIGURER.add_global_to_layer(quant_config, CLIBRATION_BIT)

        LOGGER.logd("Add global params to layer's config  success!",
                    module_name="Configuration")

    @staticmethod
    @check_params(file_name=str, graph=Graph)
    def parse_quant_config(file_name, graph):
        """parse quantize configuration from config json file"""
        quant_config = CONFIGURER.parse_config_file(file_name, graph)
        check_config_quant_enable(quant_config)
        Configuration.add_global_to_layer(quant_config)
        nuq_config = {}
        for item in quant_config:
            if not isinstance(quant_config[item], dict):
                continue
            if quant_config[item]['weight_quant_params'][
                    'wts_algo'] == 'nuq_quantize':
                nuq_config[item] = quant_config[item]
        return quant_config, nuq_config

    @check_params(config_file=str, record_file=str, graph=Graph)
    def init(self, config_file, record_file, graph):
        """
        Function: init the Configuration.
        Inputs:
            config_file: a string, the file containing the quant config.
            record_file: a string, the file containing the scale and offset.
            graph: IR Graph
        Returns: None
        """
        self.__record_file_path = os.path.realpath(record_file)
        self.__quant_config, self.__nuq_config = self.parse_quant_config(
            os.path.realpath(config_file), graph)
        self.__skip_fusion_layers = \
            self.__quant_config.get('skip_fusion_layers')
        self.__initialized = True

    def get_nuq_config(self):
        """ Get the non uniform quantization config"""
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__nuq_config

    def get_quant_config(self):
        """ get quant config. """
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__quant_config

    def get_layer_config(self, layer_name):
        """ get one lsyer's quant config. """
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__quant_config.get(layer_name)

    def get_record_file_path(self):
        """ get record_file_path. """
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__record_file_path

    def get_global_config(self, global_params_name):
        """ get global quant config. """
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__quant_config.get(global_params_name)

    def get_fusion_switch(self):
        """get global fusion switch state"""
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__quant_config.get('do_fusion')

    def get_skip_fusion_layers(self):
        """Get layers that need to skip do fusion"""
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        return self.__skip_fusion_layers

    def init_from_record(self, graph, scale_offset_record_file):
        """Parse quantize configuration from scale offset record file
        """
        self.__nuq_config = {}
        self.__quant_config, self.__record_file_path, \
        self.__skip_fusion_layers = \
            init_config_from_record(graph, scale_offset_record_file)
        self.__initialized = True

    def update_record_file(self, update_record_file):
        """Update record file path
        """
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        new_record_file_path = os.path.realpath(update_record_file)
        if not Path(new_record_file_path).exists():
            raise RuntimeError('Cannot find new record file:{}'.format( \
                               new_record_file_path))
        self.__record_file_path = new_record_file_path

    def save_nuq_quant_layer_names(self, save_dir, model_prefix):
        """ save non uniform layer name record file"""
        nuq_quant_layers = list(self.__nuq_config.keys())
        if len(nuq_quant_layers) == 0:
            LOGGER.logd('No non uniform quant layer exist in quant config.',
                        module_name='Configuration')
            return

        file_name = os.path.join(save_dir,
                                 model_prefix + '_nuq_layer_record.txt')
        file_name = create_empty_file(file_name, check_exist=True)
        line = functools.reduce(lambda x, y: x + ';' + y, nuq_quant_layers)
        with open(file_name, 'w') as nuq_record_file:
            nuq_record_file.write(line)
        LOGGER.logi('Create %s non uniform layer record.' % (file_name),
                    module_name='Configuration')

    def update_quant_config(self, quant_config):
        """Update member quant_config to new input quant_config"""
        if not self.__initialized:
            raise RuntimeError('Must init Configuration before access it.')
        self.__quant_config = quant_config
