#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Generate configs according to record file

"""
import os
import sys
from google.protobuf import text_format
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.configuration.check import GraphChecker
from amct_caffe.capacity import CAPACITY
from amct_caffe.utils.log import LOGGER
from amct_caffe.common.utils.util import proto_float_to_python_float

ENABLE_CHANNEL_WISE_TYERS = CAPACITY.get_value('CHANNEL_WISE_TYPES')
DBL_EPSILON = sys.float_info.epsilon


def init_config_from_record(graph, scale_offset_record_file):
    """Parse quantize configuration from scale offset record file
    """
    record_dir = os.path.realpath(scale_offset_record_file)
    records = caffe_pb2.ScaleOffsetRecord()
    with open(record_dir, 'r') as read_file:
        pbtxt_string = read_file.read()
        text_format.Merge(pbtxt_string, records)
    # At least should have some thing in record file, otherwise no need
    # to do quantize.
    if not records.record:
        raise RuntimeError('Cannot find record in records file: {}'.format(
            record_dir))

    quant_config = {
        'activation_offset': True,
        'batch_num': 2,
        'do_fusion': True
    }
    skip_fusion_layers = []

    for record in records.record:
        if not record.HasField('key'):
            raise RuntimeError('Cannot find "key" in record file.')
        key = record.key

        matched, target_node, _ = check_record_key(key, graph)
        # Check whether layer specified in record file exist in caffe model.
        if not matched:
            raise RuntimeError('Cannot find "{}" in graph.'.format(key))
        # each record should have key and value combine
        if not record.HasField('value'):
            raise RuntimeError('Cannot find "value" in record file ' \
                'of {}'.format(record.key))
        quant_node = _generate_quant_config(
            target_node, record.value, quant_config, skip_fusion_layers)

        if not quant_node and target_node.name not in skip_fusion_layers:
            raise RuntimeError('Exist empty node {} in record file'.format(
                target_node.name))
    return quant_config, record_dir, skip_fusion_layers


def check_record_key(key, graph):
    """check whether have layer:key in graph"""
    suffix = ''
    try:
        target_node = graph.get_node_by_name(key)
        return True, target_node, suffix
    except RuntimeError as get_normal_node_failed:
        if len(key) > 3 and key[-3:] == '_H0':
            layer_name = key[:-3]
            suffix = '_H0'
        elif len(key) > 2 and key[-2:] in ('_X', '_S', '_H'):
            layer_name = key[:-2]
            suffix = key[-2:]
        else:
            LOGGER.loge('Cannot find "{}" in model. {}'.format(
                key, get_normal_node_failed))
            return False, None, None
        try:
            target_node = graph.get_node_by_name(layer_name)
        except RuntimeError as get_lstm_node_failed:
            LOGGER.loge('Cannot find "{}" in model. {}'.format(
                key[:-2], get_lstm_node_failed))
            return False, None, None
        else:
            if target_node.type not in ('LSTM', 'LSTMCalibration'):
                LOGGER.loge('Find "{}" match LSTM name pattern, but its ' \
                    ' type is "{}"'.format(key, target_node.type))
                return False, None, None
            return True, target_node, suffix


def _generate_quant_config(node, record_value, quant_config,
                           skip_fusion_layers):
    """Parse and check single record, and generate quantize config
    """
    if record_value.shift_bit:
        raise RuntimeError('Found shift bit in layer: {}, not supported '\
            ' yet.'.format(node.name))

    if record_value.skip_fusion:
        if node.type != 'Convolution':
            raise TypeError('Illegal skip fusion layer "{}", only support ' \
                'do "Convolution" layer fusion.'.format(node.name))
        skip_fusion_layers.append(node.name)

    is_quant_layer, en_channel_wise = check_record_value(node, record_value)
    if is_quant_layer:
        if not GraphChecker.check_quantize_type(node):
            raise TypeError('layer "{}" not support do quantize yet.'.format(
                node.name))

        if node.type == 'LSTM':
            raise TypeError('Not supported do LSTM layer "{}" quantize ' \
                'yet.'.format(node.name))

        if node.name not in quant_config:
            quant_config[node.name] = {
                'weight_quant_params': {
                    'wts_algo': 'arq_quantize',
                    'channel_wise': en_channel_wise,
                    'with_offset': False,
                    'num_bits': 8
                }
            }
        return True
    return False


def check_record_value(node, record_value):
    """Check legality of value in record, return whether current node is
       quantize node, and whether do weights channel wise quantize
    """
    # scale_w and offset_w can be a vector, but must have same length
    layer_name = node.name
    if len(record_value.scale_w) != len(record_value.offset_w):
        raise RuntimeError('{} scale_w and offset_w must be same ' \
            'length'.format(layer_name))

    check_dict = {0: 'scale_d', 1: 'offset_d',
                  2: 'scale_w', 3: 'offset_w'}

    check_content = [record_value.HasField('scale_d'),
                     record_value.HasField('offset_d'),
                     record_value.scale_w,
                     record_value.offset_w]

    check_list = [check_dict.get(i) for i in range(len(check_dict)) if not check_content[i]]

    if node.type == 'Pooling':
        return _check_ave_pooling_record(node, check_list, record_value)

    # if check_list is not empty, means some parameters miss, need to check
    # whether all parameters miss, otherwise there are wrongs in record file.
    if check_list:
        if len(check_list) != len(check_content):
            raise RuntimeError('Cannot find {} in layer:{}'.format( \
                               ','.join(check_list), layer_name))
        # all quant parameters miss, means current layer is non-quantize layer
        return False, False

    # if check_list is empty, means all quantize parameter needed is satisfied,
    # current layer is quant layer, need check parameters' legality
    scales = [proto_float_to_python_float(record_value.scale_d)]
    scales.extend([proto_float_to_python_float(value) \
                  for value in record_value.scale_w])
    for scale in scales:
        # scale_d and scale_w must in range DBL_EPSILON, 1/DBL_EPSILON
        if scale < DBL_EPSILON or scale > 1/DBL_EPSILON:
            raise ValueError('Exist illegal scale {} in "{}"'.format( \
                             scale, layer_name))
    # offset_d must in range -128, 127
    if record_value.offset_d < -128 or record_value.offset_d > 127:
        raise ValueError('Exist illegal offset_d {} in "{}"'.format( \
                         record_value.offset_d, layer_name))
    # offset_w must be zero
    for offset in record_value.offset_w:
        if offset != 0:
            raise ValueError('Offset_w must be 0, {} in "{}"'.format( \
                             offset, layer_name))

    if len(record_value.scale_w) > 1:
        if node.type not in ENABLE_CHANNEL_WISE_TYERS and \
            node.type != 'LSTM':
            raise TypeError('Only support {} do channel wise quantize, '\
                'illegal weights parameters in "{}"["{}"]'.format( \
                ENABLE_CHANNEL_WISE_TYERS, node.name, node.type))

    return True, len(record_value.scale_w) > 1


def get_shape_from_pooling_layer(pooling_layer):
    """
    Function: get the shape grom pooling layer
    Inputs:
        pooling_layer: pooling layer
    Returns:
        kernel_h: kernel's h
        kernel_w: kernel's w
    """
    if not pooling_layer.HasField('pooling_param'):
        raise RuntimeError('Cannot find pooling_param in pooling ' \
            'layer {}'.format(pooling_layer.name))
    if pooling_layer.pooling_param.HasField('kernel_size'):
        kernel_h = pooling_layer.pooling_param.kernel_size
        kernel_w = pooling_layer.pooling_param.kernel_size
    elif pooling_layer.pooling_param.HasField('kernel_h') and \
        pooling_layer.pooling_param.HasField('kernel_w'):
        kernel_h = pooling_layer.pooling_param.kernel_h
        kernel_w = pooling_layer.pooling_param.kernel_w
    else:
        raise RuntimeError('Cannot find kernel param in pooling ' \
            'layer {}'.format(pooling_layer.name))
    return kernel_h, kernel_w


def _check_ave_pooling_record(node, check_list, record_value):
    """AVE Pooling only support user set scale_d, offset_d, and not
       supported global pooling yet.
    """
    layer_name = node.name
    if not GraphChecker.check_quantize_type(node):
        raise TypeError('Pooling layer {} not supported do quantize ' \
            'yet'.format(layer_name))

    if check_list != ['scale_w', 'offset_w']:
        raise ValueError('To quantize AVE pooling layer:{}, must and ' \
            'only set ["scale_d", "offset_d", "channels", "height", ' \
            ' "width"]'.format(layer_name))

    if record_value.scale_d < DBL_EPSILON or \
        record_value.scale_d > 1/DBL_EPSILON:
        raise ValueError('Exist illegal scale {} in "{}"'.format( \
                         record_value.scale_d, layer_name))
    if record_value.offset_d < -128 or record_value.offset_d > 127:
        raise ValueError('Exist illegal offset {} in "{}"'.format( \
                       record_value.offset_d, layer_name))
    return True, False
