#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Create quantize config file and parse config file.

""""""
"""
from amct_caffe.utils.log import LOGGER

MODULE_NAME = 'Retrain_json_config'


class RetrainJsonConfig():
    """
    Function: manage json config.
    APIs: init, get_quant_config, get_layer_config, get_record_file_path;
        create_quant_config, parse_quant_config
    """
    def __init__(self, retrain_config):
        self.config = retrain_config
        self.decent_config = {}

    @staticmethod
    def _check_layer_act_config(layer_config, layer):
        key = 'retrain_data_config'
        if key not in layer_config.keys():
            raise ValueError("retrain enabled but no data config found" \
                    " for layer %s " % (layer))
        decent_retrain_data_config = {}
        retrain_data_config = layer_config[key]
        key = 'algo'
        if key not in retrain_data_config or\
                retrain_data_config[key] != 'ulq_quantize':
            raise ValueError("retrain algo only supports ulq_quantize for" \
                    " layer %s " % (layer))
        decent_retrain_data_config[key] = 'ulq_quantize'
        del retrain_data_config[key]
        if 'clip_max' in retrain_data_config.keys() and\
            'clip_min' in retrain_data_config.keys():
            clip_max = retrain_data_config['clip_max']
            clip_min = retrain_data_config['clip_min']
            if not isinstance(clip_max, float) \
                    or not isinstance(clip_min, float):
                raise ValueError("clip value shoud be of type float for"\
                        " layer %s " % (layer))
            if clip_min > 0:
                raise ValueError("clip min should be less than 0 for layer %s"\
                    % (layer))
            if clip_max < 0:
                raise ValueError("clip max should be larger than 0 for layer"\
                    " %s " % (layer))
            del retrain_data_config['clip_max']
            del retrain_data_config['clip_min']
            decent_retrain_data_config['clip_max'] = clip_max
            decent_retrain_data_config['clip_min'] = clip_min
        if 'fixed_min' in retrain_data_config.keys():
            fixed_min = retrain_data_config['fixed_min']
            if not isinstance(fixed_min, bool):
                raise ValueError("fixed_min is not a bool type for layer %s "\
                        % (layer))
            del retrain_data_config['fixed_min']
            decent_retrain_data_config['fixed_min'] = fixed_min
        if retrain_data_config.keys():
            LOGGER.logw("there are some Redundant config item in %s's retrain"\
                " data config" % (layer), module_name=MODULE_NAME)
        return decent_retrain_data_config

    @staticmethod
    def _check_if_all_disable(all_disable):
        if all_disable:
            raise ValueError("At least one layer enable retrain")

    @staticmethod
    def _check_has_key(key, body, valid_range):
        if key not in body.keys():
            raise ValueError("body %s must have key %s" % (body, key))
        if body[key] not in valid_range:
            raise ValueError("key %s should in range %s" % (key, valid_range))

    def check_version(self):
        """check version"""
        config = self.config
        #check version
        key = 'version'
        if key not in config.keys() or config[key] != 1:
            raise ValueError("version should be 1")
        self.decent_config[key] = 1
        del config[key]

    def check_batch_num(self):
        """check batch_num"""
        key = 'batch_num'
        if key not in self.config.keys() or self.config[key] < 1:
            raise ValueError("batch_num shoud greater equal than 1")
        self.decent_config[key] = self.config[key]
        del self.config[key]

    def validate_and_fill_blank(self, layers):
        """validate and fill blank"""
        config = self.config
        self.check_version()
        self.check_batch_num()
        #check weights
        self._check_weights_offsets()
        #check layer config
        layers_to_delete = []
        all_disable = True

        for layer in config.keys():
            layers_to_delete.append(layer)
            if layer not in layers.keys():
                continue
            layer_config = config[layer]
            decent_layer_config = {}
            key = 'retrain_enable'
            self._check_has_key(key, layer_config, [True, False])

            retrain_enabled = layer_config[key]
            decent_layer_config[key] = layer_config[key]
            del layer_config[key]
            if not retrain_enabled:
                config[layer] = decent_layer_config
                self.decent_config[layer] = decent_layer_config
                continue
            all_disable = False
            # data retrain config
            decent_retrain_data_config = self._check_layer_act_config(
                layer_config,
                layer)
            decent_layer_config['retrain_data_config'] =\
                    decent_retrain_data_config
            del layer_config['retrain_data_config']
            # weights retrain config
            key = 'retrain_weight_config'
            if key not in layer_config.keys():
                raise ValueError("retrain enabled but no weight config found" \
                    " for layer %s " % (layer))
            decent_retrain_weight_config = {}
            retrain_weight_config = layer_config[key]
            key = 'algo'
            if key not in retrain_weight_config or\
                retrain_weight_config[key] != 'arq_retrain':
                raise ValueError("retrain algo only supports arq_retrain for"\
                    " layer %s " % (layer))
            decent_retrain_weight_config[key] = 'arq_retrain'
            del retrain_weight_config[key]
            if 'channel_wise' not in retrain_weight_config.keys():
                raise ValueError("retrain enabled but channel_wise option"\
                    " found for layer %s " % (layer))
            channel_wise = retrain_weight_config['channel_wise']
            if not isinstance(channel_wise, bool):
                raise ValueError("channel_wise should be bool type for layer"\
                    " %s " % (layer))
            if layers[layer] == 'InnerProduct' and channel_wise is True:
                raise ValueError("channel_wise should be false since layer"\
                    "%s is InnerProduct" % (layer))
            decent_retrain_weight_config['channel_wise'] = channel_wise
            del retrain_weight_config['channel_wise']
            if retrain_weight_config.keys():
                LOGGER.logw("there are some Redundant config item in %s's"\
                    " weight data config" % (layer), module_name=MODULE_NAME)
            decent_layer_config['retrain_weight_config'] = \
                decent_retrain_weight_config
            del layer_config['retrain_weight_config']

            self.decent_config[layer] = decent_layer_config

        self._check_if_all_disable(all_disable)

        return self.decent_config

    def _check_weights_offsets(self):
        config = self.config
        key = 'weights_offset'
        if key in config.keys():
            raise ValueError("weights offset currently not supported")
