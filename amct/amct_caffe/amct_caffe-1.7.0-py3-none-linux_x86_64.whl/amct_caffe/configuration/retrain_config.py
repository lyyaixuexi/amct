#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Create quantize config file and parse config file.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os

import copy
import json

from amct_caffe.graph.graph import Graph
from amct_caffe.utils.log import LOGGER
from amct_caffe.configuration.retrain_json_config import RetrainJsonConfig
from amct_caffe.configuration.check import GraphChecker
from amct_caffe.configuration.check import GraphQuerier
from amct_caffe.common.utils.check_params import check_params
from amct_caffe.common.utils.files import create_empty_file
from amct_caffe.common.retrain_config.retrain_config_base import \
        RetrainConfigBase
from amct_caffe.common.config.config_base import GraphObjects

from amct_caffe.capacity import CAPACITY

CLIBRATION_BIT = 8

CONFIGURER = RetrainConfigBase(
    GraphObjects(graph_querier=GraphQuerier, graph_checker=None), CAPACITY
)


class RetrainConfig():
    """
    Function: manage configuration of project including quant_config
              and record_file.
    APIs: init, get_quant_config, get_layer_config, get_record_file_path;
        create_quant_config, parse_quant_config
    """
    __instance = None
    __initialized = False

    def __new__(cls, *args, **kw):
        if cls.__instance is None:
            cls.__instance = object.__new__(cls, *args, **kw)
        return cls.__instance

    def __init__(self):
        super(RetrainConfig, self).__init__()
        if not RetrainConfig.__initialized:
            raise RuntimeError("The classmethod RetrainConfig.init() "
                               "should be called at first.")
        self.__retrain_config = RetrainConfig.retrain_config
        self.__skip_fusion_layers = []

    @classmethod
    def un_init(cls):
        """uninitialize class"""
        cls.__initialized = False

    @classmethod
    def get_record_file_path(cls):
        """ get record_file_path.  """""
        return cls.record_file_path

    @classmethod
    @check_params(config_file=str)
    def init_retrain(cls, config_file, graph):
        """
        Function: init the RetrainConfig.
        Inputs:
            config_file: a string, the file containing the quant config.
            graph: IR Graph
        Returns: None
        """
        cls.retrain_config = cls.parse_retrain_config(
            os.path.realpath(config_file), graph)
        RetrainConfig.__initialized = True

    @classmethod
    @check_params(scale_offset_record_file=str)
    def set_record_file(cls, scale_offset_record_file):
        """get record file """
        cls.record_file_path = os.path.realpath(scale_offset_record_file)

    @staticmethod
    @check_params(file_name=str, graph=Graph)
    def parse_retrain_config(file_name, graph):
        """
        Function: parse config json file for project to use.
        Inputs:
            file_name:a string, the file(including path information)
                      to save quant config.
            graph: IR Graph, the graph to be quantized.
        Returns:
            quant_config: a dictionary, containing the quant config.
        """

        file_name = os.path.realpath(file_name)

        # function Step1: read file
        def _detect_repetitive_key_hook(lst):
            '''
            a hook function for detect repeated key in config file.
            '''
            all_ks = [k for k, val in lst]
            found_repeat_ks = find_repeated_items(all_ks)
            if found_repeat_ks:
                raise ValueError(
                    "Please delete repeated items in %s, repeated items "\
                    "are %s." % (file_name, found_repeat_ks))
            results = {}
            for k, val in lst:
                results[k] = val
            return results

        with open(file_name, 'r') as retrain_cfg_file:
            retrain_config = json.load(
                retrain_cfg_file,
                object_pairs_hook=_detect_repetitive_key_hook)
        LOGGER.logd(
            'The retrain_config read from %s is:\n%s' \
                % (file_name, retrain_config), module_name='RetrainConfig')

        # function Step2: check
        # 2.1 check the graph
        GraphChecker.check_quant_behaviours(graph)
        quant_layers = GraphQuerier.get_support_quant_layer2type(graph)
        # 2.2 check the config
        retrain_json_config = RetrainJsonConfig(retrain_config)
        retrain_config = retrain_json_config.validate_and_fill_blank(
            quant_layers)

        layers_to_delete = []

        for key, value in retrain_config.items():
            if isinstance(value, dict) and not value['retrain_enable']:
                layers_to_delete.append(key)
        for layer in layers_to_delete:
            del retrain_config[layer]

        return retrain_config

    @staticmethod
    @check_params(config_name=str, graph=Graph, config_defination=(str))
    def create_quant_retrain_config(
            config_name,
            graph,
            config_defination):
        """
        Function: Create retrain config.
        Inputs:
            config_name: a string, the file(including path information) to
                save retrain config.
            graph: IR Graph, the graph to be retrainized.
            config_file: the file containing the simple retrain config
                according to proto.
        Returns: None
        """
        config_name = os.path.realpath(config_name)

        config_file = os.path.realpath(config_defination)
        LOGGER.logi("Create %s according to %s, other configuration "
                    "will be ignored." % (config_name, config_file),
                    module_name='RetrainConfig')
        CONFIGURER.create_config_from_proto(
            config_name,
            graph,
            config_file)

        LOGGER.logi("Create quant config success!",
                    module_name='RetrainConfig')

    @staticmethod
    def filt_white_list(quantizable_layers):
        """filt whilte list"""
        keys_to_delete = []
        for key, value in quantizable_layers.items():
            if value not in ['InnerProduct', 'Convolution',\
                    'Deconvolution', 'Pooling']:
                keys_to_delete.append(key)
        for key in keys_to_delete:
            del quantizable_layers[key]

    @staticmethod
    @check_params(file_name=str, graph=Graph)
    def create_default_retrain_config(file_name, graph):
        """create deafult config"""

        CONFIGURER.create_default_config(
            file_name,
            graph)
        LOGGER.logd("Create retrain config by file success!",
                    module_name='RetrainConfig')

    @staticmethod
    def _check_conflict_layer(override_layers, skip_layers):
        conflict_layers = [layer for layer in override_layers if layer in skip_layers]
        if conflict_layers:
            raise RuntimeError("Following layers are found in skip_layers and "
                               "override_layers: %s" % (conflict_layers))

    def retrain_enable(self, layer):
        """if retrain enable"""
        if layer not in self.__retrain_config.keys():
            return False
        return self.__retrain_config[layer]['retrain_enable']

    def get_retrain_config(self, layer):
        """get retrain config"""
        if not self.retrain_enable(layer):
            return None
        return self.__retrain_config[layer]

    def get_quant_config(self):
        """get retrain config"""
        config = copy.deepcopy(self.__retrain_config)
        config['activation_offset'] = True

        return config

    def get_layer_config(self, layer):
        """get retrain config"""
        layer_config = self.get_retrain_config(layer)
        if layer_config is None:
            return None
        config = {}
        config['weight_quant_params'] = {}
        config['weight_quant_params']['with_offset'] = False
        config['weight_quant_params']['num_bits'] = 8
        config['weight_quant_params']['wts_algo'] = 'arq_quantize'
        config['weight_quant_params']['channel_wise'] =\
                layer_config['retrain_weight_config']['channel_wise']

        return config

    def get_skip_fusion_layers(self):
        """Get layers that need to skip do fusion"""
        return self.__skip_fusion_layers


def _save_config_json(quant_config, file_name):
    file_name = create_empty_file(file_name)
    with open(file_name, 'w') as quant_cfg_file:
        json.dump(
            quant_config, quant_cfg_file, indent=4, separators=(',', ':'))
    LOGGER.logi("The quant config is saved in %s" % (file_name),
                module_name="RetrainConfig")


def find_repeated_items(item_list):
    '''find repeated items in a list '''
    repeat_items = set()
    for item in item_list:
        count = item_list.count(item)
        if count > 1:
            repeat_items.add(item)

    return list(repeat_items)
