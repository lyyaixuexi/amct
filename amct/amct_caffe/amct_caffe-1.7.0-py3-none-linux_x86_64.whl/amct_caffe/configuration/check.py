#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Check the config dictionary, graph and the node.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import functools

try:
    from caffe.proto import caffe_pb2  # pylint: disable=import-error
except ImportError:
    import caffe_pb2  # pylint: disable=import-error

from amct_caffe.utils.log import LOGGER
from amct_caffe.capacity import CAPACITY
QUANTIZABLE_TYPES = CAPACITY.get_value('QUANTIZABLE_TYPES')

QUANT_TYPES = ("Quant", "DeQuant", "IFMR", "HFMG")
AVE_FLAG = caffe_pb2.PoolingParameter.PoolMethod.AVE
QUANT_LAYER_SUFFIX = ('_quant_layer', '_dequant_layer', '_anti_quant_layer')


class GraphQuerier():
    '''provide some APIs to query the graph'''
    @staticmethod
    def get_name_type_dict(graph):
        '''get all layer name to type dict'''
        layer_type = {}
        for node in graph.nodes:
            layer_type[node.name] = node.type
        return layer_type

    @staticmethod
    def get_support_quant_layer2type(graph):
        '''return supported layer to type map in graph'''
        layers = {}
        for node in graph.nodes:
            if GraphChecker.check_quantize_type(node):
                layers[node.name] = node.type
        return layers

    @staticmethod
    def get_support_quant_layers(graph):
        '''return supported quant layers in graph'''
        layers = []
        for node in graph.nodes:
            if GraphChecker.check_quantize_type(node):
                layers.append(node.name)
        return layers

    @staticmethod
    def get_nuq_quant_layers(graph):
        '''get nuq quant layers'''
        layers = []
        for node in graph.nodes:
            if GraphChecker.check_nuq_quantize_type(node):
                layers.append(node.name)
        return layers

    @staticmethod
    def check_nuq_steps(graph, layer_name, steps):
        '''check if nuq steps is bigger than weight length'''
        node = graph.get_node_by_name(layer_name)
        weights_blob = node.get_data(0)
        weights_shape = GraphChecker.get_blob_shape(weights_blob)
        weight_length = functools.reduce(lambda x, y: x * y, weights_shape)
        if weight_length < steps:
            return False
        return True

    @staticmethod
    def check_op_matching(graph, fused_op_list):
        """
        Function: Check whether the ops in json the ops in the original graph
        Inputs:
            graph: Graph, to be quantized
            fused_op_list: list, the ops parsed from the json file
        """
        # check whether the ops in json the ops in the original graph
        original_graph_ids = graph.node_ids
        for json_op_name in fused_op_list:
            is_quant_op = False
            for quant_suffix in QUANT_LAYER_SUFFIX:
                if quant_suffix in json_op_name:
                    is_quant_op = True
            if is_quant_op:
                continue
            if json_op_name not in original_graph_ids:
                LOGGER.logd(
                    "Op '{}' in the given mapping_file does not exist in the original graph. "\
                    "The mapping_file may not match the original graph, "\
                    "please check!".format(json_op_name))

    @staticmethod
    def get_act_symmetric_limit_types():
        """get type only support activation symmetric"""
        return []

    @staticmethod
    def get_act_symmetric_limit_layers(graph):
        """get layer only support activation symmetric"""
        return []


class GraphChecker():
    """Check the graph."""
    @staticmethod
    def get_blob_shape(blob):
        """Get one blob's shape.
        Inputs:
            blob: blob from caffe.
        Returns:
            blob_shape: the shape of blob, can be a list or None. None means
                there's no shape or 'N, C, H, W' in the blob.
        """
        # get shape
        shape = None
        if blob.HasField("shape"):
            shape = blob.shape.dim
        # get 'N, C, H, W'
        dimension = [None, None, None, None]
        if blob.HasField("num"):
            dimension[0] = blob.num
        if blob.HasField("channels"):
            dimension[1] = blob.channels
        if blob.HasField("height"):
            dimension[2] = blob.height
        if blob.HasField("width"):
            dimension[3] = blob.width
        if dimension != [None, None, None, None] and None in dimension:
            raise ValueError("Invalid blob's dimension %s" % (dimension))
        # find shape
        if shape is None:
            if dimension == [None, None, None, None]:
                blob_shape = None
            else:
                blob_shape = dimension
        else:
            if dimension == [None, None, None, None]:
                blob_shape = shape
            else:
                raise ValueError("There're shape(%s) and 'N, C, H, W'(%s) "\
                                 "at the same time." % (shape, dimension))
        return blob_shape

    @staticmethod
    def check_quantize_type(node):
        """ check if node can be quantized or not."""
        # check type
        if node.type not in QUANTIZABLE_TYPES:
            return False
        # check invalid inputs
        if node.type != 'LSTM' and len(node.input_anchors) != 1:
            raise RuntimeError(
                "%s layer(%s) should have 1 input but actually %s inputs."\
                % (node.type, node.name, len(node.input_anchors)))

        if node.type == 'Pooling' and (
                node.proto.pooling_param.pool != AVE_FLAG or \
                node.proto.pooling_param.global_pooling):
            return False

        if node.type == 'InnerProduct' and (
                node.proto.inner_product_param.axis != 1
                or node.proto.inner_product_param.transpose):
            return False

        if node.type == 'LSTM':
            if not node.proto.HasField('recurrent_param'):
                raise RuntimeError('LSTM supported must have recurrent_param.')
            input_num = len(node.input_anchors)
            output_num = len(node.output_anchors)
            expose_hidden = node.proto.recurrent_param.expose_hidden

            supported_state = [
                # static_input: False, expose_hidden: False
                [2, 1, False],
                # static_input: True, expose_hidden: False
                [3, 1, False],
                # static_input: False, expose_hidden: True
                [4, 3, True],
                # static_input: True, expose_hidden: True
                [5, 3, True],
            ]
            if [input_num, output_num, expose_hidden] not in supported_state:
                raise RuntimeError('Not support LSTM layer in state: ' \
                    'input_num:{}, output_num:{}, expose_hidden:{}'.format(
                        input_num, output_num, expose_hidden))

        if not check_conv_type(node):
            return False

        return True

    @staticmethod
    def check_nuq_quantize_type(node):
        """ check if node can be non uniform quantized or not."""
        # check type
        if node.type not in CAPACITY.get_value('NUQ_QUANTIZABLE_TYPES'):
            return False
        # check invalid inputs
        if len(node.input_anchors) != 1:
            raise RuntimeError(
                "%s layer(%s) should have 1 input but actually %s inputs."\
                % (node.type, node.name, len(node.input_anchors)))

        if node.type == 'Convolution':
            # conv2D
            if not _check_weight(node, 4):
                return False
            # group is 1
            if not _check_group(node, 1):
                return False
            # dilation is 1
            if not _check_dilation(node, ([], [1], [1, 1])):
                return False
        return True

    @staticmethod
    def check_quant_behaviours(graph):
        """
        Function: Check whether there're quant behaviours in the graph.
            If there're layers defined by AMCT, raise error.
        Inputs: None
        Return: None
        """
        # find all the layers whose type is in QUANT_TYPES
        quant_defined_layers = []
        for node in graph.nodes:
            if node.type in QUANT_TYPES:
                quant_defined_layers.append(node.name)
        # check
        if quant_defined_layers:
            raise RuntimeError("The model cannot be quantized for following "\
                "quant layers are in the net %s" % (quant_defined_layers))


def check_conv_type(node):
    """Check conv type and deconv type."""
    if node.type in ('Convolution', 'Deconvolution'):
        # conv2D
        if not _check_weight(node, 4):
            return False
        if node.type == 'Deconvolution':
            # dilation is 1
            if not _check_dilation(node, ([], [1], [1, 1])):
                return False
    return True


def _check_weight(node, weights_dimension):
    """ Check whether the node's blob[0]'s shape satisfy weights_dimension"""
    if not node.get_all_data():
        raise RuntimeError("Layer %s has no weight." % (node.name))

    weights_shape = GraphChecker.get_blob_shape(node.get_data(0))
    if weights_shape is None or len(weights_shape) != weights_dimension:
        LOGGER.logd("The %s's weights_shape is %s" \
                    % (node.name, weights_shape),
                    module_name="Configuration")
        return False

    return True


def _check_dilation(node, dilation_range):
    """ Check whether the node's dilation satisfy dilation_range"""
    dilation = node.proto.convolution_param.dilation
    if dilation not in dilation_range:
        LOGGER.logd("Layer %s's dilation is %s." % (node.name, dilation),
                    module_name="Configuration")
        return False

    return True


def _check_group(node, group_range):
    """ Check whether the node's group satisfy group_range"""
    group = node.proto.convolution_param.group
    if group != group_range:
        LOGGER.logd("Layer %s's group is %s." % (node.name, group))
        return False

    return True
