#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

the auto non uniform quantize main API

"""
import os
import copy
import time
import collections
from pathlib import Path
import numpy as np
from google.protobuf import text_format
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.common.utils.check_params import check_params
from amct_caffe.common.utils import files as files_util

from amct_caffe.configuration.configuration import Configuration
from amct_caffe.parser.parser import Parser

from amct_caffe.optimizer.graph_optimizer import GraphOptimizer
from amct_caffe.optimizer.scale_conv_fusion_pass import ScaleConvFusionPass
from amct_caffe.optimizer.bn_conv_fusion_pass import BnConvFusionPass
from amct_caffe.optimizer.conv_bn_fusion_pass import ConvBnFusionPass
from amct_caffe.optimizer.conv_scale_fusion_pass import ConvScaleFusionPass
from amct_caffe.optimizer.fc_bn_fusion_pass import FcBnFusionPass
from amct_caffe.optimizer.fc_scale_fusion_pass import FcScaleFusionPass

from amct_caffe.quantize_tool import generate_model_name
import amct_caffe.quantize_tool as quantize_tool

from amct_caffe.utils.log import LOGGER
from amct_caffe.operation.save_model import save_caffe_model
from amct_caffe.utils.auto_nuq_helper import AutoNuqHelper
from amct_caffe.utils.auto_nuq_helper import AutoNuqLayer
from amct_caffe.utils.auto_nuq_helper import time_info
from amct_caffe.utils.auto_nuq_strategy import AutoNuqStrategyBisection

AUTO_NUQ_QUIT = -1
AUTO_NUQ_KEEP_SEARCH = 0
AUTO_NUQ_16_SATISFY = 1


class AutoNuqEvaluatorBase:
    """" the base class for AutoNuqEvaluator"""
    def __init__(self, batch_num_of_eval):
        """
        Function:
                __init__ function of class
        Parameter:
                batch_num_of_eval: the batch num of evaluation
        """
        self.evaluate_batch_num = batch_num_of_eval


    def eval_model(self, # pylint: disable=R0201
                   model_file,
                   weights_file,
                   batch_num):
        """
        Function:
                evaluate the input models, get the eval metric of model
        Parameter:
                model_file:   the prototxt model define file of caffe model
                weights_file: the binary caffemodel file of caffe model
                batch_num:    the batch num of eval function
        Return:
                metric: the eval metric of input caffe model, such as:
                top1 accuracy for classification model, mAP for detection model
        """
        raise RuntimeError('Not implemented.')


    def is_satisfied(self, # pylint: disable=R0201
                     original_metric,
                     new_metric):
        """
        Function:
                whether the gap between new metrics and original metric can
                satisfy the requirement.
        Parameter:
                original_metric: metric of eval original caffe model
                new_metric: metric of eval quantized caffe model
        Return:
                is_satisfied [bool]: True for satisfied and False for not
        """
        raise RuntimeError('Not implemented.')

    def get_evaluate_batch_num(self):
        """ get the evaluate batch num of evaluator.
        """
        if self.evaluate_batch_num is None:
            raise RuntimeError(
                "[AutoNuqEvaluatorBase] : evaluate_batch_num is None. ")
        return self.evaluate_batch_num


def get_record_by_name(records, layer_name):
    """ util for get specificed record"""
    for record in records:
        if record.key == layer_name:
            return record
    return None


def exchange_record(record, ref_record):
    """ exchange the record of two model"""
    for _ in range(len(record.value.scale_w)):
        record.value.scale_w.pop()
        record.value.offset_w.pop()
    record.value.scale_w.extend(ref_record.value.scale_w)
    record.value.offset_w.extend(ref_record.value.offset_w)



class AutoNuq: # pylint: disable=R0902
    """ the class for AutoNuq API"""
    def __init__(self,
                 model_file,
                 weights_file,
                 scale_offset_record_file):
        self.model_file = model_file
        self.weights_file = weights_file
        self.scale_offset_record_file = scale_offset_record_file

        self.original_graph = None
        self.nuq_evaluator = None
        self.nuq_helper = None
        self.nuq_strategy = None
        self.save_dir = None
        self.calibration_batch_num = None
        self.graph = None
        self.modified_model_file = None
        self.modified_weights_file = None

        self.history_status = collections.OrderedDict()
        self.iteration = 0
        self.iteration_time = 0
        self.auto_nuq_layers_params = collections.OrderedDict()
        self.original_metric = None
        self.current_metric = None
        self.quantized_model = None
        self.fake_quant_model = None
        self.fake_quant_caffemodel = None
        self.record = None
        self.auto_nuq_layers = None

    def quant_model_with_global_step(self, global_step):
        """
        Function:
                quantize the input model with global config, all arq or all
                nuq 32 steps or all nuq 16 steps.
        Parameter:
                global_step: arq, nuq_32, nuq_16
        """

        self.graph = self.original_graph.deep_copy()
        quantize_tool.quantize_model(
            self.graph,
            self.modified_model_file,
            self.modified_weights_file)

        records = caffe_pb2.ScaleOffsetRecord()
        with open(Configuration().get_record_file_path(), 'r') as record_file:
            pbtxt_string = record_file.read()
            text_format.Merge(pbtxt_string, records)

        # record the scale offset record to nuq helper
        self.nuq_helper.ref_records[global_step] = copy.deepcopy(
            records)

        # activation calibration process
        self.nuq_evaluator.eval_model(
            self.modified_model_file,
            self.modified_weights_file,
            self.calibration_batch_num)

        quantize_tool.save_model(self.graph.deep_copy(), 'Both', self.save_dir)
        save_dir, save_prefix = os.path.split(self.save_dir)
        self.fake_quant_model, self.fake_quant_caffemodel = \
            generate_model_name(save_dir, save_prefix, 'Fakequant')

        with open(Configuration().get_record_file_path(), 'w') as record_file:
            record_file.write('')

    def quant_model_without_global_step(self):
        """ quantize the model with given quant config."""
        files_util.create_empty_file(self.scale_offset_record_file)

        # modify the current graph according to the quant config
        for layer_name in self.auto_nuq_layers:
            if layer_name in self.auto_nuq_layers_params.keys():
                layer_step = self.auto_nuq_layers_params[layer_name].step
                layer_step_key = self.nuq_helper.find_steps.get(layer_step)
                self.graph.get_node_by_name(layer_name).set_data(
                    0, self.nuq_helper.get_weights_data(
                        layer_step_key, layer_name))
                record = get_record_by_name(self.record.record, layer_name)
                ref_record = self.nuq_helper.get_layer_record(
                    layer_step_key, layer_name)
                exchange_record(record, ref_record)

            else:
                self.graph.get_node_by_name(layer_name).set_data(
                    0, self.nuq_helper.get_weights_data('arq', layer_name))

                record = get_record_by_name(self.record.record, layer_name)
                ref_record = self.nuq_helper.get_layer_record(
                    'arq', layer_name)
                exchange_record(record, ref_record)

        save_caffe_model(self.graph,
                         self.modified_model_file,
                         self.modified_weights_file)
        with open(Configuration().get_record_file_path(), "w") as record_file:
            record_file.write(
                text_format.MessageToString(self.record, as_utf8=True))

        # Phase2: do activation calibration process
        self.nuq_evaluator.eval_model(self.modified_model_file,
                                      self.modified_weights_file,
                                      self.calibration_batch_num)
        # Pahse3: save fake quant model and deploy model
        quantize_tool.save_model(self.graph.deep_copy(), 'Both', self.save_dir)
        save_dir, save_prefix = os.path.split(self.save_dir)
        self.fake_quant_model, self.fake_quant_caffemodel = \
            generate_model_name(save_dir, save_prefix, 'Fakequant')

    def quantize_and_evaluate_model(self, quant_config, global_step=None):
        """
        Function:
                quantize the model and do activation calibration, save the
                fake quant model and get the metric by eval_model func
        Parameter:
                quant_config: the given quant config
                global_step: arq, nuq_32, nuq_16 for global quantize task
        Return:
                current_metric: the metric of this quantize task
        """
        # update the quant config in Configuration
        Configuration().update_quant_config(quant_config)

        self.iteration_time = time.time()

        if global_step:
            self.quant_model_with_global_step(global_step)
            self.quantized_model = self.graph.deep_copy()
            self.nuq_helper.ref_models[global_step] = self.graph.deep_copy()
        else:
            self.quant_model_without_global_step()
            self.quantized_model = self.graph.deep_copy()

        current_metric = self.nuq_evaluator.eval_model(
            self.fake_quant_model,
            self.fake_quant_caffemodel,
            self.nuq_evaluator.get_evaluate_batch_num())
        self.iteration_time = time.time() - self.iteration_time
        return current_metric

    def init_auto_nuq_layers(self):
        """ initial the auto nuq layers record."""
        self.auto_nuq_layers = Configuration().get_nuq_config().keys()
        for auto_nuq_layer in self.auto_nuq_layers:
            auto_nuq_layer_param = AutoNuqLayer(
                auto_nuq_layer,
                Configuration().get_nuq_config()[auto_nuq_layer][
                    "weight_quant_params"]['num_steps'])
            self.auto_nuq_layers_params[
                auto_nuq_layer] = auto_nuq_layer_param

    def quantize_and_record_global(self, step_key, step_value):
        """
        Function: quantize the model and do activation calibration, save the
                  fake quant model and get the metric by eval_model func and
                  record the metric and sensitivity
        Parameter:
                step_key: arq, nuq_32, nuq_16 for global quantize task
                step_value: 256, 32, 16 for global quant task
        """
        # update the auto nuq layer params step status
        for layer_name in self.auto_nuq_layers_params.keys():
            self.auto_nuq_layers_params[layer_name].step = step_value

        quant_config = self.nuq_strategy.get_quant_config(step_key)
        # quantize model, do activation calibration and save fake quant, deploy
        # model, record the scale and offset params;
        self.current_metric = self.quantize_and_evaluate_model(
            quant_config, step_key)

        self.nuq_helper.steps_status[step_key] = \
            self.nuq_evaluator.is_satisfied(self.original_metric,
                                            self.current_metric)
        self.cal_auto_nuq_layers_sensitivity(step_value)
        self.record_status("global")
        return self.nuq_helper.steps_status.get(step_key)

    def cal_auto_nuq_layers_sensitivity(self, global_step):
        """
        Function: calulate the cosine similarity of all arq, all nuq 32 all nuq
                16 model with original bn fold model
        Parameter:
                global_step: arq, nuq_32, nuq_16 for global quantize task
        """
        for layer_name in self.auto_nuq_layers_params.keys():
            sensitivity = self.get_cos_similarity(
                self.quantized_model, layer_name)
            self.auto_nuq_layers_params[layer_name].sensitivity[
                global_step] = sensitivity

    def fine_search(self):
        """ using the quant config from strategy to search the final
            nuq quant config.
        """
        self.graph = self.nuq_helper.ref_models['nuq_32'].deep_copy()
        self.record = copy.deepcopy(self.nuq_helper.ref_records['nuq_32'])

        cos_sim = collections.OrderedDict()
        cos_sim[256] = collections.OrderedDict()
        cos_sim[32] = collections.OrderedDict()
        cos_sim[16] = collections.OrderedDict()

        for layer_name in self.auto_nuq_layers_params.keys():
            for layer_step in self.auto_nuq_layers_params[
                    layer_name].sensitivity.keys():
                cos_sim[layer_step][layer_name] = self.auto_nuq_layers_params[
                    layer_name].sensitivity[layer_step]

        self.nuq_strategy.initial_strategy(
            cos_sim, self.original_metric,
            self.history_status['Stage[global]---Iteration[3]']['accuracy'])
        fine_end_flag = False
        while not fine_end_flag:
            strategy_quant_config, fine_end_flag = \
                self.nuq_strategy.get_next_quant_config(self.current_metric)

            if strategy_quant_config is not None:
                # update the auto nuq layers params
                for layer_name in self.auto_nuq_layers_params.keys():
                    if strategy_quant_config[
                            layer_name]['weight_quant_params']['wts_algo'] == \
                                'nuq_quantize':
                        self.auto_nuq_layers_params[layer_name].step = \
                            strategy_quant_config[layer_name][
                                'weight_quant_params']['num_steps']
                    else:
                        self.auto_nuq_layers_params[layer_name].step = 256
                self.current_metric = self.quantize_and_evaluate_model(
                    strategy_quant_config)
                self.record_status("fining")

    def init_auto_nuq(self, input_config_file):
        """initial the auto nuq process, get the all arq and all nuq 32 steps
            and nuq 16 steps metrics
        """
        # 1. get orginal_metrics and test eval model
        self.original_metric = self.nuq_evaluator.eval_model(
            self.model_file,
            self.weights_file,
            self.nuq_evaluator.get_evaluate_batch_num())
        # 2. init configuration
        file_realpath = files_util.create_empty_file(
            self.scale_offset_record_file, check_exist=True)
        LOGGER.logi(
            'scale_offset_record_file: {}'.format(file_realpath), 'init')
        parser = Parser(self.model_file, self.weights_file)
        self.original_graph = parser.parse_net_to_graph()

        Configuration().init(input_config_file,
                             file_realpath,
                             self.original_graph)
        self.calibration_batch_num = \
            Configuration().get_quant_config().get('batch_num')
        self.nuq_helper = AutoNuqHelper(
            Configuration().get_quant_config())

        self.nuq_strategy = AutoNuqStrategyBisection(
            self.original_graph,
            self.nuq_evaluator,
            Configuration().get_quant_config(),
            self.auto_nuq_layers_params.keys())

        self.init_auto_nuq_layers()
        # 3. get the orginal fusion weights
        self.get_fusion_graph()
        # 4. try all arq, all nuq 32 and all nuq 16 steps and record the quant
        # config and models and scale offset records

        # if all arq can not satisfy the requirement of user, quit auto nuq
        if not self.quantize_and_record_global('arq', 256):
            LOGGER.logw(
                "Even all arq can not satisfy the requirement, "
                "do not support auto nuq, should lower down the requirement.")
            return AUTO_NUQ_QUIT
        if self.quantize_and_record_global('nuq_16', 16):
            return AUTO_NUQ_16_SATISFY
        self.quantize_and_record_global('nuq_32', 32)
        return AUTO_NUQ_KEEP_SEARCH

    def get_fusion_graph(self):
        """ do the bn conv and conv bn fusion to get original weights data."""
        self.graph = self.original_graph.deep_copy()
        optimizer = GraphOptimizer()
        optimizer.add_pass(ScaleConvFusionPass())
        optimizer.add_pass(BnConvFusionPass())
        optimizer.add_pass(ConvBnFusionPass())
        optimizer.add_pass(ConvScaleFusionPass())
        optimizer.add_pass(FcBnFusionPass())
        optimizer.add_pass(FcScaleFusionPass())
        optimizer.do_optimizer(self.graph)
        self.nuq_helper.ref_models['original'] = self.graph.deep_copy()

    def auto_nuq(self, nuq_evaluator, config_file, save_dir):
        """ the main loop of auto nuq."""
        self.nuq_evaluator = nuq_evaluator
        self.save_dir = save_dir
        files_util.create_file_path(self.save_dir)
        tmp_path = Path(self.scale_offset_record_file).parent
        self.modified_model_file = Path(
            tmp_path, 'modified_model.prototxt').resolve()
        self.modified_weights_file = Path(
            tmp_path, 'modified_model.caffemodel').resolve()
        self.modified_model_file = os.path.join(
            *(self.modified_model_file.parts))
        self.modified_weights_file = os.path.join(
            *(self.modified_weights_file.parts))

        status = self.init_auto_nuq(os.path.realpath(config_file))

        if status == AUTO_NUQ_QUIT:
            LOGGER.logi("All arq can not statisfy, quiting auto nuq ...")
            self.show_history_records()
        elif status == AUTO_NUQ_16_SATISFY:
            LOGGER.logi("All nuq 16 steps can statisfy, auto nuq success.")
            self.show_history_records()
        else:
            self.fine_search()
            LOGGER.logi("Fining end, auto nuq success.")
            self.show_history_records()

        LOGGER.logi(
            "The generated models are stored at:\n"
            "\t\t\t\t\t dir: {}".format(
                os.path.realpath(os.path.split(self.save_dir)[0])))
        LOGGER.logi(
            "The scale and offset records file are stored at:\n"
            "\t\t\t\t\t dir: {}".format(
                os.path.realpath(self.scale_offset_record_file)))

    def get_cos_similarity(self, quantized_model, layer_name):
        """
        Function:
                calulate the cosine similarity of specificed layer of
                original bn fold model
        Parameter:
                quantized_model: the quantized graph
                layer_name: the specificed layer name
        """
        # before compress weight of model
        before_quant_weights = self.nuq_helper.ref_models[
            'original'].get_node_by_name(layer_name).get_all_data()[0].data
        before_quant_weights = np.mat(before_quant_weights)
        # after compress weight of model
        after_nuq_weights = quantized_model.get_node_by_name(
            layer_name).get_all_data()[0].data
        after_nuq_weights = np.mat(after_nuq_weights)

        if np.all(before_quant_weights == 0) or np.all(after_nuq_weights == 0):
            return 1

        num = float(before_quant_weights * after_nuq_weights.T)
        denom = np.linalg.norm(before_quant_weights) * np.linalg.norm(
            after_nuq_weights)
        cos = num / denom
        similarity = 0.5 + 0.5 * cos
        return similarity

    def record_status(self, stage=None):
        """
        Function:
                record the status of current quantize task, include the
                iteration id, iteration time, metric, and nuq layer status
        Parameter:
                stage: [global] for global quantize, [fining] for fine search
        """
        self.iteration += 1
        current_status = collections.OrderedDict()
        current_status['iteration'] = self.iteration
        current_status['accuracy'] = self.current_metric
        current_status['iteration_time'] = self.iteration_time

        auto_nuq_layer_record = collections.OrderedDict()
        for layer_name in self.auto_nuq_layers:
            if layer_name in self.auto_nuq_layers_params.keys():
                layer_step = self.auto_nuq_layers_params[layer_name].step
                auto_nuq_layer_record[layer_name] = [
                    layer_step,
                    self.auto_nuq_layers_params[
                        layer_name].sensitivity[layer_step]]
            else:
                # those not nuq layers do not need to calculate cos similarity
                auto_nuq_layer_record[layer_name] = [256, 1]
        current_status['auto_nuq_layers'] = auto_nuq_layer_record
        self.history_status['Stage[{}]---Iteration[{}]'.format(
            stage, self.iteration)] = current_status

    def show_history_records(self):
        """ show the history searching records."""
        LOGGER.logi(
            '{}: {}'.format(
                "original model metric".ljust(20),
                self.original_metric))
        LOGGER.logi(
            '{}: {}'.format(
                "current quantized model metric".ljust(20),
                self.current_metric))
        for iteration, current_status in self.history_status.items():
            LOGGER.logi('# {}:'.format(iteration))
            for key, value in current_status.items():
                if key == 'auto_nuq_layers':
                    LOGGER.logi('\t{}:'.format(key))
                    for layer_name, step_sensi in value.items():
                        LOGGER.logi('\t\t{}: step({}), sensi({})'.format(
                            layer_name.ljust(20), step_sensi[0],
                            step_sensi[1]))
                else:
                    LOGGER.logi('\t{}: {}'.format(key.ljust(20), value))



@time_info
@check_params(model_file=str, weights_file=str, config_file=str,
              scale_offset_record_file=str, save_dir=str)
def auto_nuq(model_file, # pylint: disable=R0913
             weights_file,
             nuq_evaluator,
             config_file,
             scale_offset_record_file,
             save_dir):
    """
    Function:
            nuq quantize the input model automatically, and save the final
            quantized model (fake quant and deploy models)
    Parameter:
            model_file: the prototxt model define file of caffe model
            weights_file: the binary caffemodel file of caffe model
            nuq_evaluator: the user implemented evaluator instance
            config_file: the quant config json file
            scale_offset_record_file: the scale and offset record file dir
            save_dir: prefix of filename of save model
    """
    auto_nuq_controller = AutoNuq(
        model_file, weights_file, scale_offset_record_file)
    auto_nuq_controller.auto_nuq(nuq_evaluator, config_file, save_dir)
