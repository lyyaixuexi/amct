#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Top APIs of AMCT_CAFFE tool for user

"""
import os

import shutil

from amct_caffe.utils.log import LOGGER
from amct_caffe.common.utils.check_params import check_params
from amct_caffe.common.utils.files import check_files_exist
from amct_caffe.common.utils.files import create_empty_file

from amct_caffe.configuration.check import GraphChecker
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.configuration.retrain_config import RetrainConfig

from amct_caffe.graph.graph import Graph
from amct_caffe.parser.parser import Parser

import amct_caffe.optimizer as opt
from amct_caffe.optimizer.graph_optimizer import GraphOptimizer
from amct_caffe.operation.update_record_file import update_record_file

from amct_caffe.operation.save_model import save_caffe_model
from amct_caffe.lib.load_library import DeviceMode
from amct_caffe.lib.load_library import CPU_MODE
from amct_caffe.lib.load_library import GPU_MODE


def create_quant_config(  # pylint: disable=too-many-arguments
        config_file,
        model_file,
        weights_file,
        skip_layers=None,
        batch_num=1,
        activation_offset=True,
        config_defination=None):
    """
    Function: Create quantize configuration json file for amct_caffe tool
    Parameter: config_file: file path of quantize configuration json file
               model_file: user caffe model's model file
               weights_file: user caffe model's weights file
               skip_layers: list of layers that not do quantize, default empty
               batch_num: number of batch that used for calibration
               activation_offset: whether activation quantize with offset
               config_defination: simply config file from user to set
    Return: None
    """
    # parse to graph
    model_file = os.path.realpath(model_file)
    weights_file = os.path.realpath(weights_file)
    parser = Parser(model_file, weights_file)
    graph = parser.parse_net_to_graph()
    # create config file for quantizetion
    Configuration.create_quant_config(config_file, graph, skip_layers,
                                      batch_num, activation_offset,
                                      config_defination)


def init(config_file, model_file, weights_file, scale_offset_record_file):
    """
    Function: Init AMCT_CAFFE tool, trans scale_offset_record_file path to
              abspath, parse user caffe model file to caffe.NetParameter,
              initialize Configuration module.
    Parameter: config_file: quantize configuration json file
               model_file: user caffe model's model file
               weights_file: user caffe model's weights file
               scale_offset_record_file: temporary file to store scale and
                                         offset
    Return: graph: Graph structure parsed from user caffe model
    """
    file_realpath = create_empty_file(scale_offset_record_file, check_exist=True)
    LOGGER.logi('scale_offset_record_file: {}'.format(file_realpath), 'init')

    parser = Parser(model_file, weights_file)
    graph = parser.parse_net_to_graph()

    config_file = os.path.realpath(config_file)
    Configuration().init(config_file, file_realpath, graph)

    return graph


def quantize_model(graph, modified_model_file, modified_weights_file):
    """
    Function: Modify graph, do conv+bn+scale fusion, weights calibration,
              insert IFMR layer and DeQuantLayer to each to be quantized layer,
              and save modified graph to caffe model.
    Parameter: graph: graph structure parsed from user caffe model
               modified_model_file: modified caffe model's model file path
               modified_weights_file: modified caffe model's weights file path
    Return: None
    """
    if not isinstance(graph, Graph):
        raise TypeError("Type of {} should be {} but is {}".format(
            'graph', Graph, type(graph)))

    mode_dict = {CPU_MODE: 'CPU', GPU_MODE: 'GPU'}
    LOGGER.logi('Do weight calibration in {} mode'.format(
        mode_dict.get(DeviceMode().mode)), 'Quantize_tool')

    optimizer = GraphOptimizer()
    if Configuration().get_fusion_switch():
        optimizer.add_pass(opt.CheckBNStatePass())
        optimizer.add_pass(opt.ScaleConvFusionPass())
        optimizer.add_pass(opt.BnConvFusionPass())
        optimizer.add_pass(opt.ConvBnFusionPass())
        optimizer.add_pass(opt.ConvScaleFusionPass())
        optimizer.add_pass(opt.FcBnFusionPass())
        optimizer.add_pass(opt.FcScaleFusionPass())
    do_joint_quant = Configuration().get_quant_config().get('joint_quant')
    optimizer.add_pass(opt.LstmWeightsCalibrationPass())
    if do_joint_quant:
        optimizer.add_pass(opt.EltwiseOptWeightsCalibrationPass())
    optimizer.add_pass(opt.WeightsCalibrationPass())
    if do_joint_quant:
        optimizer.add_pass(opt.EltwiseOptInsertActCaliLayerPass())
        optimizer.add_pass(opt.ConcatJointQuantOptiPass())
    optimizer.add_pass(opt.InsertActCalibrationLayerPass())
    optimizer.add_pass(opt.LSTMCalibrationReplacePass())
    if do_joint_quant:
        optimizer.add_pass(opt.EltwiseOptInsertSearchNLayerPass())
    optimizer.add_pass(opt.InsertSearchNLayerPass())
    optimizer.do_optimizer(graph)
    save_caffe_model(graph, modified_model_file, modified_weights_file)


@check_params(graph=Graph, save_type=str, save_path=str)
def save_model(graph,         # pylint: disable=too-many-locals
               save_type,
               save_path):
    """
    Function: Save quantized model to final format
    Parameter: graph: graph structure parsed from user caffe model
               save_type: support 'Fakequant'(model that can be test by caffe),
                          'Deploy'(model that only for Davinci to run),
                          'Both'(generate both 'Fakequant' and 'Deploy' model)
               save_path: prefix of filenames of save model
    Return: None
    """
    # entry check
    if save_type not in ('Fakequant', 'Deploy', 'Both'):
        raise RuntimeError("AMCT_CAFFE save_type only support ['Fakequant'," \
            " 'Deploy', 'Both'], but is %s." % (save_type))
    save_path = os.path.realpath(save_path)
    save_dir, save_prefix = os.path.split(save_path)
    if save_dir == '':
        save_dir = '.'

    # save non uniform quantization layers
    Configuration().save_nuq_quant_layer_names(save_dir, save_prefix)

    # replace layers realted to quantization.
    optimizer = GraphOptimizer()
    optimizer.add_pass(opt.CheckRecordScaleOffsetPass())
    optimizer.add_pass(opt.DeleteBypassLayerPass(["SearchNV2"]))
    optimizer.add_pass(opt.DeleteBypassLayerPass(
        ['IFMR', 'SearchN', 'HFMG']))
    optimizer.add_pass(opt.InsertQuantLayerPass())
    optimizer.add_pass(opt.LstmInsertQuantLayerPass())
    optimizer.add_pass(opt.MultQuantOptimizerPass())
    optimizer.add_pass(opt.QuantFusionPass())
    optimizer.add_pass(opt.InsertDeQuantLayerPass())
    optimizer.add_pass(opt.LstmWeightsQuantizePass())
    optimizer.add_pass(opt.WeightsQuantizePass())
    optimizer.add_pass(opt.BiasQuantizePass())
    optimizer.add_pass(opt.ReflashTopNamePass(is_retrain=False))
    gen_fusion_json_pass = opt.GenFusionJsonPass()
    gen_fusion_json_pass.set_dump_file_dir(save_dir, save_prefix)
    optimizer.add_pass(gen_fusion_json_pass)
    record_pass = opt.RecordScaleOffsetPass()
    lstm_record_pass = opt.LstmRecordScaleOffsetPass()

    # To generate deploy model
    record_pass.set_save_type("Deploy")
    lstm_record_pass.set_save_type('Deploy')
    optimizer.add_pass(record_pass)
    optimizer.add_pass(lstm_record_pass)
    optimizer.do_optimizer(graph)

    # save non uniform quantization layers
    Configuration().save_nuq_quant_layer_names(save_dir, save_prefix)
    if save_type in ('Both', 'Deploy'):
        deploy_model_file, deploy_weights_file = \
                generate_model_name(save_dir, save_prefix, 'Deploy')
        save_caffe_model(graph, deploy_model_file, deploy_weights_file)
    # To generate fake quant model
    if save_type in ('Both', 'Fakequant'):
        fake_quant_optimzier = GraphOptimizer()
        fake_quant_optimzier.add_pass(opt.LstmWeightsFakeQuantizePass())
        fake_quant_optimzier.add_pass(opt.WeightsFakeQuantizePass())
        fake_quant_optimzier.add_pass(opt.BiasFakeQuantizePass())
        record_pass.set_save_type('Fakequant')
        lstm_record_pass.set_save_type('Fakequant')
        fake_quant_optimzier.add_pass(record_pass)
        fake_quant_optimzier.add_pass(lstm_record_pass)
        fake_quant_optimzier.do_optimizer(graph)
        fake_quant_model_file, fake_quant_weights_file = \
                generate_model_name(save_dir, save_prefix, 'Fakequant')
        save_caffe_model(graph, fake_quant_model_file, fake_quant_weights_file)


@check_params(model_file=str, weights_file=str, scale_offset_record_file=str,
              save_path=str)
def convert_model(model_file,
                  weights_file,
                  scale_offset_record_file,
                  save_path):
    """
    Function: Convert original caffe model to quantized deploy or
              fake_quant model according to user scale offset record file
    Parameter: model_file: user caffe model's model file
               weights_file: user caffe model's weights file
               scale_offset_record_file: temporary file to store scale and
                                         offset
               save_path: prefix of filenames of save model
    Return: None
    """
    model_file = os.path.realpath(model_file)
    weights_file = os.path.realpath(weights_file)
    parser = Parser(model_file, weights_file)
    graph = parser.parse_net_to_graph()
    # Check graph legality
    graph_checker = GraphChecker()
    graph_checker.check_quant_behaviours(graph)
    # To reuse clibration features, generate dummy config according to
    # user record file
    Configuration().init_from_record(graph, scale_offset_record_file)
    update_record_file(graph)
    optimizer = GraphOptimizer()
    optimizer.add_pass(opt.CheckBNStatePass())
    optimizer.add_pass(opt.ConvBnFusionPass())
    optimizer.add_pass(opt.ConvScaleFusionPass())
    optimizer.do_optimizer(graph)
    save_model(graph, 'Both', save_path)


def set_gpu_mode():
    """
    Function: Set GPU mode of AMCT weight calibration.
    Parameters: None
    Return: None
    """
    DeviceMode().set_gpu_mode()


def set_cpu_mode():
    """
    Function: Set CPU mode of AMCT weight calibration.
    Parameters: None
    Return: None
    """
    DeviceMode().set_cpu_mode()


@check_params(config_file=str, model_file=str, weights_file=str)
def create_quant_retrain_config(
        config_file,
        model_file,
        weights_file,
        config_defination=None):
    """
    Function: create retain elaborated config.
    Parameters: config_file: the file in which stores the elaborated config
                model_file: user caffe model's model file
                weights_file: user caffe model's weights file
                config_defination: user simple config file
    Return: None
    """
    # parse to graph
    model_file = os.path.realpath(model_file)
    weights_file = os.path.realpath(weights_file)
    parser = Parser(model_file, weights_file)
    graph = parser.parse_net_to_graph()
    graph_checker = GraphChecker()
    graph_checker.check_quant_behaviours(graph)

    if config_defination is None:
        RetrainConfig.create_default_retrain_config(config_file, graph)
    # create config file for quantizetion
    else:
        RetrainConfig.create_quant_retrain_config(
            config_file,
            graph,
            config_defination)


@check_params(
    model_file=str,
    weights_file=str,
    config_file=str,
    modified_model_file=str,
    modified_weights_file=str)
def create_quant_retrain_model(  # pylint: disable=too-many-arguments
        model_file,
        weights_file,
        config_file,
        modified_model_file,
        modified_weights_file,
        scale_offset_record_file):
    """
    Function: generate retrain model
    Parameter: model_file: user caffe model's model file
               weights_file: user caffe model's weights file
               config_file: elaborated config file
               modified_model_file: modified caffe model's model file path
               modified_weights_file: modified caffe model's weights file path
               scale_offset_record_file: temporary file to store scale and
                                         offset
    Return: None
    """
    file_realpath = create_empty_file(scale_offset_record_file, check_exist=True)
    RetrainConfig.set_record_file(file_realpath)
    parser = Parser(model_file, weights_file)
    graph = parser.parse_net_to_graph(False)
    config_file = os.path.realpath(config_file)
    RetrainConfig.init_retrain(config_file, graph)

    optimizer = GraphOptimizer()
    optimizer.add_pass(opt.InsertRetrainLayersPass())
    optimizer.add_pass(opt.RetrainInsertSearchNLayerPass())
    optimizer.do_optimizer(graph)

    save_caffe_model(graph, modified_model_file, None)
    check_files_exist([os.path.realpath(modified_weights_file)])
    shutil.copy2(weights_file, modified_weights_file)


@check_params(
    retrained_model_file=str,
    retrained_weights_file=str,
    save_type=str,
    save_path=str)
def save_quant_retrain_model(  # pylint: disable=too-many-arguments
        retrained_model_file,
        retrained_weights_file,
        save_type,
        save_path,
        scale_offset_record_file=None,
        config_file=None):
    """
    Function: quantize retrain model to final format
    Parameter: retrained_model_file: the model file generated by the previous
               api
               retrained_weights_file: the weights file after retrain
               save_type: support 'Fakequant'(model that can be test by caffe),
                          'Deploy'(model that only for Davinci to run),
                          'Both'(generate both 'Fakequant' and 'Deploy' model)
               save_path: prefix of filenames of save model
               scale_offset_record_file: temporary file to store scale and
               config_file: elaborated config file
    Return: None
    """
    if scale_offset_record_file is not None:
        RetrainConfig.set_record_file(scale_offset_record_file)

    parser = Parser(retrained_model_file, retrained_weights_file)
    graph = parser.parse_net_to_graph()

    if config_file:
        config_file = os.path.realpath(config_file)
        RetrainConfig.init_retrain(config_file, graph)
    optimizer = GraphOptimizer()
    optimizer.add_pass(opt.CheckBNStatePass())
    optimizer.add_pass(opt.DeleteRetrainLayersPass())
    optimizer.add_pass(opt.ConvBnFusionPass(True))
    optimizer.add_pass(opt.ConvScaleFusionPass(True))
    optimizer.add_pass(opt.WeightsCalibrationPass(True))
    optimizer.do_optimizer(graph)
    optimizer.clear_pass()
    # entry check
    if save_type not in ['Fakequant', 'Deploy', 'Both']:
        raise RuntimeError("AMCT_CAFFE save_type only support ['Fakequant'," \
            " 'Deploy', 'Both'], but is %s." % (save_type))

    # replace layers realted to quantization.
    optimizer.add_pass(opt.CheckRecordScaleOffsetPass(True))
    optimizer.add_pass(opt.InsertQuantLayerPass(True))
    optimizer.add_pass(opt.MultQuantOptimizerPass(True))
    optimizer.add_pass(opt.QuantFusionPass(True))
    optimizer.add_pass(opt.InsertDeQuantLayerPass(True))
    optimizer.add_pass(opt.ReflashTopNamePass(is_retrain=True))
    optimizer.do_optimizer(graph)
    optimizer.clear_pass()

    # save
    _save_quant_retrain_model(graph, save_path, save_type)


def _save_quant_retrain_model(graph, save_path, save_type):
    save_path = os.path.realpath(save_path)
    save_dir, save_prefix = os.path.split(save_path)
    if save_dir == '':
        save_dir = '.'

    optimizer = GraphOptimizer()
    optimizer.add_pass(opt.WeightsQuantizePass(True))
    optimizer.add_pass(opt.BiasQuantizePass(True))
    record_pass = opt.RecordScaleOffsetPass(True)

    # To generate deploy model
    record_pass.set_save_type("Deploy")
    optimizer.add_pass(record_pass)
    optimizer.do_optimizer(graph)
    if save_type in ('Both', 'Deploy'):
        deploy_model_file, deploy_weights_file = \
                generate_model_name(save_dir, save_prefix, 'Deploy')
        save_caffe_model(graph, deploy_model_file, deploy_weights_file)
    # To generate fake quant model
    if save_type in ('Both', 'Fakequant'):
        fake_quant_optimzier = GraphOptimizer()
        fake_quant_optimzier.add_pass(opt.WeightsFakeQuantizePass(True))
        fake_quant_optimzier.add_pass(opt.BiasFakeQuantizePass(True))
        record_pass.set_save_type('Fakequant')
        fake_quant_optimzier.add_pass(record_pass)
        fake_quant_optimzier.do_optimizer(graph)
        fake_quant_model_file, fake_quant_weights_file = \
                generate_model_name(save_dir, save_prefix, 'Fakequant')
        save_caffe_model(graph, fake_quant_model_file, fake_quant_weights_file)


def generate_model_name(save_path, prefix, save_type):
    ''' Generate model's name. '''
    if save_type == 'Deploy':
        model_tail = 'deploy_model.prototxt'
        weights_tail = 'deploy_weights.caffemodel'
    else:
        model_tail = 'fake_quant_model.prototxt'
        weights_tail = 'fake_quant_weights.caffemodel'

    if prefix != '':
        model_file = os.path.join(save_path, '_'.join([prefix, model_tail]))
        weights_file = os.path.join(save_path, '_'.join([prefix,
                                                         weights_tail]))
    else:
        model_file = os.path.join(save_path, model_tail)
        weights_file = os.path.join(save_path, weights_tail)

    return model_file, weights_file
