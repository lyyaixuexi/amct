#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Used for update scale, offset in custom record file

"""
import os
import numpy as np
from google.protobuf import text_format
try:
    from caffe.proto import caffe_pb2 # pylint: disable=import-error
except ImportError:
    import caffe_pb2 # pylint: disable=import-error

from amct_caffe.utils.log import LOGGER
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.common.utils.files import check_files_exist
from amct_caffe.common.utils.record_file_operator import \
    read_weights_scale_offset
from amct_caffe.common.utils.record_file_operator import \
    record_weights_scale_offset
from amct_caffe.optimizer.conv_bn_fusion_pass import ConvBnFusionPass
from amct_caffe.optimizer.conv_scale_fusion_pass import ConvScaleFusionPass
from amct_caffe.configuration.init_config_from_record import \
    get_shape_from_pooling_layer


def update_record_file(graph):
    """If there need_fusion_layers, calculate fusion scale, offset, then
       generate new record file.
    """
    LOGGER.logi('Update record file for fusion.')
    need_update = False
    records = caffe_pb2.ScaleOffsetRecord()
    with open(Configuration().get_record_file_path(), 'r') as read_file:
        pbtxt_string = read_file.read()
        text_format.Merge(pbtxt_string, records)

    for node in graph.nodes:
        if node.type == 'Convolution' and \
            node.name in Configuration().get_quant_config():
            if node.name in Configuration().get_skip_fusion_layers():
                continue
            # Check whether need do Conv_BN_Scale fusion
            scale_w, offset_w = read_weights_scale_offset(
                records, node.name)
            if _update_conv_bn_scale_pattern(node, node.name, \
                scale_w, offset_w, records):
                need_update = True

    for node in graph.nodes:
        # If there are ave_pooling need to quantized, scale_w, and offset_w
        # need generate by amct_tool
        if node.type == 'Pooling' and \
            node.name in Configuration().get_quant_config():
            kernel_h, kernel_w = get_shape_from_pooling_layer(node.proto)
            scale_w = 1 / (kernel_h * kernel_w)
            offset_w = 0
            record_weights_scale_offset(records, node.name,
                                        [scale_w], [offset_w])
            need_update = True

    if need_update:
        update_record_dir = '{}_update{}'.format(
            os.path.splitext(Configuration().get_record_file_path())[0],
            os.path.splitext(Configuration().get_record_file_path())[-1])
        check_files_exist([update_record_dir])
        with open(update_record_dir, 'w') as record_file:
            record_file.write(text_format.MessageToString(
                records, as_utf8=True))
        Configuration().update_record_file(update_record_dir)
        LOGGER.logi('Update record_file to {}'.format(update_record_dir))


def _update_conv_bn_scale_pattern(node_conv,
                                  layer,
                                  scale_w,
                                  offset_w,
                                  records):
    """if there is conv+bn+scale pattern in graph, do scale and offset
       recalculate that fusion with bn and scale parameters
    """
    fused_scale_w = None
    fused_offset_w = None

    peer_anchors = node_conv.get_output_anchor(0).get_peer_input_anchor()
    if len(peer_anchors) == 1:
        peer_node = peer_anchors[0].node
        if peer_node.type == 'BatchNorm':
            fused_scale_w, fused_offset_w = _do_conv_bn_fusion(
                peer_node, scale_w, offset_w)
            LOGGER.logd('Do Conv layer {} and BatchNorm layer {} quantize ' \
                'parameter fusion'.format(node_conv.name,
                                          peer_node.name))
            tmp_scale_w, tmp_offset_w = _update_conv_scale_pattern(
                peer_node, fused_scale_w, fused_offset_w)
            if tmp_scale_w is not None and tmp_offset_w is not None:
                fused_scale_w = tmp_scale_w
                fused_offset_w = tmp_offset_w
        elif peer_node.type == 'Scale' and \
            ConvScaleFusionPass.check_matched_scale_layer(peer_node):
            fused_scale_w, fused_offset_w = _update_conv_scale_pattern(
                node_conv, scale_w, offset_w)

    if fused_scale_w is not None and fused_offset_w is not None:
        record_weights_scale_offset(records, layer,
                                    fused_scale_w, fused_offset_w)
        return True
    return False


def _update_conv_scale_pattern(node, scale_w, offset_w):
    """If there is Scale after conv
    """
    fused_scale_w = None
    fused_offset_w = None
    if len(node.output_anchors) == 1:
        peer_output_anchors = node.get_output_anchor(0).get_peer_input_anchor()
        if len(peer_output_anchors) == 1:
            node_scale = peer_output_anchors[0].node
            if node_scale.type == 'Scale' and \
                ConvScaleFusionPass.check_matched_scale_layer(node_scale):
                fused_scale_w, fused_offset_w = _do_conv_scale_fusion(
                    node_scale, scale_w, offset_w)
                LOGGER.logd('Do Conv layer {} and Scale layer {} ' \
                    'quantize parameter fusion'.format(node.name, \
                    node_scale.name))
    return fused_scale_w, fused_offset_w


def _do_conv_bn_fusion(node_bn, scale_w, offset_w):
    """Apply scale parameter to quantize parameter
    """
    if len(node_bn.get_all_data()) < 3:
        raise RuntimeError('BatchNorm at least should have three blobs')
    epsilon = node_bn.proto.batch_norm_param.eps

    factor_blob = node_bn.get_data(2)
    if len(factor_blob.shape.dim) != 1 or factor_blob.shape.dim[0] != 1:
        raise RuntimeError('BatchNorm scale factor should be one')
    if factor_blob.data:
        scale_factor = factor_blob.data[0]
    elif factor_blob.double_data:
        scale_factor = factor_blob.double_data[0]
    else:
        raise RuntimeError('Cannot find factor value in factor blob')

    _, variance_array = \
        ConvBnFusionPass.get_np_array_from_bn(node_bn.get_data(0),
                                              node_bn.get_data(1))

    if len(scale_w) == len(offset_w):
        if len(scale_w) == 1:
            scale_w = np.ones((variance_array.size), np.float32) * scale_w[0]
            offset_w = np.ones((variance_array.size), np.int8) * offset_w[0]
    else:
        raise RuntimeError('scale_w must be same length with offset_w.')
    # Subprocess variance before fusion
    if scale_factor != 0:
        scale_factor = 1 / scale_factor

    variance_array[:] = variance_array * scale_factor
    # Do scale, offset fusion
    variance = np.add(variance_array, epsilon)
    stdev = np.sqrt(variance)
    fused_scale_w = np.divide(scale_w, stdev)

    return fused_scale_w, offset_w


def _do_conv_scale_fusion(node_scale, scale_w, offset_w):
    """Apply scale parameter to quantize parameter
    """
    if not node_scale.get_all_data():
        raise RuntimeError('Scale at least should at least have one blobs')
    blob_scale = node_scale.get_data(0)
    blob_beta = None
    if len(node_scale.get_all_data()) == 2:
        blob_beta = node_scale.get_data(1)

    array_scale, _ = ConvScaleFusionPass.get_np_array_from_scale(blob_scale,
                                                                 blob_beta)

    if len(scale_w) == len(offset_w):
        if len(scale_w) == 1:
            scale_w = np.ones((array_scale.size), np.float32) * scale_w[0]
            offset_w = np.ones((array_scale.size), np.int8) * offset_w[0]
    else:
        raise RuntimeError('scale_w must be same length with offset_w.')

    fused_scale_w = scale_w * np.absolute(array_scale)

    return fused_scale_w, offset_w
