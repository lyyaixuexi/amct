#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Save graph to .prototxt and .caffemodel

"""
import os
import stat

from google.protobuf import text_format # pylint: disable=E0401
from amct_caffe.utils.log import LOGGER
from amct_caffe.common.utils import files as files_util

__all__ = ["save_caffe_model"]


def extract_net(caffe_model):
    """
    Function: extract the net from caffe_model.
    Inputs:
        caffe_model: the model extracted from.
    Returns:
        caffe_model: the net extracted.
    """
    for layer in caffe_model.layer:
        layer.ClearField('blobs')
    return caffe_model


def save_caffe_model(graph, model_file, weights_file):
    """
    Function: save graph in file.
    Inputs:
        graph: IR Graph, the graph to be saved.
        model_file: a string, a file(.prototxt) to save net's information.
        weights_file: a string, a file(.caffemodel) to save all information.
    Returns: None
    """
    dump_model = graph.dump_proto()

    if weights_file is not None:
        # save in .caffemodel
        weights_file = os.path.realpath(weights_file)
        files_util.create_file_path(weights_file, check_exist=True)
        with open(weights_file, 'wb') as file_weights:
            file_weights.write(dump_model.SerializeToString())
        # set permission 640
        os.chmod(weights_file, stat.S_IRUSR + stat.S_IWUSR + stat.S_IRGRP)
        LOGGER.logi("The weights_file is saved in %s" % (weights_file),\
                    module_name='Utils')
    #save in .prototxt
    model_file = os.path.realpath(model_file)
    files_util.create_file_path(model_file, check_exist=True)
    dump_model = extract_net(dump_model)
    with open(model_file, "w") as file_model:
        file_model.write(text_format.MessageToString(dump_model,
                                                     as_utf8=True))
    # set permission 640
    os.chmod(model_file, stat.S_IRUSR + stat.S_IWUSR + stat.S_IRGRP)
    LOGGER.logi("The model_file is saved in %s" % (model_file),\
                module_name='Utils')
