#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

func FuseConvBN, fuse CONV and BN.

"""
from amct_caffe.common.algo.conv_bn_fuse_base import FuseConvBnBase


class FuseConvBn(FuseConvBnBase):
    """ Fuse conv + bn
    """
    @staticmethod
    def get_conv_bn_param(conv_params, bn_params):
        """ Get dteail conv/bn param, such as mean, varience"""
        conv_weight = conv_params[0]
        conv_bias = conv_params[1]
        bn_mean = bn_params[0]
        bn_variance = bn_params[1]
        bn_scale_factor = bn_params[2]
        bn_epsilon = bn_params[3]

        def _subprocess_scale(bn_mean, bn_variance, bn_scale_factor):
            """process scale factor"""
            if bn_scale_factor == 0:
                bn_scale_factor = 0
            else:
                bn_scale_factor = 1 / bn_scale_factor

            bn_variance[:] = bn_variance * bn_scale_factor
            bn_mean[:] = bn_mean * bn_scale_factor

        _subprocess_scale(bn_mean, bn_variance, bn_scale_factor)

        return conv_weight, conv_bias, bn_mean, bn_variance, bn_epsilon


def fuse_conv_bn(conv_params, bn_params):
    """ Fuse conv + bn"""
    return FuseConvBn.fuse_conv_bn(conv_params, bn_params)


def fuse_bn_conv(conv_params, bn_params):
    """ Fuse bn + conv"""
    return FuseConvBn.fuse_bn_conv(conv_params, bn_params)
