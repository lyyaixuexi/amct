#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2020. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

func auto_decomposition.

"""
import os
import stat
import copy
import numpy as np
from google.protobuf import text_format
from amct_caffe.parser.parser import Parser
from amct_caffe.utils.log import LOGGER
from amct_caffe.common.utils import files as files_util
from amct_caffe.common.decomposition.decomposition import tensor_decomposition
from amct_caffe.common.decomposition.decomposition import DecomposeMode

__all__ = ['auto_decomposition']


def data_array(value):
    """
    Function: Convert data to array
    Parameter: value: blob data
    Return: ndarray of the layer data
    """
    dst_value = np.array(value.data)
    if value.HasField('channels') or value.HasField('num')\
            or value.HasField('height') or value.HasField('width'):
        param = (value.num, value.channels, value.height, value.width)
        return dst_value.reshape(param)
    return dst_value.reshape(value.shape.dim)


class AutoDecom():
    """
    Function: tensor decomposition tool
    APIs: read_net_from_proto, load_user_model, tensor_decompose,
    """

    def __init__(self, model_file, weights_file):
        """
        Function: Init tensor_decomposition tool,parse user caffe model file to
                 caffe.NetParameter,initialize Configuration module.
        Parameter: model_file: user caffe model's model file
                   weights_file: user caffe model's weights file
        """
        self.net_proto = Parser.load_user_model(model_file, weights_file)
        self.new_proto = copy.deepcopy(self.net_proto)
        self.decompose_flag = 0
        del self.new_proto.layer[:]
        self.net_proto_name = []
        for layer in self.net_proto.layer:
            self.net_proto_name.append(layer.name)

    @staticmethod
    def recognize_conv(layer):
        """
        Function: Identify whether the layer is convolution,
                  if it is, convert the layer weight to ndarray
                  and return, otherwise return none
        Parameter: layer: user caffe model's layer
        Return: ndarray of the layer or none
        """
        if layer.type == 'Convolution':
            try:
                return np.array(data_array(layer.blobs[0]))
            except IndexError as e:
                raise RuntimeError(
                    "model_file dose not correspond weights_file!"
                ) from e
        else:
            return None

    @staticmethod
    def transfer(param):
        """
        Function: Parameter data type conversion,if the parameter length
        is not 1, conversion to tuple type returns
        Parameter: param: Parameters to be converted
        Return: Type-converted parameters
        """
        if len(param) == 1:
            return param[0]

        tran_param = ()
        for item in param:
            tran_param = tran_param + (item,)
        return tran_param

    @staticmethod
    def judge_param(layer, new_layer, i, names):
        """
        Function: Update the decomposition layer param
        Parameter: layer: Layer to be decomposed
                   new_layer: Decomposition layer
                   i: Number of decomposition layer
                   names: Decomposition layer names
        """
        if layer.param:
            if layer.param[0].HasField('name'):
                layer.param[0].name = layer.param[0].name + '_{}'.format(i)
            new_layer.param.add().CopyFrom(layer.param[0])
            if i == len(names) - 1 and len(layer.param) > 1:
                if layer.param[1].HasField('name'):
                    layer.param[1].name = layer.param[1].name + '_{}'.format(i)
                new_layer.param.add().CopyFrom(layer.param[1])

    @staticmethod
    def judge_field(layer, new_layer, flag):
        """
        Function: Update the decomposition layer param,include pad,
                  stride and kernel_size
        Parameter: layer: Layer to be decomposed
                   new_layer: Decomposition layer
        """
        def _judge_field(field):
            field_h = field + '_h'
            field_w = field + '_w'
            if field == 'kernel_size':
                field_h = 'kernel_h'
                field_w = 'kernel_w'

            default_value = (1, 1)
            if field == 'pad':
                default_value = (0, 0)
            if not layer.convolution_param.HasField(field_h) and \
                    not layer.convolution_param.HasField(field_w):
                value = getattr(layer.convolution_param, field)
                param_value = (value[0], value[0])
            else:
                value_h = getattr(layer.convolution_param, field_h)
                value_w = getattr(layer.convolution_param, field_w)
                param_value = (value_h, value_w)

            if flag:
                setattr(new_layer.convolution_param, field_h, param_value[0])
                setattr(new_layer.convolution_param, field_w, default_value[1])
            else:
                setattr(new_layer.convolution_param, field_h, default_value[0])
                setattr(new_layer.convolution_param, field_w, param_value[1])


        for field in ['kernel_size', 'stride', 'pad']:
            _judge_field(field)

    @staticmethod
    def append_param(new_layer_param, layer_param):
        """
        Function: Add proto class list elements.
        Parameter: new_layer_param: Proto list after tensor decomposition
                   layer_param: The proto list in the original
                   convolution to be decomposed
        Returns: None
        """
        for param in layer_param:
            new_layer_param.append(param)

    @staticmethod
    def extract_net(caffe_model):
        """
        Function: extract the net from caffe_model.
        Inputs:
            caffe_model: the model extracted from.
        Returns:
            caffe_model: the net extracted.
        """
        for layer in caffe_model.layer:
            layer.ClearField('blobs')
        return caffe_model

    def substitute_layers(self, layer, results):
        """
        Function: Replace the original convolution
                  by multiple cascaded convolutions
                  after tensor decomposition,and convert
                  the ndarray value to the
                  caffe convolution layer weight.
        Parameter: layer: Caffe's convolution layer
                   tensors: Decomposed list of tensors
        Return: True or False
        """
        mode = results['mode']
        first_weight = results['first']
        last_weight = results['last']
        if mode == DecomposeMode.UNCHANGE:
            return False

        names = self.layer_name(layer.name, 2)
        LOGGER.logi('Decompose {} -> {}'.format(layer.name, names))
        decom_weights = (first_weight, last_weight)
        for i, name in enumerate(names):
            new_layer = self.new_proto.layer.add()
            new_layer.name = name
            new_layer.type = 'Convolution'
            kx1_flag = False
            if i == 0:
                self.append_param(new_layer.bottom, layer.bottom)
                new_layer.top.append(name)
                if mode in [DecomposeMode.FCSK, DecomposeMode.SCFK]:
                    kx1_flag = True
            else:
                new_layer.bottom.append(names[i - 1])
                self.append_param(new_layer.top, layer.top)
                if mode in [DecomposeMode.FCFK, DecomposeMode.SCSK]:
                    kx1_flag = True
            new_layer.convolution_param.num_output = decom_weights[i].shape[0]
            new_layer.convolution_param.bias_term = False

            self.judge_param(layer, new_layer, i, names)
            self.judge_field(layer, new_layer, kx1_flag)

            new_layer.convolution_param.group = 1
            if layer.convolution_param.HasField('weight_filler'):
                new_layer.convolution_param.weight_filler.CopyFrom(
                    layer.convolution_param.weight_filler)
            if layer.convolution_param.dilation:
                self.append_param(new_layer.convolution_param.dilation,
                                  layer.convolution_param.dilation)
            copy_blob = new_layer.blobs.add()
            copy_blob.data.extend(decom_weights[i].astype(float).flat)
            copy_blob.shape.dim.extend(decom_weights[i].shape)
            bias = (len(layer.blobs) != 1)
            if i == len(names) - 1 and bias:
                new_layer.convolution_param.bias_term = True
                if layer.convolution_param.HasField('bias_filler'):
                    new_layer.convolution_param.bias_filler.CopyFrom(
                        layer.convolution_param.bias_filler)
                new_layer.blobs.add().CopyFrom(layer.blobs[1])

        return True

    def save_tensor_decomposition_model(self, new_model_file,
                                        new_weights_file):
        """
        Function: Save the model after tensor decomposition.
        Inputs: new_model_file: a string, a file(.prototxt)
                to save net's information.
                new_weights_file: a string, a file(.caffemodel)
                to save all information.
        """
        if new_weights_file is not None:
            files_util.create_file_path(new_weights_file, check_exist=True)
            # save in .caffemodel
            with open(new_weights_file, 'wb') as file_weights:
                file_weights.write(self.new_proto.SerializeToString())
            # set permission 640
            os.chmod(new_weights_file,
                     stat.S_IRUSR + stat.S_IWUSR + stat.S_IRGRP)
            LOGGER.logi("The {} is saved ".format(new_weights_file))
        # save in .prototxt
        files_util.create_file_path(new_model_file, check_exist=True)
        dump_model = self.extract_net(self.new_proto)
        with open(new_model_file, "w") as file_model:
            file_model.write(text_format.MessageToString(dump_model,
                                                         as_utf8=True))
        # set permission 640
        os.chmod(new_model_file, stat.S_IRUSR + stat.S_IWUSR + stat.S_IRGRP)
        LOGGER.logi("The {} is saved ".format(new_model_file))

    def layer_name(self, name, name_length):
        """
        Function: Define the decomposed convolution name and ensure
                  it does not conflict with the original
                  network convolution layer name
        Parameter: name: The original name of the convolutional
                   layer to be decomposed name_length: The number
                   of convolutions after decomposition
        Return: The name of each layer of convolution after decomposition
        """
        decompose_name = []
        for i in range(name_length):
            decompose_name.append(name + '_{}'.format(i))
            while decompose_name[i] in self.net_proto_name:
                decompose_name[i] = decompose_name[i] + '_{}'.format(i)
        for iter_name in decompose_name:
            self.net_proto_name.append(iter_name)
        return decompose_name

    def decompse_tensors(self):
        """
        Function: Traverse each layer of the model, if it is convolution,
                  call tensor_decomposition function,and determine whether
                  the new layer is replaced by the returned tensor
        Returns: None
        """
        for layer in self.net_proto.layer:
            conv_data = self.recognize_conv(layer)
            if conv_data is None:
                self.new_proto.layer.add().CopyFrom(layer)
            else:
                if conv_data.shape[0] != layer.convolution_param.num_output:
                    raise RuntimeError(
                        "model_file's {} shape dose not correspond "
                        "weights_file {} shape!".format(layer.name, layer.name)
                    )
                if not layer.convolution_param.dilation:
                    dilation = 1
                else:
                    dilation = self.transfer(layer.convolution_param.dilation)
                if not layer.convolution_param.HasField('stride_h') and not \
                        layer.convolution_param.HasField('stride_w'):
                    stride = 1 if not layer.convolution_param.stride else self.transfer(layer.convolution_param.stride)
                else:
                    stride = self.transfer([layer.convolution_param.stride_h,
                                            layer.convolution_param.stride_w])

                results = tensor_decomposition(
                    conv_data, stride=stride,
                    group=layer.convolution_param.group,
                    dilation=dilation)
                t_flag = self.substitute_layers(layer, results)
                if not t_flag:
                    self.new_proto.layer.add().CopyFrom(layer)
                else:
                    self.decompose_flag = 1


def auto_decomposition(model_file, weights_file, new_model_file,
                       new_weights_file):
    """
    Function: Caffe model tensor decomposition function for user call,
              and save the model after tensor decomposition for user use.
    Inputs:
            model_file: user's caffe model file ,.prototxt
            weights_file: user's caffe weight file ,.caffemodel
            new_model_file: tensor-decomposed model,a file(.prototxt)
            to save net's information.
            new_weights_file: tensor-decomposed model, a file(.caffemodel)
            to save all information.
    """
    model_file = os.path.realpath(model_file)
    weights_file = os.path.realpath(weights_file)
    new_model_file = os.path.realpath(new_model_file)
    new_weights_file = os.path.realpath(new_weights_file)

    if not os.access(model_file, os.F_OK):
        raise IOError('{} path does not exist!'.format(model_file))
    if not os.access(weights_file, os.F_OK):
        raise IOError('{} path does not exist!'.format(weights_file))
    if not model_file.endswith('.prototxt'):
        raise IOError('{} is illegal path!'.format(model_file))
    if not weights_file.endswith('.caffemodel'):
        raise IOError('{} is illegal path!'.format(weights_file))
    if not new_model_file.endswith('.prototxt'):
        raise IOError('{} is illegal path!'.format(new_model_file))
    if not new_weights_file.endswith('.caffemodel'):
        raise IOError('{} is illegal path!'.format(new_weights_file))
    decom = AutoDecom(model_file, weights_file)
    decom.decompse_tensors()
    if decom.decompose_flag == 1:
        LOGGER.logi('Run tensor_decomposition success!')
        decom.save_tensor_decomposition_model(new_model_file, new_weights_file)
    else:
        LOGGER.logi('Does not meet the decomposition conditions.')
