#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os

from amct_caffe.quantize_tool import create_quant_config
from amct_caffe.quantize_tool import init
from amct_caffe.quantize_tool import quantize_model
from amct_caffe.quantize_tool import save_model
from amct_caffe.quantize_tool import set_cpu_mode
from amct_caffe.quantize_tool import set_gpu_mode
from amct_caffe.quantize_tool import convert_model
from amct_caffe.quantize_tool import create_quant_retrain_config
from amct_caffe.quantize_tool import create_quant_retrain_model
from amct_caffe.quantize_tool import save_quant_retrain_model
from amct_caffe.auto_nuq import auto_nuq
from amct_caffe.accuracy_based_auto_calibration import accuracy_based_auto_calibration
from amct_caffe.common.auto_calibration.auto_calibration_evaluator_base\
        import AutoCalibrationEvaluatorBase as CalibrationEvaluatorBase

CUR_DIR = os.path.split(os.path.realpath(__file__))[0]

with open(os.path.join(CUR_DIR, '.version')) as version_file:
    __version__ = version_file.readlines()[0].strip()
