#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

load weight calibration dynamic library

"""
import os
import ctypes

__all__ = ['Load', 'DeviceMode', 'CPU_MODE', 'GPU_MODE']

CPU_MODE = 0
GPU_MODE = 1


class Load():
    """
    Function: Wrapper class for the dynamic library API.
    APIs: cpu_lib, gpu_lib, lib
    """
    _instance = None

    def __new__(cls, *args, **kw):
        if cls._instance is None:
            cls._instance = object.__new__(cls, *args, **kw)
        return cls._instance

    def __init__(self):
        if not hasattr(self, '_cpu_lib'):
            self._cpu_lib = None
            self._gpu_lib = None

    @property
    def cpu_lib(self):
        """
        Function: Get CPU version dynamic library.
        Parameters: None
        Return: dynamic library handle
        """
        if self._cpu_lib:
            return self._cpu_lib
        library_name = self._get_library_name(CPU_MODE)
        self._cpu_lib = ctypes.cdll.LoadLibrary(library_name)
        return self._cpu_lib

    @property
    def gpu_lib(self):
        """
        Function: Get GPU version dynamic library.
        Parameters: None
        Return: dynamic library handle
        """
        if self._gpu_lib:
            return self._gpu_lib
        library_name = self._get_library_name(GPU_MODE)
        self._gpu_lib = ctypes.cdll.LoadLibrary(library_name)
        return self._gpu_lib

    @property
    def lib(self):
        """
        Function: Get dynamic library.
        Parameters: None
        Return: dynamic library handle
        """
        if DeviceMode().mode == CPU_MODE:
            return self.cpu_lib
        return self.gpu_lib

    @staticmethod
    def _get_library_name(mode):
        cur_dir = os.path.split(os.path.realpath(__file__))[0]
        library_name = 'libweight_calibration'
        if mode == GPU_MODE:
            library_name += '_gpu'
        library_name += '.so'

        library_name = os.path.join(cur_dir, library_name)
        return library_name


class DeviceMode():
    """
    Function: A singleton pattern to set and get device mode.
    APIs: set_gpu_mode, set_cpu_mode, mode
    """
    _instance = None

    def __new__(cls, *args, **kw):
        if cls._instance is None:
            cls._instance = object.__new__(cls, *args, **kw)
        return cls._instance

    def __init__(self):
        if not hasattr(self, '_mode'):
            self._mode = CPU_MODE

    @property
    def mode(self):
        """
        Function: Get current device mode.
        Parameters: None
        Return: device mode
        """
        return self._mode

    def set_gpu_mode(self):
        """
        Function: Set GPU mode.
        Parameters: None
        Return: None
        """
        self._mode = GPU_MODE

    def set_cpu_mode(self):
        """
        Function: Set CPU mode.
        Parameters: None
        Return: None
        """
        self._mode = CPU_MODE
