#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

the accuracy based auto calibration main API

"""
import os
import copy
import json
from collections import OrderedDict

import amct_caffe.quantize_tool as quantize_tool
from amct_caffe.common.utils.check_params import check_params
from amct_caffe.common.utils import files as files_util
from amct_caffe.common.utils.util import find_repeated_items
from amct_caffe.common.utils.util import check_no_repeated
from amct_caffe.common.auto_calibration import SensitivityBase
from amct_caffe.common.auto_calibration import AutoCalibrationStrategyBase
from amct_caffe.common.auto_calibration import AutoCalibrationEvaluatorBase
from amct_caffe.common.auto_calibration import AccuracyBasedAutoCalibrationBase
from amct_caffe.common.auto_calibration import BinarySearchStrategy
from amct_caffe.common.auto_calibration import CosineSimilaritySensitivity
from amct_caffe.configuration.configuration import Configuration
from amct_caffe.parser.parser import Parser
from amct_caffe.quantize_tool import generate_model_name
from amct_caffe.utils.auto_nuq_helper import time_info
from amct_caffe.utils.auto_calibration_helper import AutoCalibrationHelper
from amct_caffe.utils.auto_calibration_helper import inner_fuse_model
from amct_caffe.utils.auto_calibration_helper import inner_quantize_model
from amct_caffe.utils.log import LOGGER


AUTO_CALI_SATISFY = 0
AUTO_CALI_KEEP_SEARCH = 1

__all__ = ['accuracy_based_auto_calibration']


class AccBasedAutoCalibration(AccuracyBasedAutoCalibrationBase): # pylint: disable=R0902
    """ the class for accuracy_based_auto_calibration API"""
    def __init__(self, # pylint: disable=R0913
                 model_file,
                 weights_file,
                 model_evaluator,
                 strategy,
                 config_file,
                 record_file,
                 save_dir,
                 sensitivity):
        """ init function for class AccBasedAutoCalibration
        Parameters:
                model_file: the prototxt model define file of caffe model
                weights_file: the binary caffemodel file of caffe model
                record_file: the scale and offset record file dir
                model_evaluator: the user implemented evaluator instance
                config_file: the quant config json file
                save_dir: prefix of filename of save model
        """
        super().__init__(record_file, config_file, save_dir,
            model_evaluator, strategy, sensitivity)
        self.model_file = os.path.realpath(model_file)
        self.weights_file = os.path.realpath(weights_file)
        self.fake_quant_model = None
        self.fake_quant_caffemodel = None
        self.quant_layers = []
        self.original_quant_config = None
        self.ranking_info = None
        self.auto_calibration_helper = None
        self.original_graph = None
        self.final_config = None

    @staticmethod
    def get_quant_enable_layers(quant_config):
        """ find the quant enable layers from quant config"""
        quant_enable_layers = []
        for key, value in quant_config.items():
            if isinstance(value, dict) and value['quant_enable']:
                quant_enable_layers.append(key)
        return quant_enable_layers

    def get_original_accuracy(self):
        """ get orginal_metrics and test eval model """
        self.original_accuracy = self.evaluator.evaluate(self.model_file, self.weights_file)
        LOGGER.logi("original evaluation accurcay: {}".format(self.original_accuracy), 'auto_calibration')
        return self.original_accuracy

    def get_global_quant_accuracy(self):
        """ do the calibration and get accuracy of fake quant model """
        file_realpath = files_util.create_empty_file(
            self.record_file, check_exist=True)
        parser = Parser(self.model_file, self.weights_file)
        self.original_graph = parser.parse_net_to_graph()
        Configuration().init(self.config_file,
                             file_realpath,
                             self.original_graph)
        # do the calibration and get the metric of all quant fake quant model
        # when insert quant layer pass, it will filter the global average
        # pooling layer, so the updated quant config is basic quant config
        global_quant_accuracy = self.global_calibration()
        quant_config = Configuration().get_quant_config()
        self.original_quant_config = quant_config
        # record the layers that need quantization
        self.quant_layers = AccBasedAutoCalibration.get_quant_enable_layers(quant_config)
        roll_back_config = OrderedDict()
        for layer in self.quant_layers:
            roll_back_config[layer] = True
        record = {
            'roll_back_config': roll_back_config,
            'metric_eval': self.evaluator.metric_eval(self.original_accuracy, global_quant_accuracy)
        }
        self.final_config = roll_back_config
        self.history_records.append(record)
        return global_quant_accuracy


    def global_calibration(self):
        """ do the calibration without joint quantization"""
        # do the calibration and save fake quant deploy model
        modified_model_file = self.generate_tmp_file_path('modified_model.prototxt')
        modified_weights_file = self.generate_tmp_file_path('modified_model.caffemodel')
        graph = self.original_graph.deep_copy()
        inner_quantize_model(
            graph,
            modified_model_file,
            modified_weights_file,
            self.temp_dir)
        # activation calibration process
        self.evaluator.calibration(
            modified_model_file,
            modified_weights_file)
        quantize_tool.save_model(graph.deep_copy(), 'Both', self.save_dir)
        # evaluate the generated fake quant model
        save_dir, save_prefix = os.path.split(self.save_dir)
        self.fake_quant_model, self.fake_quant_caffemodel = generate_model_name(
            save_dir, save_prefix, 'Fakequant')
        current_accuracy = self.evaluator.evaluate(
            self.fake_quant_model,
            self.fake_quant_caffemodel)
        LOGGER.logi(
            "global calibration accuracy: {}".format(current_accuracy), 'auto_calibration')

        return current_accuracy

    def generate_tmp_file_path(self, file_name):
        """ generate the file path for modified model, fused model"""
        file_path = os.path.join(self.temp_dir, file_name)
        return file_path

    def get_ranking_info(self):
        """ get the ranking infomation of accuracy based auto calibration"""
        to_fuse_graph = self.original_graph.deep_copy()
        # generate the fused model prototxt file and caffemodel file for
        # single layer and single fake quant layer cosine similarity compare
        fused_model_file = self.generate_tmp_file_path('fused_model.prototxt')
        fused_caffemodel_file = self.generate_tmp_file_path('fused_model.caffemodel')
        inner_fuse_model(to_fuse_graph, fused_model_file, fused_caffemodel_file)

        auto_calibration_helper = AutoCalibrationHelper(
            fused_model_file,
            fused_caffemodel_file,
            self.fake_quant_model,
            self.fake_quant_caffemodel,
            self.quant_layers,
            self.record_file,
            self.temp_dir,
            self.sensitivity)
        ranking_info = auto_calibration_helper.calc_ranking_info()
        self.ranking_info = ranking_info
        return ranking_info


    def roll_back_and_evaluate_model(self, roll_back_config):
        """ generate the roll-back fake quant model and evaluate the fake quant model
        """
        # turn down the joint quant in auto calibration
        quant_config = copy.deepcopy(self.original_quant_config)
        quant_config['joint_quant'] = False
        for key, value in roll_back_config.items():
            if not value:
                del quant_config[key]
        Configuration().update_quant_config(quant_config)
        graph = self.original_graph.deep_copy()

        modified_model_file = self.generate_tmp_file_path('modified_model.prototxt')
        modified_weights_file = self.generate_tmp_file_path('modified_model.caffemodel')

        quantize_tool.quantize_model(graph, modified_model_file, modified_weights_file)
        # activation calibration process
        self.evaluator.calibration(modified_model_file, modified_weights_file)
        quantize_tool.save_model(graph, 'Both', self.save_dir)
        current_fq_metric = self.evaluator.evaluate(
            self.fake_quant_model, self.fake_quant_caffemodel)
        return current_fq_metric


    def save_final_config(self):
        """ save the accuracy based auto calibration final quant config"""
        final_config_file = files_util.create_empty_file(
            os.path.join(os.path.split(self.save_dir)[0], 'accuracy_based_auto_calibration_final_config.json'),
            check_exist=True)

        def _detect_repeated_key_hook(json_object):
            '''a hook function for detect repeated key in config file.'''
            keys = [key for key, value in json_object]
            repeat_keys = find_repeated_items(keys)
            check_no_repeated(repeat_keys, self.config_file)
            ret = {}
            for key, value in json_object:
                ret[key] = value
            return ret

        with open(self.config_file, 'r') as fid:
            quant_config = json.load(
                fid, object_pairs_hook=_detect_repeated_key_hook)
        # update the modified config to original config file
        quant_config['joint_quant'] = False
        for key, value in self.final_config.items():
            quant_config[key]['quant_enable'] = value
        with open(final_config_file, 'w') as dump_file:
            json_object = json.dumps(
                quant_config, sort_keys=False, indent=4, separators=(',', ':'), ensure_ascii=False)
            dump_file.write(json_object)



@time_info
@check_params(model_file=str, weights_file=str, config_file=str,
              record_file=str, save_dir=str)
def accuracy_based_auto_calibration(model_file, # pylint: disable=R0913
                                    weights_file,
                                    model_evaluator,
                                    config_file,
                                    record_file,
                                    save_dir,
                                    strategy='BinarySearch',
                                    sensitivity='CosineSimilarity'):
    """
    Function:
            calibration the input model automatically, decide which layers need
            to roll back and save the final quantized model (fake quant and deploy models)
    Parameters:
            model_file: the prototxt model define file of caffe model
            weights_file: the binary caffemodel file of caffe model
            model_evaluator: the user implemented evaluator instance
            config_file: the quant config json file
            record_file: the scale and offset record file path
            save_dir: prefix of filename of save model
            strategy: union [str, BinarySearchStrategy] the instance of strategy to control the search process,
                    set 'BinarySearch' to use default value
            sensitivity: union [str, CosineSimilaritySensitivity] the instance of sensitivity to measure the quant
                    sensitivity of quantable layers, set 'CosineSimilarity' to use default value
    """

    if strategy == 'BinarySearch':
        strategy = BinarySearchStrategy()
    else:
        if not isinstance(strategy, AutoCalibrationStrategyBase):
            raise RuntimeError("strategy is not inherited from base class AutoCalibrationStrategyBase")

    if sensitivity == 'CosineSimilarity':
        sensitivity = CosineSimilaritySensitivity()
    else:
        if not isinstance(sensitivity, SensitivityBase):
            raise RuntimeError("sensitivity is not inherited from base class SensitivityBase")

    files_util.check_file_path(model_file, 'model_file')
    files_util.check_file_path(weights_file, 'weights_file')
    files_util.check_file_path(config_file, 'config_file')
    if not isinstance(model_evaluator, AutoCalibrationEvaluatorBase):
        raise RuntimeError("the model evaluator is not inherited from base class AutoCalibrationEvaluatorBase")

    auto_calibration_controller = AccBasedAutoCalibration(
        model_file, weights_file, model_evaluator, strategy,
        config_file, record_file, save_dir, sensitivity)
    auto_calibration_controller.run()
