#!/usr/bin/env bash
# Copyright (c) Huawei Technologies Co., Ltd. 2020. All rights reserved.
PROTOC=protoc

log() {
  cur_date=$(date +"%Y-%m-%d %H:%M:%S")
  echo "[$cur_date] "$1
}

if [[ $# -lt 2 ]]; then
  log "[ERROR] at least speify 2 proto files: atc caffe.proto, amtc_custom.proto [user_custom.proto is optional]"
  exit -1
fi
CAFFE_PROTO=$1
AMCT_PROTO=$2
USER_PROTO=""
if [[ $# -ge 3 ]]; then
  USER_PROTO=$3
fi

check_is_digit() {
  if [ $1 -gt 0 ] 2>/dev/null; then
    return 0
  else
    log "[ERROR] Check digit failed. [$1] [$2]"
    exit 1
  fi
}

# When the user-defined operator conflicts with the built-in operator,
# the user-defined operator is finally used.
pre_proc() {
  caffe_proto=$1
  custom_proto=$2
  is_overwrite=$3

  log "[INFO] Pre proc for ${caffe_proto}."
  # Merge for LayerParameter
  declare_begin=$(grep -n -E "\s*message\s*+LayerParameter\s*{|^\s*}" ${custom_proto} | grep -A 1 LayerParameter | head -1 | awk -F : '{print $1}')
  declare_end=$(grep -n -E "\s*message\s*+LayerParameter\s*{|^\s*}" ${custom_proto} | grep -A 1 LayerParameter | tail -1 | awk -F : '{print $1}')
  check_is_digit $declare_begin "Invaliend begin of message LayerParameter."
  check_is_digit $declare_end "Invaliend end of message LayerParameter."
  declare_params=$(sed -n "$declare_begin, $declare_end p" ${custom_proto} | grep optional | awk -F ' ' '{print $2}')
  log "[INFO] User-declared operator: $declare_params."

  list=($(grep -E "\s*message.*{.*" ${custom_proto} | grep -v 'LayerParameter' | awk -F ' ' '{print $2}'))
  log "[INFO] User-defined operator size: ${#list[@]}."
  for list_element in ${list[@]}; do
    element=$(echo $list_element | sed 's/{.*$//')
    match_regex="\s*message\s*+"${element}"\s*{"
    match_count=$(grep -c -E $match_regex ${caffe_proto})
    if [ "$match_count" == "0" ]; then
      continue
    fi
    match_count=$(echo $declare_params | grep -c -w $element)
    if [ "$match_count" == "1" ]; then
      if [[ "${is_overwrite}" == "false" ]]; then
        if [[ "$element" != "ClipParameter" && "$element" != "SwishParameter" ]]; then
          log "[ERROR] Find duplicate message define of $element"
          return 1
        fi
      fi
      # Delete the declare in caffe_proto
      declare_regex="\s*optional\s*+"${element}"\s.*"
      declare_line=($(grep -n -E $declare_regex ${caffe_proto} | awk -F : '{print $1}'))
      check_is_digit $declare_line "Invaliend line number of declare."
      sed -i ''${declare_line[0]}' d' ${caffe_proto}
      if [ $? -ne 0 ]; then
        log "[ERROR] Delete the declare of $element failed."
        return 1
      fi
      log "[INFO] Delete the declare of $element."
    fi
    # Delete the definition in caffe_proto
    define_regex="\s*message\s*+"${element}"\s*+{|^}"
    define_begin=$(grep -n -E $define_regex ${caffe_proto} | grep -A 1 message | head -1 | awk -F : '{print $1}')
    define_end=$(grep -n -E $define_regex ${caffe_proto} | grep -A 1 message | tail -1 | awk -F : '{print $1}')
    check_is_digit $declare_begin "Invaliend define_begin of definition."
    check_is_digit $declare_end "Invaliend define_end of definition."
    sed -i ''$define_begin','$define_end' d' ${caffe_proto}
    if [ $? -ne 0 ]; then
      log "[ERROR] Delete the definition of $element failed."
      return 1
    fi
    log "[INFO] Delete the definition of $element."
  done
  log "[INFO] End of pre proc for ${caffe_proto}."
}

merge_proto() {
  caffe_proto1=$1
  custom_proto1=$2
  is_overwrite1=$3

  pre_proc ${caffe_proto1} ${custom_proto1} ${is_overwrite1}
  if [ $? -ne 0 ]; then
    return 1
  fi
  # check if user define null LayerParameter by 'message LayerParameter { }'
  check_null=($(grep -n -E "^message\s+LayerParameter\s*{\s*}" ${custom_proto1} | awk -F ' ' '{print $2}'))
  if [[ ${#check_null[@]} -gt 0 ]]; then
    return 0
  fi

  begin=$(grep -n -E "^message\s+LayerParameter\s*{|^\s*}" ${custom_proto1} | grep -A 1 LayerParameter | head -1 | awk -F : '{print $1}')
  end=$(grep -n -E "^message\s+LayerParameter\s*{|^\s*}" ${custom_proto1} | grep -A 1 LayerParameter | tail -1 | awk -F : '{print $1}')
  check_is_digit $begin "Can not find message LayerParameter in custom proto."
  check_is_digit $end "Can not find end of message LayerParameter in custom proto."
  # check if distance between begin, end is less equal than 1, means empty
  distance=$(expr $end - $begin)
  if [[ ${distance} -le 1 ]]; then
    return 0
  fi
  ((begin+=1))
  ((end-=1))
  check_is_digit $end "Invaliend end of message LayerParameter."
  sed -n "$begin, $end p" ${custom_proto1} > tmp/insert.proto
  if [ $? -ne 0 ]; then
    log "[ERROR] Get LayerParameter from custom proto failed."
    return 1
  fi
  ((end+=2))
  insert_begin=$(grep -n -E "^message\s+LayerParameter\s*{|^\s*}" ${caffe_proto1} | grep -A 1 LayerParameter | tail -1 | awk -F : '{print $1}')
  check_is_digit $insert_begin "Failed to find insert position in caffe proto."
  ((insert_begin-=1))
  sed "$insert_begin r tmp/insert.proto" ${caffe_proto1} > tmp/caffe.proto
  if [ $? -ne 0 ]; then
    log "[ERROR] Set LayerParameter to caffe proto failed."
    return 1
  fi
  sed -n "$end, $ p" ${custom_proto1} >> tmp/caffe.proto
  if [ $? -ne 0 ]; then
    log "[ERROR] Set definition of Parameter to caffe proto failed."
    return 1
  fi
  mv tmp/caffe.proto ${caffe_proto1}
}

check_protoc() {
  ${PROTOC} --version
}

mkdir -p tmp

if [ -f "tmp/${CAFFE_PROTO}.origin" ]; then
  log "[INFO] Restore ${CAFFE_PROTO}."
  cp tmp/${CAFFE_PROTO}.origin ${CAFFE_PROTO}
fi

if [ ! -f "tmp/${CAFFE_PROTO}.origin" ]; then
  log "[INFO] Backup ${CAFFE_PROTO}."
  cp ${CAFFE_PROTO} tmp/${CAFFE_PROTO}.origin
fi
# if there is no custom.proto, then no need backup amct_custom.proto
if [[ "${USER_PROTO}" != "" ]]; then
  if [ -f "tmp/${AMCT_PROTO}.origin" ]; then
    log "[INFO] Restore ${AMCT_PROTO}."
    cp tmp/${AMCT_PROTO}.origin ${AMCT_PROTO}
  fi

  if [ ! -f "tmp/${AMCT_PROTO}.origin" ]; then
    log "[INFO] Backup ${AMCT_PROTO}."
    cp ${AMCT_PROTO} tmp/${AMCT_PROTO}.origin
  fi
fi

log "[INFO] Merge caffe proto."
####################update ATC caffe.proto from caffe 1.0 to caffe-master
# delete domi define in ATC caffe.proto
sed -i 's|domi.caffe|caffe|' ${CAFFE_PROTO}
# add repeated string weights = 42; to ATC caffe.proto
begin1=$(grep -n -E "optional bool layer_wise_reduce = 41" ${CAFFE_PROTO} | head -1 | awk -F : '{print $1}')
sed -i "$begin1 a \ \ repeated string weights = 42;" ${CAFFE_PROTO}

# Step1: Merge user custom.proto and amct custom.proto
if [[ "${USER_PROTO}" != "" ]]; then
  merge_proto ${AMCT_PROTO} ${USER_PROTO} false
  if [ $? -ne 0 ]; then
    log "[ERROR] Merge proto failed, please check your custom proto."
    exit 1
  fi
fi
# Step2: Merge to atc caffe.proto as final caffe.proto
merge_proto ${CAFFE_PROTO} ${AMCT_PROTO} true
if [ $? -ne 0 ]; then
  log "[ERROR] Merge proto failed, please check your custom proto."
  exit 1
fi
# Step3: Try to check the legality of merged caffe.proto by protoc compile
check_protoc
if [[ $? -eq 0 ]]; then
  log "[INFO] Compile caffe proto."
  $PROTOC --proto_path=./ --python_out=./tmp ./caffe.proto
  if [ $? -ne 0 ]; then
    log "[ERROR] Protoc run failed, maybe need to compare the merged proto with origin or check your custom proto."
    exit 1
  fi
else
  log "[WARNING] Cannot find protoc in env, may use 'sudo apt-get install protobuf-compiler' install it"
fi
