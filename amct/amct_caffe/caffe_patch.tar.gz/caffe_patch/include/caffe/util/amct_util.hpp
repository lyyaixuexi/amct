/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief amct_util head file
 *
 * @file amct_util.h
 *
 * @version 1.0
 */
#ifndef AMCT_UTIL_H
#define AMCT_UTIL_H

#include <string>
#include "caffe/layers/util.h"
#include "caffe/proto/caffe.pb.h"
#include "caffe/util/io.hpp"


namespace caffe {
const int LSTM_CHANNEL_NUM = 4;
const int LSTM_XH_CHANNEL_AXIS = 2;
const int LSTM_S_CHANNEL_AXIS = 1;
const int CONV_HEIGHT_AXIS = 2;
const int CONV_WIDTH_AXIS = 3;
const std::string REPLACE_STR = "_";
void ConvertLayerName(std::string& originalLayerName, const std::string& subString, const std::string& replaceString);
int RecordScaleOffset(std::string file_name, std::string layer_name, util::FloatData scale, util::IntData offset);
}
#endif // AMCT_UTIL_H