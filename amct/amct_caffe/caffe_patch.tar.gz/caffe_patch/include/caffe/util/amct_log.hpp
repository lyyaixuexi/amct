/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief amct log head file
 *
 * @file amct_log.hpp
 *
 * @version 1.0
 */
#ifndef AMCT_LOG_H
#define AMCT_LOG_H

#include <map>
#include <cstdint>

namespace caffe {
constexpr int32_t ERROR_LEVEL = 1;
constexpr int32_t WARNING_LEVEL = 2;
constexpr int32_t INFO_LEVEL = 3;
constexpr int32_t DEBUG_LEVEL = 4;

class AmctLog {
public:
    explicit AmctLog(const std::string &logEnv_);
    AmctLog() = default;
    ~AmctLog() = default;

    template<typename T>
    void DataDebugLog(const std::string &logPath, const std::string &msg, T *data, uint32_t len);
    void DebugLog(const std::string &logPath, const std::string &msg, const std::string &log);

private:
    std::string GetTimeStamp();
    int32_t GetLogLevel();
    std::string logEnv_ {"AMCT_LOG_FILE_LEVEL"};
    std::map<std::string, int32_t> mapLog_ {
        {"ERROR", ERROR_LEVEL},
        {"WARNING", WARNING_LEVEL},
        {"INFO", INFO_LEVEL},
        {"DEBUG", DEBUG_LEVEL}
    };
};
}

#define FUNC_LINE (std::string("[") + __FILE__ + "][" + __func__ + "][" + std::to_string(__LINE__) + "]\n")

#endif // AMCT_LOG_H
