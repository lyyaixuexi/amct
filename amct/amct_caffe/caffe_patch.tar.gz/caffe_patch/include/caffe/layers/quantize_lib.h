/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief amct_caffe quantize library header file
 *
 * @file quantize_lib.h
 *
 * @version 1.0
 */

#ifndef QUANTIZE_LIB_H
#define QUANTIZE_LIB_H

#include "arq.h"
#include "nuq.h"
#include "ifmr.h"
#include "hfmg.h"
#include "search_n.h"
#include "search_n_v2.h"
#include "ulq.h"

#endif /* QUANTIZE_LIB_H */
