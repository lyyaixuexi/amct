/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief search n v2 layer header file
 *
 * @version 1.0
 */
#ifndef CAFFE_SEARCH_N_V2_LAYER_HPP_
#define CAFFE_SEARCH_N_V2_LAYER_HPP_

#include <vector>
#include <cstdlib>
#include <cstdio>
#include <fstream>
#include "caffe/blob.hpp"
#include "caffe/layer.hpp"
#include "caffe/proto/caffe.pb.h"
#include "caffe/layers/search_n_layer.hpp"

#include "quantize_lib.h"

namespace caffe {
template <typename Dtype>
class SearchNV2Layer : public SearchNLayer<Dtype> {
public:
    explicit SearchNV2Layer(const LayerParameter& param)
        : SearchNLayer<Dtype>(param) {}
    virtual void LayerSetUp(const vector<Blob<Dtype>* >& bottom,
        const vector<Blob<Dtype>* >& top);
    virtual void Reshape(const vector<Blob<Dtype>* >& bottom,
        const vector<Blob<Dtype>* >& top);
    virtual inline const char* type() const
    {
        return "SearchNV2";
    }
    virtual ~SearchNV2Layer() {}
    void GetDeqScaleSearchNV2(const Dtype scaleD);

protected:
    virtual void Forward_cpu(const vector<Blob<Dtype>* >& bottom,
        const vector<Blob<Dtype>* >& top);
    virtual void Backward_cpu(const vector<Blob<Dtype>* >& top,
        const vector<bool>& propagate_down, const vector<Blob<Dtype>* >& bottom);
    virtual void Forward_gpu(const vector<Blob<Dtype>* >& bottom,
        const vector<Blob<Dtype>* >& top);
    virtual void Backward_gpu(const vector<Blob<Dtype>* >& top,
        const vector<bool>& propagate_down, const vector<Blob<Dtype>* >& bottom);
    std::vector<vector<Dtype>> searchNError_;
};
}  // namespace caffe
#endif  // CAFFE_SEARCH_N_V2_LAYER_HPP_
