/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief hfmg layer head file
 *
 * @file hfmg_layer.hpp
 *
 * @version 1.0
 */
#ifndef CAFFE_HFMG_LAYER_HPP_
#define CAFFE_HFMG_LAYER_HPP_

#include <cstdlib>
#include <vector>
#include "caffe/util/io.hpp"
#include "caffe/blob.hpp"
#include "caffe/layer.hpp"
#include "caffe/proto/caffe.pb.h"
#include "caffe/layers/neuron_layer.hpp"
#include "caffe/util/amct_util.hpp"
#include "quantize_lib.h"


namespace caffe {
template <typename Dtype>
class HFMGLayer : public NeuronLayer<Dtype> {
public:

    explicit HFMGLayer(const LayerParameter& param)
        : NeuronLayer<Dtype>(param) {}
    virtual void LayerSetUp(const vector<Blob<Dtype>* >& bottom, const vector<Blob<Dtype>* >& top);
    virtual void Reshape(const vector<Blob<Dtype>* >& bottom,
        const vector<Blob<Dtype>* >& top) {}
    void RecordQuantParams(
        const std::string& fileName,
        const google::protobuf::RepeatedPtrField<std::string>& objectLayerNames,
        util::FloatData scale, util::IntData offset);
    virtual inline int ExactNumBottomBlobs() const
    {
        return -1;
    }
    virtual inline int MinBottomBlobs() const
    {
        return 1;
    }
    virtual inline const char* type() const
    {
        return "HFMG";
    }
    virtual ~HFMGLayer() {}

protected:

    virtual void Forward_cpu(const vector<Blob<Dtype>* >& bottom,
        const vector<Blob<Dtype>* >& top);
    virtual void Forward_gpu(const vector<Blob<Dtype>* >& bottom,
        const vector<Blob<Dtype>* >& top);

    void Preprocess_gpu(const vector<Blob<Dtype>* >& bottom,
        const vector<Blob<Dtype>* >& top);

    void Calibration_gpu(const vector<Blob<Dtype>* >& bottom,
        const vector<Blob<Dtype>* >& top);

    virtual void Backward_cpu(const vector<Blob<Dtype>* >& top,
                              const vector<bool>& propagate_down,
                              const vector<Blob<Dtype>* >& bottom)
    {
        for (int i = 0; i < propagate_down.size(); ++i) {
            if (propagate_down[i]) {
                NOT_IMPLEMENTED;
            }
        }
    }
    virtual void Backward_gpu(const vector<Blob<Dtype>* >& top,
                              const vector<bool>& propagate_down,
                              const vector<Blob<Dtype>* >& bottom);

private:
    util::FloatData scale_{0, nullptr};
    float scaleData_{0};
    util::IntData offset_{0, nullptr};
    int offsetData_{0};
    AmctCommon::HfmgAlgoParam hfmgParam_;
    unsigned int numBatchProcessed_{0};
    google::protobuf::RepeatedPtrField<std::string> objectLayerNames_;
    bool needDump_ = false;
    std::string dump_dir_;
    unsigned int targetBatchNum_{1};
    std::vector<AmctCommon::DataBin<Dtype>> dataBins_;
    int* binCountDevicePtr_ = nullptr;
    float* l2LossDevicePtr_ = nullptr;
};
}  // namespace caffe

#endif  // CAFFE_HFMG_LAYER_HPP_
