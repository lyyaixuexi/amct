/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief anti_quant layer head file
 *
 * @file anti_quant_layer.hpp
 *
 * @version 1.0
 */
#ifndef CAFFE_RECORD_QUANTIZE_FACTOR_LAYER_HPP_
#define CAFFE_RECORD_QUANTIZE_FACTOR_LAYER_HPP_

#include <vector>
#include "caffe/blob.hpp"
#include "caffe/layer.hpp"
#include "caffe/proto/caffe.pb.h"
#include "caffe/layers/neuron_layer.hpp"
#include "quantize_lib.h"

namespace caffe {
template <typename Dtype>
class RecordQuantizeFactorLayer : public NeuronLayer<Dtype> {
public:
    explicit RecordQuantizeFactorLayer(const LayerParameter& param)
        : NeuronLayer<Dtype>(param) {}
    virtual inline const char* type() const
    {
        return "RecordQuantizeFactor";
    }
    virtual inline int ExactNumBottomBlobs() const
    {
        return 1;
    }
    virtual inline int ExactNumTopBlobs() const
    {
        return 1;
    }
    virtual ~RecordQuantizeFactorLayer() {}

protected:
    virtual void LayerSetUp(const vector<Blob<Dtype>* >& bottom, const vector<Blob<Dtype>* >& top);
    virtual void Forward_gpu(const vector<Blob<Dtype>* >& bottom,
        const vector<Blob<Dtype>* >& top);
    virtual void Forward_cpu(const vector<Blob<Dtype>* >& bottom,
        const vector<Blob<Dtype>* >& top);
    virtual void Backward_gpu(const vector<Blob<Dtype>* >& top,
        const vector<bool>& propagate_down, const vector<Blob<Dtype>* >& bottom);
    virtual void Backward_cpu(const vector<Blob<Dtype>* >& top,
        const vector<bool>& propagate_down, const vector<Blob<Dtype>* >& bottom);

    void WeightsParamSetUp();
    void BatchNormParamSetUp(const std::vector<int>& shapeCout);
    void DoBatchNormFusion(bool updateWeightsFactor, bool& updateWeightsBNFusion);
    void DoScaleFusion(bool updateWeightsFactor, bool updateWeightsBNFusion, bool& updateWeightsScaleFusion);
    void UpdateRecordFile(bool updateDataFactor,
                          bool updateWeightsFactor,
                          bool updateWeightsBNFusion,
                          bool updateWeightsScaleFusion);
    void RecordQuantizeFactorKernel();
    bool WeightsRecordQuantizeFactorKernel();
    void updateWeightsFactorKernel(SingleLayerRecord* layerQuantInfo);

    bool needUpdate_{true};
    bool isPooling_{false};
    std::vector<int> weightsShape_{};
    uint blobSize_{2};
    std::string objectLayer_;
    std::string recordFileName_;
    // For activation quantize factor
    Dtype clipMax_{0};
    Dtype clipMin_{0};
    float scaleData_{0};
    int offsetData_{0};

    // For weights quantize factor
    std::string layerType_;
    AmctCommon::ArqParam arqParam_;
    util::FloatData scaleWeights_;
    std::vector<float> scaleWeightsData_{};
    util::IntData offsetWeights_;
    std::vector<int> offsetWeightsData_{};

    // For Conv+BN fusion
    bool withBatchNorm_{false};
    std::vector<Dtype> variance_{};
    Dtype scaleFactor_;
    float epsilon_{0};
    std::vector<float> scaleWeightsBNFused_{};

    // For Conv+Scale fusion
    bool withScale_{false};
    uint scaleBlobIndex_{0};
    std::vector<Dtype> scale_{};
    std::vector<float> scaleWeightsScaleFused_{};
};
}  // namespace caffe

#endif  // CAFFE_RECORD_QUANTIZE_FACTOR_LAYER_HPP_
