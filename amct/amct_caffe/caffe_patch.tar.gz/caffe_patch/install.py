#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Install source code, dynamic library and patch to caffe

"""
import os
import argparse
import subprocess
from datetime import datetime
from datetime import timezone
from datetime import timedelta
from pathlib import Path
from collections import namedtuple
from collections import OrderedDict

CUR_DIR = os.path.split(os.path.realpath(__file__))[0]
PATCH_DIR = os.path.join(CUR_DIR, 'patch')
COPY_SUB_DIRS = ['include', 'src', 'quant_lib']

PatchSpec = namedtuple('PatchSpec', ['new_target', 'url'])
PatchSpec.__new__.__defaults__ = (None,) * len(PatchSpec._fields)

PATCHS = OrderedDict()
PATCHS['lstm_quant_layer.cpp.patch'] = PatchSpec(
    new_target='src/caffe/layers/lstm_quant_layer.cpp',
    url='https://raw.githubusercontent.com/BVLC/caffe/master/include/caffe/layers/lstm_layer.hpp')
PATCHS['lstm_quant_layer.hpp.patch'] = PatchSpec(
    new_target='include/caffe/layers/lstm_quant_layer.hpp',
    url='https://raw.githubusercontent.com/BVLC/caffe/master/src/caffe/layers/lstm_layer.cpp')
PATCHS['lstm_calibration_layer.cpp.patch'] = PatchSpec(
    new_target='src/caffe/layers/lstm_calibration_layer.cpp',
    url='https://raw.githubusercontent.com/BVLC/caffe/master/include/caffe/layers/lstm_layer.hpp')
PATCHS['lstm_calibration_layer.hpp.patch'] = PatchSpec(
    new_target='include/caffe/layers/lstm_calibration_layer.hpp',
    url='https://raw.githubusercontent.com/BVLC/caffe/master/src/caffe/layers/lstm_layer.cpp')

ADD_QUANT_LIB_TO_CAFFE = '\
# add quant lib to caffe\n\
ifeq ($(CPU_ONLY), 1)\n\
\tLIBRARIES += quant\n\
else\n\
\tLIBRARIES += quant_gpu\n\
endif\n\
'
ADD_QUANT_LIB_TO_CAFFE_ANCHOR = '\
# CPU-only configuration\n\
ifeq ($(CPU_ONLY), 1)\n\
\tOBJS := $(PROTO_OBJS) $(CXX_OBJS)\n\
\tTEST_OBJS := $(TEST_CXX_OBJS)\n\
\tTEST_BINS := $(TEST_CXX_BINS)\n\
\tALL_WARNS := $(ALL_CXX_WARNS)\n\
\tTEST_FILTER := --gtest_filter="-*GPU*"\n\
\tCOMMON_FLAGS += -DCPU_ONLY\n\
endif\n\
'

INCLUDE_LIB = 'LIBRARY_DIRS += quant_lib'
INCLUDE_LIB_ANCHOR = 'LIBRARY_DIRS += $(LIB_BUILD_DIR)'

CP_QUANT_LIB = '\tcp -af quant_lib/* $(LIB_BUILD_DIR)'
CP_QUANT_LIB_ANCHOR = 'lib: $(STATIC_NAME) $(DYNAMIC_NAME)'

CPP11_SUPPORT = 'COMMON_FLAGS += --std=c++11'
CPP11_SUPPORT_ANCHOR = \
    'COMMON_FLAGS += $(foreach includedir,$(INCLUDE_DIRS),-I$(includedir))'

TIME = datetime.now(tz=timezone(offset=timedelta(hours=8)))
TIME_NOW = '{:0>4}{:0>2}{:0>2}{:0>2}{:0>2}{:0>2}{:0>2}'.format( \
            TIME.year, TIME.month, TIME.day, TIME.hour, TIME.minute, \
            TIME.second, TIME.microsecond // 10000)

OLD_PATCH_SRC_FILE_LIST = [
    "lstm_quant_layer", "lstm_calibration_layer", "activation_qat_layer", "anti_quant_layer",
    "dequant_layer", "ifmr_layer", "hfmg_layer", "quant_layer", "record_quantize_factor_layer",
    "retrain_search_n_layer", "search_n_layer", "search_n_v2_layer", "weight_qat_layer",
    "transparent_layer"
]

OLD_PATCH_HEADER_FILE_LIST = [
    "lstm_quant_layer.hpp", "lstm_calibration_layer.hpp", "activation_qat_layer.hpp",
    "anti_quant_layer.hpp", "dequant_layer.hpp", "ifmr_layer.hpp",
    "hfmg_layer.hpp", "quant_layer.hpp", "record_quantize_factor_layer.hpp",
    "retrain_search_n_layer.hpp", "search_n_layer.hpp", "search_n_v2_layer.hpp",
    "weight_qat_layer.hpp", "transparent_layer.hpp", "util.h", "quant.h",
    "arq.h", "error_codes.h", "hfmg.h", "ifmr.h", "nuq.h", "quantize_lib.h", "search_n_v2.h",
    "ulq.h", "weight_ulq.h"
]


def execute_cmd(cmd, work_dir, show_err_msg=True):
    """execute cmd"""
    cmd_list = cmd.split(' ')
    with subprocess.Popen(cmd_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          close_fds=True, shell=False, cwd=work_dir) as proc:
        outs, errs = proc.communicate()
        ret = proc.returncode

    if ret != 0:
        if show_err_msg:
            print('cmd is:\n%s' % (cmd))
            if outs:
                print('output message is:\n%s' % outs.decode('ascii'))
            if errs:
                print('error message is:\n%s' % errs.decode('ascii'))
    return ret


def parse_args():
    """Parse input arguments."""
    parser = argparse.ArgumentParser(
        description='install amct caffe patch to caffe_dir')
    parser.add_argument('--caffe_dir', dest='caffe_dir',
                        help='specify the dir of caffe',
                        default=None, type=str)
    parser.add_argument('--custom_proto', dest='custom_proto',
                        help='specify the dir of custom.proto',
                        default=None, type=str)
    return parser.parse_args()


def args_check(args):
    """check args"""
    if args.caffe_dir is None:
        raise RuntimeError('Must specify a caffe framework dir')
    caffe_dir = os.path.realpath(args.caffe_dir)
    if not Path(caffe_dir).exists():
        raise RuntimeError('Must specify a caffe framework dir')
    if args.custom_proto is not None:
        if not Path(args.custom_proto).exists():
            raise RuntimeError('Cannot find user custom proto: "{}"'.format(
                args.custom_proto))


def copy_sub_dirs(caffe_dir):
    """copy sub dir to caffe dir"""
    for sub_dir in COPY_SUB_DIRS:
        cmd = 'cp -rf %s %s/' % (os.path.join(CUR_DIR, sub_dir), caffe_dir)
        ret = execute_cmd(cmd, CUR_DIR)
        if ret != 0:
            raise RuntimeError("Copy directory '{}' to '{}' failed."
                               .format(sub_dir, caffe_dir))


def generate_patch_cmd(caffe_dir, patch_name, patch_spec):
    """cmd of generate patch"""
    patch_path = os.path.join(PATCH_DIR, patch_name)
    cmd = 'patch -p1 -i %s' % (patch_path)
    if patch_spec.new_target:
        cmd = '%s -o %s' % (cmd, os.path.join(caffe_dir, patch_spec.new_target))

    return cmd


def install_patch(caffe_dir, patch_list, show_err_msg=False):
    """install patch to caffe dir"""
    fail_list = []
    for item in patch_list:
        cmd = generate_patch_cmd(caffe_dir, item, PATCHS[item])
        ret = execute_cmd(cmd, caffe_dir, show_err_msg)
        if ret != 0:
            fail_list.append(item)
    return fail_list


def merge_proto(custom_proto, caffe_dir):
    """merge caffe.proto"""
    if custom_proto is not None:
        custom_proto_path = os.path.realpath(custom_proto)
        ret = execute_cmd('bash merge_proto.sh caffe.proto ' \
            'amct_custom.proto {}'.format( \
            custom_proto_path), os.path.join(CUR_DIR, 'merge_proto'), True)
    else:
        ret = execute_cmd('bash merge_proto.sh caffe.proto ' \
            'amct_custom.proto', os.path.join(CUR_DIR, 'merge_proto'), True)

    if ret != 0:
        raise RuntimeError('Merge user proto failed.')

    caffe_proto_path = os.path.join(caffe_dir, 'src/caffe/proto/caffe.proto')
    # back up user caffe.proto
    execute_cmd('cp %s %s' % (caffe_proto_path,
                              '%s.backup%s' % (caffe_proto_path, TIME_NOW)), CUR_DIR)

    ret = execute_cmd('cp {} {}'.format( \
        os.path.join(CUR_DIR, 'merge_proto/caffe.proto'), \
        os.path.join(caffe_dir, 'src/caffe/proto')), CUR_DIR)
    if ret != 0:
        raise RuntimeError('Replace caffe.proto to user caffe failed.')
    print('[INFO]Merge and replace "caffe.proto" success.')


def check_and_add_content(contents, dst, anchor):
    """check then add content to input"""
    replaced = False
    if contents.find(dst) == -1:
        if contents.find(anchor) == -1:
            print('[WARNING]Cannot auto add:\n%s\nto caffe/Makefile, please ' \
                  'manually add it after:\n%s\n' % (dst, anchor))
        else:
            contents = contents.replace(anchor, '%s\n%s' % (anchor, dst))
            replaced = True
    return contents, replaced


def merge_makefile(caffe_dir):
    """merge caffe Makefile"""
    make_file = os.path.join(caffe_dir, 'Makefile')
    with open(make_file, 'r') as file_open:
        contents = file_open.read()
    need_update = False
    # add add quant lib to caffe
    contents, replaced = check_and_add_content(
        contents, ADD_QUANT_LIB_TO_CAFFE, ADD_QUANT_LIB_TO_CAFFE_ANCHOR)
    need_update = need_update or replaced
    # add quant_lib to LIBRARY_DIRS
    contents, replaced = check_and_add_content(
        contents, INCLUDE_LIB, INCLUDE_LIB_ANCHOR)
    need_update = need_update or replaced
    # add cp quant lib
    contents, replaced = check_and_add_content(
        contents, CP_QUANT_LIB, CP_QUANT_LIB_ANCHOR)
    need_update = need_update or replaced
    # add c++11 standard support
    if contents.find('--std=c++11') == -1:
        contents, replaced = check_and_add_content(
            contents, CPP11_SUPPORT, CPP11_SUPPORT_ANCHOR)
        need_update = need_update or replaced
    if need_update:
        # back up user Makefile
        execute_cmd('cp %s %s' % (make_file, \
            os.path.join(caffe_dir, 'Makefile.bakup%s' % (TIME_NOW))), CUR_DIR)
        # resave updated Makefile
        with open(make_file, 'w') as file_open:
            file_open.write(contents)
        print('[INFO]Merge and replace "Makefile" success.')


def backup_old_patch(caffe_dir):
    """ mv the old caffe patch files to a temp folder"""
    src_dir_mid = "src/caffe/layers"
    header_dir_mid = "include/caffe/layers"
    temp_dir = 'caffe_patch_backup{}'.format(TIME_NOW)
    src_backup_dir = os.path.join(caffe_dir, temp_dir, src_dir_mid)
    header_backup_dir = os.path.join(caffe_dir, temp_dir, header_dir_mid)
    execute_cmd('mkdir -p {}'.format(src_backup_dir), CUR_DIR)
    execute_cmd('mkdir -p {}'.format(header_backup_dir), CUR_DIR)

    for header_sufix in OLD_PATCH_HEADER_FILE_LIST:
        header_file_path = os.path.join(caffe_dir, header_dir_mid, header_sufix)
        real_header_file_path = os.path.realpath(header_file_path)
        if Path(real_header_file_path).exists():
            execute_cmd('mv {} {}'.format(real_header_file_path, header_backup_dir), CUR_DIR)

    for src_sufix in OLD_PATCH_SRC_FILE_LIST:
        for file_format in ['cu', 'cpp']:
            src_name_sufix = "{}.{}".format(src_sufix, file_format)
            src_file_path = os.path.join(caffe_dir, src_dir_mid, src_name_sufix)
            real_src_file_path = os.path.realpath(src_file_path)
            if Path(real_src_file_path).exists():
                execute_cmd('mv {} {}'.format(real_src_file_path, src_backup_dir), CUR_DIR)
    print("[INFO] Now the old amct_caffe patch files (src and header files)"
        " are moved to {}, ignore this when first time install.".format(
            os.path.join(caffe_dir, temp_dir)))


def main():
    """main function"""
    args = parse_args()
    args_check(args)
    print("[INFO]Begin to backup amct_caffe source files, header files, \n "
        "when first time install, this operation does nothing.")
    backup_old_patch(args.caffe_dir)
    print("[INFO]Begin to copy source files, header files and quant_lib to '{}'"
          .format(args.caffe_dir))
    copy_sub_dirs(args.caffe_dir)
    print("[INFO]Finish copy source files, header files and quant_lib to '{}'"
          .format(args.caffe_dir))
    print('[INFO]Begin to install patch.')
    fail_list = install_patch(args.caffe_dir, list(PATCHS))

    success_list = list(set(PATCHS) - set(fail_list))
    for item in success_list:
        print("[INFO]Install patch '{}' successfully.".format(item))
    for item in fail_list:
        print("[ERROR]Install patch '{}' failed.".format(item))
    print('[INFO]Finish install patch.')

    merge_proto(args.custom_proto, args.caffe_dir)
    merge_makefile(args.caffe_dir)


if __name__ == '__main__':
    main()
