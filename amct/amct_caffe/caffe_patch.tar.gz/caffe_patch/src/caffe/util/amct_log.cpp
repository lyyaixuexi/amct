/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2022-2022. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief amct_util src file
 *
 * @file amct_log.cpp
 *
 * @version 1.0
 */

#include "caffe/util/amct_log.hpp"
#include <ctime>
#include <algorithm>
#include <fstream>

namespace caffe {
AmctLog::AmctLog(const std::string &logEnv) : logEnv_(logEnv)
{
}

template<typename T>
void AmctLog::DataDebugLog(const std::string &logPath, const std::string &msg, T *data, uint32_t len)
{
    if (GetLogLevel() < mapLog_["DEBUG"]) {
        return;
    }

    std::ofstream pfLog(logPath, std::ios::trunc);
    if (!pfLog.is_open()) {
        return;
    }
    pfLog << GetTimeStamp() << "[DEBUG]" << msg;
    for (uint32_t i = 0; i < len; i++) {
        pfLog << data[i] << " ";
    }
    pfLog << "\n";
    pfLog.close();
}

void AmctLog::DebugLog(const std::string &logPath, const std::string &msg, const std::string &log)
{
    if (GetLogLevel() < mapLog_["DEBUG"]) {
        return;
    }

    std::ofstream pfLog;
    pfLog.open(logPath, std::ios::app);
    if (!pfLog.is_open()) {
        return;
    }
    pfLog << GetTimeStamp() << "[DEBUG]" << msg;
    pfLog << log << "\n";
    pfLog.close();
}

std::string AmctLog::GetTimeStamp()
{
    time_t t = time(nullptr);
    char timeStamp[32] = {};
    (void)std::strftime(timeStamp, sizeof(timeStamp), "%Y-%m-%d %H:%M:%S", std::localtime(&t));

    return timeStamp;
}

int32_t AmctLog::GetLogLevel()
{
    auto amctenv = getenv(logEnv_.c_str());
    if (amctenv != nullptr) {
        std::string logLevel = amctenv;
        std::transform(logLevel.begin(), logLevel.end(), logLevel.begin(), ::toupper);
        if (mapLog_.count(logLevel) == 0) {
            return INFO_LEVEL;
        }
    }
    return INFO_LEVEL;
}

template void AmctLog::DataDebugLog(const std::string &logPath, const std::string &msg,
    const float *data, uint32_t len);

template void AmctLog::DataDebugLog(const std::string &logPath, const std::string &msg,
    const double *data, uint32_t len);
}
