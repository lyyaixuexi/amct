/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief amct_util src file
 *
 * @file amct_util.cpp
 *
 * @version 1.0
 */
#include "caffe/util/amct_util.hpp"

using std::string;
using namespace util;

namespace caffe {
void ConvertLayerName(std::string& originalLayerName, const std::string& subString, const std::string& replaceString)
{
    string::size_type pos = 0;
    string::size_type subStrLength = subString.size();
    string::size_type replaceStringLen = replaceString.size();
    while ((pos = originalLayerName.find(subString, pos)) != string::npos) {
        originalLayerName.replace(pos, subStrLength, replaceString);
        pos += replaceStringLen;
    }
}

void RecordLayerScaleOffset(SingleLayerRecord* layer_record, FloatData scale, IntData offset)
{
    // record scale_d
    layer_record->clear_scale_d();
    for (unsigned int index = 0; index < scale.length; ++index) {
        layer_record->set_scale_d(scale.data[index]);
    }
    // record offset_w
    layer_record->clear_offset_d();
    for (unsigned int index = 0; index < offset.length; ++index) {
        layer_record->set_offset_d(offset.data[index]);
    }
}

int RecordScaleOffset(std::string file_name, std::string layer_name, FloatData scale, IntData offset)
{
    ScaleOffsetRecord records;
    if (!ReadProtoFromTextFile(file_name.c_str(), &records)) {
        LOG(ERROR) << "Read records from " << file_name << " failed.";
        return AmctCommon::NOT_SUPPORT_ERROR;
    }
    bool found_layer = false;
    for (int i = 0; i < records.record_size(); ++i) {
        ScaleOffsetRecord_MapFiledEntry* record = records.mutable_record(i);
        if (record->has_key() && record->key() == layer_name) {
            SingleLayerRecord* found_layer_record = record->mutable_value();
            RecordLayerScaleOffset(found_layer_record, scale, offset);
            found_layer = true;
            break;
        }
    }
    if (!found_layer) {
        ScaleOffsetRecord_MapFiledEntry* record = records.add_record();
        record->set_key(layer_name);
        SingleLayerRecord* new_layer_record = record->mutable_value();
        RecordLayerScaleOffset(new_layer_record, scale, offset);
    }
    WriteProtoToTextFile(records, file_name.c_str());
    return 0;
}
} // namespace caffe