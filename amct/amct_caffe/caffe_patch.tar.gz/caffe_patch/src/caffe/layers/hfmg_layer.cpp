/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief hfmg layer src file
 *
 * @file hfmg_layer.cpp
 *
 * @version 1.0
 */

#include "caffe/layers/hfmg_layer.hpp"
#include <vector>
#include <cmath>
#include <fstream>
#include <sstream>
#include <iostream>
#include <map>
#include "caffe/util/math_functions.hpp"
#include "caffe/util/io.hpp"


namespace caffe {
template <typename Dtype>
void HFMGLayer<Dtype>::RecordQuantParams(const std::string& fileName,
    const google::protobuf::RepeatedPtrField<std::string>& objectLayerNames,
    util::FloatData scale, util::IntData offset)
{
    for (int index = 0; index < objectLayerNames.size(); ++index) {
        int ret = caffe::RecordScaleOffset(fileName, objectLayerNames.Get(index), scale, offset);
        CHECK_EQ(ret, 0) << "Record scale and offset to file failed.";
        LOG(INFO) << "Do layer:\"" << objectLayerNames_.Get(index) << "\" activation calibration success!";
    }
}


template <typename Dtype>
void UpdateMinMax(const Dtype* bottom_data, const int count, Dtype& min, Dtype& max)
{
    Dtype inputMin = *std::min_element(bottom_data, bottom_data + count);
    Dtype inputMax = *std::max_element(bottom_data, bottom_data + count);
    min = inputMin < min ? inputMin : min;
    max = inputMax > max ? inputMax : max;
}

template <typename Dtype>
void HFMGLayer<Dtype>::LayerSetUp(const vector<Blob<Dtype>* >& bottom, const vector<Blob<Dtype>* >& top)
{
    vector<int> topShape = {1};
    if (top[0] == nullptr) {
        return;
    }
    top[0]->Reshape(topShape);
    scale_.length = 1;
    scale_.data = &scaleData_;
    offset_.length = 1;
    offset_.data = &offsetData_;
    // Set HFMG quantize algorithm parameters
    hfmgParam_.quantBitNum = util::NUM_BITS_QUANT;
    hfmgParam_.nbins = this->layer_param_.hfmg_param().nbins();
    hfmgParam_.withOffset = this->layer_param_.hfmg_param().with_offset();
    needDump_ = this->layer_param_.hfmg_param().need_dump();
    dump_dir_ = this->layer_param_.hfmg_param().dump_dir();
    objectLayerNames_ = this->layer_param_.hfmg_param().object_layer();
    targetBatchNum_ = this->layer_param_.hfmg_param().batch_num();
}

template <typename Dtype>
void HFMGLayer<Dtype>::Forward_cpu(const vector<Blob<Dtype>* >& bottom, const vector<Blob<Dtype>* >& top)
{
    // DO HFMG calibration
    if (numBatchProcessed_ > targetBatchNum_) {
        return;
    }
    // Phase 0, do calibration, search best scale and offset for feature map
    if (numBatchProcessed_ < targetBatchNum_) {
        Dtype bottomMin = 0;
        Dtype bottomMax = 0;
        for (size_t bottomIndex = 0; bottomIndex < bottom.size(); ++bottomIndex) {
            const Dtype* bottom_data = bottom[bottomIndex]->cpu_data();
            const int count = bottom[bottomIndex]->count();
            UpdateMinMax<Dtype>(bottom_data, count, bottomMin, bottomMax);
            AmctCommon::InputData<Dtype> inputData(count, bottom_data);
            HfmgMerge(hfmgParam_.nbins, dataBins_, inputData);
        }
        AmctCommon::ActArqCalibration(bottomMin, bottomMax, scale_, offset_, hfmgParam_);
        if (needDump_) {
            std::string layerName = this->layer_param_.name();
            ConvertLayerName(layerName, "/", REPLACE_STR);
            std::stringstream ss;
            ss << dump_dir_ << "/" << layerName << "_" << std::to_string(numBatchProcessed_) << ".bin";
            std::string fileName = ss.str();
            BlobProto blobProto;
            bottom[0]->ToProto(&blobProto, false);
            // dump bottom proto to file
            WriteProtoToBinaryFile(blobProto, fileName);
        }

        ++numBatchProcessed_;
        for (auto objectLayerName : objectLayerNames_) {
            LOG(INFO) <<  "Doing layer: \"" << objectLayerName << "\" calibration, already preprocess "
                << numBatchProcessed_ << "/" << targetBatchNum_ << " data.";
        }
    }
    if (numBatchProcessed_ == targetBatchNum_) {
        int ret;
        LOG(INFO) << "Start to do hfmg calibration.";
        // Already have enough data, then do once HFMG calibration.
        ret = AmctCommon::HfmgCompute(dataBins_, *scale_.data, *offset_.data, hfmgParam_);
        CHECK_EQ(ret, 0) << "Do HFMG calibration failed";
        this->RecordQuantParams(this->layer_param_.hfmg_param().record_file_path(),
            objectLayerNames_, scale_, offset_);
        ++numBatchProcessed_;
    }

    // pass the ActArqCalibration scale to the top as output for each forward;
    Dtype* top_data = top[0]->mutable_cpu_data();
    Dtype scaleArq = static_cast<Dtype>(*scale_.data);
    caffe_copy(scale_.length, &scaleArq, top_data);
}

#ifdef CPU_ONLY
STUB_GPU(HFMGLayer);
#endif

INSTANTIATE_CLASS(HFMGLayer);
REGISTER_LAYER_CLASS(HFMG);
}  // namespace caffe
