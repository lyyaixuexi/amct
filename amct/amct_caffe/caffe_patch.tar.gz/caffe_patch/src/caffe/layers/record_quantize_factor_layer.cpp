/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief record_quantize_factor layer src file
 *
 * @file record_quantize_factor_layer.cpp
 *
 * @version 1.0
 */
#include <vector>
#include <cmath>
#include <cfloat>
#include <fstream>
#include <iostream>
#include <map>

#include "caffe/layers/record_quantize_factor_layer.hpp"

#include "caffe/util/math_functions.hpp"
#include "caffe/util/amct_util.hpp"
#include "caffe/util/io.hpp"


namespace caffe {
const unsigned int NUM_BIT = 8;
const unsigned int WEIGHTS_BLOB_SIZE = 1;
const unsigned int BATCHNORM_BLOB_SIZE = 2;
const unsigned int SCLAE_BLOB_SIZE = 1;
const unsigned int BLOB_NUM_WITH_BN = 5;

const unsigned int CLIP_MAX_INDEX = 0;
const unsigned int CLIP_MIN_INDEX = 1;
const unsigned int WEIGHTS_INDEX = 2;
const unsigned int VARIANCE_INDEX = 3;
const unsigned int SCLAE_FACTOR_INDEX = 4;
const unsigned int SCLAE_WITH_BN_INDEX = 5;
const unsigned int SCLAE_WITHOUT_BN_INDEX = 3;

const unsigned int FOUR_DIM_SHAPE_SIZE = 4;
const unsigned int BATCH_DIM = 0;
const unsigned int CHANNEL_DIM = 1;
const unsigned int HIGH_DIM = 2;
const unsigned int WEIGHT_DIM = 3;

const unsigned int QUANT_BINS = 255;
const int INT8_MIN_VALUE = -128;

template <typename Dtype>
void RecordQuantizeFactorLayer<Dtype>::LayerSetUp(const vector<Blob<Dtype>* >& bottom,
                                                  const vector<Blob<Dtype>* >& top)
{
    // Read basic info of layer to be recorded
    objectLayer_ = this->layer_param_.record_quantize_factor_param().activation_qat_param().object_layer();
    recordFileName_ = this->layer_param_.record_quantize_factor_param().activation_qat_param().record_file_path();
    withBatchNorm_ = this->layer_param_.record_quantize_factor_param().with_batch_norm();
    withScale_ = this->layer_param_.record_quantize_factor_param().with_scale();
    isPooling_ = this->layer_param_.record_quantize_factor_param().weights_qat_param().layer_type() == "Pooling";

    blobSize_ += WEIGHTS_BLOB_SIZE * static_cast<unsigned int>(!isPooling_);
    blobSize_ += BATCHNORM_BLOB_SIZE * static_cast<unsigned int>(withBatchNorm_);
    blobSize_ += SCLAE_BLOB_SIZE * static_cast<unsigned int>(withScale_);
    this->blobs_.resize(blobSize_);

    // Init blob for clip_max, clip_min
    this->blobs_[CLIP_MAX_INDEX].reset(new(std::nothrow) Blob<Dtype>({1}));
    this->blobs_[CLIP_MIN_INDEX].reset(new(std::nothrow) Blob<Dtype>({1}));

    WeightsParamSetUp();
    // prepare BatchNorm info
    unsigned int coutIndex = (layerType_ == "Deconvolution") ? 1 : 0;
    vector<int> shapeCout = {weightsShape_[coutIndex]};
    if (withBatchNorm_) {
        BatchNormParamSetUp(shapeCout);
    }

    if (withScale_) {
        scaleBlobIndex_ = (withBatchNorm_) ? SCLAE_WITH_BN_INDEX : SCLAE_WITHOUT_BN_INDEX;
        this->blobs_[scaleBlobIndex_].reset(new(std::nothrow) Blob<Dtype>(shapeCout));
        scale_.resize(this->blobs_[scaleBlobIndex_]->count());
        scaleWeightsScaleFused_.resize(this->blobs_[scaleBlobIndex_]->count());
        LOG(INFO) << this->layer_param_.name() << " prepare Scale info success.";
    }
}

template <typename Dtype>
void RecordQuantizeFactorLayer<Dtype>::WeightsParamSetUp()
{
    // Init blob for weights
    RetrainWeightQuantParameter weightQuantParam =
        this->layer_param_.record_quantize_factor_param().weights_qat_param();
    weightsShape_.push_back(weightQuantParam.cout());
    weightsShape_.push_back(weightQuantParam.cin());
    if (weightQuantParam.has_h() && weightQuantParam.has_w()) {
        weightsShape_.push_back(weightQuantParam.h());
        weightsShape_.push_back(weightQuantParam.w());
    }
    if (isPooling_) {
        // If doing pooling quantize, scale_w, offset_w don't need online calculate
        CHECK_EQ(weightsShape_.size(), FOUR_DIM_SHAPE_SIZE) << "Pooling's weight shape must with kernel_h, kernel_w";
        scaleWeightsData_.push_back(1 / static_cast<float>(weightsShape_[HIGH_DIM] * weightsShape_[WEIGHT_DIM]));
        offsetWeightsData_.push_back(0);
    } else {
        this->blobs_[WEIGHTS_INDEX].reset(new(std::nothrow) Blob<Dtype>(weightsShape_));
    }
    // Read weights quantize param for weights ARQ quantize algorithm
    if (!isPooling_) {
        arqParam_.numBits = NUM_BIT;
        arqParam_.channelWise = this->layer_param_.record_quantize_factor_param().weights_qat_param().channel_wise();
        arqParam_.withOffset = false;
        layerType_ = this->layer_param_.record_quantize_factor_param().weights_qat_param().layer_type();

        if (arqParam_.channelWise) {
            if (layerType_ == "Deconvolution") {
                scaleWeights_.length = weightsShape_[1];
                scaleWeightsData_.resize(weightsShape_[1]);
                offsetWeights_.length = weightsShape_[1];
                offsetWeightsData_.resize(weightsShape_[1]);
            } else {
                scaleWeights_.length = weightsShape_[0];
                scaleWeightsData_.resize(weightsShape_[0]);
                offsetWeights_.length = weightsShape_[0];
                offsetWeightsData_.resize(weightsShape_[0]);
            }
        } else {
            scaleWeights_.length = 1;
            scaleWeightsData_.resize(1);
            offsetWeights_.length = 1;
            offsetWeightsData_.resize(1);
        }
    }
    LOG(INFO) << "\""<< this->layer_param_.name() << "\" prepare weights quantize parameters success.";
}

template <typename Dtype>
void RecordQuantizeFactorLayer<Dtype>::BatchNormParamSetUp(const vector<int>& shapeCout)
{
    CHECK_GE(this->blobs_.size(), BLOB_NUM_WITH_BN) << "IF with BatchNorm, at least have 5 blobs.";
    this->blobs_[VARIANCE_INDEX].reset(new(std::nothrow) Blob<Dtype>(shapeCout));
    this->blobs_[SCLAE_FACTOR_INDEX].reset(new(std::nothrow) Blob<Dtype>({1}));
    variance_.resize(this->blobs_[VARIANCE_INDEX]->count());
    scaleWeightsBNFused_.resize(this->blobs_[VARIANCE_INDEX]->count());
    epsilon_ = this->layer_param_.record_quantize_factor_param().eps();
    LOG(INFO) << "\""<< this->layer_param_.name() << "\" prepare BatchNorm parameters success.";
}

template <typename Dtype>
void RecordQuantizeFactorLayer<Dtype>::DoBatchNormFusion(bool updateWeightsFactor,
                                                         bool& updateWeightsBNFusion)
{
    const Dtype* variance = this->blobs_[VARIANCE_INDEX]->cpu_data();
    const Dtype* scaleFactor = this->blobs_[SCLAE_FACTOR_INDEX]->cpu_data();
    for (unsigned int i = 0; i < variance_.size(); ++i) {
        if (needUpdate_ || abs(variance_[i] - variance[i]) > FLT_EPSILON) {
            variance_[i] = variance[i];
            updateWeightsBNFusion = true;
        }
    }
    if (needUpdate_ || abs(scaleFactor[0] - scaleFactor_) > FLT_EPSILON) {
        scaleFactor_ = scaleFactor[0];
        updateWeightsBNFusion = true;
    }
    // 3.2. If BatchNorm updated or scale_w, offset_w updated, re-calculate fused scale_w, offset_w
    if (needUpdate_ || updateWeightsFactor || updateWeightsBNFusion) {
        // do weights scale_w conv+bn fusion
        Dtype actualScaleFactor = scaleFactor_;
        if (scaleFactor_ != 0) {
            actualScaleFactor = 1 / scaleFactor_;
        }
        for (unsigned int i = 0; i < scaleWeightsBNFused_.size(); ++i) {
            Dtype tmpVariance = variance_[i] * actualScaleFactor + epsilon_;
            unsigned int scaleWeightsIndex = (scaleWeightsData_.size() > 1) ? i : 0;
            scaleWeightsBNFused_[i] = scaleWeightsData_[scaleWeightsIndex] / sqrt(tmpVariance);
        }
        LOG(INFO) << "Update scale_w and offset_w of " << objectLayer_ << " by BatchNorm fusion.";
    }
}

template <typename Dtype>
void RecordQuantizeFactorLayer<Dtype>::DoScaleFusion(bool updateWeightsFactor,
                                                     bool updateWeightsBNFusion,
                                                     bool& updateWeightsScaleFusion)
{
    Dtype* scale = this->blobs_[scaleBlobIndex_]->mutable_cpu_data();
    for (unsigned int i = 0; i < scale_.size(); ++i)  {
        if (needUpdate_ || abs(scale[i] - scale_[i]) > FLT_EPSILON) {
            scale_[i] = scale[i];
            updateWeightsScaleFusion = true;
        }
    }
    // 4.2. If Scale updated or scale_w, offset_w updated, re-calculate fused scale_w, offset_w
    if (needUpdate_ || updateWeightsFactor || updateWeightsBNFusion || updateWeightsScaleFusion) {
        for (unsigned int i = 0; i < scaleWeightsScaleFused_.size(); ++i) {
            if (withBatchNorm_) {
                scaleWeightsScaleFused_[i] = scaleWeightsBNFused_[i] * scale_[i];
            } else {
                unsigned int scaleWeightsIndex = (scaleWeightsData_.size() > 1) ? i : 0;
                scaleWeightsScaleFused_[i] = scaleWeightsData_[scaleWeightsIndex] * scale_[i];
            }
        }
        LOG(INFO) << "Update scale_w and offset_w of " << objectLayer_ << " by Scale fusion.";
    }
}

template <typename Dtype>
void RecordQuantizeFactorLayer<Dtype>::UpdateRecordFile(bool updateDataFactor,
                                                        bool updateWeightsFactor,
                                                        bool updateWeightsBNFusion,
                                                        bool updateWeightsScaleFusion)
{
    ScaleOffsetRecord records;
    CHECK(ReadProtoFromTextFile(recordFileName_.c_str(), &records)) << "Read " << recordFileName_ << "failed";
    // get SingleLayerRecord from record
    SingleLayerRecord* layerQuantInfo = nullptr;
    bool foundKey = false;
    for (int i = 0; i < records.record_size(); ++i) {
        ScaleOffsetRecord_MapFiledEntry* record = records.mutable_record(i);
        if (record->has_key() && record->key() == objectLayer_) {
            layerQuantInfo = record->mutable_value();
            foundKey = true;
        }
    }
    if (!foundKey) {
        ScaleOffsetRecord_MapFiledEntry* record = records.add_record();
        record->set_key(objectLayer_);
        layerQuantInfo = record->mutable_value();
    }
    // update quantize factor to record file
    if (needUpdate_ || updateDataFactor) {
        layerQuantInfo->set_scale_d(scaleData_);
        layerQuantInfo->set_offset_d(offsetData_);
    }
    bool updateWeightsRecord = needUpdate_ || updateWeightsFactor || updateWeightsBNFusion || updateWeightsScaleFusion;
    if (updateWeightsRecord) {
        this->updateWeightsFactorKernel(layerQuantInfo);
    }
    // write record back to file
    WriteProtoToTextFile(records, recordFileName_.c_str());
    LOG(INFO) << "Update quantize factor of " << objectLayer_ << " to record file success.";
}

template <typename Dtype>
void RecordQuantizeFactorLayer<Dtype>::updateWeightsFactorKernel(SingleLayerRecord* layerQuantInfo)
{
    layerQuantInfo->clear_scale_w();
    layerQuantInfo->clear_offset_w();
    if (withScale_) {
        for (unsigned int i = 0; i < scaleWeightsScaleFused_.size(); ++i) {
            layerQuantInfo->add_scale_w(scaleWeightsScaleFused_[i]);
            unsigned int offsetWeightsIndex = (offsetWeightsData_.size() > 1) ? i : 0;
            layerQuantInfo->add_offset_w(offsetWeightsData_[offsetWeightsIndex]);
        }
    } else if (withBatchNorm_) {
        for (unsigned int i = 0; i < scaleWeightsBNFused_.size(); ++i) {
            layerQuantInfo->add_scale_w(scaleWeightsBNFused_[i]);
            unsigned int offsetWeightsIndex = (offsetWeightsData_.size() > 1) ? i : 0;
            layerQuantInfo->add_offset_w(offsetWeightsData_[offsetWeightsIndex]);
        }
    } else {
        for (unsigned int i = 0; i < scaleWeightsData_.size(); ++i) {
            layerQuantInfo->add_scale_w(scaleWeightsData_[i]);
            layerQuantInfo->add_offset_w(offsetWeightsData_[i]);
        }
    }
}

template <typename Dtype>
bool RecordQuantizeFactorLayer<Dtype>::WeightsRecordQuantizeFactorKernel()
{
    bool updateWeightsFactor = false;
    if (!isPooling_) {
        // if not Pooling, calculate scale_w, offset_w online by ARQ
        vector<float> scaleWeightsData(scaleWeightsData_.size());
        vector<int> offsetWeightsData(offsetWeightsData_.size());
        scaleWeights_.data = scaleWeightsData.data();
        offsetWeights_.data = offsetWeightsData.data();
        Dtype* weights = this->blobs_[WEIGHTS_INDEX]->mutable_cpu_data();
        unsigned int length = static_cast<unsigned int>(this->blobs_[WEIGHTS_INDEX]->count());
        if (layerType_ == "Deconvolution") {
            AmctCommon::TransposeAB(weights, length, weightsShape_);
            Status ret = ArqQuant(weights, length, arqParam_, scaleWeights_, offsetWeights_);
            AmctCommon::TransposeAB(weights, length, weightsShape_);
            CHECK_EQ(ret, AmctCommon::SUCCESS) << "Do ARQ after WeightsQAT failed.";
        } else {
            Status ret = ArqQuant(weights, length, arqParam_, scaleWeights_, offsetWeights_);
            CHECK_EQ(ret, AmctCommon::SUCCESS) << "Do ARQ after WeightsQAT failed.";
        }
        for (unsigned int i = 0; i < scaleWeights_.length; ++i) {
            if (needUpdate_ || abs(scaleWeightsData[i] - scaleWeightsData_[i]) > FLT_EPSILON) {
                scaleWeightsData_[i] = scaleWeightsData[i];
                offsetWeightsData_[i] = offsetWeightsData[i];
                updateWeightsFactor = true;
            }
        }
    }
    return updateWeightsFactor;
}

template <typename Dtype>
void RecordQuantizeFactorLayer<Dtype>::RecordQuantizeFactorKernel()
{
    // 1.1. Check whether need to update scale_d, offset_d
    const Dtype* clipMax = this->blobs_[0]->cpu_data();
    const Dtype* clipMin = this->blobs_[1]->cpu_data();

    bool updateDataFactor = false;
    if (needUpdate_ || (abs(clipMax_ - clipMax[0]) > FLT_EPSILON || abs(clipMin_ - clipMin[0]) > FLT_EPSILON)) {
        clipMax_ = clipMax[0];
        clipMin_ = clipMin[0];
        updateDataFactor = true;
    }
    // 1.2. Calculate scale_d, offset_d according to clip_max, clip_min
    if (updateDataFactor) {
        scaleData_ = (clipMax_ - clipMin_) / QUANT_BINS + FLT_EPSILON;
        Status ret = util::ProcessScale(scaleData_);
        CHECK_EQ(ret, AmctCommon::SUCCESS) << "ActivationQAT scale is illegal.";
        offsetData_ = static_cast<int>(-round(clipMin_ / scaleData_)) + INT8_MIN_VALUE;
        LOG(INFO) << "Update scale_d and offset_d of " << objectLayer_;
    }
    // 2.1. Check whether need to update scale_w, offset_w, calculate scale_w, offset_w by ARQ
    bool updateWeightsFactor = this->WeightsRecordQuantizeFactorKernel();
    if (updateWeightsFactor) {
        LOG(INFO) << "Update scale_w and offset_w of " << objectLayer_;
    }
    // 3.1. Check whether BatchNorm update
    bool updateWeightsBNFusion = false;
    if (withBatchNorm_) {
        DoBatchNormFusion(updateWeightsFactor, updateWeightsBNFusion);
    }
    // 4.1. Check whether Scale update
    bool updateWeightsScaleFusion = false;
    if (withScale_) {
        DoScaleFusion(updateWeightsFactor, updateWeightsBNFusion, updateWeightsScaleFusion);
    }
    // 5.1. If there is any update in scale_d, offset_d, scale_w, offset_w, trigger update record file
    if (needUpdate_ || updateDataFactor || updateWeightsFactor || updateWeightsBNFusion || updateWeightsScaleFusion) {
        LOG(INFO) << "Start do " << this->layer_param_.name() << " rcord quantize factor.";
        UpdateRecordFile(updateDataFactor, updateWeightsFactor, updateWeightsBNFusion, updateWeightsScaleFusion);
        LOG(INFO) << "Do " << this->layer_param_.name() << " rcord quantize factor success.";
    }
    needUpdate_ = false;
}

template <typename Dtype>
void RecordQuantizeFactorLayer<Dtype>::Forward_cpu(const vector<Blob<Dtype>* >& bottom,
                                                   const vector<Blob<Dtype>* >& top)
{
    const Dtype* bottom_data = bottom[0]->cpu_data();
    const int count = bottom[0]->count();
    Dtype* top_data = top[0]->mutable_cpu_data();
    caffe_copy(count, bottom_data, top_data);
    if (this->phase_ == TEST) {
        RecordQuantizeFactorKernel();
    }
}

template <typename Dtype>
void RecordQuantizeFactorLayer<Dtype>::Backward_cpu(const vector<Blob<Dtype>* >& top,
                                                    const vector<bool>& propagate_down,
                                                    const vector<Blob<Dtype>* >& bottom)
{
    const Dtype* top_diff = top[0]->cpu_diff();
    const int count = bottom[0]->count();
    Dtype* bottom_diff = bottom[0]->mutable_cpu_diff();

    caffe_copy(count, top_diff, bottom_diff);
}

#ifdef CPU_ONLY
STUB_GPU(RecordQuantizeFactorLayer);
#endif

INSTANTIATE_CLASS(RecordQuantizeFactorLayer);
REGISTER_LAYER_CLASS(RecordQuantizeFactor);
}  // namespace caffe
