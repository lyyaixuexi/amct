/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief ifmr layer src file
 *
 * @file ifmr_layer.cpp
 *
 * @version 1.0
 */
#include <vector>
#include <cmath>
#include <fstream>
#include <iostream>
#include <map>
#include "caffe/layers/ifmr_layer.hpp"
#include "caffe/util/math_functions.hpp"
#include "caffe/util/io.hpp"

namespace caffe {
template <typename Dtype>
void IFMRLayer<Dtype>::LayerSetUp(const vector<Blob<Dtype>* >& bottom,
                                  const vector<Blob<Dtype>* >& top)
{
    scale_.length = 1;
    scale_.data = &scaleData_;
    offset_.length = 1;
    offset_.data = &offsetData_;
    // Set IFMR quantize algorithm parameters
    ifmrParam_.calibration = 0; // first phase, store data
    ifmrParam_.numBits = util::NUM_BITS_QUANT;
    ifmrParam_.withOffset = this->layer_param_.ifmr_param().with_offset();
    ifmrParam_.needDump = this->layer_param_.ifmr_param().need_dump();
    ifmrParam_.startRatio = this->layer_param_.ifmr_param().search_range_start();
    ifmrParam_.endRatio = this->layer_param_.ifmr_param().search_range_end();
    ifmrParam_.step = this->layer_param_.ifmr_param().search_step();
    ifmrParam_.maxPercentile = this->layer_param_.ifmr_param().max_percentile();
    ifmrParam_.minPercentile = this->layer_param_.ifmr_param().min_percentile();
    ifmr_dump_dir_ = this->layer_param_.ifmr_param().dump_dir();
    objectLayerNames_ = this->layer_param_.ifmr_param().object_layer();
    targetBatchNum_ = this->layer_param_.ifmr_param().batch_num();
}

template <typename Dtype>
void IFMRLayer<Dtype>::Forward_cpu(const vector<Blob<Dtype>* >& bottom,
                                   const vector<Blob<Dtype>* >& top)
{
    // DO IFMR calibration
    if (ifmrParam_.calibration != 0) {
        return;
    }
    // Phase 0, do calibration, search best scale and offset for feature map
    if (numBatchStored_ < targetBatchNum_) {
        // If numBatchStored_ < Seted num batch, then store data in vector
        for (size_t bottomIndex = 0; bottomIndex < bottom.size(); ++bottomIndex) {
            const int count = bottom[bottomIndex]->count();
            const Dtype* bottom_data = bottom[bottomIndex]->cpu_data();
            for (int index = 0; index < count; ++index) {
                storedDataForCalibration_.push_back(bottom_data[index]);
            }
        }

        if (ifmrParam_.needDump && recordData_) {
            std::string layerName = this->layer_param_.name();
            ConvertLayerName(layerName, "/", REPLACE_STR);
            std::string fileName = ifmr_dump_dir_ + "/" + layerName + "_" + std::to_string(
                numBatchStored_) + ".bin";
            BlobProto blobProto;
            bottom[0]->ToProto(&blobProto, false);
            // dump bottom proto to file
            WriteProtoToBinaryFile(blobProto, fileName);
        }
        numBatchStored_++;
        for (auto objectLayerName : objectLayerNames_) {
            LOG(INFO) <<  "Doing layer: \"" << objectLayerName << "\" calibration, already store "
                << numBatchStored_ << "/" << targetBatchNum_ << " data.";
        }
    }
    if (numBatchStored_ == targetBatchNum_) {
        LOG(INFO) << "Start to do ifmr quant.";
        // Already have enough data, then do once IFMR calibration.
        int ret = AmctCommon::IfmrQuant(storedDataForCalibration_.data(), storedDataForCalibration_.size(),
            ifmrParam_, scale_, offset_);
        storedDataForCalibration_.clear();
        storedDataForCalibration_.shrink_to_fit();
        CHECK_EQ(ret, 0) << "Do IFMR calibration failed";
        // Record scale and offset
        for (int index = 0; index < objectLayerNames_.size(); ++index) {
            ret = caffe::RecordScaleOffset(this->layer_param_.ifmr_param().record_file_path(),
                objectLayerNames_.Get(index), scale_, offset_);
            CHECK_EQ(ret, 0) << "Record scale and offset to file failed.";
            LOG(INFO) << "Do layer:\"" << objectLayerNames_.Get(index) << "\" activation calibration success!";
        }
        ifmrParam_.calibration = 1;  // Phase 0 end, set calibration flag to test
    }
}

#ifdef CPU_ONLY
STUB_GPU(IFMRLayer);
#endif

INSTANTIATE_CLASS(IFMRLayer);
REGISTER_LAYER_CLASS(IFMR);
}  // namespace caffe
