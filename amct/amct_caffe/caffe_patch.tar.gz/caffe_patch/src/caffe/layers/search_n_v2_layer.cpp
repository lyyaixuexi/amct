/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief search shift bit layer cpp source
 *
 * @version 1.0
 */
#include <vector>
#include <cmath>
#include <fstream>
#include <sstream>
#include <iostream>
#include <map>

#include "caffe/layers/search_n_v2_layer.hpp"
#include "caffe/util/math_functions.hpp"
#include "caffe/util/io.hpp"
#include "caffe/util/amct_util.hpp"

using namespace util;

namespace caffe {
template <typename Dtype>
void SearchNV2Layer<Dtype>::Reshape(const vector<Blob<Dtype>* >& bottom,
                                    const vector<Blob<Dtype>* >& top)
{
    if (top.size() == 1) {
        if (top[0] == nullptr) {
            return;
        }
        top[0]->ReshapeLike(*bottom[0]);
    }
    return;
}


template <typename Dtype>
void ReadSingleRecord(
    vector<vector<Dtype>>& multiDeqScales,
    const ScaleOffsetRecord& records,
    const Dtype& scaleD,
    const string& layerName,
    const int& layerIndex)
{
    for (int j = 0; j < records.record_size(); j++) {
        const ScaleOffsetRecord_MapFiledEntry& record = records.record(j);
        if (record.has_key() && record.key() == layerName) {
            const SingleLayerRecord& layerQuantInfo = record.value();
            int scaleWSize = layerQuantInfo.scale_w_size();
            for (int k = 0; k < scaleWSize; k++) {
                multiDeqScales[layerIndex].push_back(scaleD * layerQuantInfo.scale_w(k));
            }
        }
    }
}


template <typename Dtype>
void SearchNV2Layer<Dtype>::GetDeqScaleSearchNV2(const Dtype scaleD)
{
    ScaleOffsetRecord records;
    this->deqScale.clear();
    this->deqScale.shrink_to_fit();
    this->ReadRecord(&records);
    vector<vector<Dtype>> multiDeqScales((this->quantLayerNames).size());
    for (int i = 0; i < this->quantLayerNames.size(); i++) {
        string layerName(this->quantLayerNames.Get(i));
        ReadSingleRecord(multiDeqScales, records, scaleD, layerName, i);
    }

    for (int i = 1; i < multiDeqScales.size(); i++) {
        CHECK_EQ(multiDeqScales[i].size(), multiDeqScales[0].size());
        for (int j = 0; j < multiDeqScales[i].size(); j++) {
            CHECK_EQ(multiDeqScales[i][j], multiDeqScales[0][j]);
        }
    }
    for (int i = 0; i < multiDeqScales[0].size(); i++) {
        this->deqScale.push_back(multiDeqScales[0][i]);
    }
    return;
}


template <typename Dtype>
void SearchNV2Layer<Dtype>::LayerSetUp(const vector<Blob<Dtype>* >& bottom,
                                       const vector<Blob<Dtype>* >& top)
{
    this->quantLayerNames = this->layer_param_.search_n_param().layer_name();
    this->targetBatchNum = this->layer_param_.search_n_param().batch_num();
    CHECK_GE(this->quantLayerNames.size(), 1);
    std::stringstream ss;
    ss << "[";
    for (auto layerName : this->quantLayerNames) {
        ss << layerName << " ";
    }
    ss << "]";
    this->showQuantLayerNames = ss.str();

    this->quantLayerTypes = this->layer_param_.search_n_param().layer_type();
    CHECK_EQ(this->quantLayerNames.size(), this->quantLayerTypes.size()) <<
        "layer_name size(" << this->quantLayerNames.size() <<
        ") must be equal to layer_type size(" << this->quantLayerTypes.size() << ").";

    this->recordFileName = this->layer_param_.search_n_param().record_file_path();
    this->GetBottomChannels();
    this->channelNum = this->bottomChannels[0];

    for (int idx = 0; idx < this->quantLayerTypes.size(); ++idx) {
        if ((this->quantLayerTypes.Get(idx) == "Convolution" || \
                this->quantLayerTypes.Get(idx) == "DepthwiseConvolution" || \
                this->quantLayerTypes.Get(idx) == "Deconvolution") && this->channelNum > 1) {
            if (bottom[idx]->shape(CONV_HEIGHT_AXIS) == 1 && bottom[idx]->shape(CONV_WIDTH_AXIS) == 1) {
                this->globalConvFlag = true;
                LOG(INFO) << "Find layer \"" << this->quantLayerNames.Get(idx) << "\" is global conv";
            }
        }
    }
    this->storedData.resize(this->channelNum);
    this->searchNError_.resize((this->globalConvFlag) ? 1 : this->channelNum);
    for (auto& item : this->searchNError_) {
        item.resize(SHIFT_BITS, 0);
    }
}


template <typename Dtype>
void SearchNV2Layer<Dtype>::Forward_cpu(const vector<Blob<Dtype>* >& bottom,
    const vector<Blob<Dtype>* >& top)
{
    if (this->curBatchNum > this->targetBatchNum) {
        return;
    }
    if (this->curBatchNum < this->targetBatchNum) {
        vector<Blob<Dtype>* > dataBottom(bottom);
        // the last bottom input is scale_d, not the data;
        dataBottom.pop_back();
        this->AccumulateData(dataBottom);
        Blob<Dtype>* scaleDBlob = bottom.back();
        const Dtype* scaleD = scaleDBlob->cpu_data();
        this->GetDeqScaleSearchNV2(scaleD[0]);
        vector<float> deqScaleFlt(this->deqScale.begin(), this->deqScale.end());
        FloatData deqScaleCpu{this->channelNum, deqScaleFlt.data()};
        AmctCommon::SearchNV2AccumulateError(this->storedData, this->searchNError_, deqScaleCpu, this->globalConvFlag);
        this->curBatchNum++;
        LOG(INFO) << "Doing layer: " << this->showQuantLayerNames << " searchNV2 calibration, already preprocess "
                  << this->curBatchNum << "/" << this->targetBatchNum << " data.";
        this->storedData.clear();
        this->storedData.shrink_to_fit();
        this->storedData.resize(this->channelNum);
    }

    if (this->curBatchNum == this->targetBatchNum) {
        size_t channelNumTemp = this->searchNError_.size();
        vector<int> bestN(channelNumTemp);
        IntData bestNdata{static_cast<unsigned int>(channelNumTemp), bestN.data()};
        int ret = AmctCommon::SearchNV2FindBestNCpu(this->searchNError_, bestNdata, this->globalConvFlag);
        CHECK_EQ(ret, 0) << "searchNV2 calibration failed!";
        this->RecordN(bestN);
        LOG(INFO) << "Do layer: " << this->showQuantLayerNames << " searchNV2 calibration success!";

        this->storedData.clear();
        this->searchNError_.clear();
        this->storedData.shrink_to_fit();
        this->searchNError_.shrink_to_fit();
        this->curBatchNum++;
    }
    if (top.size() == 1) {
        const int count = bottom[0]->count();
        const Dtype* bottom_data = bottom[0]->cpu_data();
        Dtype* top_data = top[0]->mutable_cpu_data();
        caffe_copy(count, bottom_data, top_data);
    }
}

template <typename Dtype>
void SearchNV2Layer<Dtype>::Backward_cpu(const vector<Blob<Dtype>* >& top,
    const vector<bool>& propagate_down, const vector<Blob<Dtype>* >& bottom)
{
    return;
}

#ifdef CPU_ONLY
STUB_GPU(SearchNV2Layer);
#endif

INSTANTIATE_CLASS(SearchNV2Layer);
REGISTER_LAYER_CLASS(SearchNV2);
}  // namespace caffe
