/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief retrain_search_n layer src file
 *
 * @file retrain_search_n_layer.cpp
 *
 * @version 1.0
 */
#include <vector>
#include <cmath>
#include <fstream>
#include <iostream>
#include <map>
#include <cfloat>

#include "caffe/layers/retrain_search_n_layer.hpp"

#include "caffe/util/math_functions.hpp"
#include "caffe/util/amct_util.hpp"

namespace caffe {
template <typename Dtype>
void RetrainSearchNLayer<Dtype>::LayerSetUp(const vector<Blob<Dtype>* >& bottom,
                                            const vector<Blob<Dtype>* >& top)
{
    this->targetBatchNum = this->layer_param_.search_n_param().batch_num();
    this->quantLayerNames = this->layer_param_.search_n_param().layer_name();
    CHECK_GE(this->quantLayerNames.size(), 1);

    this->showQuantLayerNames = "[";
    for (auto layerName : this->quantLayerNames) {
        this->showQuantLayerNames += layerName;
        this->showQuantLayerNames += " ";
    }
    this->showQuantLayerNames[this->showQuantLayerNames.size() - 1] = ']';

    this->quantLayerTypes = this->layer_param_.search_n_param().layer_type();
    CHECK_EQ(this->quantLayerNames.size(), this->quantLayerTypes.size()) << "layer_name size("
        << this->quantLayerNames.size() << ") must be equal to layer_type size("
        << this->quantLayerTypes.size() << ").";
}

template <typename Dtype>
void RetrainSearchNLayer<Dtype>::UpdateChannelNum(const vector<Blob<Dtype>* >& bottom,
                                                  const vector<Blob<Dtype>* >& top)
{
    if (setupFlag_) {
        return;
    }
    this->recordFileName = this->layer_param_.search_n_param().record_file_path();
    this->GetBottomChannels();
    this->channelNum = this->bottomChannels[0];

    for (int index = 0; index < this->quantLayerTypes.size(); ++index) {
        if ((this->quantLayerTypes.Get(index) == "Convolution" || \
                this->quantLayerTypes.Get(index) == "DepthwiseConvolution" || \
                this->quantLayerTypes.Get(index) == "Deconvolution") && this->channelNum > 1) {
            if (bottom[index]->shape(CONV_HEIGHT_AXIS) == 1 && bottom[index]->shape(CONV_WIDTH_AXIS) == 1) {
                this->globalConvFlag = true;
                LOG(INFO) << "Find layer \"" << this->quantLayerNames.Get(index) << "\" is global conv";
            }
        }
    }
    setupFlag_ = true;
}

template <typename Dtype>
void RetrainSearchNLayer<Dtype>::Forward_cpu(const vector<Blob<Dtype>* >& bottom,
                                             const vector<Blob<Dtype>* >& top)
{
    // Check when scale_d and offset_d in record file update, do once SearchN
    UpdateChannelNum(bottom, top);
    this->GetDeqScale();
    bool deqUpdated = false;
    if (deqScaleStored_.empty()) {
        deqScaleStored_ = this->deqScale;
        deqUpdated = true;
    } else {
        for (unsigned int i = 0; i < this->deqScale.size(); ++i)  {
            if (abs(this->deqScale[i] - deqScaleStored_[i]) > FLT_EPSILON) {
                deqScaleStored_[i] = this->deqScale[i];
                deqUpdated = true;
            }
        }
    }
    if (deqUpdated) {
        this->storedData.clear();
        this->storedData.shrink_to_fit();
        this->storedData.resize(this->channelNum);
        this->curBatchNum = 0;
    }
    // Stand SearchN
    if (this->curBatchNum < this->targetBatchNum) {
        this->AccumulateData(bottom);
        this->curBatchNum++;
        LOG(INFO) << "Doing layer: " << this->showQuantLayerNames << " search shift bits calibration, already store "
                  << this->curBatchNum << "/" << this->targetBatchNum << " data.";
    }
    if (this->curBatchNum == this->targetBatchNum) {
        std::vector<std::vector<int>> s32Data((this->globalConvFlag) ? 1 : this->channelNum);
        for (unsigned int i = 0; i < this->storedData.size(); i++) {
            for (unsigned int j = 0; j < this->storedData[i].size(); j++) {
                s32Data[(this->globalConvFlag) ? 0 : i].push_back(round(this->storedData[i][j] / this->deqScale[i]));
            }
        }
        vector<int> bestN;
        AmctCommon::SearchShiftBits(s32Data, bestN);
        this->RecordN(bestN);
        LOG(INFO) << "Do layer: " << this->showQuantLayerNames << " search shift bits calibration success!";

        this->storedData.clear();
        this->storedData.shrink_to_fit();
        this->curBatchNum++;
    }
}

template <typename Dtype>
void RetrainSearchNLayer<Dtype>::Backward_cpu(const vector<Blob<Dtype>* >& top,
    const vector<bool>& propagate_down, const vector<Blob<Dtype>* >& bottom)
{
    return;
}

#ifdef CPU_ONLY
STUB_GPU(RetrainSearchNLayer);
#endif

INSTANTIATE_CLASS(RetrainSearchNLayer);
REGISTER_LAYER_CLASS(RetrainSearchN);
}  // namespace caffe
