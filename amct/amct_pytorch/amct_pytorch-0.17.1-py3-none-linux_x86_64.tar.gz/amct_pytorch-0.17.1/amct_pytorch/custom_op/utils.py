#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

utils for custom ops

"""
import torch
from amct_pytorch.utils.vars import FLT_EPSILON
from amct_pytorch.utils.weight_quant_api import adjust_deconv_weight_shape


def check_quant_data(data, data_type):
    """
    Function: check quant data for ops
    Inputs:
        data: torch.Tensor, data to ops
        data_type: a string, type of data, including: "weight", "input"
    """
    if data.dtype not in [torch.float32, torch.float16]:
        raise TypeError(
            "Only {} with dtype 'torch.float32' and 'torch.float16' is supported to be " \
            "quantized, but got {}.".format(data_type, data.dtype))
    if not torch.all(torch.isfinite(data)):
        raise RuntimeError(
            "The {} to be quantized has invalid value inf or nan!"
            .format(data_type))


def check_scale_offset(scale, offset):
    """
    Function: check scale and offset for ops
    Inputs:
        scale: torch.Tensor
        offset: torch.Tensor
    """
    valid = True
    if not torch.all(torch.isfinite(scale)):
        valid = False
    if not torch.all(torch.isfinite(1 / scale)):
        valid = False
    if not valid:
        raise RuntimeError(
            "Param scale has invalid value inf, nan or zeros!")

    if not torch.all(torch.isfinite(offset)):
        raise RuntimeError(
            "Param offset has invalid value inf or nan!")


def check_deq_scale(deq_scale):
    """
    Function: check scale and offset for ops
    Inputs:
        deq_scale: torch.Tensor
    """
    valid = True
    if not torch.all(torch.isfinite(deq_scale)):
        valid = False
    if not torch.all(torch.isfinite(1 / deq_scale)):
        valid = False

    if not valid:
        raise RuntimeError(
            "The deq_scale to do search_n has invalid value inf, nan or zero!")


def check_tensor_balance_factor(tensor_balance_factor):
    """
    Function: check tensor_balance_factor for ops
    Inputs:
        tensor_balance_factor: torch.Tensor
    """
    valid = True
    if not torch.all(torch.isfinite(tensor_balance_factor)):
        valid = False
    if not torch.all(torch.isfinite(1 / tensor_balance_factor)):
        valid = False

    if not valid:
        raise RuntimeError(
            "The tensor_balance_factor of dmq_balancer op has invalid value inf, nan or zero!")


def copy_tensor(target, source):
    """
    Function: copy tensor data
    Inputs:
        target: torch.Tensor, taget tensor
        source: torch.Tensor, source tensor
    """
    if isinstance(target, torch.Tensor):
        target.data.copy_(source.data)


def tensor(value, dtype=torch.float, requires_grad=False, device=None):
    """
    Function: check scale and offset for ops
    Inputs:
        value: torch.Tensor
        dtype: tensor type
        requires_grad: tensor grad
        device: tensor device
    Outputs:
        output: torch.Tensor
    """
    if isinstance(value, torch.Tensor):
        if device is not None:
            return value.to(device).clone().detach().requires_grad_(requires_grad)
        return value.clone().detach().requires_grad_(requires_grad)
    else:
        if device is not None:
            return torch.tensor(value, dtype=dtype,
                                requires_grad=requires_grad, device=device)
        return torch.tensor(value, dtype=dtype,
                            requires_grad=requires_grad)


def process_scale(scale, offset, with_offset=True, numbit=8):
    """
    Function: check the validity of quant factor(scale)'s range
    Inputs:
        scale: torch.Tensor, quant factor
        offset: torch.Tensor, quant factor
        with_offset: bool, with offset or not
        numbit: int, quant bits
    Outputs:
        scale: torch.Tensor, quant factor
        offset: torch.Tensor, quant factor
    """
    base_bit = 2.0
    if with_offset:
        offset = torch.where(
            scale < FLT_EPSILON,
            tensor(-pow(base_bit, numbit - 1), device=offset.device), offset)
        scale = torch.where(
            scale < FLT_EPSILON,
            tensor(1.0, device=scale.device), scale)
    else:
        scale = torch.where(
            scale < FLT_EPSILON,
            tensor(1.0, device=scale.device), scale)
    return scale, offset


def process_tensor_shape(input_tensor, module_type, module):
    """
    Function: adjust tensor shape according to module_type
    Inputs:
    data: torch.Tensor, data to ops
    module_type: a string, type of the nn.module
    """
    # ConvTranspose2d wts is in cin,cout,h,w need to be adjust.
    if module_type == 'ConvTranspose2d':
        group = module.groups
        processed_tensor = adjust_deconv_weight_shape(group, input_tensor)
    else:
        processed_tensor = input_tensor
    return processed_tensor


def get_distribute_config():
    process_group = torch.distributed.group.WORLD
    try:
        world_size = torch.distributed.get_world_size(process_group)
    except (AttributeError, AssertionError, RuntimeError):
        process_group = None
        world_size = 1
    need_sync = world_size > 1
    config = dict()
    config['need_sync'] = need_sync
    config['process_group'] = process_group
    config['world_size'] = world_size
    return config
