#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

load libquant.so and libamct_pytorch_ops.so

"""
import os
import imp
import ctypes
import pkg_resources
import torch


__all__ = [
    'arq_cali',
    'arq_real',
    'nuq_cali',
    'ifmr_forward',
    'ifmr_backward',
    'hfmg_arq',
    'hfmg_merge',
    'hfmg_forward',
    'hfmg_backward',
    'searchn_forward',
    'searchn_backward',
    'searchn_v2_get_shiftn',
    'searchn_v2_forward',
    'searchn_v2_backward',
    'arq_retrain_forward',
    'arq_retrain_backward',
    'ulq_retrain_forward',
    'ulq_retrain_backward',
    'ulq_scale_retrain_forward',
    'ulq_scale_retrain_backward',
    'bcp',
    'BcpParam',
    'dump_forward',
    'selective_mask_gen',
    'PruneParam',
    'dmq_balancer_forward']

CUR_DIR = os.path.split(os.path.realpath(__file__))[0]


def __load_quant_lib():
    lib_name = './libquant_lib.so'
    lib_name = os.path.join(CUR_DIR, lib_name)
    ctypes.cdll.LoadLibrary(lib_name)


__load_quant_lib()

from .arq.amct_pytorch_op_arq import arq_cali
from .arq.amct_pytorch_op_arq import arq_real
from .ifmr.amct_pytorch_op_ifmr import ifmr_forward
from .ifmr.amct_pytorch_op_ifmr import ifmr_backward
from .hfmg.amct_pytorch_op_hfmg import hfmg_arq
from .hfmg.amct_pytorch_op_hfmg import hfmg_merge
from .hfmg.amct_pytorch_op_hfmg import hfmg_forward
from .hfmg.amct_pytorch_op_hfmg import hfmg_backward
from .nuq.amct_pytorch_op_nuq import nuq_cali
from .search_n.amct_pytorch_op_searchn import searchn_forward
from .search_n.amct_pytorch_op_searchn import searchn_backward
from .search_n_v2.amct_pytorch_op_searchn_v2 import searchn_v2_forward
from .search_n_v2.amct_pytorch_op_searchn_v2 import searchn_v2_get_shiftn
from .search_n_v2.amct_pytorch_op_searchn_v2 import searchn_v2_backward
from .arq_retrain.amct_pytorch_op_arq_qat import arq_retrain_forward
from .arq_retrain.amct_pytorch_op_arq_qat import arq_retrain_backward
from .ulq_retrain.amct_pytorch_op_ulq_qat import ulq_retrain_forward
from .ulq_retrain.amct_pytorch_op_ulq_qat import ulq_retrain_backward
from .ulq_scale_retrain.amct_pytorch_op_ulq_scale_qat import ulq_scale_retrain_forward
from .ulq_scale_retrain.amct_pytorch_op_ulq_scale_qat import ulq_scale_retrain_backward
from .bcp.amct_pytorch_op_bcp import bcp
from .bcp.amct_pytorch_op_bcp import BcpParam
from .dump.amct_pytorch_op_dump import dump_forward
from .selective_mask_gen.amct_pytorch_op_selective_mask_gen import selective_mask_gen
from .selective_mask_gen.amct_pytorch_op_selective_mask_gen import PruneParam
from .dmq_balancer.amct_pytorch_op_dmq_balancer import dmq_balancer_forward