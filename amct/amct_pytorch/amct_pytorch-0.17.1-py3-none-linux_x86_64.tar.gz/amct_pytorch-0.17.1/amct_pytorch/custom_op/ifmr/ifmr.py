#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

IFMR module and Function

"""

from collections import namedtuple
from torch import nn # pylint: disable=E0401
import torch # pylint: disable=E0401
from amct_pytorch.custom_op import ifmr_forward
from amct_pytorch.custom_op.utils import check_quant_data
from amct_pytorch.utils.log import LOGGER

QuantInfo = namedtuple('QuantInfo', ['flag', 'scale', 'offset', 'clip_max', 'clip_min'])


class IFMR(nn.Module): # pylint: disable=R0903
    """
    Function: Run calibration process for quantization of the given layer.
    APIs: forward
    """
    def __init__(self, # pylint: disable=R0913
                 layers_name,
                 num_bits=8,
                 batch_num=2,
                 with_offset=False,
                 max_percentile=0.999999,
                 min_percentile=0.999999,
                 search_start=0.7,
                 search_end=1.3,
                 search_step=0.01):
        super().__init__()
        self.param = {}
        self.param['num_bits'] = num_bits
        self.param['batch_num'] = batch_num
        self.param['with_offset'] = with_offset
        self.param['max_percentile'] = max_percentile
        self.param['min_percentile'] = min_percentile
        self.param['search_start'] = search_start
        self.param['search_end'] = search_end
        self.param['search_step'] = search_step

        self.layers_name = layers_name

        self.ifmr_data = None
        self.cur_batch = 0
        self.calibrated_flag = False

    def forward(self, inputs): # pylint: disable=W0221
        """
        Function: IFMR foward funtion.
        """
        self.cur_batch += 1
        if inputs.dtype is torch.float16:
            inputs = inputs.to(dtype=torch.float)
        LOGGER.logi(f"Accumulated {self.cur_batch} batch "
            f"to do layer {self.layers_name} data calibration.")
        self._accm_data(inputs)

        ifmr_param = self.param
        do_calibration = (self.cur_batch == ifmr_param.get('batch_num'))
        if not do_calibration:
            scale = torch.tensor(1.0) # pylint: disable=E1102
            offset = torch.tensor(0) # pylint: disable=E1102
            clip_max = torch.tensor(0)
            clip_min = torch.tensor(0)
            return QuantInfo._make([self.calibrated_flag, scale, offset, clip_max, clip_min])

        if inputs.is_cuda:
            device_id = inputs.device.index
        else:
            device_id = -1
        LOGGER.logi(f"Use {ifmr_param.get('batch_num')} batch "
            f"to do layer {self.layers_name} data calibration.")
        flag, scale, offset, clip_max, clip_min = ifmr_forward(self.ifmr_data,
                                           device_id,
                                           ifmr_param.get('num_bits'),
                                           ifmr_param.get('with_offset'),
                                           ifmr_param.get('max_percentile'),
                                           ifmr_param.get('min_percentile'),
                                           ifmr_param.get('search_start'),
                                           ifmr_param.get('search_end'),
                                           ifmr_param.get('search_step'))
        del self.ifmr_data
        self.ifmr_data = None
        if flag.item() != 0:
            LOGGER.loge("Do layer {} data calibration failed!"
                        .format(self.layers_name), 'IFMR')
            raise RuntimeError

        self.calibrated_flag = True
        LOGGER.logi("Do layer {} data calibration succeeded!"
                    .format(self.layers_name), 'IFMR')

        return QuantInfo._make([self.calibrated_flag, scale, offset, clip_max, clip_min])

    def _accm_data(self, inputs):
        """ Accumulate data for ifmr and search"""
        if self.cur_batch > self.param.get('batch_num'):
            return

        # check and accumelate data
        check_quant_data(inputs, 'activation')

        if self.ifmr_data is None:
            self.ifmr_data = inputs.cpu().reshape([-1])
        else:
            self.ifmr_data = torch.cat([self.ifmr_data, # pylint: disable=E1101
                                        inputs.cpu().reshape([-1])])
        LOGGER.logi(
            "Doing layer {} data calibration: data already stored {}/{}"
            .format(self.layers_name, self.cur_batch, self.param.get('batch_num')),
            'IFMR')
