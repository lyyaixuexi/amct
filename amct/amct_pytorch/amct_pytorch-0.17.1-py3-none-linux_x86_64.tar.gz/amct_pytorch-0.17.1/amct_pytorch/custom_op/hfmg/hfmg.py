#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

HFMG module and Function

"""

from collections import namedtuple
from torch import nn
import torch
from amct_pytorch.custom_op import hfmg_arq
from amct_pytorch.custom_op import hfmg_merge
from amct_pytorch.custom_op import hfmg_forward
from amct_pytorch.custom_op.utils import check_quant_data
from amct_pytorch.utils.log import LOGGER

QuantInfo = namedtuple('QuantInfo', ['flag', 'scale', 'offset', 'clip_max', 'clip_min'])


class HFMG(nn.Module):
    """
    Function: Run calibration process for quantization of the given layer.
    APIs: forward
    """
    def __init__(self,
                 layers_name,
                 num_bits=8,
                 batch_num=2,
                 with_offset=True,
                 nbins=4096):
        super().__init__()
        self.param = {}
        self.param['num_bits'] = num_bits
        self.param['batch_num'] = batch_num
        self.param['with_offset'] = with_offset
        self.param['nbins'] = nbins

        self.layers_name = layers_name

        self.register_buffer('histogram', torch.zeros(nbins))
        self.min_val = None
        self.max_val = None
        self.nbins = nbins
        self.hfmg_data = None
        self.histogram = None
        self.cur_batch = 0
        self.calibrated_flag = False

    @staticmethod
    def get_device_id(inputs):
        """ get the device id"""
        if inputs.is_cuda:
            device_id = inputs.device.index
        else:
            device_id = -1
        return device_id

    def forward(self, inputs):
        """
        Function: HFMG foward funtion.
        """
        self.cur_batch += 1
        if inputs.dtype is torch.float16:
            inputs = inputs.to(dtype=torch.float)
        self._merge_histogram(inputs)

        hfmg_param = self.param
        do_calibration = (self.cur_batch == hfmg_param.get('batch_num'))
        device_id = HFMG.get_device_id(inputs)
        clip_max = torch.tensor(0)
        clip_min = torch.tensor(0)
        if not do_calibration:
            input_min = torch.min(inputs)
            input_max = torch.max(inputs)
            scale, offset = hfmg_arq(input_min, input_max, device_id,
                self.param.get('num_bits'), self.param.get('with_offset'), self.param.get('nbins'))

            return QuantInfo._make([self.calibrated_flag, scale, offset, clip_max, clip_min])

        min_max = torch.cat([self.min_val.reshape(-1), self.max_val.reshape(-1)])
        flag, scale, offset = hfmg_forward(self.histogram,
                                           min_max,
                                           device_id,
                                           hfmg_param.get('num_bits'),
                                           hfmg_param.get('with_offset'),
                                           hfmg_param.get('nbins'))

        if flag.item() != 0:
            LOGGER.loge("Do layer {} data calibration failed!"
                        .format(self.layers_name), 'HFMG')
            raise RuntimeError

        self.calibrated_flag = True
        LOGGER.logi("Do layer {} data calibration succeeded!"
                    .format(self.layers_name), 'HFMG')

        return QuantInfo._make([self.calibrated_flag, scale, offset, clip_max, clip_min])

    def _merge_histogram(self, inputs):
        """ Accumulate data for hfmg and search"""
        if self.cur_batch > self.param.get('batch_num'):
            return
        # check and accumelate data
        check_quant_data(inputs, 'activation')

        min_val = self.min_val
        max_val = self.max_val
        if min_val is None or max_val is None:  # the first mini-batch
            self.min_val = torch.min(inputs)
            self.max_val = torch.max(inputs)
            histc_min = float(self.min_val.cpu().detach().numpy())
            histc_max = float(self.max_val.cpu().detach().numpy())
            self.histogram = torch.histc(
                inputs, self.nbins, min=histc_min, max=histc_max).contiguous()
        else:
            new_min = torch.min(inputs)
            new_max = torch.max(inputs)
            combined_min = torch.min(new_min, min_val)
            combined_max = torch.max(new_max, max_val)
            combined_min_max = torch.cat([combined_min.reshape(-1), combined_max.reshape(-1)])
            histc_min = float(combined_min.cpu().detach().numpy())
            histc_max = float(combined_max.cpu().detach().numpy())
            new_hist = torch.histc(
                inputs, self.nbins, min=histc_min, max=histc_max).contiguous()

            device_id = HFMG.get_device_id(inputs)
            min_max = torch.cat([self.min_val.reshape(-1), self.max_val.reshape(-1)])
            merged_hist = hfmg_merge(self.histogram, min_max, new_hist,
                combined_min_max, device_id, self.nbins)
            self.histogram = merged_hist[0]
            self.min_val = combined_min
            self.max_val = combined_max

        LOGGER.logi(
            "Doing layer {} data calibration: data already preprocess {}/{}"
            .format(self.layers_name, self.cur_batch, self.param.get('batch_num')),
            'HFMG')
