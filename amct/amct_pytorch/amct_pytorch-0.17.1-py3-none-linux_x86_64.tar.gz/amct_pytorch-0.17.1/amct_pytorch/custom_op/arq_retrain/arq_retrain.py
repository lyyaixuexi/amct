#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

ArqRetrain Function

"""
import torch
from torch.autograd import Function

from amct_pytorch.utils.log import LOGGER
from amct_pytorch.custom_op import arq_retrain_forward
from amct_pytorch.custom_op import arq_retrain_backward
from amct_pytorch.custom_op.utils import check_quant_data
from amct_pytorch.custom_op.utils import process_tensor_shape


class ArqRetrainFunction(Function):
    """
    Function: Run weight retrain process for quantization of the given layer.
    APIs: forward, backward
    """
    @staticmethod
    def forward(ctx, weight_tensor, scale, offset, wts_param, offset_deploy=None):
        """
        Function: ArqRetrain foward funtion.
        """
        # check weight tensor
        check_quant_data(weight_tensor, 'weight')
        weight_tensor_processed = process_tensor_shape(weight_tensor, wts_param.get('module_type'),
            wts_param.get('module'))

        results = arq_retrain_forward(
            weight_tensor_processed,
            wts_param.get('num_bits'),
            wts_param.get('channel_wise'),
            wts_param.get('with_offset'))
        is_quant, scale_out, offset_out, quantized_weight = results

        scale.data.copy_(scale_out.data)
        offset.data.copy_(offset_out.data)
        quantized_weight = process_tensor_shape(quantized_weight, wts_param.get('module_type'),
            wts_param.get('module'))
        quantized_weight = quantized_weight.to(weight_tensor.device)

        if not torch.equal(is_quant, torch.zeros(is_quant.shape)):
            raise RuntimeError("Weight quant with ARQ failed!")

        return quantized_weight, scale, offset

    @staticmethod
    def backward(ctx, grad_outputs, grad_scale, grad_offset):
        """
        Function: ArqRetrain backward funtion required by torch torch.autograd.
        """
        grad_input = arq_retrain_backward(grad_outputs)
        ret = (grad_input, None, None, None, None)
        return ret


class ArqRetrainFuncQAT(ArqRetrainFunction):
    @staticmethod
    def symbolic(g, *inputs):
        """
        Turn ARQ retrain op to onnx QDQ structure.
        Args:
            g (Graph): graph to write the ONNX representation into.
        """
        module_type = inputs[3].get('module_type')
        if module_type == "ConvTranspose2d":
            quant = g.op("QuantizeLinear", inputs[0], inputs[1], inputs[4])
            out_node = g.op("DequantizeLinear", quant, inputs[1], inputs[4])
        elif module_type == 'Conv2d':
            transpose = g.op("Transpose", inputs[0], perm_i=list([1, 0, 2, 3]))
            quant = g.op("QuantizeLinear", transpose, inputs[1], inputs[4])
            dequant = g.op("DequantizeLinear", quant, inputs[1], inputs[4])
            out_node = g.op("Transpose", dequant, perm_i=list([1, 0, 2, 3]))
        elif module_type == 'Conv3d':
            transpose = g.op("Transpose", inputs[0], perm_i=list([1, 0, 2, 3, 4]))
            quant = g.op("QuantizeLinear", transpose, inputs[1], inputs[4])
            dequant = g.op("DequantizeLinear", quant, inputs[1], inputs[4])
            out_node = g.op("Transpose", dequant, perm_i=list([1, 0, 2, 3, 4]))
        elif module_type == 'Linear':
            quant = g.op("QuantizeLinear", inputs[0], inputs[1], inputs[4])
            out_node = g.op("DequantizeLinear", quant, inputs[1], inputs[4])
        LOGGER.logi(
            f'Convert ARQ op to onnx QuantizeLinear and DequantizeLinear op successfully.')
        return out_node, None, None
