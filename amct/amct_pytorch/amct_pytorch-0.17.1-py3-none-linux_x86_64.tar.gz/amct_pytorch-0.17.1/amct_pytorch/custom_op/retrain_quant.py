#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

RetrainQuant module includes searchn and quantization factor recording module.

"""

import numpy as np
import torch
from torch import nn

from amct_pytorch.custom_op.comp_module.comp_module_base import CompModuleBase
from amct_pytorch.custom_op.search_n.search_n import SearchN
from amct_pytorch.custom_op.utils import copy_tensor
from amct_pytorch.custom_op.utils import tensor
from amct_pytorch.custom_op.utils import check_scale_offset
from amct_pytorch.custom_op.utils import process_scale


class RetrainQuant(nn.Module):
    """
    Search shift_n and record quantization factor.
    """
    def __init__(self, quant_module, record_module,
                 bn_module=None, bn_module_name=None, common_config=None):
        """
        Function: init function
        Inputs:
            quant_module: a torch.nn.Module inculdes conv/linear, ulq_retrain,
                arq_retrain.
            record_module: a torch.nn.Module recording quantification factor.
            bn_module: a torch.nn.Module record batchnorm.
            bn_module_name: a string of the batchnorm's name.
            common_config: a dict includes common information.
        Returns: None
        """
        super(RetrainQuant, self).__init__()
        self.common_config = common_config
        self.quant_module = quant_module
        self.searchn_module = SearchN(
            self.common_config.get('layers_name'),
            self.common_config.get('batch_num'),
            get_quant_type(quant_module))
        self.record_module = record_module
        self.bn_module = bn_module
        self.bn_module_name = bn_module_name
        self.cur_batch = 0
        self.type = 'RetrainQuant'
        # if channel-wise F, num_scales should keep same with bn features.
        if self.bn_module and self.quant_module.num_scales == 1:
            self.quant_module.num_scales *= self.bn_module.num_features
        self.register_buffer(
            'search_n',
            tensor([np.nan] * self.quant_module.num_scales))

        self.searchn_param = dict()
        self.searchn_param['do_search_n'] = self.common_config.get('do_search_n')
        self.searchn_param['scale_w'] = \
            tensor([1.0], device=self.common_config.get('device'))
        self.searchn_param['scale_d'] = \
            tensor(1.0, device=self.common_config.get('device'))

        self.scale_w_old = \
            tensor([0.0], device=self.common_config.get('device'))
        self.scale_d_old = \
            tensor(0.0, device=self.common_config.get('device'))
        self.scale_d = 1.0
        # register buffer space FIRST instead of reference in update_quant_factor.
        self.register_buffer(
            'scale_w',
            tensor([1.0] * self.quant_module.num_scales)
        )
        self.offset_d = 0.0
        # register buffer space FIRST instead of reference in update_quant_factor.
        self.register_buffer(
            'offset_w',
            tensor([0.0] * self.quant_module.num_scales)
        )
        self.searched_flag = False
        self.write_done_flag = False

    def update_quant_factor(self):
        """
        Function: update quant factor function.
        Inputs: None
        Returns: None
        """
        if self.quant_module.acts_comp_reuse:
            quant_module = self.quant_module.acts_comp_reuse
        else:
            quant_module = self.quant_module
        self.scale_d = quant_module.acts_scale
        self.offset_d = quant_module.acts_offset
        # assignment instead of reference
        # if, channel-wise False, has bn, quant_module.num_scales has expand.
        # else, channel-wise True.
        for idx in range(self.quant_module.num_scales):
            scale_id = 0
            if self.quant_module.wts_scales.numel() != 1:
                scale_id = idx
            wts_scale = self.quant_module.wts_scales.data[scale_id]
            self.scale_w.data[idx] = 1 / wts_scale if self.quant_module.s_rec_flag else wts_scale

            offset_id = 0
            if self.quant_module.wts_scales.numel() != 1:
                offset_id = idx
            self.offset_w.data[idx] = self.quant_module.wts_offsets.data[offset_id]

        if self.bn_module:
            bn_var_rsqrt = torch.rsqrt(self.bn_module.running_var + self.bn_module.eps)
            scale = self.bn_module.weight * bn_var_rsqrt
            # if channel-wise F & BN. scale_w and offset_w expand.
            self.scale_w = self.scale_w.to(scale.device).abs() * abs(scale).detach()

        self.scale_d, self.offset_d = process_scale(
            self.scale_d, self.offset_d, True,
            self.common_config.get('data_num_bits'))
        self.scale_w, self.offset_w = process_scale(
            self.scale_w, self.offset_w, False,
            self.common_config.get('wts_num_bits'))
        check_scale_offset(self.scale_d, self.offset_d)
        check_scale_offset(self.scale_w, self.offset_w)

        self.searchn_param['scale_d'] = self.scale_d
        self.searchn_param['scale_w'] = self.scale_w

    def update_trigger_status(self):
        """
        Function: update searchn's trigger status function.
        Inputs: None
        Returns: None
        """
        scale_w_error = \
            self.searchn_param.get('scale_w').cpu().sub(
                self.scale_w_old.cpu()).sum().abs()
        scale_d_error = \
            self.searchn_param.get('scale_d').cpu().sub(
                self.scale_d_old.cpu()).sum().abs()
        if scale_w_error > 0 or scale_d_error > 0:
            self.searchn_module.cur_batch = 0
            self.searched_flag = False
            self.write_done_flag = False
            self.scale_w_old = tensor(self.searchn_param.get('scale_w'))
            self.scale_d_old = tensor(self.searchn_param.get('scale_d'))

    def forward(self, inputs): # pylint: disable=W0221
        """
        Function: forward function
        Inputs:
            inputs: a torch.tensor, activations.
        Returns:
            outputs: a torch.tensor, quantized output data.
        """
        layers_name = self.common_config.get('layers_name')
        outputs = self.quant_module(inputs)
        if self.bn_module:
            outputs = self.bn_module(outputs)

        if not self.training and not self.quant_module.do_init:
            self.cur_batch += 1
            if self.cur_batch == 1:
                self.update_quant_factor()
                self.update_trigger_status()

            if self.searchn_param.get('do_search_n'):
                if not self.searched_flag:
                    self.searched_flag, shift_n = self.searchn_module.forward(
                        outputs, self.searchn_param.get('scale_w'),
                        self.searchn_param.get('scale_d'))
                    with torch.no_grad():
                        copy_tensor(self.search_n, shift_n)
                    shift_n = shift_n.cpu().tolist()
            else:
                self.searched_flag = True
                shift_n = np.zeros(self.searchn_param.get('scale_w').size(), dtype=np.int32).tolist()

            if self.searched_flag and not self.write_done_flag:
                self.record_module(
                    layers_name, 'ifmr',
                    {'scale_d': self.scale_d.cpu().tolist(),
                     'offset_d': int(self.offset_d.cpu().tolist()),
                     'num_bits': self.common_config.get('data_num_bits')})
                self.record_module(
                    layers_name, 'arq',
                    {'scale_w': self.scale_w.cpu().tolist(),
                     'offset_w': list(
                         map(int, self.offset_w.cpu().tolist())),
                     'num_bits': self.common_config.get('wts_num_bits')})
                self.record_module(layers_name, 'search_n',
                                   {'shift_n': shift_n})
                self.write_done_flag = True
        else:
            self.cur_batch = 0
            self.record_module.record_quant_layer(layers_name)

        return outputs

    def backward(self):
        ''' backward function '''
        raise NotImplementedError


def get_quant_type(module):
    """get quantized module's type from  module"""
    if isinstance(module, CompModuleBase):
        return type(module.replaced_module).__name__
    return type(module).__name__
