#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2023. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

DMQBalancer Function

"""

import torch
from torch.autograd import Function

from amct_pytorch.utils.log import LOGGER
from amct_pytorch.custom_op import dmq_balancer_forward
from amct_pytorch.custom_op.utils import check_quant_data
from amct_pytorch.custom_op.utils import check_tensor_balance_factor


class DMQBalancerFunction(Function):
    """
    Function: Run calibration process for quantization of the given layer.
    APIs: forward
    """
    @staticmethod
    def forward(ctx, inputs, weights, migration_strength, act_channel_num):
        """
        Function: dmq_balancer foward funtion.
        """
        # check data's type and range
        check_quant_data(inputs, 'activation')
        check_quant_data(weights, 'weight')
        if inputs.dtype is torch.float16:
            inputs = inputs.to(dtype=torch.float)
        if weights.dtype is torch.float16:
            weights = weights.to(dtype=torch.float)

        flag, tensor_balance_factor = dmq_balancer_forward(inputs, weights, migration_strength, act_channel_num)
        check_tensor_balance_factor(tensor_balance_factor.cpu())

        if flag.item() != 0:
            LOGGER.loge("Do DMQBalancer failed!")
            raise RuntimeError

        return tensor_balance_factor



