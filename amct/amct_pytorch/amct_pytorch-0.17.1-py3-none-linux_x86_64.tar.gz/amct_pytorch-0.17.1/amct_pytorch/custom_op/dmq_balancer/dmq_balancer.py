#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2023. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

dmq_balancer module and Function

"""
from torch import nn
import torch

from amct_pytorch.custom_op.dmq_balancer.dmq_balancer_func import DMQBalancerFunction
from amct_pytorch.utils.module_info import ModuleInfo
from amct_pytorch.utils.log import LOGGER


class DMQBalancer(nn.Module):
    """
    Function: Run calibration process for dmq_balancer of the given layer.
    APIs: forward
    """
    act_channel_dims = {
        'Conv2d': 1,
        'Conv3d': 1,
        'ConvTranspose2d': 1,
        'Linear': -1
    }

    def __init__(self, module, record_module, migration_strength, layers_name):
        super().__init__()
        self.replaced_module = module
        self.record_module = record_module
        self.migration_strength = migration_strength
        self.layers_name = layers_name
        self.dmq_algo_name = 'dmq_balancer'

    def forward(self, inputs):
        """
        Function: DMQBalancer foward.
        """
        weights = self.replaced_module.weight
        sub_out = self.replaced_module(inputs)

        _, wts_cin_axis = ModuleInfo.get_wts_cout_cin(self.replaced_module)

        # transpose activation and weight to c-first format
        if type(self.replaced_module).__name__ in ('Conv2d', 'Conv3d') and self.replaced_module.groups > 1:
            group = self.replaced_module.groups
            weight_shape = weights.shape
            new_shape = tuple([group, -1] + list(weight_shape)[1:])
            weights = weights.reshape(new_shape)
            weights = weights.transpose(2, 1)
            weight_shape = weights.shape
            new_shape = tuple([-1] + list(weight_shape)[2:])
            weights = weights.reshape(new_shape)
        else:
            weights = weights.transpose(0, wts_cin_axis)
        wts_channel_num = weights.shape[0]

        module_type = type(self.replaced_module).__name__
        act_channel_dim = self.act_channel_dims.get(module_type)
        act_channel_num = inputs.shape[act_channel_dim]
        inputs = inputs.transpose(0, act_channel_dim)

        input_data = inputs.reshape([-1])
        input_weight = weights.reshape([-1])

        if act_channel_num != wts_channel_num:
            raise ValueError(
                "the activation channel_num of {} must equal to weight channel_num".format(self.layers_name))

        tensor_balance_factor = DMQBalancerFunction.apply(
            input_data, input_weight, self.migration_strength, act_channel_num)

        # save tensor_balance_factor to record_module
        self.record_module(self.layers_name, self.dmq_algo_name,
                           {'tensor_balance_factor': tensor_balance_factor.cpu().tolist()})

        LOGGER.logi("Do layer {} dmq_balancer calibration succeeded!"
                    .format(self.layers_name), 'DMQBalancer')

        return sub_out




