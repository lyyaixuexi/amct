#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Optimizer is manager and executor of graph passes.

"""

import threading
from google.protobuf import text_format # pylint: disable=E0401
from torch import nn # pylint: disable=E0401

from amct_pytorch.proto import scale_offset_record_pb2 # pylint: disable=E0611
from amct_pytorch.common.utils.record_file_operator import \
    record_activation_scale_offset
from amct_pytorch.common.utils.record_file_operator import \
    record_weights_scale_offset
from amct_pytorch.common.utils.record_file_operator import \
    record_shift_bits
from amct_pytorch.common.utils.record_file_operator import \
    read_weights_scale_offset
from amct_pytorch.common.utils.record_file_operator import \
    read_activation_scale_offset
from amct_pytorch.common.utils.record_file_operator import \
    record_dmq_balancer_factor
from amct_pytorch.utils.log import LOGGER
from amct_pytorch.custom_op.utils import tensor
from amct_pytorch.utils.singleton_record import SingletonScaleOffsetRecord


class Recorder(nn.Module): # pylint: disable=R0902
    """
    Record quant factors to record file.
    """
    def __init__(self, record_file, enable_shift_n=True, enable_dmq_balancer=False):
        """
        Function: init function
        Inputs:
            record_file: a string, the file to record quant factors
            enable_shift_n: bool, whether the shift_n is recorded
        Returns: None
        """
        super().__init__()
        self.record_file = record_file
        self.enable_shift_n = enable_shift_n
        self.enable_dmq_balancer = enable_dmq_balancer
        self.register_buffer('quant_layer_num', tensor(0))
        self.quant_layer_names = []

        self.__read_over = False
        self.__write_over = False
        self.__counts = {
            'layers_num': 0,
            'act_cali_num': 0,
            'wts_cali_num': 0,
            'search_n_num': 0,
            'dmq_balancer_num': 0,
        }

        SingletonScaleOffsetRecord().reset_record()
        self.records = SingletonScaleOffsetRecord().record

    def record_quant_layer(self, layer_name):
        """
        Function: record the number of quantization layers.
        Inputs:
            layer_name: a string, layer name to be quantified
        Returns: None
        """
        if not set(layer_name) < set(self.quant_layer_names):
            self.quant_layer_names.extend(layer_name)
            count_num = len(list(set(self.quant_layer_names)))
            if self.quant_layer_num != count_num: # pylint: disable=E0203
                self.quant_layer_num.mul_(0).add_(1).mul_(count_num)
        self.__counts['act_cali_num'] = 0
        self.__counts['wts_cali_num'] = 0
        self.__counts['search_n_num'] = 0
        self.__counts['dmq_balancer_num'] = 0

    def forward(self, # pylint: disable=W0221
                layers_name,
                factors_type,
                quant_factors):
        """
        Function: forward function
        Inputs:
            layers_name: a string, the file to record quant factors
            factors_type: bool, whether the shift_n is recorded
            quant_factors: a dict, include
                scale_d: float number, data's scale
                offset_d: int number, data's offset
                shift_n: float number, data's shift bit
        Returns: None
        """
        if factors_type not in ['ifmr', 'arq', 'search_n', 'hfmg', 'search_n_v2', 'dmq_balancer']:
            raise ValueError("unsupport factors_type %s!" % (factors_type))

        # enable lock
        SingletonScaleOffsetRecord().lock.acquire()
        self._read_record_file()
        self._add_record_factors(layers_name, factors_type, quant_factors)
        self._write_record_file()
        # release lock
        SingletonScaleOffsetRecord().lock.release()

    def get_scales(self, layer_name):
        """
        Function: get scale_w, scale_d of layer_name from record
        Inputs:
            layer_name: string, name of layer
        Returns:
            scale_w: a list, scale_w of layer_name
            scale_d: a number, scale_d of layer_name
        """
        SingletonScaleOffsetRecord().lock.acquire()
        scale_w, _ = read_weights_scale_offset(self.records, layer_name)
        scale_d, _ = read_activation_scale_offset(self.records, layer_name)
        SingletonScaleOffsetRecord().lock.release()
        return scale_w, scale_d

    def backward(self):
        ''' backward function '''
        raise NotImplementedError

    def _read_record_file(self):
        """ read record from file"""
        if not self.__read_over:
            with open(self.record_file, 'r') as fid:
                pbtxt_string = fid.read()
                text_format.Merge(pbtxt_string, self.records)
            if self.quant_layer_num.cpu():
                self.__counts['layers_num'] = self.quant_layer_num.cpu()
            else:
                self.__counts['layers_num'] = len(self.records.record)
            self.__read_over = True

    def _write_record_file(self):
        """ write record to file"""
        if not self.enable_shift_n:
            if self.__counts.get('act_cali_num') == self.__counts.get('layers_num'):
                with open(self.record_file, "w") as fid:
                    fid.write(
                        text_format.MessageToString(self.records,
                                                    as_utf8=True))
                if not self.quant_layer_num.cpu():
                    self.__write_over = True
        elif self.enable_dmq_balancer:
            if self.__counts.get('dmq_balancer_num') == self.__counts.get('layers_num'):
                with open(self.record_file, "w") as fid:
                    fid.write(
                        text_format.MessageToString(self.records,
                                                    as_utf8=True))
                if not self.quant_layer_num.cpu():
                    self.__write_over = True
        else:
            if self.__counts.get('act_cali_num') == self.__counts.get('layers_num') and \
                self.__counts.get('search_n_num') == self.__counts.get('layers_num'):
                with open(self.record_file, "w") as fid:
                    fid.write(
                        text_format.MessageToString(self.records,
                                                    as_utf8=True))
                if not self.quant_layer_num.cpu():
                    self.__write_over = True

    def _add_record_factors(self, layers_name, factors_type, quant_factors):
        """ add quant factors to record"""
        if self.__write_over:
            raise RuntimeError("The records has been written to record_file!")

        if factors_type in ['ifmr', 'hfmg']:
            self._add_acts_factors(layers_name, quant_factors)

        if factors_type == 'arq':
            self._add_wts_factors(layers_name, quant_factors)

        if factors_type in ['search_n', 'search_n_v2']:
            self._add_shiftn_factors(layers_name, quant_factors)

        if factors_type in ['dmq_balancer']:
            self._add_dmq_balancer_factors(layers_name, quant_factors)

    def _add_acts_factors(self, layers_name, quant_factors):
        """ add acts quant factors to record"""
        if self.__counts.get('act_cali_num') >= self.__counts.get('layers_num'):
            raise RuntimeError(
                "number of data's factors(scale_d, offset_d) has been "
                "samed with number of quantization layers")
        scale_d = quant_factors.get('scale_d')
        offset_d = quant_factors.get('offset_d')
        num_bits = quant_factors.get('num_bits')
        if scale_d is None or offset_d is None:
            raise ValueError("scale_d and offset_d are necessary")
        for layer_name in layers_name:
            record_activation_scale_offset(self.records, layer_name,
                                           scale_d, offset_d, num_bits)
            self.__counts['act_cali_num'] += 1
        LOGGER.logd(
            "Record layer '{}' data's quant factors!".format(layers_name),
            'Recorder')

    def _add_wts_factors(self, layers_name, quant_factors):
        """ add wts quant factors to record"""
        if self.__counts.get('wts_cali_num') >= self.__counts.get('layers_num'):
            raise RuntimeError(
                "number of data's factors(scale_w, offset_w) has been "
                "samed with number of quantization layers")
        scale_w = quant_factors.get('scale_w')
        offset_w = quant_factors.get('offset_w')
        num_bits = quant_factors.get('num_bits')
        if scale_w is None or offset_w is None:
            raise ValueError("scale_w and offset_w are necessary")
        for layer_name in layers_name:
            record_weights_scale_offset(self.records, layer_name,
                                        scale_w, offset_w, num_bits)
            self.__counts['wts_cali_num'] += 1
        LOGGER.logd("Record layer '{}' weight's quant "
                    "factors!".format(layers_name), 'Recorder')

    def _add_shiftn_factors(self, layers_name, quant_factors):
        """ add shiftn quant factors to record"""
        if self.__counts.get('search_n_num') >= self.__counts.get('layers_num'):
            raise RuntimeError(
                "number of data's factors(shift_bit) has been "
                "samed with number of quantization layers")
        shift_n = quant_factors.get('shift_n')
        if shift_n is None:
            raise ValueError("shift_n is necessary")
        for layer_name in layers_name:
            record_shift_bits(self.records, layer_name, shift_n)
            self.__counts['search_n_num'] += 1
        LOGGER.logd(
            "Record layer '{}' shift_bit!".format(layers_name),
            'Recorder')

    def _add_dmq_balancer_factors(self, layers_name, quant_factors):
        """ add dmq_balancer factors to record"""
        tensor_balance_factor = quant_factors.get('tensor_balance_factor')
        if tensor_balance_factor is None:
            raise ValueError("tensor_balance_factor is necessary")
        for layer_name in layers_name:
            record_dmq_balancer_factor(self.records, layer_name, tensor_balance_factor)
            self.__counts['dmq_balancer_num'] += 1
        LOGGER.logd(
            "Record layer '{}' tensor_balance_factor!".format(layers_name),
            'Recorder')