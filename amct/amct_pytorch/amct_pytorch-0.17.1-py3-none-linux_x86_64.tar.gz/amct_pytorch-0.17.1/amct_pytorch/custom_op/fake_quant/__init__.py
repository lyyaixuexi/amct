#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

init file

"""
from amct_pytorch.custom_op.fake_quant.fake_dequant import FakeDeQuant
from amct_pytorch.custom_op.fake_quant.fake_quant import FakeQuant
from amct_pytorch.custom_op.fake_quant.fake_quantized_conv3d import FakeQuantizedConv3d
from amct_pytorch.custom_op.fake_quant.fake_quantized_convtranspose3d import FakeQuantizedConvTranspose3d

from . import fake_dequant
from . import fake_quant
from . import fake_quantized_conv2d
from . import fake_quantized_convtranspose2d
from . import fake_quantized_linear

from .fake_quantized_conv2d import FakeQuantizedConv2d
from .fake_quantized_convtranspose2d import FakeQuantizedConvTranspose2d
from .fake_quantized_linear import FakeQuantizedLinear
from .fake_quantized_avgpool2d import FakeQuantizedAvgPool2d

__all__ = [
    'FakeDeQuant',
    'FakeQuant',
    'FakeQuantizedConv2d',
    'FakeQuantizedConvTranspose2d',
    'FakeQuantizedLinear',
    'FakeQuantizedAvgPool2d',
    'FakeQuantizedConv3d',
    ]

FAKE_CONV2D = "FakeQuantizedConv2d"
FAKE_CONV_TRANSPOSE2D = "FakeQuantizedConvTranspose2d"
FAKE_LINEAR = "FakeQuantizedLinear"
FAKE_CONV3D = "FakeQuantizedConv3d"

FAKE_MODULES = [FAKE_CONV2D,
                FAKE_CONV_TRANSPOSE2D,
                FAKE_LINEAR,
                FAKE_CONV3D]
