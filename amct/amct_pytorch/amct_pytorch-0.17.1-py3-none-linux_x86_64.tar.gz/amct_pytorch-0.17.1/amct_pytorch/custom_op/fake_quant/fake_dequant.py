#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

fake dequant module and Function

"""
import numpy as np
from torch import nn # pylint: disable=E0401
import torch # pylint: disable=E0401

S16_BASE = 16
S32_BASE = 32


class FakeDeQuant(nn.Module): # pylint: disable=R0903, R0902
    """
    Function: Customized torch.nn.Module of the fake dequant operator.
    APIs: forward
    """
    def __init__(self, # pylint: disable=R0913
                 scale_d,
                 scale_w,
                 shift_n,
                 deq_shape,
                 num_bits=8,
                 layer_name=None):
        super().__init__()
        self.layer_name = layer_name
        self.deq_shape = deq_shape
        self.num_bits = num_bits
        self.deq_scale = torch.tensor(scale_w * scale_d, requires_grad=False)
        clip_mode = S32_BASE if np.sum(shift_n) == 0 else S16_BASE
        self.clamp_min = torch.tensor(
            -2**(clip_mode - 1), dtype=torch.float32, requires_grad=False)
        self.clamp_max = torch.tensor(
            2**(clip_mode - 1) - 1, dtype=torch.float32, requires_grad=False)
        self.shift_nums = torch.tensor(
            2**shift_n, dtype=torch.float32, requires_grad=False)

    def forward(self, inputs): # pylint: disable=W0221
        """
        Function: fake dequant forward function.
        Inputs:
            inputs: intput data in torch.tensor.
        """
        is_cuda = inputs.is_cuda
        deq_scale = self.deq_scale.reshape(self.deq_shape)
        shift_nums = self.shift_nums.reshape(self.deq_shape)
        deq_scale = deq_scale.cuda() if is_cuda else deq_scale
        shift_nums = shift_nums.cuda() if is_cuda else shift_nums
        self.clamp_min = self.clamp_min.cuda() if is_cuda else self.clamp_min
        self.clamp_max = self.clamp_max.cuda() if is_cuda else self.clamp_max
        shifted_data = torch.floor(torch.div(inputs, shift_nums))
        clamped_data = torch.clamp(
            shifted_data, self.clamp_min, self.clamp_max)
        temp_data = torch.mul(clamped_data, shift_nums)
        dequantized_data = torch.mul(temp_data, deq_scale)

        return dequantized_data
