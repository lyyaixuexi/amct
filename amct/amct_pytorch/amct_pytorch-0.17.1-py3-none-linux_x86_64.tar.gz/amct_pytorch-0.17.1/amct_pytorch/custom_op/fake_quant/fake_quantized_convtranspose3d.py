#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

fake quantized convtranspose3d module and Function

"""

from torch import nn # pylint: disable=E0401

from amct_pytorch.custom_op.fake_quant.fake_quant import FakeQuant
from amct_pytorch.custom_op.fake_quant.fake_dequant import FakeDeQuant


class FakeQuantizedConvTranspose3d(nn.Module):
    """
    Function: Customized torch.nn.Module of the fake quantized ConvTranspose3d operator.
    APIs: forward
    """
    def __init__(self, # pylint: disable=R0913
                 sub_module,
                 quant_params,
                 layer_name,
                 num_bits=8):
        super().__init__()
        self.sub_module = sub_module
        self.layer_name = layer_name
        self.quant_params = quant_params
        self.fake_dequant = FakeDeQuant(
            scale_d=quant_params['data_scale'],
            scale_w=quant_params['weight_scale'],
            shift_n=quant_params['shift_n'],
            deq_shape=(1, -1, 1, 1, 1),
            layer_name=layer_name)
        self.fake_quant = FakeQuant(
            scale_d=quant_params['data_scale'],
            offset_d=quant_params['data_offset'],
            num_bits=num_bits,
            layer_name=layer_name)


    def forward(self, inputs):
        """
        Function: fake quantized ConvTranspose3d forward function.
        Inputs:
            inputs: intput data in torch.tensor.
        """
        int8_out = self.fake_quant(inputs)
        int32_out = self.sub_module(int8_out)
        dequant_out = self.fake_dequant(int32_out).to(inputs.dtype)
        return dequant_out
