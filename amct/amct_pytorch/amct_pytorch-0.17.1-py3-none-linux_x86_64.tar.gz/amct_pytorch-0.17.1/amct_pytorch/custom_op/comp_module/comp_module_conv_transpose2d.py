#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2022 Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quantization module after ConvTranspose2d encapsulation

"""
import torch.nn.functional as F

from amct_pytorch.custom_op.comp_module.comp_module_base \
    import CompModuleBase


class CompModuleConvTranspose2d(CompModuleBase):
    """
    Function: Quantization module class after Quantization module after ConvTranspose2d encapsulation.
    APIs: __init__, forward
    """
    def __init__(self, *args, **kwargs):
        super(CompModuleConvTranspose2d, self).__init__(*args, **kwargs)
        if not self.wts_config.get('channel_wise'):
            self.num_scales = 1
        else:
            self.num_scales = self.replaced_module.weight.size(1) * self.replaced_module.groups
        self._init_output()

    def forward(self, inputs, output_size=None):
        """
        Defines the computation performed at every call.
        Should be overridden by all subclasses.
        """
        compressed_inputs, compressed_weights = \
            super(CompModuleConvTranspose2d, self).forward(inputs)

        # Forward
        output_padding = self.replaced_module._output_padding(inputs, output_size, \
            self.replaced_module.stride, self.replaced_module.padding, self.replaced_module.kernel_size)

        output = F.conv_transpose2d(compressed_inputs, compressed_weights, self.replaced_module.bias, \
            self.replaced_module.stride, self.replaced_module.padding, output_padding, \
            self.replaced_module.groups, self.replaced_module.dilation)

        return output
