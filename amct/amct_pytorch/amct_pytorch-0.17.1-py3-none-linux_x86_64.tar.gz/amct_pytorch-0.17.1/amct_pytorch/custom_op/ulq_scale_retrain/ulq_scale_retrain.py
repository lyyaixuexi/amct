#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

UlqRetrain Function

"""
from torch.autograd import Function

from amct_pytorch.utils.log import LOGGER
from amct_pytorch.custom_op import ulq_scale_retrain_forward
from amct_pytorch.custom_op import ulq_scale_retrain_backward
from amct_pytorch.custom_op.utils import check_quant_data
from amct_pytorch.custom_op.utils import process_tensor_shape


class UlqScaleRetrainFunction(Function):
    """
    Function: Run calibration process for quantization of the given layer.
    APIs: forward
    """
    @staticmethod
    def forward(ctx, inputs, scale, offset, wts_qat_param, cur_batch, offset_deploy=None):
        """
        Function: UlqRetrain foward funtion.
        """
        # check input data
        check_quant_data(inputs, 'weights')
        inputs_processed = process_tensor_shape(inputs, wts_qat_param.get('module_type'),
            wts_qat_param.get('module'))

        ctx.inputs = inputs_processed
        ctx.module_type = wts_qat_param.get('module_type')
        results = ulq_scale_retrain_forward(
            inputs_processed,
            scale,
            offset,
            wts_qat_param.get('num_bits'),
            wts_qat_param.get('channel_wise'),
            wts_qat_param.get('arq_init') and cur_batch == 0,
            wts_qat_param.get('s_rec_flag'))
        outputs, scale_out, offset_out = results
        scale.data.copy_(scale_out.data)
        offset.data.copy_(offset_out.data)

        ctx.scale = scale
        ctx.num_bits = wts_qat_param.get('num_bits')
        ctx.s_rec_flag = wts_qat_param.get('s_rec_flag')

        outputs = process_tensor_shape(outputs, wts_qat_param.get('module_type'),
            wts_qat_param.get('module'))

        return outputs, scale, offset

    @staticmethod
    def backward(ctx, grad_outputs, grad_scale, grad_offset):
        """
        Function: UlqRetrain backward funtion required by torch
                  torch.autograd.
        """
        res = ulq_scale_retrain_backward(
            ctx.inputs,
            grad_outputs,
            ctx.scale,
            ctx.num_bits,
            ctx.s_rec_flag)
        grad_input, grad_scale = res

        if ctx.module_type == 'ConvTranspose2d':
            grad_input = grad_input.transpose(1, 0)
        ret = (grad_input, grad_scale, None, None, None, None)
        return ret


class UlqScaleRetrainFuncQAT(UlqScaleRetrainFunction):
    @staticmethod
    def symbolic(g, *inputs):
        """
        Turn ULQ scale retrain op to onnx QDQ structure.
        Args:
            g (Graph): graph to write the ONNX representation into.
        """
        module_type = inputs[3].get('module_type')
        if module_type == "ConvTranspose2d":
            quant = g.op("QuantizeLinear", inputs[0], inputs[1], inputs[5])
            out_node = g.op("DequantizeLinear", quant, inputs[1], inputs[5])
        elif module_type == 'Conv2d':
            transpose = g.op("Transpose", inputs[0], perm_i=list([1, 0, 2, 3]))
            quant = g.op("QuantizeLinear", transpose, inputs[1], inputs[5])
            dequant = g.op("DequantizeLinear", quant, inputs[1], inputs[5])
            out_node = g.op("Transpose", dequant, perm_i=list([1, 0, 2, 3]))
        elif module_type == 'Conv3d':
            transpose = g.op("Transpose", inputs[0], perm_i=list([1, 0, 2, 3, 4]))
            quant = g.op("QuantizeLinear", transpose, inputs[1], inputs[5])
            dequant = g.op("DequantizeLinear", quant, inputs[1], inputs[5])
            out_node = g.op("Transpose", dequant, perm_i=list([1, 0, 2, 3, 4]))
        elif module_type == 'Linear':
            quant = g.op("QuantizeLinear", inputs[0], inputs[1], inputs[5])
            out_node = g.op("DequantizeLinear", quant, inputs[1], inputs[5])
        LOGGER.logi(f'Convert ULQ scale op to onnx QuantizeLinear and DequantizeLinear op successfully.')
        return out_node, None, None
