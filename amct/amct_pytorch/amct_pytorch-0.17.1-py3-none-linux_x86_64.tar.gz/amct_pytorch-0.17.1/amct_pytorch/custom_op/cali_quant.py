#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

IFMR and HFMG module and Function

"""

from torch import nn
import torch

from amct_pytorch.custom_op.ifmr.ifmr import IFMR
from amct_pytorch.custom_op.hfmg.hfmg import HFMG
from amct_pytorch.custom_op.search_n.search_n import SearchN
from amct_pytorch.custom_op.search_n_v2.search_n_v2 import SearchNV2
from amct_pytorch.custom_op.dump.dump import DUMP


class CaliQuantBase(nn.Module):
    """
    Function: Customized torch.nn.Module of the calibration operator base class.
    APIs: forward.
    """
    def __init__(self,
                sub_module,
                record_module,
                layers_name,
                num_bits=8,
                batch_num=2,
                with_offset=False,
                do_search_n=False,
                dump_config=None,
                mode='cali_dump',
                do_dmq_balancer=False,
                tensor_balance_factor=None):
        """
        Function: init base function.
        Init some common param both in IFMR and HFMG.

        Args:
        sub_module: torch module. Quantized_type.
        record_module: customed record module. To read and write.
        layers_name: sub_module's name.
        num_bits: controls the cali quant's num bits.
        batch_num: IFMR and HFMG, SearchN and SearchNV2's accumulate data.
        mode: controls the data quant.
        1) cali: ONLY do data calibration.
        2) dump: ONLY do dump the input data.
        3) cali_dump: First dump the input data, secondly do data calibration.
        """
        super().__init__()
        self.sub_module = sub_module
        self.record_module = record_module
        self.layers_name = layers_name
        self.num_bits = num_bits
        self.batch_num = batch_num
        self.with_offset = with_offset
        self.do_search_n = do_search_n
        self.dump_config = dump_config
        self.mode = mode
        self.do_dmq_balancer = do_dmq_balancer
        self.tensor_balance_factor = tensor_balance_factor

        self.cur_batch = 0

        self._init_dump_mode()
        self._init_cali_param()
        self._init_search_param()

        self.scale_d = None

    def forward(self, inputs):
        """
        Function: IFMR / HFMG foward funtion.

        Args:
        inputs: data used for calibration in torch.tensor.
        """
        # step 0. cali / dump / cali_dump
        if 'dump' in self.mode and self.dump_config is not None:
            # directly pass the inputs.
            inputs = self.dump_module.forward(inputs)

        if self.do_dmq_balancer:
            device = inputs.device
            inputs = inputs.detach().cpu() if inputs.requires_grad else inputs.cpu()
            inputs = inputs / self.tensor_balance_factor
            inputs = inputs.to(device)

        sub_out = self.sub_module(inputs)

        if 'cali' not in self.mode:
            return sub_out

        # step 1. ifmr & searchn / hfmg & searchnv2
        self.cur_batch += 1
        if self.cur_batch <= self.cali_algo_param.get('batch_num'):
            self.cali_process(inputs)
            self.do_search_n_process(sub_out)

        return sub_out

    def cali_process(self, inputs):
        """
        Function: data cali process.

        Args:
        inputs: the data before input into the sub_module.
        """
        # do ifmr / hfmg
        quant_info = self.cali_quant_module.forward(inputs)
        calibration_flag = quant_info.flag
        scale_d = quant_info.scale
        offset_d = quant_info.offset

        self.scale_d = scale_d

        if calibration_flag:
            # save scale_d and offset_d to record_module
            self.record_module(self.layers_name, self.cali_algo_name,
                                {'scale_d': scale_d.cpu().tolist(),
                                'offset_d': int(offset_d.cpu().tolist())})
            # update searchn_param with valid scale_d and scael_w
            self._update_search_param()

    def do_search_n_process(self, sub_out):
        """
        Function: searchN / searchNV2 process.

        Args:
        sub_out: searchN / searchNV2 need the FP32 data.
        """
        # do search_n
        if self.search_param.get('do_search_n'):
            calibration_flag, shift_n = self.search_module.forward(
                sub_out, self.search_param.get('scale_w').to(sub_out.device),
                self.scale_d.to(sub_out.device))
            if calibration_flag:
                self.record_module(self.layers_name, 'search_n',
                                    {'shift_n': shift_n.cpu().tolist()})
        elif self.cur_batch == self.search_param.get('batch_num'):
            self.record_module(self.layers_name, 'search_n', {'shift_n': []})

    def _init_dump_mode(self):
        """
        Function: check mode and init dump_config.
        """
        if self.dump_config is not None:
            if self.dump_config.batch_num is None:
                self.dump_config.batch_num = self.batch_num
            self.dump_module = DUMP(self.layers_name, self.dump_config)
        if self.mode not in ['cali', 'dump', 'cali_dump']:
            raise ValueError("param mode only support ['cali', 'dump', 'cali_dump'], but get {}"
            .format(self.mode))

    def _init_cali_param(self):
        """
        Function: init cali params. IFMR and HFMG's common param.
        """
        self.cali_algo_param = {}
        self.cali_algo_param['layers_name'] = self.layers_name
        self.cali_algo_param['num_bits'] = self.num_bits
        self.cali_algo_param['batch_num'] = self.batch_num
        self.cali_algo_param['with_offset'] = self.with_offset

    def _init_search_param(self):
        """
        Function: base init searchn / searchnv2 params.
        """
        self.search_param = {}
        self.search_param['do_search_n'] = self.do_search_n
        self.search_param['batch_num'] = self.batch_num
        self.search_param['layers_name'] = self.layers_name
        self.search_param['scale_w'] = torch.tensor([1.0])
        self.search_param['scale_d'] = torch.tensor(1.0)

    def _update_search_param(self):
        """update searchn_param with valid scale_d and scael_w """
        # get scale_d and scale_w from record_module
        scale_w, scale_d = \
            self.record_module.get_scales(self.layers_name[0])
        # update searchn param
        scale_w = torch.tensor(scale_w)
        scale_d = torch.tensor(scale_d)
        self.search_param['scale_w'] = scale_w
        self.search_param['scale_d'] = scale_d


class CaliQuant(CaliQuantBase):
    """
    Function: Customized torch.nn.Module of the calibration operator. IFMR.
    APIs: forward
    """
    def __init__(self,
                 sub_module,
                 record_module,
                 layers_name,
                 num_bits=8,
                 batch_num=2,
                 with_offset=False,
                 max_percentile=0.999999,
                 min_percentile=0.999999,
                 search_start=0.7,
                 search_end=1.3,
                 search_step=0.01,
                 do_search_n=False,
                 dump_config=None,
                 mode='cali_dump',
                 do_dmq_balancer=False,
                 tensor_balance_factor=None):
        """
        Function: IFMR init function.

        Args:
        max_percentile: IFMR param.
        min_percentile: IFMR param.
        search_start: IFMR param.
        search_end: IFMR param.
        search_step: IFMR param.
        """
        super().__init__(
            sub_module=sub_module,
            record_module=record_module,
            layers_name=layers_name,
            num_bits=num_bits,
            batch_num=batch_num,
            with_offset=with_offset,
            do_search_n=do_search_n,
            dump_config=dump_config,
            mode=mode,
            do_dmq_balancer=do_dmq_balancer,
            tensor_balance_factor=tensor_balance_factor
        )
        # IFMR params init
        self.cali_algo_param['max_percentile'] = max_percentile
        self.cali_algo_param['min_percentile'] = min_percentile
        self.cali_algo_param['search_start'] = search_start
        self.cali_algo_param['search_end'] = search_end
        self.cali_algo_param['search_step'] = search_step
        # IFMR module init.
        self.cali_quant_module = IFMR(**self.cali_algo_param)
        # SearchN module init.
        self.search_module = SearchN(
            layers_name=self.layers_name,
            batch_num=self.batch_num,
            module_type=type(sub_module).__name__)
        # algo name and search name
        self.cali_algo_name = 'ifmr'
        self.search_algo_name = 'searchn'


class CaliQuantHfmg(CaliQuantBase):
    """
    Function: Customized torch.nn.Module of the calibration operator. HFMG.
    APIs: forward.
    """
    def __init__(self,
                 sub_module,
                 record_module,
                 layers_name,
                 num_bits=8,
                 batch_num=2,
                 with_offset=False,
                 nbins=4096,
                 do_search_n=False,
                 dump_config=None,
                 mode='cali_dump',
                 do_dmq_balancer=False,
                 tensor_balance_factor=None):
        """
        Function: HFMG init function.

        Args:
        nbins: HFMG param.
        """
        super().__init__(
            sub_module=sub_module,
            record_module=record_module,
            layers_name=layers_name,
            num_bits=num_bits,
            batch_num=batch_num,
            with_offset=with_offset,
            do_search_n=do_search_n,
            dump_config=dump_config,
            mode=mode,
            do_dmq_balancer=do_dmq_balancer,
            tensor_balance_factor=tensor_balance_factor
        )
        # HFMG param init.
        self.cali_algo_param['nbins'] = nbins
        # HFMG module init.
        self.cali_quant_module = HFMG(**self.cali_algo_param)
        # SearchNV2 module init.
        self.search_module = SearchNV2(
            layers_name=self.layers_name,
            batch_num=self.batch_num,
            module_type=type(sub_module).__name__)
        # algo name and search name
        self.cali_algo_name = 'hfmg'
        self.search_algo_name = 'searchnv2'
