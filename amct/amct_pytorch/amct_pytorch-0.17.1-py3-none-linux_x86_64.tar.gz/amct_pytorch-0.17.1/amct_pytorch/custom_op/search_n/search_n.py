#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

SearchN module and Function

"""
import functools
from torch import nn # pylint: disable=E0401
import torch # pylint: disable=E0401

from amct_pytorch.custom_op import searchn_forward
from amct_pytorch.custom_op.utils import check_quant_data
from amct_pytorch.custom_op.utils import check_deq_scale
from amct_pytorch.utils.log import LOGGER
from amct_pytorch.utils.vars import CHANNEL_WISE_TYPES


class SearchN(nn.Module):  # pylint: disable=R0903
    """
    Function: Run calibration process for quantization of the given layer.
    APIs: forward
    """
    channel_dims = {
        'Conv2d': 1,
        'Conv3d': 1,
        'ConvTranspose2d': 1,
        'ConvTranspose3d': 1,
        'Linear': -1,
        'AvgPool2d': 1,
    }

    def __init__(self, layers_name, batch_num, module_type):
        super().__init__()
        self.param = {}
        self.param['batch_num'] = batch_num
        self.param['layers_name'] = layers_name
        self.param['module_type'] = module_type
        self.param['channel_dim'] = self.channel_dims.get(module_type)

        self.searchn_data = None
        self.layers_name = layers_name
        self.cur_batch = 0
        self.single_perchl = False
        self.searched_flag = False

    def forward(self, inputs, scale_w, scale_d): # pylint: disable=W0221
        """
        Function: SearchN foward.
        """
        self.cur_batch += 1
        if inputs.dtype is torch.float16:
            inputs = inputs.to(torch.float)
        self._accm_data(inputs)
        deq_scale = scale_w * scale_d
        check_deq_scale(deq_scale)

        do_cali = (self.cur_batch == self.param.get('batch_num'))
        if not do_cali:
            return torch.tensor(0), torch.tensor(0) # pylint: disable=E1102

        # find the shift_bit with op
        if list(deq_scale.size()) == [1] or self.single_perchl:
            channel_wise = False
        else:
            channel_wise = True

        device_idx = inputs.device.index
        if device_idx is None:
            device_idx = -1
        flag, shift_n = searchn_forward(
            self.searchn_data, deq_scale, channel_wise, device_idx)
        # release cpu memory
        del self.searchn_data
        self.searchn_data = None

        if flag.item() != 0:
            raise RuntimeError(
                "Do searchn_forward fail with amct_pytorch_ops!")
        self.searched_flag = True
        LOGGER.logi(
            "Do layer {} search_n succeeded!".format(self.layers_name),
            'SearchN')


        shift_n = self._postprocess_shift_n(shift_n, scale_w)
        return self.searched_flag, shift_n

    def _accm_data(self, inputs):
        """ Accumulate data for ifmr and search"""
        if self.cur_batch > self.param.get('batch_num'):
            return

        # check data's type and range
        check_quant_data(inputs, 'activation')

        # check 1 point in per channle
        if self.cur_batch == 1 and \
            self.param.get('module_type') in CHANNEL_WISE_TYPES:
            # CHANNEL_WISE_TYPES shape is N,C,**
            data_num_perchl = functools.reduce(
                lambda x, y: x*y, list(inputs.shape)[2:])
            if data_num_perchl == 1:
                self.single_perchl = True

        # accumelate data
        channel_dim = self.param.get('channel_dim')
        channel_num = inputs.shape[channel_dim]
        accu_data = inputs.cpu().transpose(0, channel_dim)
        accu_data = accu_data.reshape([channel_num, -1])
        accu_data = accu_data.transpose(0, 1)
        if self.searchn_data is None:
            self.searchn_data = accu_data
        else:
            try:
                self.searchn_data = torch.cat( # pylint: disable=E1101
                    [self.searchn_data, accu_data], 0)
            except RuntimeError as e:
                raise RuntimeError("inputs's channel's dim should be same "
                                   "with previous batch.") from e

        LOGGER.logi(
            "Doing layer {} search_n: data already stored {}/{}"
            .format(self.layers_name, self.cur_batch, self.param.get('batch_num')),
            'SearchN')

    def _postprocess_shift_n(self, shift_n, scale_w):
        if self.single_perchl:
            channel_num = scale_w.shape[0]
            shift_n = shift_n.repeat(channel_num)
        return shift_n
