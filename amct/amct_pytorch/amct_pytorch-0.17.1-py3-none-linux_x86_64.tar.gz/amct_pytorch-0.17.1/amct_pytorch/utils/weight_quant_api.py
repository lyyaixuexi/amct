#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Ctypes APIs for arq_quant algorithm

"""
import torch
import numpy as np
from amct_pytorch.utils.onnx_node_util import AttributeProtoHelper


def get_deconv_group(node_deconv):
    """Get ConvTranspose's group param value"""
    attrs_helper = AttributeProtoHelper(node_deconv.proto)
    if not attrs_helper.has_attr('group'):
        raise RuntimeError("can not get the 'group' attr of {}".format(node_deconv.name))
    group = attrs_helper.get_attr_value('group')
    return group


def adjust_deconv_weight_shape(group, weights_array):
    """Adjust ConvTranspose weight shape to fit group param """
    weight_shape = weights_array.shape
    trans_common = [1, 0, 2, 3, 4]
    trans_shape = tuple(trans_common[:len(weight_shape)])
    if isinstance(weights_array, torch.Tensor):
        device = weights_array.device
        weights_array = weights_array.cpu().detach()
    if group == 1:
        weights_array = np.transpose(weights_array, trans_shape)
        if isinstance(weights_array, torch.Tensor):
            weights_array = weights_array.to(device)
        return weights_array

    new_shape = tuple([group, -1] + list(weight_shape)[1:])
    weights_array = np.reshape(weights_array, new_shape)

    weights_array = np.transpose(weights_array, (0, 2, 1, 3, 4))

    weight_shape = weights_array.shape
    new_shape = tuple([-1] + list(weight_shape)[2:])
    weights_array = np.reshape(weights_array, new_shape)

    if isinstance(weights_array, torch.Tensor):
        weights_array = weights_array.to(device)

    return weights_array


def adjust_conv_weight_shape(group, weight):
    """Adjust Conv weight shape to fit group param """
    weight_shape = weight.shape
    new_shape = tuple([group, -1] + list(weight_shape)[1:])
    weight = weight.reshape(new_shape)
    if len(weight.shape) == 5:
        weight = np.transpose(weight, (0, 2, 1, 3, 4))
    else:
        weight = np.transpose(weight, (0, 2, 1, 3, 4, 5))
    weight_shape = weight.shape
    new_shape = tuple([-1] + list(weight_shape)[2:])
    weight = weight.reshape(new_shape)
    return weight

