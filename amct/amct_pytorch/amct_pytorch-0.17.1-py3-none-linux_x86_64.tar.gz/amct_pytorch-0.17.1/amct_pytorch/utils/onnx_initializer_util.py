#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

utils for onnx.graph.initializer

"""
import numpy as np
from google.protobuf.internal import api_implementation
from onnx.onnx_pb import TensorProto # pylint: disable=E0401


class TensorProtoHelper():
    """ Help cope with onnx.TensorProto
    APIs: map_data_location, map_np_type, get_data, clear_data, set_data
    """
    data_type = TensorProto.DataType # pylint: disable=E1101
    data_type_maps = {
        # DataType: proto_value, data_location, np.type
        'UNDEFINED': [data_type.UNDEFINED, 'raw_data', None],
        'FLOAT': [data_type.FLOAT, 'float_data', 'float32'],
        'UINT8': [data_type.UINT8, 'int32_data', 'uint8'],
        'INT8': [data_type.INT8, 'raw_data', 'int8'],
        'UINT16': [data_type.UINT16, 'int32_data', 'uint16'],
        'INT16': [data_type.INT16, 'int32_data', 'int16'],
        'INT32': [data_type.INT32, 'int32_data', 'int32'],
        'INT64': [data_type.INT64, 'int64_data', 'int64'],
        'STRING': [data_type.STRING, 'string_data', 'str'],
        'BOOL': [data_type.BOOL, 'int32_data', 'bool_'],
        'FLOAT16': [data_type.FLOAT16, 'int32_data', 'float16'],
        'DOUBLE': [data_type.DOUBLE, 'double_data', 'float64'],
        'UINT32': [data_type.UINT32, 'uint64_data', 'uint32'],
        'UINT64': [data_type.UINT64, 'uint64_data', 'uint64'],
        'COMPLEX64': [data_type.COMPLEX64, 'float_data', 'complex64'],
        'COMPLEX128': [data_type.COMPLEX128, 'double_data', 'complex128'],
        'BFLOAT16': [data_type.BFLOAT16, 'raw_data', 'float32'],
    }
    proto_value_id = 0
    data_location_id = 1
    np_type_id = 2

    def __init__(self, tensor):
        ''' init function '''
        super().__init__()
        self.tensor = tensor

    @classmethod
    def map_data_location(cls, proto_value):
        ''' find data_location according to TensorProto.data_type'''
        for key in cls.data_type_maps:
            value = cls.data_type_maps[key]
            if proto_value == value[cls.proto_value_id]:
                return value[cls.data_location_id]

        raise ValueError('The data_type{%s} is UNEXCEPTED' % (proto_value))

    @classmethod
    def map_np_type(cls, proto_value):
        ''' find np's dtype according to TensorProto.data_type'''
        for key in cls.data_type_maps:
            value = cls.data_type_maps[key]
            if proto_value == value[cls.proto_value_id]:
                return value[cls.np_type_id]

        raise ValueError('The data_type{%s} is UNEXCEPTED' % (proto_value))

    def get_data(self):
        '''
        Function: get data from tensor. Return a numpy.array If
            tensor.data_type is not UNDEFINED, otherwise return a binary
        Parameters:
            tensor: a instance of TensorProto
        Return: value: byte_value or np_value
        '''
        tensor_data_type = self.tensor.data_type
        byte_value = self.tensor.raw_data

        if tensor_data_type == \
            self.data_type_maps['UNDEFINED'][self.proto_value_id]:
            return byte_value

        np_type = self.map_np_type(tensor_data_type)
        if byte_value:
            np_value = np.frombuffer(byte_value, getattr(np, np_type))
            # to modify np_value.flags['WRITEABLE'] as True
            np_value = np.array(np_value)
        else:
            value = getattr(self.tensor,
                            self.map_data_location(tensor_data_type))
            np_value = np.array(value, getattr(np, np_type))
        np_value = np_value.reshape(self.tensor.dims)
        return np_value

    def clear_data(self):
        '''
        Function: clear data of tensor, the raw_data is cleared if it exists.
        Parameters:
            tensor: a instance of TensorProto
        Return: None
        '''
        byte_value = self.tensor.raw_data
        if byte_value:
            self.tensor.ClearField('raw_data')
        else:
            self.tensor.ClearField(
                self.map_data_location(self.tensor.data_type))

    def set_data(self, data, type_string=None, dims=None):
        '''
        Function: set data from tensor. The raw data is unexcepted
        Parameters:
            tensor: a instance of TensorProto
            data: a list containing the data
            type_string: a string to indicating the data_type, is must be in
                data_type_maps's keys
            dims: the dim of data
        Return: None
        '''
        if type_string is not None:
            data_type = self.data_type_maps[type_string][self.proto_value_id]
            self.tensor.data_type = data_type
        if dims is not None:
            self.tensor.ClearField('dims')
            self.tensor.dims.extend(dims)

        data_location = self.map_data_location(self.tensor.data_type)
        if data_location == 'raw_data':
            setattr(self.tensor, data_location, bytes(data.flatten()))
        else:
            self.tensor.ClearField(data_location)
            if api_implementation.Type() == 'python':
                getattr(self.tensor, data_location).extend(data)
            else:
                getattr(self.tensor, data_location).MergeFrom(data)
