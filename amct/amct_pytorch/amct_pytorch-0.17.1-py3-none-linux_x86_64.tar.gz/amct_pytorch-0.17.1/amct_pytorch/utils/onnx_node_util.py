#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

utils for onnx.AttributeProto

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from onnx.onnx_pb import AttributeProto


class AttributeProtoHelper():
    """docstring for AttributeProtoHelper"""
    attribute_type = AttributeProto.AttributeType # pylint: disable=E1101
    attribute_type_map = {
        # type_string ,type_proto_value, location
        'UNDEFINED': [attribute_type.UNDEFINED, None],
        'FLOAT': [attribute_type.FLOAT, 'f'],
        'INT': [attribute_type.INT, 'i'],
        'STRING': [attribute_type.STRING, 's'],
        'TENSOR': [attribute_type.TENSOR, 't'],
        'GRAPH': [attribute_type.GRAPH, 'g'],
        'FLOATS': [attribute_type.FLOATS, 'floats'],
        'INTS': [attribute_type.INTS, 'ints'],
        'STRINGS': [attribute_type.STRINGS, 'strings'],
        'TENSORS': [attribute_type.TENSORS, 'tensors'],
        'GRAPHS': [attribute_type.GRAPHS, 'graphs'],
        'SPARSE_TENSOR': [attribute_type.SPARSE_TENSOR, 'sparse_tensor'],
        'SPARSE_TENSORS': [attribute_type.SPARSE_TENSORS, 'sparse_tensors'],
    }
    proto_value_id = 0
    value_location_id = 1

    def __init__(self, node_proto):
        """
        Function: init object
        Inputs:
            node_proto: onnx.AttributeProto
        Returns: None
        """
        super().__init__()
        self.node_proto = node_proto

    @classmethod
    def map_value_location(cls, proto_value):
        """
        Funtion: find value's location in node_proto with proto_value
        Inputs:
            proto_value: a number in [0, 12], means the location as
            attribute_type_map
        Returns:
            location: a string, where the value locate as attribute_type_map
        """
        for key in cls.attribute_type_map:
            value = cls.attribute_type_map[key]
            if proto_value == value[0]:
                return value[1]
        raise ValueError('The type{%s} of attr is UNEXCEPTED' % (proto_value))

    def has_attr(self, attr_name):
        """
        Function: Whether node has attr of attr_name
        Inputs:
            attr_name: string, name of sttr
        Returns:
            True/False: True means attr exists and False otherwise
        """
        for attribute in self.node_proto.attribute:
            if attribute.name != attr_name:
                continue
            return True
        return False

    def get_attr_value(self, attr_name):
        """
        Function: get attr's value
        Inputs:
            attr_name: string, name of attr
        Returns:
            attr_value: attr's value
        """
        for attribute in self.node_proto.attribute:
            if attribute.name != attr_name:
                continue
            attr_value = getattr(attribute,
                                 self.map_value_location(attribute.type))
            return attr_value
        raise RuntimeError("node %s has no attribute %s" %
                           (self.node_proto.name, attr_name))

    def set_attr_value(self, attr_name, type_string, value):
        """
        Function: Set attr
        Inputs:
            attr_name: string, name of attr
            type_string: string, indicate type
            value: number or lsit, attr's data
        Returns:
            None
        """
        attr_type = self.attribute_type_map[type_string][self.proto_value_id]
        target_attr = None
        for attribute in self.node_proto.attribute:
            if attribute.name == attr_name:
                target_attr = attribute
        if target_attr is None:
            target_attr = self.node_proto.attribute.add()
            target_attr.name = attr_name

        target_attr.type = attr_type
        value_location = self.map_value_location(target_attr.type)

        if value_location in ['f', 'i', 's']:
            # set value in f/i/s
            setattr(target_attr, value_location, value)
        elif value_location in ['t', 'g', 'sparse_tensor']:
            # add an attr without value
            return
        else:
            # set value in floats/ints/strings
            target_attr.ClearField(value_location)
            getattr(target_attr, value_location).extend(value)
