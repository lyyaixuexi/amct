#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Common data definition module.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import platform
import sys
import re

import torch

from amct_pytorch.capacity import CAPACITY
from amct_pytorch.utils.log import LOGGER

CUR_DIR = os.path.split(os.path.realpath(__file__))[0]

QUANTIZABLE_TYPES = CAPACITY.get_value('QUANTIZABLE_TYPES')
QUANTIZABLE_ONNX_TYPES = CAPACITY.get_value('QUANTIZABLE_ONNX_TYPES')
NUQ_QUANTIZABLE_ONNX_TYPES = CAPACITY.get_value('NUQ_QUANTIZABLE_ONNX_TYPES')
NUQ_QUANTIZABLE_TYPES = CAPACITY.get_value('NUQ_QUANTIZABLE_TYPES')
CHANNEL_WISE_TYPES = CAPACITY.get_value('CHANNEL_WISE_TYPES')
CHANNEL_WISE_ONNX_TYPES = CAPACITY.get_value('CHANNEL_ONNX_WISE_TYPES')

SHIFT_N_TYPES = CAPACITY.get_value('SHIFT_N_TYPES')
SHIFT_N_ONNX_TYPES = CAPACITY.get_value('SHIFT_N_ONNX_TYPES')

FUSE_TYPES = CAPACITY.get_value('FUSE_TYPES')
FUSE_ONNX_TYPES = CAPACITY.get_value('FUSE_ONNX_TYPES')

AMCT_OPERATIONS = CAPACITY.get_value('AMCT_OPERATIONS')
AMCT_RETRAIN_OPERATIONS = CAPACITY.get_value('AMCT_RETRAIN_OPERATIONS')

RETRAIN_TYPES = CAPACITY.get_value('RETRAIN_TYPES')
RETRAIN_ONNX_TYPES = CAPACITY.get_value('RETRAIN_ONNX_TYPES')

MULT_OUTPUT_TYPES = CAPACITY.get_value('MULT_OUTPUT_TYPES')

PRUNABLE_TYPES = CAPACITY.get_value('PRUNABLE_TYPES')
PRUNABLE_ONNX_TYPES = CAPACITY.get_value('PRUNABLE_ONNX_TYPES')
PASSIVE_PRUNABLE_TYPES = CAPACITY.get_value('PASSIVE_PRUNABLE_TYPES')
PASSIVE_PRUNABLE_ONNX_TYPES = CAPACITY.get_value('PASSIVE_PRUNABLE_ONNX_TYPES')
SELECTIVE_PRUNABLE_TYPES = CAPACITY.get_value('SELECTIVE_PRUNABLE_TYPES')
CHANNEL_UNRELATED_ONNX_TYPES_P1 = CAPACITY.get_value('CHANNEL_UNRELATED_ONNX_TYPES_P1')
CHANNEL_UNRELATED_ONNX_TYPES_P2 = CAPACITY.get_value('CHANNEL_UNRELATED_ONNX_TYPES_P2')
ELTWISE_ONNX_TYPES = CAPACITY.get_value('ELTWISE_ONNX_TYPES')
CHANNEL_UNRELATED_ONNX_TYPES = CHANNEL_UNRELATED_ONNX_TYPES_P1 + CHANNEL_UNRELATED_ONNX_TYPES_P2

CLIBRATION_BIT = 8
QUANT_BIAS_BITS = 32
ZERO = 0.0
ONE = 1.0
BASE = 2
EPSILON = 1E-6
FLT_EPSILON = 1.192092896e-7


QUANT_LAYER_SUFFIX = ('.quant', '.dequant', '.anti_quant')


def find_torch_version():
    """
    Function: find torch's valid version.
    """
    version = torch.__version__
    for support_version in SUPPORT_TORCH_VERSIONS:
        if version.startswith(support_version):
            return support_version
    LOGGER.logw("amct_pytorch cannot support torch %s" % (version))
    return version


def torch_version_higher_than(left_version, right_version):
    """
    Function: check if the left_version is higher than right_version
    """
    def _get_version_list(version_string):
        """
        Function: wrap version string for comparing
        """
        version = re.findall(r"\d{1,2}\.+\d{1,2}\.+\d{1,2}", version_string)
        if len(version) == 0:
            raise RuntimeError('Get invalid version {}, \
                please make sure to use the released version of Pytorch!'.format(version_string))
        version_list = list(map(int, version[0].split('.')))
        return version_list

    left_ints = _get_version_list(left_version)
    right_ints = _get_version_list(right_version)

    version_length = 3
    is_higher = True
    for _ in range(version_length):
        left_tmp = left_ints.pop()
        right_tmp = right_ints.pop()
        if left_tmp == right_tmp:
            continue
        is_higher = left_tmp >= right_tmp

    return is_higher


def find_platform():
    """
    Function: find hardware platform for load op.
    """
    support_platforms = ['x86_64', 'aarch64']
    hardware_platform = platform.platform()
    for arch in support_platforms:
        if arch in hardware_platform:
            return arch
    raise RuntimeError("Unsupport platform {}".format(hardware_platform))


def find_op_py():
    """
    Function: obtain python version for loading op.
    """
    python_version = sys.version_info
    op_py = '{}{}'.format(python_version.major, python_version.minor)
    if op_py in ['37']:
        op_py = '{}m'.format(op_py)
    return op_py

SUPPORT_TORCH_VERSIONS = ['1.5.0', '1.8.0', '1.10.0']
TORCH_VERSION = find_torch_version()
PLATFORM = find_platform()
OP_PY = find_op_py()
