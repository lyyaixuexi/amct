#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Common data definition module.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import numpy as np
from amct_pytorch.utils.log import LOGGER
from amct_pytorch.common.utils import files as files_util
from amct_pytorch.utils.onnx_node_util import AttributeProtoHelper

__all__ = ['save_onnx_model', 'generate_onnx_file_name', 'split_dir_prefix']


def save_onnx_model(graph_proto, file_name, node_info=None, deleted_attr=None):
    """
    Function: save graph_proto in file.
    Inputs:
        graph_proto: IR Graph, the graph_proto to be saved.
        file_name: a string, a file(.onnx) to save net's information.
    Returns: None
    """
    file_realpath = os.path.realpath(file_name)
    # save to file
    files_util.create_file_path(file_realpath, check_exist=True)
    dump_model = graph_proto.dump_proto()
    if node_info:
        dump_model = _write_node_info(dump_model, node_info)
    if deleted_attr:
        delete_customized_attr(dump_model, deleted_attr)
    with open(file_realpath, 'wb') as fid:
        fid.write(dump_model.SerializeToString())
    # set file's permission 640
    os.chmod(file_realpath, files_util.FILE_MODE)

    LOGGER.logi("The model file is saved in %s" % (file_realpath),\
                module_name='Utils')


def _write_node_info(onnx_model, node_info):
    """
    Function: set node info as attribute in the exported onnx model file.
    Inputs:
        onnx_model: exported onnx model.
        node_info: node info which will be written in onnx model as node attr.
    Outputs:
        onnx_model: exported onnx model.
    """
    for node_proto in onnx_model.graph.node:
        if node_proto.name not in node_info:
            continue
        for _, attr in enumerate(node_info.get(node_proto.name)):
            AttributeProtoHelper(node_proto).set_attr_value(attr.get('attr_name'),
                                                            attr.get('attr_type'),
                                                            attr.get('attr_val'))
    return onnx_model


def delete_customized_attr(onnx_model, deleted_attr):
    for node in onnx_model.graph.node:
        for idx, attr in enumerate(node.attribute):
            if attr.name in deleted_attr:
                del node.attribute[idx]


def generate_onnx_file_name(save_dir, save_prefix, save_type):
    ''' Generate model's name. '''
    if save_type == 'Deploy':
        file_suffix = 'deploy_model.onnx'
    else:
        file_suffix = 'fake_quant_model.onnx'

    if save_prefix != '':
        ckpt_file = os.path.join(save_dir, '_'.join([save_prefix,
                                                     file_suffix]))
    else:
        ckpt_file = os.path.join(save_dir, file_suffix)

    return ckpt_file


def split_dir_prefix(save_path):
    ''' split save_path to save_dir and save_prefix'''
    if save_path == '':
        save_prefix = ''
        save_dir = os.path.realpath(save_path)
    elif save_path != '' and save_path[-1] == '/':
        save_prefix = ''
        save_dir = os.path.realpath(save_path)
    else:
        save_dir, save_prefix = os.path.split(os.path.realpath(save_path))
    files_util.is_valid_save_prefix(save_prefix)

    return save_dir, save_prefix


def dump_ifmr_input_tensor(dump_data, dump_dir, layer_name, batch_idx):
    """ dump the input data"""
    if not os.path.exists(dump_dir):
        raise RuntimeError("{} does not exists.".format(dump_dir))
    layer_name = layer_name.replace("/", "_")
    npy_dump_file_path = "{}/{}_ifmr_layer_{}.npy".format(
        dump_dir, layer_name, batch_idx)
    np.save(npy_dump_file_path, dump_data)
