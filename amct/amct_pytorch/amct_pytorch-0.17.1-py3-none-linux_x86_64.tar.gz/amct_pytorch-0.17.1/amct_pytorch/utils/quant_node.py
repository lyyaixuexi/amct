#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Information Helper to cope with different quant related operation

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_pytorch.capacity import CAPACITY
from amct_pytorch.utils.onnx_node_util import AttributeProtoHelper
from amct_pytorch.utils.onnx_initializer_util import TensorProtoHelper
from amct_pytorch.utils.weight_quant_api import get_deconv_group


class QuantOpInfo():
    '''
    Find infomation of quant_op.
    '''
    @staticmethod
    def get_scale_shape(node, channel_wise):
        """
        Function: Get the weights' scale's shape of node.
        Inputs:
            node: Node, it's type should be in QUANTIZABLE_ONNX_TYPES.
            channel_wise: a bool, parameter of quantization.
        Returns:
            shape: a list, the shape of scale.
            scale_length : a number, the length of scale.
        """

        if node.type not in CAPACITY.get_value('QUANTIZABLE_ONNX_TYPES'):
            raise RuntimeError(
                'Not supported get scale shape from type:%s(%s)' %
                (node.type, node.name))
        weight_param = QuantOpInfo.get_weight_tensor(node)
        if channel_wise and node.type in CAPACITY.get_value(
                'CHANNEL_WISE_ONNX_TYPES'):
            if node.type == 'ConvTranspose':
                # deconv2d or deconv3d
                group = get_deconv_group(node)
                length = weight_param.dims[1] * group
                shape = [1] * len(weight_param.dims)
                shape[1] = length
            else:
                # conv2D or conv3D
                length = weight_param.dims[0]
                shape = [1] * len(weight_param.dims)
                shape[0] = weight_param.dims[0]
        else:
            shape = []
            length = 1

        return shape, length

    @staticmethod
    def get_quant_index(node):
        """
        Function: get act's index and weight's index of node.
        Inputs:
            node: Node, it's type should be in QUANTIZABLE_ONNX_TYPES.
        Returns:
            act_index: the act's index in inputs of node.
            weight_index: the weight's index in inputs of node.
        """
        if node.type not in CAPACITY.get_value('QUANTIZABLE_ONNX_TYPES'):
            raise RuntimeError("%s is not supported." % (node.type))

        quant_indexes = {
            "Conv": [0, 1, 2],
            "Gemm": [0, 1, 2],
            "MatMul": [0, 1, None],
            'ConvTranspose': [0, 1, 2]
        }

        act_index, weight_index, bias_index = quant_indexes.get(node.type)

        return act_index, weight_index, bias_index

    @staticmethod
    def get_dequant_shape(node):
        """
        Function: Get the dequant scale's shape from node
        Inputs: node: the node te be quantized
        Returns: the shape of dequant scale
        """
        if node.type in ["Conv", "AscendDequant", "ConvTranspose"]:
            dequant_shape = [1, -1, 1, 1]
            if node.type == 'Conv' or node.type == 'ConvTranspose':
                conv_weights_node = QuantOpInfo.get_weight_node(node)
                weight_tensor = QuantOpInfo.get_node_tensor(conv_weights_node)
                if len(weight_tensor.dims) == 5:
                    dequant_shape = [1, -1, 1, 1, 1]
        elif node.type in ["Gemm", "MatMul", "AveragePool"]:
            dequant_shape = [1, -1]
        else:
            raise RuntimeError("%s is not supported." % (node.type))

        return dequant_shape

    @staticmethod
    def get_weight_node(node):
        '''
        Function: Get quantizable_node's weight node
        Parameters:
            quantizable_node: a node, which is quantizable
        Return:
            weight_param: a node, it's quantizable_node' weight
        '''
        _, weight_index, _ = QuantOpInfo.get_quant_index(node)

        weight_input_anchor = node.get_input_anchor(weight_index)
        weight_param = weight_input_anchor.get_peer_output_anchor().node

        if weight_param.type == 'Transpose':
            weight_input_anchor = weight_param.get_input_anchor(0)
            weight_param = weight_input_anchor.get_peer_output_anchor().node
            node.set_attr('with_weights_trans', True)

        return weight_param

    @staticmethod
    def get_weight_tensor(node):
        '''
        Function: Get quantizable_node's weight node
        Parameters:
            quantizable_node: a node, which is quantizable
        Return:
            weight_param: a node, it's quantizable_node' weight
        '''
        weight_node = QuantOpInfo.get_weight_node(node)
        weight_tensor = QuantOpInfo.get_node_tensor(weight_node)

        return weight_tensor

    @staticmethod
    def get_cout_length(node):
        """
        Function: Get cout length of the given node
        Parameter: node
        Return: cout_length
        """
        if node.type not in CAPACITY.get_value('PASSIVE_PRUNABLE_ONNX_TYPES'):
            raise RuntimeError("Unexpected node's type {} for {}".format(node.type, node.name))
        cout_length = None
        if node.type == 'BatchNormalization':
            scale_node, _ = node.get_producer(1)
            tensor = QuantOpInfo.get_node_tensor(scale_node)
            cout_length = tensor.dims[0]
        else:
            # 'Conv', 'ConvTranspose', 'Gemm', 'MatMul'
            tensor = QuantOpInfo.get_weight_tensor(node)
            if node.type == 'Conv':
                cout_length = tensor.dims[0]
            elif node.type in ['ConvTranspose', 'MatMul']:
                # group conv case
                cout_length = tensor.dims[1]
            elif node.type == 'Gemm':
                attr_helper = AttributeProtoHelper(node.proto)
                if not attr_helper.has_attr('transB') or attr_helper.get_attr_value('transB') == 0:
                    cout_length = tensor.dims[1]
                else:
                    cout_length = tensor.dims[0]
        return cout_length

    @staticmethod
    def get_cin_length(node):
        """
        Function: Get cin length of the given node
        Parameter: node
        Return: cin_length
        """
        if node.type not in CAPACITY.get_value('QUANTIZABLE_ONNX_TYPES'):
            raise RuntimeError("Unexpected node's type {} for {}".format(node.type, node.name))
        cin_length = None
        tensor = QuantOpInfo.get_weight_tensor(node)
        if node.type == 'Conv':
            group = get_deconv_group(node)
            cin_length = tensor.dims[1] * group
        elif node.type in ['ConvTranspose', 'MatMul']:
            cin_length = tensor.dims[0]
        elif node.type == 'Gemm':
            attr_helper = AttributeProtoHelper(node.proto)
            if not attr_helper.has_attr('transB') or attr_helper.get_attr_value('transB') == 0:
                cin_length = tensor.dims[0]
            else:
                cin_length = tensor.dims[1]
        return cin_length


    @staticmethod
    def get_node_tensor(node):
        '''
        Function: Get node's value tensor
        Parameters:
            node: a node, which contain value, usually is initializer or constant
        Return:
        '''
        node_type = node.type
        if node_type not in ['initializer', 'Constant']:
            raise RuntimeError("Do not support get tensor from node {} with type {}".format(node.name, node_type))
        if node_type == 'initializer':
            # for 'initializer' type
            node_tensor = node.proto
        else:
            # for 'Constant' type
            attr_helper = AttributeProtoHelper(node.proto)
            node_tensor = attr_helper.get_attr_value('value')

        return node_tensor

    @staticmethod
    def get_node_value(node):
        '''
        Function: Get node's value
        Parameters:
            node: a node, which contain value, usually is initializer or constant
        Return:
        '''
        node_tensor = QuantOpInfo.get_node_tensor(node)
        tensor_helper = TensorProtoHelper(node_tensor)
        node_value = tensor_helper.get_data()

        return node_value
