#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Add fakequant dequant pattern in graph.

"""

from onnx import onnx_pb, AttributeProto # pylint: disable=E0401
from amct_pytorch.utils.onnx_node_util import AttributeProtoHelper
from amct_pytorch.utils.onnx_initializer_util import TensorProtoHelper
from amct_pytorch.module.quant_module import construct_fake_quant_dequant_cast_op


def add_fake_dequant(graph, layer_name, dqscale, shift_bit, clip_mode):
    """
    Function: Add fakequant "dequant" pattern in graph
    """
    node = graph.get_node_by_name(layer_name)
    if node.has_attr('dtype'):
        dtype = node.get_attr('dtype')
    else:
        dtype = 'float32'
    layer_name = '.'.join([layer_name, 'fakedequant'])
    # add scale, offset, clip_min, clip_max
    dqscale_node = graph.add_node(
        _construct_fake_dequant_dqscale(layer_name, dqscale))
    shift_node = graph.add_node(
        _construct_fake_dequant_shift_bit(layer_name, shift_bit))
    min_node = graph.add_node(
        _construct_fake_dequant_clip_min(layer_name, -2**(clip_mode - 1)))
    max_node = graph.add_node(
        _construct_fake_dequant_clip_max(layer_name, 2**(clip_mode - 1) - 1))
    pow_base_node = graph.add_node(
        _construct_fake_dequant_pow_base(layer_name, 2.0))
    # add pow
    pow_node = graph.add_node(_construct_fake_dequant_pow(layer_name))
    # add div
    div_node = graph.add_node(_construct_fake_dequant_div(layer_name))
    # add floor
    floor_node = graph.add_node(_construct_fake_dequant_floor(layer_name))
    # add clip
    clip_node = graph.add_node(_construct_fake_dequant_clip(layer_name))
    # add mul
    mul_node = graph.add_node(_construct_fake_dequant_mul(layer_name))

    # add links
    graph.add_edge(pow_base_node, 0, pow_node, 0)
    graph.add_edge(shift_node, 0, pow_node, 1)
    graph.add_edge(pow_node, 0, div_node, 1)
    graph.add_edge(div_node, 0, floor_node, 0)
    graph.add_edge(floor_node, 0, clip_node, 0)
    graph.add_edge(min_node, 0, clip_node, 1)
    graph.add_edge(max_node, 0, clip_node, 2)
    graph.add_edge(clip_node, 0, mul_node, 0)
    graph.add_edge(dqscale_node, 0, mul_node, 1)

    enter_node = div_node
    out_node = mul_node

    if dtype == 'float16':
        cast_node = graph.add_node(construct_fake_quant_dequant_cast_op(layer_name, "float16"))
        graph.add_edge(mul_node, 0, cast_node, 0)
        out_node = cast_node

    return enter_node, out_node


def _construct_fake_dequant_pow(layer_name):
    '''construct pow op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'pow'])
    node_proto.op_type = 'Pow'
    node_proto.doc_string = 'pow of the Fake dequant'
    node_proto.input.extend([ # pylint: disable=E1101
        '.'.join([layer_name, 'pow_base.output0']),
        '.'.join([layer_name, 'shifit_bit.output0'])
    ])
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'pow.output0'])])

    return node_proto


def _construct_fake_dequant_div(layer_name):
    '''construct div op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'div'])
    node_proto.op_type = 'Div'
    node_proto.doc_string = 'div of the Fake dequant'
    node_proto.input.extend([ # pylint: disable=E1101
        '.'.join([layer_name, 'div.input0']),
        '.'.join([layer_name, 'pow.output0'])
    ])
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'div.output0'])])

    return node_proto


def _construct_fake_dequant_floor(layer_name):
    '''construct floor op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'floor'])
    node_proto.op_type = 'Floor'
    node_proto.doc_string = 'floor of the Fake dequant'
    node_proto.input.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'div.output0'])])
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'floor.output0'])])

    return node_proto


def _construct_fake_dequant_clip(layer_name):
    '''construct clip op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'clip'])
    node_proto.op_type = 'Clip'
    node_proto.doc_string = 'clip of the Fake dequant'
    node_proto.input.extend([ # pylint: disable=E1101
        '.'.join([layer_name, 'floor',
                  'output0']), '.'.join([layer_name, 'min_val', 'output0']),
        '.'.join([layer_name, 'max_val', 'output0'])
    ])
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'clip', 'output0'])])

    return node_proto


def _construct_fake_dequant_mul(layer_name):
    '''construct mul op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'mul'])
    node_proto.op_type = 'Mul'
    node_proto.doc_string = 'mul of the Fake dequant'
    node_proto.input.extend([ # pylint: disable=E1101
        '.'.join([layer_name, 'clip', 'output0']),
        '.'.join([layer_name, 'dqscale', 'output0'])
    ])
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'mul', 'output0'])])

    return node_proto


def _construct_fake_dequant_dqscale(layer_name, dqscale):
    '''construct dqscale op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'dqscale'])
    node_proto.op_type = 'Constant'
    node_proto.doc_string = 'scale of the Fake dequant'
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'dqscale', 'output0'])])

    AttributeProtoHelper(node_proto).set_attr_value('value', 'TENSOR', None)
    attr = node_proto.attribute[0] # pylint: disable=E1101
    TensorProtoHelper(attr.t).set_data(
        dqscale.reshape([-1]).tolist(), 'FLOAT', list(dqscale.shape))

    return node_proto


def _construct_fake_dequant_shift_bit(layer_name, shift_bit):
    '''construct shift_bit op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'shift_bit'])
    node_proto.op_type = 'Constant'
    node_proto.doc_string = 'shift_bit of the Fake dequant'
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'shift_bit', 'output0'])])

    AttributeProtoHelper(node_proto).set_attr_value('value', 'TENSOR', None)
    attr = node_proto.attribute[0] # pylint: disable=E1101
    TensorProtoHelper(attr.t).set_data(
        shift_bit.reshape([-1]).tolist(), 'FLOAT', list(shift_bit.shape))

    return node_proto


def _construct_fake_dequant_clip_min(layer_name, clip_min):
    '''construct clip's min op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.doc_string = 'clip min of the Fake dequant'
    node_proto.name = '.'.join([layer_name, 'min_val'])
    node_proto.op_type = 'Constant'
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'min_val', 'output0'])])

    AttributeProtoHelper(node_proto).set_attr_value('value', 'TENSOR', None)
    attr = node_proto.attribute[0] # pylint: disable=E1101
    TensorProtoHelper(attr.t).set_data([clip_min], 'FLOAT')

    return node_proto


def _construct_fake_dequant_clip_max(layer_name, clip_max):
    '''construct clip's max op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.doc_string = 'clip max of the Fakequant'
    node_proto.name = '.'.join([layer_name, 'max_val'])
    node_proto.op_type = 'Constant'
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'max_val', 'output0'])])

    AttributeProtoHelper(node_proto).set_attr_value('value', 'TENSOR', None)
    attr = node_proto.attribute[0] # pylint: disable=E1101
    TensorProtoHelper(attr.t).set_data([clip_max], 'FLOAT')

    return node_proto


def _construct_fake_dequant_pow_base(layer_name, pow_base):
    '''construct pow's base op '''
    node_proto = onnx_pb.NodeProto()
    node_proto.name = '.'.join([layer_name, 'pow_base'])
    node_proto.op_type = 'Constant'
    node_proto.doc_string = 'pow_base of the Fake dequant'
    node_proto.output.extend( # pylint: disable=E1101
        ['.'.join([layer_name, 'pow_base', 'output0'])])

    AttributeProtoHelper(node_proto).set_attr_value('value', 'TENSOR', None)
    attr = node_proto.attribute[0] # pylint: disable=E1101
    TensorProtoHelper(attr.t).set_data([pow_base], 'FLOAT')

    return node_proto
