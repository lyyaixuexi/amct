#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert AscendWeightQuant in the graph.

"""
import numpy as np
from onnx import onnx_pb # pylint: disable=import-error

from amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass
from amct_pytorch.utils.quant_node import QuantOpInfo
from amct_pytorch.utils.vars import QUANT_BIAS_BITS
from amct_pytorch.utils.vars import BASE
from amct_pytorch.utils.log import LOGGER
from amct_pytorch.utils.onnx_initializer_util import TensorProtoHelper
from amct_pytorch.utils.onnx_node_util import AttributeProtoHelper


class InsertBiasQuantPass(BaseFusionPass):
    """
    Function: Quant weight from float32 to int8
    APIs: match_pattern, do_pass, quant_weight
    """
    def __init__(self, records):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records

    @staticmethod
    def quant_bias(bias, scale_w, scale_d, layer_name):
        '''Function: kernel function, quant bias with scale and offset
        Parameters:
            bias: np.array, to be quantized
            scale: float number, quant factor
            offset: int number, quant factor
        Returns:
            quant_bias, np.array with type int32, quantized bias
        '''
        left_bound = -pow(1.0*BASE, QUANT_BIAS_BITS - 1)
        right_bound = pow(1.0*BASE, QUANT_BIAS_BITS - 1) - 1
        deq_scale = np.multiply(scale_w, scale_d).reshape([-1])
        quant_bias = np.round(np.true_divide(bias, deq_scale))
        # check the quant_bias in range of int32
        quant_bias = quant_bias.reshape(-1)
        cmp_ans = np.add(quant_bias < left_bound, quant_bias > right_bound)
        if cmp_ans.any():
            invalid_value = quant_bias[np.argmax(cmp_ans)]
            LOGGER.loge('Quantized bias {} of layer "{}" exceed int32 ' \
                'range:[{}, {}], please add it to skip layer.'.format(
                    invalid_value, layer_name,
                    left_bound, right_bound))
            raise RuntimeError('Do bias quantize failed.')
        quant_bias = quant_bias.reshape(bias.shape).astype(np.int32)
        return quant_bias

    def match_pattern(self, node):
        """
        Function: Match the node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type == 'AveragePool':
            return False

        if node.name not in self.records:
            return False

        _, _, bias_index = QuantOpInfo.get_quant_index(node)
        if bias_index and len(node.input_anchors) > bias_index:
            return True

        return False

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Do actual quantization and node's bias is changed to int32.
        Parameters:
            graph: graph structure
            object_node: node to process
            model: torch.nn.Module, the model to be modified. if it's
                None, the gaph will be modified.
        Return: None
        """
        num_bits = self.get_dst_type(object_node.name)
        _, _, bias_index = QuantOpInfo.get_quant_index(object_node)
        bias_input_anchor = object_node.get_input_anchor(bias_index)
        bias_param = bias_input_anchor.get_peer_output_anchor().node
        bias_helper = TensorProtoHelper(bias_param.proto)
        bias = bias_helper.get_data()
        bias_helper.clear_data()
        int32_bias = InsertBiasQuantPass.quant_bias(
            bias,
            self.records.get(object_node.name).get('weight_scale'),
            self.records.get(object_node.name).get('data_scale'),
            object_node.name)

        bias_helper.set_data(int32_bias, 'INT32')

        if num_bits == 4:
            # Step1: add a new_node
            node_proto = construct_bias_quant_node(
                inputs=['.'.join([object_node.name, 'bias_quant', 'input0'])],
                outputs=['.'.join([object_node.name, 'bias_quant', 'output0'])],
                layer_name=object_node.name)
            bias_quant_node = graph.add_node(node_proto)

            # Step2: Relink nodes in th graph
            # remove output links
            graph.remove_edge(bias_param, 0,
                            object_node, bias_index)
            # add links
            graph.add_edge(bias_param, 0, bias_quant_node, 0)
            graph.add_edge(bias_quant_node, 0, object_node, bias_index)

        LOGGER.logd("Quant bias from float32 to int32 for layer '{}' " \
            "success!".format(object_node.name), 'BiasQuantPass')


def construct_bias_quant_node(inputs, # pylint: disable=no-member
                              outputs,
                              layer_name):
    """
    Function: construct quant node in onnx
    Inputs:
        input: a list of inputs' name
        output: a list of outputs' name
        attrs: a dict of attrs including
            scale: numpy.array
            offset: numpy.array
            dst_type: a string
        quantize_layer: a string, layer to be quantized
    """
    node_proto = onnx_pb.NodeProto()

    node_proto.name = '.'.join([layer_name, 'bias_quant'])
    node_proto.op_type = 'Cast'

    cast_dtype = onnx_pb.TensorProto.DataType.FLOAT
    AttributeProtoHelper(node_proto).set_attr_value('to', 'INT', cast_dtype)
    node_proto.input.extend(inputs) # pylint: disable=E1101
    node_proto.output.extend(outputs) # pylint: disable=E1101

    return node_proto
