#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Fakequant weight from int8 to int9.

"""
import numpy as np

from amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass

from amct_pytorch.utils.log import LOGGER
from amct_pytorch.utils.onnx_initializer_util import TensorProtoHelper
from amct_pytorch.utils.quant_node import QuantOpInfo
from amct_pytorch.utils.weight_quant_api import get_deconv_group
from amct_pytorch.utils.weight_quant_api import adjust_deconv_weight_shape


class WeightFakequantPass(BaseFusionPass):
    """
    Function: Fakequant weight from int8 to int9
    APIs: match_pattern, do_pass
    """
    def __init__(self, records):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
            num_bits: int number indicating the bit to be quanted such as 8
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records

    def match_pattern(self, node):
        """
        Function: Match pattern of node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type == 'AveragePool':
            return False

        if node.name not in self.records:
            return False

        if self.get_dst_type(node.name) != 8:
            return False
        return True

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Do actual quantization and node's weight is changed to int9.
        Parameters:
            graph: graph structure
            object_node: node to process
            model: torch.nn.Module, the model to be modified. if it's
                None, the gaph will be modified.
        Return: None
        """
        weight_param = QuantOpInfo.get_weight_node(object_node)
        weight_helper = TensorProtoHelper(weight_param.proto)
        # get data
        int8_weight = weight_helper.get_data()
        if object_node.type == 'ConvTranspose' and get_deconv_group(object_node) > 1:
            group = get_deconv_group(object_node)
            int8_weight = adjust_deconv_weight_shape(group, int8_weight)
            int8_weight = np.transpose(int8_weight, (1, 0, 2, 3))
        weight_helper.clear_data()

        weight_offset = self.records.get(object_node.name).get('weight_offset')
        int9_weight = int8_weight.astype(np.float32)
        if not np.all(weight_offset == 0):
            int9_weight = int9_weight - weight_offset.astype(np.float32)

        if object_node.type == 'ConvTranspose' and get_deconv_group(object_node) > 1:
            group = get_deconv_group(object_node)
            int9_weight = np.transpose(int9_weight, (1, 0, 2, 3))
            int9_weight = adjust_deconv_weight_shape(group, int9_weight)

        int9_weight = int9_weight.reshape([-1])

        weight_helper.set_data(int9_weight, 'FLOAT')

        LOGGER.logd("Fakequant weight from int8 to int9 for layer '{}' " \
            "success!".format(object_node.name), 'WeightFakequantPass')
