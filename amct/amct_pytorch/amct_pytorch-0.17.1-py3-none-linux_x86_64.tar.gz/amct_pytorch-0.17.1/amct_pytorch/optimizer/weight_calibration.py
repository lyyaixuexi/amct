#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Do caliration for weight, sacle and offset for weight will be finded and
weight is fake_quantized.

"""
from google.protobuf import text_format
import torch
import numpy as np

from amct_pytorch.configuration.configuration import Configuration
from amct_pytorch.optimizer.base_module_fusion_pass import BaseModuleFusionPass
from amct_pytorch.proto import scale_offset_record_pb2
from amct_pytorch.custom_op.arq.arq import weight_cali_tensor
from amct_pytorch.custom_op.nuq.nuq import weight_nuq_cali_tensor

from amct_pytorch.common.utils.record_file_operator import record_weights_scale_offset
from amct_pytorch.common.utils.record_file_operator import \
    read_activation_scale_offset
from amct_pytorch.utils.log import LOGGER
from amct_pytorch.utils.vars import QUANTIZABLE_TYPES
from amct_pytorch.configuration.check import GraphChecker
from amct_pytorch.utils.quant_node import QuantOpInfo
from amct_pytorch.utils.onnx_initializer_util import TensorProtoHelper
from amct_pytorch.utils.weight_quant_api import adjust_deconv_weight_shape
from amct_pytorch.utils.weight_quant_api import adjust_conv_weight_shape


class WeightsCalibrationPass(BaseModuleFusionPass):
    """
    Function: Do caliration for weight, sacle and offset for weight will
        be found and weight is fake_quantized.
    APIs: set_up, tear_down, match_pattern, do_pass
    """
    def __init__(self, record_dict=None, weight_fakequant=True):
        """
        Function: init object
        Parameter:
        weight_fakequant: bool, whether to use the fake quant weight.
                For AMC Feature, set to False.

        Return: None
        """
        BaseModuleFusionPass.__init__(self)
        self.records = scale_offset_record_pb2.ScaleOffsetRecord()
        self.conf = Configuration()
        self.record_file_path = self.conf.get_record_file_path()
        self.weight_fakequant = weight_fakequant
        self.record_dict = {} if record_dict is None else record_dict

    @staticmethod
    def _graph_weight_set_process(object_node, object_module, weight):
        """
        Function: set weight data to graph.

        Args:
        object_node: graph object node.
        object_module: module to process.
        weight: new weigh to set into the graph.

        Return:
        None.
        """
        weight_param = QuantOpInfo.get_weight_node(object_node)
        weight_helper = TensorProtoHelper(weight_param.proto)

        calied_weight_raw = weight
        # transpose torch.nn.Linear.weight in (Cout, Cin) to ONNX (Cin, Cout).
        if object_node.type == 'MatMul' and type(object_module).__name__ == 'Linear':
            need_transpose = True
            # Trans op may already be inserted in exported ONNX model
            if object_node.has_attr('with_weights_trans'):
                if object_node.get_attr('with_weights_trans'):
                    need_transpose = False
            if need_transpose:
                calied_weight_raw = calied_weight_raw.transpose(1, 0)
        calied_weight_raw = calied_weight_raw.flatten().cpu().numpy().tolist()

        weight_helper.clear_data()
        weight_helper.set_data(calied_weight_raw, 'FLOAT')

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, 'r') as record_read_file:
            pbtxt_string = record_read_file.read()
            text_format.Merge(pbtxt_string, self.records)

    def match_pattern(self, module, name, graph=None):
        """
        Function:Match the module to be quantized in model
        Parameters:
            module: module to be matched
            name: module's name
            graph: graph structure, not necessary
        Return: True: matched
                False: mismatch
        """
        if type(module).__name__ not in QUANTIZABLE_TYPES:
            return False
        if name not in self.conf.get_quant_config():
            return False

        return True

    def do_pass(self, model, object_module, object_name, graph=None):
        """
        Function: Do actual Insert IFMR module
        Parameters: model: torch.nn.Module, the model to be modified.
                    object_module: module to process
                    object_name: name of object_module
                    graph: graph structure, not necessary
        Return: None
        """
        # Step0: do avgpooling calibration only by kernel shape
        object_node = graph.get_node_by_name(object_name)
        if object_node.type == 'AveragePool':
            self._averagegpool_process(object_name)
            return

        # Step1: do weight calibration by algo
        # get weights' information for quantization
        layer_config = self.conf.get_layer_config(object_name)
        wts_param = layer_config.get('weight_quant_params')
        dmq_param = layer_config.get('dmq_balancer_param')
        calied_weight = self._weight_calibration_process(
            object_module=object_module,
            object_node=object_node,
            wts_param=wts_param,
            dmq_param=dmq_param
        )
        object_module.weight.data = calied_weight

        # step2: set weights data to graph.
        self._graph_weight_set_process(
            object_node=object_node,
            object_module=object_module,
            weight=object_module.weight.data)

        LOGGER.logd('Do layer \'{}[{}]\' weights calibration success!'\
                    .format(object_node.name, wts_param.get('wts_algo')), \
                    'WeightsCalibrationPass')

    def tear_down(self):
        """
        Function: write the scale and offset to Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, "w") as record_write_file:
            record_write_file.write(
                text_format.MessageToString(self.records, as_utf8=True))

    def _averagegpool_process(self, object_name):
        """
        Function: process average pool. write weight scale and offset.
        AveragePool do not need weight calibration.

        Args:
        object_name: name of object_module.
        """
        scale = [1.0]
        offset = [0]
        record_weights_scale_offset(self.records, object_name, scale,
                                    offset)
        LOGGER.logd(
            'Do layer:\'{}\' weights calibration success!'.format(
                object_name), 'WeightsCalibrationPass')

    def _weight_calibration_process(
        self,
        object_module,
        object_node,
        wts_param,
        dmq_param):
        """
        Function: do weight calibration by specific algorithm.
        write scale and offset to records.

        Args:
        object_module: module to process.

        Return:
        calied_weight: fake quant weight.
        Notes, `auto_mixed_precision_search` is original weight. NOT FAKE.
        """
        data_tensor = object_module.weight.data
        device = data_tensor.device

        # broadcast tensor_balance_factor to weight shape and apply to weight
        if dmq_param:
            if not self.record_dict.get(object_node.name) or \
                not self.record_dict.get(object_node.name).get('tensor_balance_factor'):
                raise ValueError("config indicates dmq_balancer in layer: %s, " \
                                    "but no tensor_balance_factor found in record." \
                                    "please check quant_preprocess and calibration is done!" % object_node.name)
            tensor_balance_factor = self.record_dict.get(object_node.name).get('tensor_balance_factor')
            tensor_balance_factor = np.array(tensor_balance_factor, np.float32)
            data_tensor = data_tensor.cpu()
            if type(object_module).__name__ == 'Conv2d':
                tensor_balance_factor = tensor_balance_factor.reshape([1, -1, 1, 1])
            elif type(object_module).__name__ == 'ConvTranspose2d':
                tensor_balance_factor = tensor_balance_factor.reshape([-1, 1, 1, 1])
            elif type(object_module).__name__ == 'Conv3d':
                tensor_balance_factor = tensor_balance_factor.reshape([1, -1, 1, 1, 1])

            if type(object_module).__name__ in ('Conv2d', 'Conv3d') and object_module.groups > 1:
                group = object_module.groups
                data_tensor = adjust_conv_weight_shape(group, data_tensor)
                data_tensor = data_tensor.transpose(0, 1)

            data_tensor = data_tensor * tensor_balance_factor

            if type(object_module).__name__ in ('Conv2d', 'Conv3d') and object_module.groups > 1:
                group = object_module.groups
                data_tensor = data_tensor.transpose(0, 1)
                data_tensor = adjust_conv_weight_shape(group, data_tensor)
            data_tensor = data_tensor.to(device)

        # find scale and offset
        if type(object_module).__name__ in ('ConvTranspose2d', 'ConvTranspose3d'):
            group = object_module.groups
            data_tensor = adjust_deconv_weight_shape(group, data_tensor)

        if wts_param.get('wts_algo') == 'arq_quantize':
            scale, offset, calied_weight = weight_cali_tensor(data_tensor,
                                                              wts_param)
        else:
            weights_len = data_tensor.numel()
            _check_nuq_executable(wts_param, object_node, weights_len)
            scale, offset, calied_weight = weight_nuq_cali_tensor(data_tensor,
                                                                  wts_param)

        # FOR AMC Feature, weight do not need fake quant.
        if not self.weight_fakequant:
            calied_weight = data_tensor

        if type(object_module).__name__ in ('ConvTranspose2d', 'ConvTranspose3d'):
            group = object_module.groups
            calied_weight = adjust_deconv_weight_shape(group, data_tensor)

        # save the quantize information
        record_weights_scale_offset(self.records, object_node.name, scale,
                                    offset)
        return calied_weight


def _check_nuq_executable(wts_param, object_node, weights_len):
    """
    Function: check whether nuq is supported for current object_node.
    Inputs:
        wts_param: weight quantization parameters.
        object_node: 'node' in the 'graph'.
        weights_len: length of weight's node.
    Returns: None
    """
    is_supported = GraphChecker.check_nuq_graph_quantize_type(object_node)
    object_name = object_node.name
    if not is_supported:
        raise RuntimeError("Layer '{}' is not supported for NUQ, but 'wts_algo' is set to 'nuq_quantize'!" \
            .format(object_name))
    nuq_steps = wts_param.get('num_steps')
    if nuq_steps > weights_len:
        raise RuntimeError("Layer '{}' is not supported for NUQ with num_steps: {} > weight length {}!" \
            .format(object_name, nuq_steps, weights_len))

