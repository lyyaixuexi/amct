#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Fakequant weight from int8 to int9.

"""
import numpy as np

from torch import Tensor # pylint: disable=E0401
from torch.nn.parameter import Parameter # pylint: disable=E0401

from amct_pytorch.optimizer.base_module_fusion_pass import BaseModuleFusionPass
from amct_pytorch.custom_op.arq.arq import weight_quant_np
from amct_pytorch.custom_op.fake_quant import FAKE_MODULES
from amct_pytorch.custom_op.fake_quant import FAKE_CONV2D
from amct_pytorch.custom_op.fake_quant import FAKE_CONV_TRANSPOSE2D
from amct_pytorch.custom_op.fake_quant import FAKE_CONV3D
from amct_pytorch.utils.log import LOGGER
from amct_pytorch.utils.weight_quant_api import adjust_deconv_weight_shape


class WeightFakequantModulePass(BaseModuleFusionPass):
    """
    Function: Fakequant weight from int8 to int9
    APIs: match_pattern, do_pass
    """
    def __init__(self, records, num_bits):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
            num_bits: int number indicating the bit to be quanted such as 8
        Return: None
        """
        BaseModuleFusionPass.__init__(self)
        self.num_bits = num_bits
        self.records = records

    def match_pattern(self, module, name, graph=None):
        """
        Function: Match pattern of node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if name not in self.records:
            return False

        if type(module).__name__ in FAKE_MODULES:
            return True

        return False

    def do_pass(self, model, object_module, object_name, graph=None):
        """
        Function: Do actual quantization and node's weight is changed to int9.
        Parameters:
            graph: graph structure
            object_node: node to process
            model: torch.nn.Module, the model to be modified. if it's
                None, the graph will be modified.
        Return: None
        """
        is_cuda = object_module.sub_module.weight.is_cuda
        weight_np = object_module.sub_module.weight.cpu().detach().numpy()
        weight_offset = self.records.get(object_name).get('weight_offset')
        ori_weight_shape = weight_np.shape
        if type(object_module).__name__ == FAKE_CONV_TRANSPOSE2D:
            group = object_module.sub_module.groups
            weight_np = adjust_deconv_weight_shape(group, weight_np)
            weight_np = weight_np.transpose((1, 0, 2, 3))
        int8_weight = weight_quant_np(
            weight_np,
            self.records.get(object_name).get('weight_scale'),
            self.records.get(object_name).get('weight_offset'),
            self.num_bits)
        if type(object_module).__name__ == FAKE_CONV_TRANSPOSE2D:
            weight_offset = weight_offset.astype(np.float32).reshape(
                [1, -1, 1, 1])
        if type(object_module).__name__ == FAKE_CONV2D:
            weight_offset = weight_offset.astype(np.float32).reshape(
                [-1, 1, 1, 1])
        if type(object_module).__name__ == FAKE_CONV3D:
            weight_offset = weight_offset.astype(np.float32).reshape(
                [-1, 1, 1, 1, 1])

        int9_weight = int8_weight.astype(np.float32) - weight_offset
        if type(object_module).__name__ == FAKE_CONV_TRANSPOSE2D:
            int9_weight = int9_weight.transpose((1, 0, 2, 3))
            group = object_module.sub_module.groups
            weight_np = adjust_deconv_weight_shape(group, int9_weight)
        int9_weight = int9_weight.reshape(ori_weight_shape)
        if is_cuda:
            object_module.sub_module.weight = Parameter(Tensor(int9_weight).cuda())
        else:
            object_module.sub_module.weight = Parameter(Tensor(int9_weight))

        LOGGER.logd("Fakequant weight from float32 to int9 for module '{}' " \
            "success!".format(object_name), 'WeightFakequantModulePass')
