#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace AscendWeightQuant to fakeqaunt 'WeightQuant' with onnx's ops.

"""
import numpy as np

from amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass
from amct_pytorch.utils.log import LOGGER
from amct_pytorch.utils.onnx_initializer_util import TensorProtoHelper
from amct_pytorch.utils.quant_node import QuantOpInfo


class ReplaceBiasQuantPass(BaseFusionPass):
    """
    Function: Fakequant weight from int8 to int9
    APIs: match_pattern, do_pass
    """
    def __init__(self, records):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records

    def match_pattern(self, node):
        """
        Function: Match pattern of node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.name not in self.records:
            return False

        if node.type == 'AveragePool':
            return False

        _, _, bias_index = QuantOpInfo.get_quant_index(node)
        if bias_index and len(node.input_anchors) > bias_index:
            return True

        return False

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Do actual quantization and node's weight is changed to int9.
        Parameters:
            graph: graph structure
            object_node: node to process
            model: torch.nn.Module, the model to be modified. if it's
                None, the gaph will be modified.
        Return: None
        """
        _, _, bias_index = QuantOpInfo.get_quant_index(object_node)
        num_bits = self.get_dst_type(object_node.name)

        if num_bits == 4:
            cast_input_anchor = object_node.get_input_anchor(bias_index)
            cast_node = cast_input_anchor.get_peer_output_anchor().node
            bias_input_anchor = cast_node.get_input_anchor(0)
            bias_node = bias_input_anchor.get_peer_output_anchor().node

            # remove input links
            graph.remove_edge(bias_node, 0, cast_node, 0)
            # remove output links
            output_anchor = cast_node.get_output_anchor(0)

            peer_input_anchors = []
            for input_anchor in output_anchor.get_peer_input_anchor():
                peer_input_anchors.append(input_anchor)

            for input_anchor in peer_input_anchors:
                peer_input_node = input_anchor.node
                input_index = input_anchor.index
                graph.remove_edge(cast_node, 0, peer_input_node, input_index)
                graph.add_edge(bias_node, 0, peer_input_node, input_index)

            graph.remove_node(cast_node)

        if bias_index and len(object_node.input_anchors) > bias_index:
            bias_input_anchor = object_node.get_input_anchor(bias_index)
            bias_param = bias_input_anchor.get_peer_output_anchor().node

            bias_helper = TensorProtoHelper(bias_param.proto)
            int32_bias = bias_helper.get_data()
            float_bias = int32_bias.astype(np.float32)

            bias_helper.clear_data()
            bias_helper.set_data(float_bias, 'FLOAT')

        LOGGER.logd(
            "Replace bias quant layer '{}' to fake weight quant layer success!".
            format(object_node.name), 'ReplaceBiasQuantPass')
