#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Convolution + BatchNorm fusion operation

"""
from amct_pytorch.optimizer.base_fusion_pass import BaseFusionPass
from amct_pytorch.module.quant_module import add_fake_antiquant
from amct_pytorch.utils.onnx_node_util import AttributeProtoHelper
from amct_pytorch.utils.log import LOGGER


class ReplaceAntiQuantPass(BaseFusionPass):
    """
    Function: Do "Convolution" layer and "BatchNorm" layer fusion operation
    APIs: match_pattern, do_pass, get_np_array_from_conv,
          get_np_array_from_bn, write_fused_weights_bias_back
    """
    def __init__(self, records):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records

    def match_pattern(self, node):
        """
        Function: Match pattern of "Conv" + "BatchNormalization" in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type != 'AscendAntiQuant':
            return False

        return True

    def do_pass(self, graph, object_node, model=None):
        """
        Function: Do actual "Convolution" layer and "BatchNorm" layer
                  fusion operation
        Parameters: graph: graph structure
                    object_node: node to process
                    model: torch.nn.Module, the model to be modified. if it's
                        None, the gaph will be modified.
        Return: None
        """
        # Step1: add a new_node
        quantized_layer_name = '.'.join(object_node.name.split('.')[0:-1])
        attr_helper = AttributeProtoHelper(object_node.proto)
        mul_node = add_fake_antiquant(graph, quantized_layer_name,
                                      attr_helper.get_attr_value('scale'))

        # remove input links
        in_index = 0
        in_anchor = object_node.get_input_anchor(in_index)
        peer_output_anchor = in_anchor.get_peer_output_anchor()
        peer_node = peer_output_anchor.node
        peer_output_anchor_index = peer_output_anchor.index
        graph.remove_edge(peer_node, peer_output_anchor_index,
                          object_node, in_index)
        graph.add_edge(peer_node, peer_output_anchor_index, mul_node, 0)
        # remove output links
        output_anchor = object_node.get_output_anchor(0)

        peer_input_anchors = list()
        for in_anchor in output_anchor.get_peer_input_anchor():
            peer_input_anchors.append(in_anchor)

        for in_anchor in peer_input_anchors:
            peer_input_node = in_anchor.node
            in_index = in_anchor.index
            graph.remove_edge(object_node, 0, peer_input_node, in_index)
            graph.add_edge(mul_node, 0, peer_input_node, in_index)

        graph.remove_node(object_node)

        LOGGER.logd(
            "Replace anti-quant layer '{}' to fake anti-quant "
            "layer '{}' success!".format(object_node.name,
                                         quantized_layer_name + '.fakequant'),
            'ReplaceAntiQuantPass')
