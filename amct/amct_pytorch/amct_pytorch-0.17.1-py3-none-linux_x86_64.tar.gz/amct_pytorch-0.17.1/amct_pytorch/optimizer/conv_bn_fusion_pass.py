#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Convolution + BatchNorm fusion operation

"""
import torch
from onnx import onnx_pb

from amct_pytorch.optimizer.base_module_fusion_pass import BaseModuleFusionPass
from amct_pytorch.utils.log import LOGGER
from amct_pytorch.utils.model_util import ModuleHelper
from amct_pytorch.utils.quant_node import QuantOpInfo
from amct_pytorch.utils.onnx_initializer_util import TensorProtoHelper
from amct_pytorch.utils.vars import torch_version_higher_than

LOW_TORCH_VERSION = '1.6.0'


class ConvBnFusionPass(BaseModuleFusionPass):
    """
    Function: Do "Conv2d" and "BatchNorm2d" fusion operation
    APIs: match_pattern, do_pass
    """
    def __init__(self, config):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseModuleFusionPass.__init__(self)

        self.config = config()
        self.structure = {}

    @staticmethod
    def is_fusionable_conv(conv_module, conv_name):
        """
        Function: check if the conv module can be fused
        Parameters:
        conv_module: conv module
        conv_name: name of the module
        Return: bool value which specifies wether the module can be fused
        """
        if type(conv_module).__name__ not in ('Conv2d', 'Conv3d'):
            return False
        if conv_module.padding_mode != 'zeros':
            LOGGER.logd('Can only do Conv+BN fusion of Conv that padding_mode '
                        '= "zeros", but "%s" is "%s"' % (
                            conv_name, conv_module.padding_mode),
                        'ConvBnFusionPass')
            return False
        return True

    def match_pattern(self, module, name, graph=None):
        """
        Function:Match the bn module to be fused in model
        Parameters:
            module: module to be matched
            name: module's name
            graph: graph structure
        Return: True: matched
                False: mismatch
        """
        # limit mod type and status
        if not isinstance(module, torch.nn.BatchNorm2d) and not isinstance(module, torch.nn.BatchNorm3d):
            return False
        if isinstance(module, torch.nn.BatchNorm3d) and \
            torch.__version__ != LOW_TORCH_VERSION and \
            not torch_version_higher_than(torch.__version__ , LOW_TORCH_VERSION):
            return False
        if not module.affine or not module.track_running_stats:
            LOGGER.logd(
                'Cannot do conv + bn:\'{}\' fuison for affine and ' \
                'track_running_stats must be True!'.format(name),
                'ConvBnFusionPass')
            return False

        # limit graph link
        try:
            bn_node = graph.get_node_by_name(name)
        except RuntimeError:
            LOGGER.logd('Cannot find module "%s" in graph, means it not used '
                        'in forward.' % (name))
            return False

        if len(bn_node.input_anchors) != 5:
            raise RuntimeError('BatchNorm node should only have 5 output ' \
                'actually have {}'.format(len(bn_node.input_anchors)))

        peer_out_anchor = bn_node.get_input_anchor(0).get_peer_output_anchor()
        conv_node = peer_out_anchor.node

        # return false if moudle is in training mode
        if module.training:
            LOGGER.logw(
                'Cannot do conv:\'{}\' + bn:\'{}\' fuison for training must be False! ' \
                'Conv + bn fusion process will be skipped.'.format(conv_node.name, name), \
                'ConvBnFusionPass')
            return False

        # If do Conv + BN fusion, conv must can only output to bn
        if len(conv_node.output_anchors) != 1 or \
            len(conv_node.get_output_anchor(0).get_peer_input_anchor()) != 1:
            return False
        if conv_node.type != 'Conv' or \
            conv_node.name in self.config.get_skip_fusion_layers():
            return False

        self.structure[name] = {'conv': conv_node.name}
        return True

    def do_pass(self, model, object_module, object_name, graph=None):
        """
        Function: Do actual "Convolution" layer and "BatchNorm" layer
                  fusion operation
        Parameters: model: torch.nn.Module, the model to be modified.
                    object_module: module to process
                    object_name: name of object_module
                    graph: graph structure
        Return: None
        """
        conv_name = self.structure.get(object_name).get('conv')
        # conv and bn must be in eval state
        try:
            conv_module = ModuleHelper(model).get_module(conv_name)
        except RuntimeError:
            LOGGER.logd('Cannot find "%s" in model, cannot do Conv+BN '
                        'fuison.' % (conv_name))
            return
        if not self.is_fusionable_conv(conv_module, conv_name):
            return
        checked_model = torch.quantization.fuse_modules(model, [[conv_name, object_name]])
        checked_module = ModuleHelper(checked_model).get_module(conv_name)
        if torch.isinf(checked_module.weight).any() or torch.isnan(checked_module.weight).any() or \
            torch.isinf(checked_module.bias).any() or torch.isnan(checked_module.bias).any():
            LOGGER.logw(f'Conv+BN fusion for {conv_name} skipped because data is abnormal after fusion.')
            return
        # delete bn in graph
        _delete_bn_from_graph(graph, conv_name, object_name)

        # fuse "bn + conv" in model
        torch.quantization.fuse_modules(model, [[conv_name, object_name]], inplace=True)

        # Set fused weights and bias back
        fused_conv_module = ModuleHelper(model).get_module(conv_name)
        fused_weight_raw = fused_conv_module.weight.cpu().detach().numpy().flatten().tolist()
        conv_node = graph.get_node_by_name(conv_name)
        weight_param = QuantOpInfo.get_weight_node(conv_node)
        weight_helper = TensorProtoHelper(weight_param.proto)
        # set weights data to graph
        weight_helper.clear_data()
        weight_helper.set_data(fused_weight_raw, 'FLOAT')

        # set bias data to graph
        fused_bias_tensor = fused_conv_module.bias.data
        fused_bias_raw = fused_bias_tensor.cpu().detach().numpy().flatten().tolist()
        if len(conv_node.input_anchors) <= 2:
            bias = None
        else:
            _, _, bias_index = QuantOpInfo.get_quant_index(conv_node)
            bias_input_anchor = conv_node.get_input_anchor(bias_index)
            bias_param = bias_input_anchor.get_peer_output_anchor().node
            bias_helper = TensorProtoHelper(bias_param.proto)
            bias = bias_helper.get_data()

        if bias is None:
            bias_tensor = onnx_pb.TensorProto()
            bias_tensor.name = '%s.bias' % (conv_name)
            bias_helper = TensorProtoHelper(bias_tensor)
            bias_helper.set_data(fused_bias_raw,
                                 type_string='FLOAT',
                                 dims=[fused_bias_tensor.numel()])
            conv_bias = graph.add_node(bias_tensor)
            conv_node.add_input_anchor('%s.sub_module.bias' % (conv_name))
            graph.add_edge(conv_bias, 0, conv_node, 2)
        else:
            bias_helper.clear_data()
            bias_helper.set_data(fused_bias_raw, 'FLOAT')

        LOGGER.logd(
            'Do conv:\'{}\' + bn:\'{}\' fuison success!'.format(conv_name, object_name), 'ConvBnFusionPass')


def _delete_bn_from_graph(graph, conv_name, bn_name):
    """Function: delete bn from graph"""
    # Step1: remove edge of BatchNorm
    conv_node = graph.get_node_by_name(conv_name)
    bn_node = graph.get_node_by_name(bn_name)
    node_scale = bn_node.get_input_anchor(1).get_peer_output_anchor().node
    node_b = bn_node.get_input_anchor(2).get_peer_output_anchor().node
    node_mean = bn_node.get_input_anchor(3).get_peer_output_anchor().node
    node_var = bn_node.get_input_anchor(4).get_peer_output_anchor().node
    # remove input links
    graph.remove_edge(conv_node, 0, bn_node, 0)
    graph.remove_edge(node_scale, 0, bn_node, 1)
    graph.remove_edge(node_b, 0, bn_node, 2)
    graph.remove_edge(node_mean, 0, bn_node, 3)
    graph.remove_edge(node_var, 0, bn_node, 4)
    # remove output links
    bn_peer_in_anchors = \
        bn_node.get_output_anchor(0).get_peer_input_anchor()
    bn_peer_input_nodes = []
    bn_peer_input_indexes = []
    for input_anchor in bn_peer_in_anchors:
        bn_peer_input_nodes.append(input_anchor.node)
        bn_peer_input_indexes.append(input_anchor.index)
    for index, element in enumerate(bn_peer_input_nodes):
        graph.remove_edge(bn_node, 0,
                          element, bn_peer_input_indexes[index])

    # Step2: Add link from conv to bn_peer_input_node
    for index, element in enumerate(bn_peer_input_nodes):
        graph.add_edge(conv_node, 0, element, bn_peer_input_indexes[index])
        if element.type == 'graph_anchor':
            conv_node.get_output_anchor(0).set_name(element.name)

    # Step3: Remove node from graph
    graph.remove_node(bn_node)

    # Step4: Remove initializer from graph
    graph.remove_initializer(node_scale)
    graph.remove_initializer(node_b)
    graph.remove_initializer(node_mean)
    graph.remove_initializer(node_var)
