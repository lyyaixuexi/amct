#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Operation functions for scale and offset record file

"""


import os
import sys
import functools
from google.protobuf import text_format
from .util import proto_float_to_python_float
from .files import create_empty_file

DBL_EPSILON = sys.float_info.epsilon


def record_weights_scale_offset(records, layer_name, scale, offset, num_bits=None):
    """
    Function: Write scale_w and offset_w to record file
    Parameters: records: ScaleOffsetRecord() object to write
                layer_name: layer name of scale_w, offset_w
                scale: vector of scale_w
                offset: vector of offset_w
    Return: None
    """
    done_flag = False
    for record in records.record:
        if record.key == layer_name:
            record.value.scale_w[:] = scale
            record.value.offset_w[:] = offset
            if num_bits is not None:
                record.value.dst_type = 'INT{}'.format(num_bits)
            done_flag = True
            break
    if not done_flag:
        record = records.record.add()
        record.key = layer_name
        record.value.scale_w[:] = scale
        record.value.offset_w[:] = offset
        if num_bits is not None:
            record.value.dst_type = 'INT{}'.format(num_bits)


def record_skip_status(records, layer_name, is_skip_fusion):
    """
    Function: Write scale_w and offset_w to record file
    Parameters: records: ScaleOffsetRecord() object to write
                layer_name: layer name of scale_w, offset_w
                scale: vector of scale_w
                offset: vector of offset_w
    Return: None
    """
    done_flag = False
    for record in records.record:
        if record.key == layer_name:
            record.value.skip_fusion = is_skip_fusion
            done_flag = True
            break
    if not done_flag:
        record = records.record.add()
        record.key = layer_name
        record.value.skip_fusion = is_skip_fusion


def read_weights_scale_offset(records, layer_name):
    """
    Function: Read scale_w and offset_w from record file
    Parameters: records: ScaleOffsetRecord() object to read
                layer_name: layer name of scale_w, offset_w
    Return: scale: vector of scale_w
            offset: vector of offset_w
    """
    done_flag = False
    scale = []
    offset = []
    for record in records.record:
        if record.key == layer_name:
            # Read scale_w from record file
            if not record.value.scale_w:
                raise RuntimeError("Cannot find scale_w of layer '{}' " \
                    "in record file".format(layer_name))
            scale.extend(record.value.scale_w)
            # Read offset_w from record file
            if not record.value.offset_w:
                raise RuntimeError("Cannot find offset_w of layer \'{}\' " \
                    "in record file".format(layer_name))
            offset.extend(record.value.offset_w)
            done_flag = True
            break
    if not done_flag:
        raise RuntimeError("Cannot find layer '{}' in record " \
            "file".format(layer_name))
    return scale, offset


def record_shift_bits(records, layer_name, shift_bit):
    """
    Function: Write shift_bit to record file
    Parameters: records: ScaleOffsetRecord() object to write
                layer_name: layer name of scale_w, offset_w
                shift_bit: vector of shift_bit
    Return: None
    """
    done_flag = False
    for record in records.record:
        if record.key == layer_name:
            record.value.shift_bit[:] = shift_bit
            done_flag = True
            break
    if not done_flag:
        record = records.record.add()
        record.key = layer_name
        record.value.shift_bit[:] = shift_bit


def read_shift_bits(records, layer_name):
    """
    Function: Read the number of bit to shift from record file
    Parameters: records: ScaleOffsetRecord() object to read
                layer_name: layer name to read shift_bits
    Return: : shift_bits: the number of bit to shift
    """
    shift_bits = []
    for record in records.record:
        if record.key == layer_name:
            if record.value.shift_bit:
                shift_bits.extend(record.value.shift_bit)
            break
    else:
        raise RuntimeError("Cannot find layer '{}' in record "
                           "file".format(layer_name))

    return shift_bits


def record_activation_scale_offset(records, layer_name, scale, offset, num_bits=None):
    """
    Function: Write scale_w and offset_w to record file
    Parameters: records: ScaleOffsetRecord() object to write
                layer_name: layer name of scale_w, offset_w
                scale: vector of scale_w
                offset: vector of offset_w
    Return: None
    """
    key_found = False
    for record in records.record:
        if record.key == layer_name:
            record.value.scale_d = scale
            record.value.offset_d = offset
            if num_bits is not None:
                record.value.dst_type = 'INT{}'.format(num_bits)
            key_found = True
            break
    if not key_found:
        record = records.record.add()
        record.key = layer_name
        record.value.scale_d = scale
        record.value.offset_d = offset
        if num_bits is not None:
            record.value.dst_type = 'INT{}'.format(num_bits)


def read_activation_scale_offset(records, layer_name):
    """
    Function: Read scale_d and offset_d from record file
    Parameters: records: ScaleOffsetRecord() object to read
                layer_name: layer name of scale_d, offset_d
    Return: scale: scalar of scale_d
            offset: scalar of offset_d
    """
    done_flag = False
    scale = 1
    offset = 0
    for record in records.record:
        if record.key == layer_name:
            # Read scale_d from record file
            if not record.value.HasField('scale_d'):
                raise RuntimeError("Cannot find scale_d of layer '{}' " \
                    "in record file".format(layer_name))
            scale = record.value.scale_d
            # Read offset_d from record file
            if not record.value.HasField('offset_d'):
                raise RuntimeError("Cannot find offset_d of layer '{}' " \
                    "in record file".format(layer_name))
            offset = record.value.offset_d
            done_flag = True
            break
    if not done_flag:
        raise RuntimeError("Cannot find layer '{}' in record " \
            "file".format(layer_name))
    return scale, offset


def record_dmq_balancer_factor(records, layer_name, factor):
    """
    Function: Write tensor_balance_factor to record file
    Parameters: records: ScaleOffsetRecord() object to write
                layer_name: layer name of tensor_balance_factor
                factor: vector of tensor_balance_factor
    Return: None
    """
    done_flag = False
    for record in records.record:
        if record.key == layer_name:
            record.value.tensor_balance_factor[:] = factor
            done_flag = True
            break
    if not done_flag:
        record = records.record.add()
        record.key = layer_name
        record.value.tensor_balance_factor[:] = factor


def create_empty_record(records, layer_name):
    """
    Function: create empty record for layer with name of layer_name
    param:records, proto type, add a new record for records
    param:layer_name, string, key of new record
    """
    for record in records.record:
        if record.key == layer_name:
            raise RuntimeError("the {} has already in records".format(layer_name))
    record = records.record.add()
    record.key = layer_name
    record.value.Clear()


class ScaleOffsetRecordHelper():
    """
    Utility class for reading, recording, modifying, and saving.

    Args:
        scale_offset_record (proto): proto message for scale and offset.
    """
    def __init__(self, scale_offset_record):
        self._record_file = None
        self._records = scale_offset_record()

    @property
    def keys(self):
        """
        Enumerates all keys.

        Returns:
            list: a list of keys string.
        """
        keys = list()
        for record in self._records.record:
            keys.append(record.key)
        return keys

    @property
    def records(self):
        """Return the instance itself"""
        return self._records

    @staticmethod
    def check_record(key, record_value):
        """
        Check if the record is valid.

        Args:
            key (str): a string of layer name.
            record_value : a record object.

        Returns:
            bool: whether the record is valid.
        """
        # scale_w and offset_w can be a vector, but must have same length
        if len(record_value.scale_w) != len(record_value.offset_w):
            raise RuntimeError('{} scale_w and offset_w must be same length'.format(key))

        # current layer is quant layer, need check parameters' legality
        scales = [proto_float_to_python_float(record_value.scale_d)]
        scales.extend([proto_float_to_python_float(value) for value in record_value.scale_w])
        for scale in scales:
            # scale_d and scale_w must in range DBL_EPSILON, 1/DBL_EPSILON
            if scale < DBL_EPSILON or scale > 1 / DBL_EPSILON:
                raise ValueError('Exist illegal scale {} in "{}"'.format(scale, key))
        # offset_d must in range -128, 127
        if record_value.offset_d < -128 or record_value.offset_d > 127:
            raise ValueError('Exist illegal offset_d {} in "{}"'.format(record_value.offset_d, key))
        # offset_w must be zero
        for offset in record_value.offset_w:
            if offset != 0:
                raise ValueError('Offset_w must be 0, {} in "{}"'.format(offset, key))
        return True

    def init_from_file(self, record_file):
        """
        Initialize from a file.

        Args:
            record_file (str): a string of record file path.
        """
        record_file = os.path.realpath(record_file)
        self._record_file = record_file
        with open(record_file, 'r') as fid:
            pbtxt_string = fid.read()
            try:
                text_format.Merge(pbtxt_string, self._records)
            except text_format.ParseError as e:
                raise RuntimeError(
                    "the record_file{%s} cannot be parsered, please ensure "\
                    "it matches with scale_offset_record.proto!"
                    % (record_file)) from e
        return self

    def init(self, records):
        """
        Initialize from an ScaleOffsetRecord object.

        Args:
            records (ScaleOffsetRecord): a instance of record.
        """
        self._records = records
        return self

    def merge(self, records):
        """
        Merge records into the current instance.

        Args:
            records (ScaleOffsetRecord): a instance of record.
        """
        for record in records.record:
            if self.has_key(record.key):
                raise RuntimeError('Merge failed, alrady has key "%s"' % record.key)
            self._records.record.append(record)

    def has_key(self, key):
        """
        Determines whether the instance has the key.

        Args:
            key (str): a string of layer name.

        Returns:
            bool: whether the key exists.
        """
        for record in self._records.record:
            if record.key == key:
                return True
        return False

    def delete_key(self, key):
        """
        Delete the key from the instance.

        Args:
            key (str): a string of layer name.

        Returns:
            bool: whether the key has been deleted.
        """
        for index, record in enumerate(self._records.record):
            if record.key == key:
                del self._records.record[index]
                return True
        return False

    def get_record(self, key):
        """
        Get the value of the key.

        Args:
            key (str): a string of layer name.

        Returns:
            dict: the value of the key.
        """
        for record in self._records.record:
            if record.key == key:
                return record.value
        return None

    def record_weights_scale_offset(self, key, scale, offset):
        """
        Record scale and offset of the layer's weight.

        Args:
            key (str): the layer name.
            scale (list): a list of scale value.
            offset (list): a list of offset value.
        """
        done_flag = False
        for record in self.records.record:
            if record.key == key:
                record.value.scale_w[:] = scale
                record.value.offset_w[:] = offset
                done_flag = True
                break
        if not done_flag:
            record = self.records.record.add()
            record.key = key
            record.value.scale_w[:] = scale
            record.value.offset_w[:] = offset

    def record_skip_status(self, key, is_skip_fusion):
        """
        Record whether the layer skips fusion.

        Args:
            key (str): the layer name.
            is_skip_fusion (bool): whether skips fusion.
        """
        done_flag = False
        for record in self.records.record:
            if record.key == key:
                record.value.skip_fusion = is_skip_fusion
                done_flag = True
                break
        if not done_flag:
            record = self.records.record.add()
            record.key = key
            record.value.skip_fusion = is_skip_fusion

    def read_weights_scale_offset(self, key):
        """
        Read scale and offset of the layer's weight.

        Args:
            key (str): the layer name.

        Returns:
            list: a list of scale value.
            list: a list of offset value.
        """
        done_flag = False
        scale = []
        offset = []
        for record in self.records.record:
            if record.key == key:
                # Read scale_w from record file
                if not record.value.scale_w:
                    raise RuntimeError("Cannot find scale_w of layer '{}' " \
                        "in record file".format(key))
                scale.extend(record.value.scale_w)
                # Read offset_w from record file
                if not record.value.offset_w:
                    raise RuntimeError("Cannot find offset_w of layer \'{}\' " \
                        "in record file".format(key))
                offset.extend(record.value.offset_w)
                done_flag = True
                break
        if not done_flag:
            raise RuntimeError("Cannot find layer '{}' in record file".format(key))
        return scale, offset

    def record_shift_bits(self, key, shift_bit):
        """
        Record the shift bit of layer.

        Args:
            key (str): the layer name.
            shift_bit (list): a list of shift bit.
        """
        done_flag = False
        for record in self.records.record:
            if record.key == key:
                record.value.shift_bit[:] = shift_bit
                done_flag = True
                break
        if not done_flag:
            record = self.records.record.add()
            record.key = key
            record.value.shift_bit[:] = shift_bit

    def read_shift_bits(self, key):
        """
        Read the number of bit to shift from record file.

        Args:
            key (str): the layer name.

        Returns:
            int: shift bit value.
        """
        shift_bits = []
        for record in self.records.record:
            if record.key == key:
                if record.value.shift_bit:
                    shift_bits.extend(record.value.shift_bit)
                break
        else:
            raise RuntimeError("Cannot find layer '{}' in record file".format(key))

        return shift_bits

    def record_activation_scale_offset(self, key, scale, offset):
        """
        Reccord scale and offset of layer's activation.

        Args:
            key (str): the layer name.
            scale (float): the scale value.
            offset (int): the offset value.
        """
        key_found = False
        for record in self.records.record:
            if record.key == key:
                record.value.scale_d = scale
                record.value.offset_d = offset
                key_found = True
                break

        if not key_found:
            record = self.records.record.add()
            record.key = key
            record.value.scale_d = scale
            record.value.offset_d = offset

    def read_activation_scale_offset(self, key):
        """
        Read scale and offset of the layer's activation.

        Args:
            key (str): the layer name.

        Returns:
            float: the scale value.
            int: the offset value.
        """
        done_flag = False
        scale = 1
        offset = 0
        for record in self.records.record:
            if record.key == key:
                # Read scale_d from record file
                if not record.value.HasField('scale_d'):
                    raise RuntimeError("Cannot find scale_d of layer '{}' " \
                        "in record file".format(key))
                scale = record.value.scale_d
                # Read offset_d from record file
                if not record.value.HasField('offset_d'):
                    raise RuntimeError("Cannot find offset_d of layer '{}' " \
                        "in record file".format(key))
                offset = record.value.offset_d
                done_flag = True
                break
        if not done_flag:
            raise RuntimeError("Cannot find layer '{}' in record " \
                "file".format(key))
        return scale, offset

    def update_record(self):
        """Update the record file with the latest records."""
        if self._record_file is None:
            raise RuntimeError('Cannot update record without record file')

        with open(self._record_file, "w") as record_write_file:
            record_write_file.write(text_format.MessageToString(
                self._records, as_utf8=True))

    def dump(self, record_file):
        """
        Write records to the record file.

        Args:
            record_file (str): a string of record file path.
        """
        with open(record_file, "w") as record_write_file:
            record_write_file.write(text_format.MessageToString(
                self._records, as_utf8=True))


def save_nuq_quant_layer_names(nuq_config, save_path):
    """ save non uniform layer name record file"""
    save_dir, save_prefix = os.path.split(save_path)
    save_dir = '.' if save_dir == '' else save_dir
    nuq_quant_layers = list(nuq_config.keys())
    if len(nuq_quant_layers) == 0:
        return None

    file_name = os.path.join(save_dir, save_prefix + '_nuq_layer_record.txt')
    file_name = create_empty_file(file_name, check_exist=True)
    line = functools.reduce(lambda x, y: x + ';' + y, nuq_quant_layers)
    with open(file_name, 'w') as nuq_record_file:
        nuq_record_file.write(line)
    return file_name
