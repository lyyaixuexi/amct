#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

ARQ quantize algorithm
"""
import ctypes
import collections

from .base_quant_algo import BaseQuantizeAlgorithm
from .base_quant_algo import FloatData
from .base_quant_algo import IntData


class ArqParam(ctypes.Structure):# pylint: disable=too-few-public-methods
    """
    Function: Data structure for c++ 'ArqParam'
    """
    _fields_ = [("numBits", ctypes.c_uint),
                ("channelWise", ctypes.c_bool),
                ("withOffset", ctypes.c_bool)]


ArqProcessedParams = collections.namedtuple('ArqProcessedParams',
                                            ['data_p', 'arq_params', 'scale_offset_size', 'scale_offset_data'])


class ArqAlgoBase(BaseQuantizeAlgorithm):
    """Function: The implement of ARQ quantize algorithm
       APIs: preprocess_params, quantize_data
    """
    _instance = None
    _lib_loader = None
    _enable_gpu = True

    def __new__(cls, *args, **kw): # pylint: disable=W0613
        if cls._instance is None:
            cls._instance = object.__new__(cls)
        return cls._instance

    def __init__(self, lib_loader, enable_gpu=True):
        ArqAlgoBase._lib_loader = lib_loader
        ArqAlgoBase._enable_gpu = enable_gpu

    @classmethod
    def quantize_data(cls, data, shape, args, mode='CPU'):
        """Do arq quantize.
           Parameters: data(array): data to be quantized
                       shape(list/tuple): shape of data, should be 2 dims(fc)
                                          or 4dims(conv, deconv, lstm...)
                       args: quantize algorithm parameters, such as 'num_bits',
                             'channel_wise', 'with_offset'
           Return: scale, offset: quantize factor
        """
        if cls._lib_loader is None:
            raise RuntimeError(" The algorithm lib is None!")

        data_p, arq_params, scale_offset_size, scale_offset_data = \
            ArqAlgoBase.preprocess_params(data, shape, args)

        if mode == 'CPU':
            ret = cls._lib_loader.lib.ArqQuantDoublePython(
                data_p, arq_params.get('data_length'),
                ArqParam(arq_params.get('num_bits'),
                         arq_params.get('channel_wise'),
                         arq_params.get('with_offset')), scale_offset_data[0],
                scale_offset_data[1])
        else:
            if not cls._enable_gpu:
                raise RuntimeError("mode {} is not supported!".format(mode))
            ret = cls._lib_loader.lib.ArqQuantDoublePythonGPU(
                data_p, arq_params.get('data_length'),
                ArqParam(arq_params.get('num_bits'),
                         arq_params.get('channel_wise'),
                         arq_params.get('with_offset')), scale_offset_data[0],
                scale_offset_data[1])
        if ret != 0:
            raise RuntimeError(
                "Do ArqQuant failed, error code: {}".format(ret))

        scale_size = arq_params.get('scale_size')
        scale = [scale_offset_size[0][i] for i in range(scale_size)]
        offset = [scale_offset_size[1][i] for i in range(scale_size)]

        return scale, offset

    @staticmethod
    def preprocess_params(data, shape, args):
        """Extract and check input parameters, then convert them to cTypes's
           data type.
        """
        ArqAlgoBase.check_paramters(data, shape, args)
        arq_params = {}
        arq_params['data_length'] = ArqAlgoBase.get_data_length(shape)
        arq_params['channel_wise'] = ArqAlgoBase.extract_quant_param(
            args, 'channel_wise', bool)
        arq_params['with_offset'] = ArqAlgoBase.extract_quant_param(
            args, 'with_offset', bool)
        arq_params['num_bits'] = ArqAlgoBase.extract_quant_param(
            args, 'num_bits', int)

        if arq_params.get('channel_wise'):
            scale_size = shape[0]
        else:
            scale_size = 1
        arq_params['scale_size'] = scale_size

        scale_offset_size = [(ctypes.c_float * scale_size)(),
                             (ctypes.c_int * scale_size)()]
        scale_offset_data = \
            [FloatData(scale_size, scale_offset_size[0]),
             IntData(scale_size, scale_offset_size[1])]

        data_p = ctypes.cast(data.buffer_info()[0],
                             ctypes.POINTER(ctypes.c_double))
        return ArqProcessedParams(data_p, arq_params, scale_offset_size, scale_offset_data)
