#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2023. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Base class for amct qat module

"""
from abc import ABCMeta, abstractmethod
import copy

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn, tensor
from torch.nn.parameter import Parameter

from amct_pytorch.utils.log import LOGGER
from amct_pytorch.common.utils.check_params import check_params
from amct_pytorch.custom_op.ifmr.ifmr import IFMR
from amct_pytorch.custom_op.utils import copy_tensor
from amct_pytorch.custom_op.utils import get_distribute_config
from amct_pytorch.custom_op.comp_module.comp_module_base import ActsQuantInfo
from amct_pytorch.custom_op.ulq_retrain.ulq_retrain import UlqRetrainFuncQAT
from amct_pytorch.custom_op.arq_retrain.arq_retrain import ArqRetrainFuncQAT
from amct_pytorch.custom_op.ulq_scale_retrain.ulq_scale_retrain import UlqScaleRetrainFuncQAT


class QATBase(metaclass=ABCMeta):
    """
    Function: Base class module for qat op.
    """
    _float_module = None
    _required_params = list()

    @check_params(layer_type=str,
                  device=(str, type(None)),
                  config=(dict, type(None)))
    def __init__(self, layer_type, device, config=None):
        self.layer_type = layer_type
        self.quant_device = device
        self.cur = 0
        if config is None:
            config = dict()
        if not isinstance(config, dict):
            raise TypeError(f'config should be none or dict, but your input is {type(config)}')
        self.retrain_enable = config.get('retrain_enable', True)
        self.retrain_data_config = config.get('retrain_data_config', dict())
        if not isinstance(self.retrain_data_config, dict):
            raise TypeError(
                f'retrain_data_config should be none or dict, but your input is {type(config)}')
        self.retrain_weight_config = config.get(
            'retrain_weight_config', dict())
        if not isinstance(self.retrain_weight_config, dict):
            raise TypeError(
                f'retrain_weight_config should be none or dict, but your input is {type(config)}')
        self.distribute_config = get_distribute_config()

        if not isinstance(self.retrain_data_config.get('clip_min'),
                          type(self.retrain_data_config.get('clip_max'))):
            raise TypeError(
                'clip_min and clip_max must be of the same data type. Please check your config.')

        if self.retrain_data_config.get('clip_max') is None:
            self.do_init = True
            self.retrain_data_config['clip_max'] = 1.0
            self.retrain_data_config['clip_min'] = -1.0
        else:
            self.do_init = False
        self.check_quantifiable()
        self._check_qat_config()
        self.num_bits = 8 if self.retrain_weight_config.get('wts_dst_type', 'INT8') == 'INT8' else 4
        self._register_qat_params(self)
        self.init_module = IFMR(layers_name=self.layer_type,
                                batch_num=self.retrain_data_config.get('batch_num', 1))

    @classmethod
    def _get_ori_op_params(cls, mod):
        """
        extract parameters from torch origin op.
        Args:
            mod (torch.nn.Module): a float module, either produced by torch.quantization utilities or directly from user
        """
        ori_op_params = {}
        err_params = list()
        for param in cls._required_params:
            if not hasattr(mod, param):
                err_params.append(param)
                continue
            ori_op_params[param] = getattr(mod, param)

        if err_params:
            raise RuntimeError(f'The following parameters are not found in the torch operator. {err_params}'\
                ' Check the _required_params parameter of the QAT operator.')
        return ori_op_params

    @classmethod
    def from_float(cls,
                   mod,
                   config=None):
        """turn a torch.nn.Module to custom qat operator

        Args:
            mod (torch.nn.module): a float module, either produced by torch.quantization utilities or directly from user
            config (dict, optional): config used in wts quant and act quant. Defaults to DEFAULT_QAT_CONF.

        Returns:
            torch.nn.Module: qat operator constructed based on mod input
        """
        if not type(mod) == cls._float_module:
            raise TypeError(
                f'{cls.__name__}.from_float can only works for '
                f'{cls._float_module.__name__}')
        ori_op_params = cls._get_ori_op_params(mod)
        if 'bias' in ori_op_params:
            ori_op_params['bias'] = ori_op_params.get('bias') is not None
        qat_op = cls(config=config, **ori_op_params)
        setattr(qat_op, 'weight', mod.weight)
        setattr(qat_op, 'bias', mod.bias)
        qat_op.to(mod.weight.device)
        LOGGER.logi(
            f'Convert {cls._float_module.__name__} to QAT op successfully.')
        return qat_op

    @staticmethod
    def _register_qat_params(module):
        """Register quantitative parameters
        """
        module.register_buffer('cur_batch', tensor(0))
        module.register_parameter('acts_clip_max',
                                  Parameter(tensor(module.retrain_data_config.get('clip_max'),
                                                   device=module.quant_device),
                                            requires_grad=True))
        module.register_parameter('acts_clip_min',
                                  Parameter(tensor(module.retrain_data_config.get('clip_min'),
                                                   device=module.quant_device),
                                            requires_grad=True))
        module.register_buffer('acts_clip_max_pre',
                               tensor(np.nan, device=module.quant_device))
        module.register_buffer('acts_clip_min_pre',
                               tensor(np.nan, device=module.quant_device))
        module.register_buffer('acts_scale',
                               tensor([np.nan], device=module.quant_device))
        module.register_buffer('acts_offset',
                               tensor([np.nan], device=module.quant_device))
        module.register_buffer('acts_offset_deploy',
                               tensor([0], dtype=torch.int8, device=module.quant_device))
        if module.retrain_weight_config.get('channel_wise', True):
            num_channel = module.out_channels
        else:
            num_channel = 1
        module.register_parameter('wts_scales',
                                  Parameter(tensor([np.nan]*num_channel,
                                                   device=module.quant_device),
                                            requires_grad=False))
        module.register_parameter('wts_offsets',
                                  Parameter(tensor([np.nan]*num_channel,
                                                   device=module.quant_device),
                                            requires_grad=False))
        module.register_buffer('wts_offsets_deploy',
                               tensor([0]*num_channel, dtype=torch.int8,
                                      device=module.quant_device))
        module.register_buffer('s_rec_flag',
                               tensor(module.retrain_weight_config.get('s_rec_flag', False),
                                      device=module.quant_device))

    @abstractmethod
    def check_quantifiable(self):
        """Check whether the ori op support quant on its params
        """
        pass

    @abstractmethod
    def forward(self):
        pass

    def _check_qat_config(self):
        err_types = []
        err_vals = []
        err_flag = False
        acts_params_restriction = {
            'dst_type': {'type': str, 'scope': ['INT8'], 'default': 'INT8'},
            'batch_num': {'type': int, 'scope': None, 'default': 1},
            'fixed_min': {'type': bool, 'scope': [True, False], 'default': False},
            'clip_max': {'type': float, 'scope': None, 'default': 1.0},
            'clip_min': {'type': float, 'scope': None, 'default': -1.0}
        }
        wts_params_restriction = {
            'dst_type': {'type': str, 'scope': ['INT8'], 'default': 'INT8'},
            'weights_retrain_algo': {'type': str, 'scope': ['arq_retrain', 'ulq_retrain'], 'default': 'arq_retrain'},
            'channel_wise': {'type': bool, 'scope': [True, False], 'default': True}
        }

        acts_dst_type = self.retrain_data_config.get('dst_type', 'INT8')
        wts_dst_type = self.retrain_weight_config.get('dst_type', 'INT8')

        if acts_dst_type != wts_dst_type:
            raise RuntimeError('The dst_type of weights and of activations must be the same.')

        for key, value in acts_params_restriction.items():
            param = self.retrain_data_config.get(key, value.get('default'))
            if not isinstance(param, value.get('type')):
                err_types.append((key, value.get('type'), type(param)))
            if value.get('scope') and param not in value.get('scope'):
                err_vals.append((key, value.get('scope'), param))

        for key, value in wts_params_restriction.items():
            param = self.retrain_weight_config.get(key, value.get('default'))
            if not isinstance(param, value.get('type')):
                err_types.append((key, value.get('type'), type(param)))
            if value.get('scope') and param not in value.get('scope'):
                err_vals.append((key, value.get('scope'), param))
        if err_types:
            err_flag = True
            LOGGER.loge('The following configuration data types are incorrect.')
            for err in err_types:
                LOGGER.loge(f'\t{err[0]} should be {err[1]}, but your input is {err[2]}.')
        if err_vals:
            err_flag = True
            LOGGER.loge('The following configurations are out of allowed range.')
            for err in err_vals:
                LOGGER.loge(f'\t{err[0]} should be in range {err[1]}, but your input is {err[2]}.')
        if err_flag:
            raise ValueError('The configuration you entered is incorrect.'
                             'Please check according to the preceding logs.')
        batch_num = self.retrain_data_config.get('batch_num', 1)
        if batch_num <= 0:
            raise ValueError(f'batch_num must be bigger than 0, but your input is {batch_num}.')
        clip_min = self.retrain_data_config.get('clip_min')
        clip_max = self.retrain_data_config.get('clip_max')

        if clip_min >= 0.0:
            raise ValueError(f'clip_min should be smaller than zero, but your input is {clip_min}.')
        if clip_max <= 0.0:
            raise ValueError(f'clip_max should be bigger than zero, but your input is {clip_max}.')

    def forward_qat(self, inputs):
        if self.retrain_enable:
            if self.do_init:
                self._acts_quant_init(inputs)
                quantized_acts = inputs
            else:
                quantized_acts = self._acts_quant(inputs)
            quantized_weights = self._wts_quant()
            if self.cur < 100:
                self.cur += 1
                self.cur_batch += 1
        else:
            quantized_acts, quantized_weights = inputs, self.weight
        return quantized_acts, quantized_weights

    def _wts_quant(self):
        """do weight quant using arq or ulq algo based on config
        """
        wts_quant_dict = {
            'arq_retrain': self._wts_quant_arq,
            'ulq_retrain': self._wts_quant_ulq
        }
        weights_retrain_algo = self.retrain_weight_config.get('weights_retrain_algo', 'arq_retrain')
        quantized_weight, scales, offsets = \
            wts_quant_dict.get(weights_retrain_algo)()

        with torch.no_grad():
            copy_tensor(self.wts_scales, scales)
            copy_tensor(self.wts_offsets, offsets)
            copy_tensor(self.wts_offsets_deploy, offsets.to(torch.int8))
        return quantized_weight

    def _wts_quant_arq(self):
        """do weight quant using arq algo
        """
        wts_param = {
            'num_bits': self.num_bits,
            'channel_wise': self.retrain_weight_config.get('channel_wise', True),
            'with_offset': False,
            'module_type': self.layer_type,
            'module': self
        }
        quantized_weight, scale, offset = ArqRetrainFuncQAT.apply(self.weight,
                                                                  self.wts_scales,
                                                                  self.wts_offsets,
                                                                  wts_param,
                                                                  self.wts_offsets_deploy)
        return quantized_weight, scale, offset

    def _wts_quant_ulq(self):
        """do weight quant using ulq algo
        """
        wts_param = {
            'num_bits': self.num_bits,
            'channel_wise': self.retrain_data_config.get('channel_wise', True),
            'with_offset': False,
            'module_type': self.layer_type,
            's_rec_flag': self.retrain_data_config.get('s_rec_flag', False),
            'arq_init': True,
            'module': self
        }
        quantized_weight, scale, offset = UlqScaleRetrainFuncQAT.apply(self.weight,
                                                                       self.wts_scales,
                                                                       self.wts_offsets,
                                                                       wts_param,
                                                                       self.cur_batch,
                                                                       self.wts_offsets_deploy
                                                                       )
        return quantized_weight, scale, offset

    def _acts_quant_init(self, inputs):
        """do activations quant in the first batch
        """
        is_init, scale, offset, clip_max, clip_min = self.init_module.forward(inputs)
        if is_init:
            clip_min = -(offset + 2 ** (self.num_bits - 1)) * scale
            max_limits = 2 ** self.num_bits - 1
            clip_max = scale * max_limits + clip_min

            # sync in ddp mode
            world_size = self.distribute_config.get('world_size')
            process_group = self.distribute_config.get('process_group')
            if self.distribute_config.get('need_sync'):
                clip_max_all = torch.empty(
                    world_size, 1, dtype=clip_max.dtype, device=clip_max.device)
                clip_min_all = torch.empty(
                    world_size, 1, dtype=clip_min.dtype, device=clip_min.device)

                clip_max_l = list(clip_max_all.unbind(0))
                clip_min_l = list(clip_min_all.unbind(0))

                clip_max_all_reduce = torch.distributed.all_gather(
                    clip_max_l, clip_max, process_group, async_op=True)
                clip_min_all_reduce = torch.distributed.all_gather(
                    clip_min_l, clip_min, process_group, async_op=True)

                # wait on the async communication to finish
                clip_max_all_reduce.wait()
                clip_min_all_reduce.wait()
                clip_max_tmp = clip_max_all.mean()
                clip_min_tmp = clip_min_all.mean()
                clip_max.data.copy_(clip_max_tmp.data)
                clip_min.data.copy_(clip_min_tmp.data)
            del self.init_module
        else:
            clip_min = inputs.min()
            clip_max = inputs.max()

        with torch.no_grad():
            copy_tensor(self.acts_scale, scale)
            copy_tensor(self.acts_offset, offset)
            copy_tensor(self.acts_offset_deploy, offset.to(torch.int8))
            copy_tensor(self.acts_clip_max, clip_max)
            copy_tensor(self.acts_clip_min, clip_min)
            copy_tensor(self.acts_clip_max_pre, clip_max)
            copy_tensor(self.acts_clip_min_pre, clip_min)

        self.do_init = not is_init

    def _acts_quant(self, inputs):
        """
        Call the core method of ulq_retrain.
        """
        need_sync = self.distribute_config.get('need_sync') and self.training
        act_param = {
            'num_bits': self.num_bits,
            'ifmr_init': False,
            'fixed_min': self.retrain_data_config.get('fixed_min', False),
            'acts_scale': self.acts_scale,
            'acts_offset': self.acts_offset_deploy
        }
        outputs, scale, offset, clip_max, clip_min = \
            UlqRetrainFuncQAT.apply(
                inputs, self.acts_clip_max, self.acts_clip_min,
                self.acts_clip_max_pre, self.acts_clip_min_pre,
                act_param, self.cur_batch,
                need_sync, self.distribute_config.get('process_group'),
                self.distribute_config.get('world_size')
            )
        # Update quantization related parameters.
        with torch.no_grad():
            copy_tensor(self.acts_scale, scale)
            copy_tensor(self.acts_offset, offset)
            copy_tensor(self.acts_offset_deploy, offset.to(torch.int8))
            copy_tensor(self.acts_clip_max, clip_max)
            copy_tensor(self.acts_clip_min, clip_min)
            copy_tensor(self.acts_clip_max_pre, clip_max)
            copy_tensor(self.acts_clip_min_pre, clip_min)
        return outputs
