/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief torch C++ backend of arq algorithm.
 *
 * @file arq_torch.cpp
 *
 * @version 1.0
 */

#include <vector>
#include <algorithm>

#include "arq_op.h"
#include "arq_kernel.h"
#include "utils_kernel.h"

using namespace util;

std::vector<torch::Tensor> ArqCali(
    torch::Tensor input,
    int numBits = 8,
    bool channelWise = true,
    bool withOffset = false)
{
    AmctCommon::ArqParam arqParam = {static_cast<unsigned int>(numBits), channelWise, withOffset};

    auto quantData = input.clone();
    torch::Tensor offset;
    torch::Tensor scale;

    if (channelWise) {
        scale = torch::zeros({input.sizes()[0]}).to(input.device());
        offset = torch::zeros({input.sizes()[0]}, torch::kInt32).to(input.device());
    } else {
        scale = torch::zeros({1}).to(input.device());
        offset = torch::zeros({1}, torch::kInt32).to(input.device());
    }
    Status status;
    quantData = quantData.contiguous();
    offset = offset.contiguous();
    scale = scale.contiguous();

#ifdef USE_CUDA
    if (quantData.is_cuda()) {
        torch::Tensor max = torch::zeros_like(scale);
        torch::Tensor min = torch::zeros_like(scale);
        const int deviceId = quantData.device().index();

        WeightQuantParam quantParam;
        quantParam.scale = scale.data_ptr<float>();
        quantParam.offset = offset.data_ptr<int>();
        quantParam.scaleNumber = static_cast<int>(scale.numel());
        quantParam.quantBits = numBits;
        quantParam.deviceId = deviceId;

        status = ArqQuantFunctor<util::GPUDevice, float>()(quantData.numel(), quantData.data_ptr<float>(),
            quantData.data_ptr<float>(), max.data_ptr<float>(), min.data_ptr<float>(), quantParam);
    } else {
#endif
        FloatData scaleData = {static_cast<uint32_t>(scale.numel()),  scale.data_ptr<float>()};
        IntData offsetData = {static_cast<uint32_t>(offset.numel()),  offset.data_ptr<int>()};

        status = ArqQuant(quantData.data_ptr<float>(), static_cast<uint32_t>(quantData.numel()),
            arqParam, scaleData, offsetData);
#ifdef USE_CUDA
    }
#endif
    torch::Tensor calibratedFlag = torch::scalar_tensor(status);

    return {calibratedFlag,
            scale,
            offset,
            quantData};
}

std::vector<torch::Tensor> ArqReal(
    torch::Tensor input,
    torch::Tensor scale,
    torch::Tensor offset,
    int numBits)
{
    AmctCommon::ArqParam arqParam = {static_cast<unsigned int>(numBits), true, false};

    auto quantData = input.clone();
    std::vector<char> int8DataRaw(quantData.numel());

    if (quantData.is_cuda()) {
        quantData = quantData.cpu();
        scale = scale.cpu();
        offset = offset.cpu();
    }
    quantData = quantData.contiguous();
    scale = scale.contiguous();
    offset = offset.contiguous();
    FloatData scaleData = {static_cast<uint32_t>(scale.numel()),  scale.data_ptr<float>()};
    IntData offsetData = {static_cast<uint32_t>(offset.numel()),  offset.data_ptr<int>()};

    Status status = AmctCommon::ArqQuantReal(quantData.data_ptr<float>(), static_cast<uint32_t>(quantData.numel()),
        arqParam, scaleData, offsetData, int8DataRaw.data());

    torch::Tensor int8Data = torch::from_blob(int8DataRaw.data(), input.sizes(), torch::kUInt8).to(torch::kInt8);
    torch::Tensor quantizedFlag = torch::scalar_tensor(status);
    return {
        quantizedFlag,
        int8Data};
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("arq_cali", &ArqCali, "ARQ calibration to find scale and offset");
    m.def("arq_real", &ArqReal, "ARQ real to quant input to int8");
}
