/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief torch C++ backend api of ifmr algorithm.
 *
 * @file ifmr_torch.cpp
 *
 * @version 1.0
 */

#include <vector>
#include <cfloat>
#include <sstream>
#include <algorithm>
#include <unordered_map>

#include "ifmr_op.h"
#include "util_op.h"
#include "ifmr.h"
#include "ifmr_kernel.h"
#include "utils_kernel.h"

using namespace util;

std::vector<torch::Tensor> IfmrForward(torch::Tensor input,
                                       const int deviceId,
                                       int num_bits,
                                       bool with_offset,
                                       float maxPercentile,
                                       float minPercentile,
                                       float search_start,
                                       float search_end,
                                       float search_step)
{
    torch::Tensor calibratedFlag;
    torch::Tensor scaleTensor;
    torch::Tensor offsetTensor;

    // Move data to vector format
    std::vector<float> accumulatedData;
    TensorToVector(input, accumulatedData);

    Status statusCode;
    float scale = 1.0;
    int offset = 0;

#ifdef USE_CUDA
    if (deviceId < 0) {
#endif
        AmctCommon::IfmrParam ifmrParam = {0, static_cast<unsigned int>(num_bits), with_offset,
            false, search_start, search_end, search_step,  maxPercentile, minPercentile};

        FloatData scaleData = {1,  &scale};
        IntData offsetData = {1,  &offset};

        // Calibration kernel function
        statusCode = AmctCommon::IfmrQuant(accumulatedData.data(), accumulatedData.size(),
            ifmrParam, scaleData, offsetData);

        calibratedFlag = torch::scalar_tensor(statusCode);
        scaleTensor = torch::scalar_tensor(scale);
        offsetTensor = torch::scalar_tensor(offset);

#ifdef USE_CUDA
    } else {
        const std::string deviceString = getDeviceName(deviceId);
        scaleTensor = torch::scalar_tensor(scale);
        offsetTensor = torch::scalar_tensor(offset).to(torch::kInt32);

        input = input.to(deviceString).contiguous();
        scaleTensor = scaleTensor.to(deviceString);
        offsetTensor = offsetTensor.to(deviceString);
        torch::Tensor quantError =  torch::zeros_like(input).contiguous();

        AmctCommon::IfmrQuantParam ifmrParam = {num_bits, with_offset,
            maxPercentile, minPercentile, search_start, search_end, search_step};

        AmctCommon::DataQuantParam<float> quantParam;
        quantParam.scale = scaleTensor.data_ptr<float>();
        quantParam.offset = offsetTensor.data_ptr<int>();
        quantParam.scaleCpu = &scale;
        quantParam.offsetCpu = &offset;
        quantParam.ifmrData = input.data_ptr<float>();
        quantParam.quantError = quantError.data_ptr<float>();
        quantParam.deviceId = deviceId;

        // Calibration kernel function
        statusCode = AmctCommon::IfmrQuantFunctor<util::GPUDevice, float>()(accumulatedData, ifmrParam, quantParam);

        calibratedFlag = torch::scalar_tensor(statusCode);
    }
#endif
    torch::Tensor clipMax = torch::scalar_tensor(0);
    torch::Tensor clipMin = torch::scalar_tensor(0);
    clipMax = clipMax.mul_(ZERO).add_(ONE).mul_(pow(BASENUM, num_bits - 1) - 1).sub_(offset).mul_(scale);
    clipMin = clipMin.mul_(ZERO).add_(ONE).mul_(pow(BASENUM, num_bits - 1)).add_(offset).mul_(-scale);
    return {calibratedFlag, scaleTensor, offsetTensor, clipMax, clipMin};
}

torch::Tensor IfmrBackward(torch::Tensor grad)
{
    return grad;
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("ifmr_forward", &IfmrForward, "IFMR forward");
    m.def("ifmr_backward", &IfmrBackward, "IFMR backward");
}
