/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief torch C++ backend of arq algorithm.
 *
 * @file bcp_op.cpp
 *
 * @version 1.0
 */

#include "bcp_op.h"
#include "util.h"
#include "bcp.h"

std::vector<torch::Tensor> Bcp(std::vector<torch::Tensor> inputs, std::vector<int> pruneAxis, BcpParam param)
{
    Status status = 0;
    std::vector<const float*> wgtPtrs(inputs.size(), nullptr);
    std::vector<int> wgtSizes(inputs.size(), 0);
    std::vector<int> innerJumps(inputs.size(), 1);

    for (size_t idx = 0; idx < inputs.size(); idx++) {
        inputs[idx] = inputs[idx].contiguous();
        wgtPtrs[idx] = inputs[idx].data_ptr<float>();
        wgtSizes[idx] = static_cast<int>(inputs[idx].numel());
        for (int axis = inputs[idx].dim() - 1; axis > pruneAxis[idx]; --axis) {
            innerJumps[idx] *=  inputs[idx].sizes()[axis];
        }
    }

    AmctCommon::PruneParam algoParam;
    algoParam.numChannels = inputs[0].sizes()[pruneAxis[0]];
    algoParam.pruneAxis = pruneAxis;
    algoParam.numSplits = param.pruneGroup;

    int grpLen = algoParam.numChannels / algoParam.numSplits;
    int dropNum = AmctCommon::CalPruneNum(algoParam.numChannels, param.pruneGroup, param.pruneRatio,
        param.ascendOptimized);
    std::vector<int> sizeSplits(algoParam.numSplits, grpLen);
    std::vector<int> dropNums(algoParam.numSplits, 0);
    for (size_t idx = 0; idx < dropNums.size(); idx++) {
        dropNums[idx] = dropNum / algoParam.numSplits;
    }
    algoParam.sizeSplits = sizeSplits;
    algoParam.dropNums = dropNums;

    // to int
    std::vector<float*> remainChannelsContainerPtrs(algoParam.numSplits+1, nullptr);
    torch::Tensor remainChannels = torch::ones({algoParam.numChannels}, torch::kFloat32).to(inputs[0].device());
    torch::Tensor remainChannelsAll = torch::ones({algoParam.numChannels}, torch::kFloat32).to(inputs[0].device());
    remainChannels = remainChannels.contiguous();
    remainChannelsAll = remainChannelsAll.contiguous();
    for (int idx = 0; idx < algoParam.numSplits; ++idx) {
        remainChannelsContainerPtrs[idx] = &remainChannels.data_ptr<float>()[idx*grpLen];
    }
    remainChannelsContainerPtrs[algoParam.numSplits] = remainChannelsAll.data_ptr<float>();

#ifdef USE_CUDA
    if (inputs[0].is_cuda()) {
        status = AmctCommon::ComputeRemainOut<util::GPUDevice, float>()(
            wgtPtrs, wgtSizes, innerJumps, algoParam,
            remainChannelsContainerPtrs);
    } else {
#endif
        status = AmctCommon::ComputeRemainOut<util::CPUDevice, float>()(
            wgtPtrs, wgtSizes, innerJumps, algoParam,
            remainChannelsContainerPtrs);
#ifdef USE_CUDA
    }
#endif

    torch::Tensor Flag = torch::scalar_tensor(status);
    return {Flag, remainChannels};
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("bcp", &Bcp, "Bcp to find pruen mask");

    py::class_<BcpParam>(m, "BcpParam")
        .def(py::init<float, uint, bool>())
        .def_readwrite("prune_ratio", &BcpParam::pruneRatio)
        .def_readwrite("prune_group", &BcpParam::pruneGroup)
        .def_readwrite("ascend_optimized", &BcpParam::ascendOptimized);
}
