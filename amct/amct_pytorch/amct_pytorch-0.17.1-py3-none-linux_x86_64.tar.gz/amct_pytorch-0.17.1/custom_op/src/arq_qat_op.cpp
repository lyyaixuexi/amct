/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief arq_retrain algorithm custom op C++ implement
 *
 * @file arq_retrain.cpp
 *
 * @version 1.0
 */

#include <vector>
#include <cfloat>
#include <algorithm>

#include "arq.h"
#include "arq_qat_op.h"
#include "arq_kernel.h"
#include "utils_kernel.h"

using namespace util;

Status WtsQATKernel(
    torch::Tensor &quantData,
    AmctCommon::ArqParam &arqParam,
    torch::Tensor &scale,
    torch::Tensor &offset)
{
    Status status;
#ifdef USE_CUDA
    if (quantData.is_cuda()) {
        torch::Tensor max = torch::zeros_like(scale);
        torch::Tensor min = torch::zeros_like(scale);
        const int deviceId = quantData.device().index();

        WeightQuantParam quantParam;
        quantParam.scale = scale.data_ptr<float>();
        quantParam.offset = offset.data_ptr<int>();
        quantParam.scaleNumber = static_cast<int>(scale.numel());
        quantParam.deviceId = deviceId;
        quantParam.quantBits = arqParam.numBits;

        status = ArqQuantFunctor<util::GPUDevice, float>()(quantData.numel(), quantData.data_ptr<float>(),
            quantData.data_ptr<float>(), max.data_ptr<float>(), min.data_ptr<float>(), quantParam);
    } else {
#endif
        IntData offsetData = {static_cast<uint32_t>(offset.numel()),  offset.data_ptr<int>()};
        FloatData scaleData = {static_cast<uint32_t>(scale.numel()),  scale.data_ptr<float>()};

        status = ArqQuant(quantData.data_ptr<float>(), static_cast<uint32_t>(quantData.numel()),
            arqParam, scaleData, offsetData);
#ifdef USE_CUDA
    }
#endif
    return status;
}


std::vector<torch::Tensor> ArqRetrainForward(
    torch::Tensor input,
    int numBits = 8,
    bool channelWise = true,
    bool withOffset = false)
{
    AmctCommon::ArqParam arqParam = {static_cast<unsigned int>(numBits), channelWise, withOffset};
    auto quantData = input.clone();

    torch::Tensor scale;
    torch::Tensor offset;
    if (channelWise) {
        scale = torch::zeros({input.sizes()[0]}).detach().to(input.device());
        offset = torch::zeros({input.sizes()[0]}, torch::kInt32).detach().to(input.device());
    } else {
        scale = torch::zeros({1}).to(input.device());
        offset = torch::zeros({1}, torch::kInt32).to(input.device());
    }
    scale = scale.contiguous();
    offset = offset.contiguous();
    quantData = quantData.contiguous();

    Status status = WtsQATKernel(quantData, arqParam, scale, offset);
    torch::Tensor calibratedFlag = torch::scalar_tensor(status);

    return {calibratedFlag,
            scale,
            offset,
            quantData};
}

torch::Tensor ArqRetrainBackward(
    torch::Tensor gradOutputs)
{
    return gradOutputs;
}


PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("arq_retrain_forward", &ArqRetrainForward, "ArqRetrain forward");
    m.def("arq_retrain_backward", &ArqRetrainBackward, "ArqRetrain backward");
}
