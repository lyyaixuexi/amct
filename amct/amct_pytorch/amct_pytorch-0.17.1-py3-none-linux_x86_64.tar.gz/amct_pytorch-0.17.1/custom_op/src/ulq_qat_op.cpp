/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief torch C++ backend api of ulq algorithm.
 *
 * @file ulq_retrain.cpp
 *
 * @version 1.0
 */

#include <vector>
#include <cfloat>
#include <algorithm>

#include "ulq_qat_op.h"
#include "ulq.h"
#include "ulq_kernel.h"
#include "utils_kernel.h"
#include "util_op.h"
#include "ifmr.h"
#include "ifmr_kernel.h"

using namespace util;

std::vector<torch::Tensor> UlqRetrainForward(
    torch::Tensor input, torch::Tensor clipMax, torch::Tensor clipMin, torch::Tensor clipMaxPre,
    torch::Tensor clipMinPre, short int deviceId, int numBits, bool fixedMin)
{
    torch::Tensor outputTensor = input.clone();

    if (fixedMin) {
        clipMin = clipMin.mul_(0);
    }

    if ((*clipMax.cpu().data_ptr<float>() - *clipMin.cpu().data_ptr<float>()) <= FLT_EPSILON) {
        clipMax = clipMaxPre;
        clipMin = clipMinPre;
    } else if (*clipMax.cpu().data_ptr<float>() < 0) {
        clipMax = clipMaxPre;
    } else if (*clipMin.cpu().data_ptr<float>() > 0) {
        clipMin = clipMinPre;
    }

    torch::Tensor scaleTensor = clipMax.sub(clipMin).div_(pow(BASENUM, numBits) - 1);
    torch::Tensor offsetTensor = -(clipMin.div(scaleTensor).round_().add_(pow(BASENUM, numBits - 1)));

#ifdef USE_CUDA
    if (deviceId == -1) {
#endif
        float scaleVal = *scaleTensor.cpu().data_ptr<float>();
        // add pow(BASENUM, numBits - 1) for fit the Ulq cpu function.
        int offsetVal = -(*offsetTensor.cpu().to(torch::kInt32).data_ptr<int>() + pow(BASENUM, numBits - 1));
        FloatData scaleData = {1,  &scaleVal};
        IntData offsetData = {1,  &offsetVal};
        AmctCommon::Ulq(input.data_ptr<float>(), outputTensor.cpu().data_ptr<float>(),
            static_cast<uint32_t>(outputTensor.numel()), scaleData, offsetData, numBits);
#ifdef USE_CUDA
    } else {
        scaleTensor = scaleTensor.cuda();
        offsetTensor = offsetTensor.to(torch::kInt32).cuda();
        Input<float> inputParam = {input.data_ptr<float>(), static_cast<int>(input.numel()),
            clipMax.data_ptr<float>(), clipMin.data_ptr<float>()};
        Output<float> outputParam = {outputTensor.data_ptr<float>(), scaleTensor.data_ptr<float>(),
            offsetTensor.data_ptr<int>()};

        Status statusCode = UlqFunctor<util::GPUDevice, float>()(inputParam, outputParam, numBits);
        if (statusCode != AmctCommon::SUCCESS) {
            LOG_ERROR("Run ULQ GPU function failed, please check!\n");
        }
    }
#endif
    return {outputTensor, scaleTensor, offsetTensor, clipMax, clipMin};
}

std::vector<torch::Tensor> UlqRetrainBackward(
    torch::Tensor input,
    torch::Tensor gradOutputs,
    torch::Tensor clipMax,
    torch::Tensor clipMin,
    int numBits)
{
    torch::Tensor gradInputs;
    torch::Tensor gradActsClipMax;
    torch::Tensor gradActsClipMin;

    torch::Tensor upperMask;
    torch::Tensor lowerMask;
    torch::Tensor roundTensor;
    torch::Tensor notRoundTensor;
    torch::Tensor quantError;

    torch::Tensor oneTensor = torch::scalar_tensor(1);
    torch::Tensor zeroTensor = torch::scalar_tensor(0);

    torch::Tensor scaleTensor = clipMax.sub(clipMin).div_(pow(BASENUM, numBits) - 1);
    torch::Tensor offsetTensor = clipMin.div(scaleTensor).round_();

    if (gradOutputs.is_cuda()) {
        oneTensor = oneTensor.cuda();
        zeroTensor = zeroTensor.cuda();
    }

    upperMask = at::where(input > scaleTensor.mul(offsetTensor.add(pow(BASENUM, numBits) - 1)),
                          oneTensor, zeroTensor);
    lowerMask = at::where(input < scaleTensor.mul(offsetTensor),
                          oneTensor, zeroTensor);

    notRoundTensor = at::where(upperMask > 0,
                               clipMin, input);
    notRoundTensor = at::where(lowerMask > 0,
                               clipMin, notRoundTensor);

    notRoundTensor = notRoundTensor.div_(scaleTensor);
    roundTensor = notRoundTensor.round();
    quantError = roundTensor.sub_(notRoundTensor).div_(pow(BASENUM, numBits) - 1);

    gradActsClipMax = quantError.add(upperMask).mul_(gradOutputs).sum();
    gradActsClipMin = quantError.mul(-1).add(lowerMask).mul_(gradOutputs).sum();

    gradInputs = at::where(upperMask.add_(lowerMask) < oneTensor, gradOutputs, zeroTensor);

    return {gradInputs, gradActsClipMax, gradActsClipMin};
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("ulq_retrain_forward", &UlqRetrainForward, "UlqRetrain forward");
    m.def("ulq_retrain_backward", &UlqRetrainBackward, "UlqRetrain backward");
}
