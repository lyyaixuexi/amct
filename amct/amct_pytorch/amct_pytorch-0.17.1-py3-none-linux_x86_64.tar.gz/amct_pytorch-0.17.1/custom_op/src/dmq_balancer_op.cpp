/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief torch C++ backend of arq algorithm.
 *
 * @file dmq_balancer_op.cpp
 *
 * @version 1.0
 */

#include "dmq_balancer_op.h"
#include <vector>
#include <algorithm>

#include "dmq_balance.h"
#include "util_op.h"
#include "utils_kernel.h"

using namespace util;

std::vector<torch::Tensor> DMQBalancerForward(torch::Tensor input,
                                              torch::Tensor weight,
                                              float migrationStrength,
                                              uint32_t channelNum)
{
    auto quantData = input.clone();
    auto quantWeight = weight.clone();

    Status status;
    quantData = quantData.contiguous();
    quantWeight = quantWeight.contiguous();

    FloatData actData = {static_cast<uint32_t>(quantData.numel()),  quantData.data_ptr<float>()};
    FloatData wtsData = {static_cast<uint32_t>(quantWeight.numel()),  quantWeight.data_ptr<float>()};
    torch::Tensor dmqFactor = torch::zeros({channelNum}).to(input.device());

#ifdef USE_CUDA
    if (quantData.is_cuda()) {
        status = AmctCommon::DMQBalanceGpu(
            actData, wtsData, migrationStrength, channelNum, dmqFactor.data_ptr<float>());
    } else {
#endif
        status = AmctCommon::DMQBalance(
            actData, wtsData, migrationStrength, channelNum, dmqFactor.data_ptr<float>());
#ifdef USE_CUDA
    }
#endif
    torch::Tensor dmqFlag = torch::scalar_tensor(status);
    return {dmqFlag, dmqFactor};
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("dmq_balancer_forward", &DMQBalancerForward, "DMQBalancer function");
}
