/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief ulq_scale_qat algorithm custom op C++ implement
 *
 * @file ulq_scale_qat.cpp
 *
 * @version 1.0
 */

#include <vector>
#include <cfloat>
#include <algorithm>

#include "ulq_scale_qat_op.h"
#include "fake_quant_kernel.h"
#include "arq_kernel.h"
#include "utils_kernel.h"
#include "util.h"
#include "util_op.h"


using namespace util;

const int COUTAXIS = 0;

template<class T>
    Status FakeQuantByAxis(T* data, const std::vector<int>& dims, const int64_t coutAxis,
        const int numBits, const QuantFactors& factors)
    {
        int64_t dataSize;
        if (util::GetLengthByDim(dims, dataSize) != AmctCommon::SUCCESS || dims.empty()) {
            LOG_ERROR("Find invalid dims, please check!");
            return AmctCommon::BAD_PARAMETERS_ERROR;
        }

        int64_t innerNum = 1;
        int64_t dimNum = static_cast<int64_t>(dims.size());
        for (int64_t innerIdx = coutAxis + 1; innerIdx < dimNum; innerIdx++) {
            innerNum *= static_cast<int64_t>(dims[innerIdx]);
        }
        int64_t coutDim = static_cast<int64_t>(dims[coutAxis]);

        T minValue = static_cast<T>(-pow(BINARY_BASE, numBits - 1));
        T maxValue = static_cast<T>(pow(BINARY_BASE, numBits - 1) - 1);
        // element-wisely fake-quant data
#pragma omp parallel for
        for (int64_t idx = 0; idx < dataSize; idx++) {
            // calculate the idx at cout dim
            int64_t coutIdx = (idx / innerNum) % coutDim;

            float currentScale = (factors.scale.length == 1) ? factors.scale.data[0] : factors.scale.data[coutIdx];
            int currentOffset = (factors.offset.length == 1) ? factors.offset.data[0] : factors.offset.data[coutIdx];

            T quantValue = static_cast<T>(round(data[idx] / currentScale) + currentOffset);
            if (quantValue < minValue) {
                quantValue = minValue;
            } else if (quantValue > maxValue) {
                quantValue = maxValue;
            }
            data[idx] = (quantValue - currentOffset)  * currentScale;
        }
        return AmctCommon::SUCCESS;
    }

template Status FakeQuantByAxis<float>(float*, const std::vector<int>&, const int64_t, const int, const QuantFactors&);

Status arqInitFunc(torch::Tensor &input, torch::Tensor &scale, torch::Tensor &offset,
    AmctCommon::ArqParam arqParam, bool sRecFlag)
{
    auto quantData = input.clone().contiguous();
    Status status = AmctCommon::SUCCESS;

#ifdef USE_CUDA
    if (quantData.is_cuda()) {
        scale = scale.cuda().contiguous();
        offset = offset.cuda().contiguous();

        torch::Tensor max = torch::zeros_like(scale);
        torch::Tensor min = torch::zeros_like(scale);
        WeightQuantParam quantParam;
        quantParam.scale = scale.data_ptr<float>();
        quantParam.offset =  offset.data_ptr<int>();
        quantParam.scaleNumber = static_cast<int>(scale.numel());
        quantParam.quantBits = static_cast<int>(arqParam.numBits);
        status = ArqQuantFunctor<util::GPUDevice, float>()(quantData.numel(), quantData.data_ptr<float>(),
            quantData.data_ptr<float>(), max.data_ptr<float>(), min.data_ptr<float>(), quantParam);
    } else {
#endif
        scale = scale.cpu().contiguous();
        offset = offset.cpu().contiguous();
        FloatData scaleData = {static_cast<uint32_t>(scale.numel()),  scale.data_ptr<float>()};
        IntData offsetData = {static_cast<uint32_t>(offset.numel()),  offset.data_ptr<int>()};

        status = ArqQuant(quantData.data_ptr<float>(), static_cast<uint32_t>(quantData.numel()),
            arqParam, scaleData, offsetData);
#ifdef USE_CUDA
    }
#endif
    scale = sRecFlag ? scale.reciprocal_() : scale;
    return status;
}

std::vector<torch::Tensor> UlqScaleRetrainForward(
    torch::Tensor input,
    torch::Tensor scale,
    torch::Tensor offset,
    int numBits,
    bool channelWise,
    bool arqInit,
    bool sRecFlag)
{
    torch::Tensor outputTensor = input.clone().detach();
    std::vector<int> sizes;
    for (int i = 0; i < input.dim(); i++) {
        sizes.push_back(input.sizes()[i]);
    }
    if (sizes.size() == KERNEL_DIM_4D) {
        input = input.reshape({sizes[0], -1});
    }
    offset = offset.to(torch::kInt32);

    if (arqInit) {
        AmctCommon::ArqParam arqParam = {static_cast<unsigned int>(numBits), channelWise, false};
        // Calibration kernel function
        Status statusCode = arqInitFunc(input, scale, offset, arqParam, sRecFlag);
        if (statusCode != AmctCommon::SUCCESS) {
            LOG_ERROR("Init ulq algo with ARQ failed, please check!\n");
        }
    }

    scale = scale.reshape({-1, 1});
    offset = offset.reshape({-1, 1});
    scale = sRecFlag ? scale.reciprocal_() : scale;

#ifdef USE_CUDA
    if (outputTensor.is_cuda()) {
        scale = scale.cuda().contiguous();
        offset = offset.cuda().contiguous();
        FloatData scaleData = {static_cast<uint32_t>(scale.numel()),  scale.data_ptr<float>()};
        IntData offsetData = {static_cast<uint32_t>(offset.numel()),  offset.data_ptr<int>()};
        QuantFactors factors = {scaleData, offsetData};

        Status statusCode = FakeQuantFunctor<util::GPUDevice, float>()(outputTensor.data_ptr<float>(), sizes,
            COUTAXIS, numBits, factors);
        if (statusCode != AmctCommon::SUCCESS) {
            LOG_ERROR("Run FakeQunt CPU function failed, please check!\n");
        }
    } else {
#endif
        FloatData scaleData = {static_cast<uint32_t>(scale.numel()),  scale.data_ptr<float>()};
        IntData offsetData = {static_cast<uint32_t>(offset.numel()),  offset.data_ptr<int>()};
        QuantFactors factors = {scaleData, offsetData};
        Status statusCode = FakeQuantByAxis(outputTensor.data_ptr<float>(), sizes, COUTAXIS, numBits, factors);
        if (statusCode != AmctCommon::SUCCESS) {
            LOG_ERROR("Run FakeQunt GPU function failed, please check!\n");
        }
#ifdef USE_CUDA
    }
#endif

    scale = sRecFlag ? scale.reciprocal_() : scale;
    if (sizes.size() == KERNEL_DIM_4D) {
        outputTensor = outputTensor.reshape({sizes[DIM0], sizes[DIM1], sizes[DIM2], sizes[DIM3]});
    }
    scale = scale.reshape({-1});
    offset = offset.reshape({-1}).to(torch::kFloat32);
    return {outputTensor, scale, offset};
}

std::vector<torch::Tensor> UlqScaleRetrainBackward(
    torch::Tensor input,
    torch::Tensor gradOutputs,
    torch::Tensor scale,
    int numBits,
    bool sRecFlag)
{
    torch::Tensor upperMask;
    torch::Tensor lowerMask;
    torch::Tensor innerMask;
    torch::Tensor roundTensor;
    torch::Tensor notRoundTensor;
    torch::Tensor gradScales;
    torch::Tensor oneTensor = torch::scalar_tensor(1);
    torch::Tensor zeroTensor = torch::scalar_tensor(0);
    torch::Tensor halfStage = torch::scalar_tensor(pow(BINARY_BASE, numBits - 1));
    if (gradOutputs.is_cuda()) {
        oneTensor = oneTensor.cuda();
        zeroTensor = zeroTensor.cuda();
        halfStage = halfStage.cuda();
    }
    std::vector<int> sizes;
    for (int i = 0; i < input.dim(); i++) {
        sizes.push_back(input.sizes()[i]);
    }
    if (sizes.size() == KERNEL_DIM_4D) {
        input = input.reshape({sizes[0], -1});
        gradOutputs = gradOutputs.reshape({sizes[0], -1});
    }
    scale = scale.reshape({-1, 1});
    scale = sRecFlag ? scale.reciprocal_() : scale;

    upperMask = at::where(input > scale.mul(halfStage - 1), oneTensor, zeroTensor);
    lowerMask = at::where(input < scale.mul(-halfStage), oneTensor, zeroTensor);
    innerMask = -(upperMask + lowerMask) + 1;

    notRoundTensor = input.div(scale);
    roundTensor = notRoundTensor.round();
    gradScales = roundTensor.sub_(notRoundTensor).mul_(innerMask)
        .add_(-halfStage * lowerMask).add_((halfStage - 1) * upperMask);

    gradScales = sRecFlag ? -gradScales.mul_(scale.pow(SQURE)) : gradScales;

    gradScales = gradScales.mul_((input.sizes()[1] * (halfStage - 1)).sqrt_().reciprocal_());
    if (scale.sizes()[0] > 1) {
        gradScales = gradScales.mul_(gradOutputs).sum(1);
    } else {
        gradScales = gradScales.mul_(gradOutputs).sum();
    }

    scale = sRecFlag ? scale.reciprocal_() : scale;
    if (sizes.size() == KERNEL_DIM_4D) {
        gradOutputs = gradOutputs.reshape({sizes[DIM0], sizes[DIM1], sizes[DIM2], sizes[DIM3]});
    }
    gradScales = gradScales.reshape({-1});

    return {gradOutputs, gradScales};
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("ulq_scale_retrain_forward", &UlqScaleRetrainForward, "UlqScaleRetrain forward");
    m.def("ulq_scale_retrain_backward", &UlqScaleRetrainBackward, "UlqScaleRetrain backward");
}
