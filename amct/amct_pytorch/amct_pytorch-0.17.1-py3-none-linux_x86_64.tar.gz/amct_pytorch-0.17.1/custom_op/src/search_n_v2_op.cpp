/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief torch C++ backend api of shift n searching algorithm.
 *
 * @file search_n_v2_op.cpp
 *
 * @version 1.0
 */

#include <vector>
#include <algorithm>
#include <map>
#include <string>
#include <utility>
#include <sstream>

#include "search_n.h"
#include "search_n_v2_kernel.h"
#include "search_n_v2_op.h"

#include "util_op.h"

using namespace util;

torch::Tensor TransSearchNError(std::vector<std::vector<float>>& searchNError,
                                int searchNErrorSize)
{
    torch::Tensor accumulateError = torch::zeros(
        {static_cast<long int>(searchNErrorSize), MAX_SHIFT_BIT}, torch::kFloat32).contiguous();
    float* accumulateErrorPtr = accumulateError.data_ptr<float>();
    for (size_t i = 0; i < searchNError.size(); i++) {
        for (size_t j = 0; j < searchNError[0].size(); j++) {
            accumulateErrorPtr[i * MAX_SHIFT_BIT + j] = searchNError[i][j];
        }
    }
    return accumulateError;
}


torch::Tensor SearchNV2GetShiftN(
    torch::Tensor input,
    bool isBroadcast,
    const int deviceId)
{
    int channelNum = input.sizes()[0];
    input = input.cpu().contiguous();
    float* inputPtr = input.data_ptr<float>();

    torch::Tensor bestN = torch::zeros({channelNum}, torch::kInt32);
    int* bestNPtr = bestN.data_ptr<int>();
    IntData bestNData{static_cast<unsigned int>(channelNum), bestNPtr};
    std::vector<std::vector<float>> storeError(channelNum);

    for (int index = 0; index < channelNum; index++) {
        float* offsetPtr = inputPtr + index * MAX_SHIFT_BIT;
        storeError[index].assign(offsetPtr, offsetPtr + MAX_SHIFT_BIT);
    }
    AmctCommon::SearchNV2FindBestNCpu<float>(storeError, bestNData, isBroadcast);

#ifdef USE_CUDA
    if (deviceId >= 0) {
        const std::string deviceString = getDeviceName(deviceId);
        bestN = bestN.to(deviceString);
        return bestN;
    } else {
#endif
        return bestN;
#ifdef USE_CUDA
    }
#endif
}


std::vector<torch::Tensor> SearchNV2Forward(
    torch::Tensor input,
    torch::Tensor deqScale,
    bool isBroadcast,
    const int deviceId)
{
    Status status = CheckCaliParams(input, deqScale);
    if (status != AmctCommon::SUCCESS) {
        return {torch::scalar_tensor(status), torch::zeros({deqScale.numel(), MAX_SHIFT_BIT}, torch::kFloat32)};
    }
    const int CHANNEL_DIM = 1;
    const int channelNum = input.sizes()[CHANNEL_DIM];
    int channelSize = input.numel() / channelNum;
    int deqScaleSize = deqScale.numel();
    int searchNErrorSize = isBroadcast ? 1 : deqScale.numel();
    int kernelSize = input.numel() / deqScale.numel();
    std::vector<std::vector<float>> searchNError(searchNErrorSize, std::vector<float>(MAX_SHIFT_BIT, 0));

#ifdef USE_CUDA
    if (deviceId >= 0) {
        const std::string deviceString = getDeviceName(deviceId);
        input = input.contiguous();
        deqScale = deqScale.to(deviceString).contiguous();
        float* inputDevicePtr = input.data_ptr<float>();
        float* deqDevicePtr = deqScale.data_ptr<float>();
        int blockNum = AMCT_GET_BLOCKS(input.numel());

        AmctCommon::NchwShapeInfo shapeInfo{channelSize, channelSize, 1, channelNum};
        AmctCommon::SearchnV2InputParam<float> inputParam{searchNError, static_cast<int>(input.numel()),
            inputDevicePtr};
        AmctCommon::SearchnV2AlgoParam<float> algoParam;
        torch::Tensor quantErrorSum = torch::zeros({blockNum}, torch::kFloat32);
        quantErrorSum = quantErrorSum.to(deviceString).contiguous();
        algoParam.isBroadcast = isBroadcast;
        algoParam.quantErrorSum = quantErrorSum.data_ptr<float>();
        algoParam.quantErrorSumSize = blockNum;
        algoParam.deqScale = deqDevicePtr;
        algoParam.deqScaleSize = deqScaleSize;
        algoParam.channelNum = channelNum;
        status = SearchNV2Kernel(inputParam, algoParam, shapeInfo, deviceId);
        // assign the data in vector to tensor
        torch::Tensor accumulateError = TransSearchNError(inputParam.storeError, searchNErrorSize);
        accumulateError = accumulateError.to(deviceString);
        return {torch::scalar_tensor(status), accumulateError};
    } else {
#endif
        // transpose to dataformat [C, N]
        input = input.transpose(1, 0).reshape({channelNum, -1});
        input = input.cpu().contiguous();
        deqScale = deqScale.cpu().contiguous();
        float* inputPtr = input.data_ptr<float>();
        float* deqPtr = deqScale.data_ptr<float>();
        std::vector<std::vector<float>> currentData(deqScaleSize);
        for (int index = 0; index < deqScaleSize; index++) {
            float* offsetData = inputPtr + index * kernelSize;
            currentData[index].insert(currentData[index].begin(), offsetData, offsetData + kernelSize);
        }
        FloatData deqScaleData{static_cast<unsigned int>(deqScaleSize), deqPtr};
        status = AmctCommon::SearchNV2AccumulateError<float>(currentData, searchNError, deqScaleData, isBroadcast);

        // assign the data in vector to tensor
        torch::Tensor accumulateError = TransSearchNError(searchNError, searchNErrorSize);
        return {torch::scalar_tensor(status), accumulateError};
#ifdef USE_CUDA
    }
#endif
}

torch::Tensor SearchNV2Backward(torch::Tensor grad)
{
    return grad;
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("searchn_v2_forward", &SearchNV2Forward, "SearchNV2 forward to find shift_bit");
    m.def("searchn_v2_get_shiftn", &SearchNV2GetShiftN, "SearchNV2 get shift_bit");
    m.def("searchn_v2_backward", &SearchNV2Backward, "SearchNV2 backward");
}
