/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief torch C++ backend api of hfmg algorithm.
 *
 * @file hfmg_op.cpp
 *
 * @version 1.0
 */

#include <vector>
#include <cfloat>
#include <sstream>
#include <algorithm>
#include <unordered_map>

#include "hfmg_op.h"
#include "util_op.h"
#include "hfmg.h"
#include "hfmg_kernel.h"
#include "utils_kernel.h"

using namespace util;

Status TransformHist(
    std::vector<AmctCommon::DataBin<float>>& dataBins,
    torch::Tensor& hist,
    torch::Tensor& histRange,
    const int nbins)
{
    std::vector<float> histRangeVec;
    TensorToVector(histRange, histRangeVec);
    std::vector<float> histVec;
    TensorToVector(hist, histVec);

    float dataMin = histRangeVec.front();
    float dataMax = histRangeVec.back();
    // initialize all the bins;
    float lowerBound;
    float higherBound;
    if (nbins == 0) {
        return AmctCommon::ZERO_DIVISION_ERROR;
    }
    float binWidth = (dataMax - dataMin) / nbins;
    for (int index = 0; index < nbins; index++) {
        lowerBound = dataMin + index * binWidth;
        higherBound = dataMin + (index + 1) * binWidth;
        dataBins.push_back(AmctCommon::DataBin<float>(histVec[index], lowerBound, higherBound));
    }
    return AmctCommon::SUCCESS;
}


std::vector<torch::Tensor> HfmgActArqCalibration(
    torch::Tensor min,
    torch::Tensor max,
    const int deviceId,
    unsigned int num_bits,
    bool with_offset,
    unsigned int nbins)
{
    std::vector<float> minVec;
    TensorToVector(min, minVec);
    std::vector<float> maxVec;
    TensorToVector(max, maxVec);
    float scaleData;
    int offsetData;
    FloatData scale{1, &scaleData};
    IntData offset{1, &offsetData};

    torch::Tensor scaleTensor;
    torch::Tensor offsetTensor;

    AmctCommon::HfmgAlgoParam hfmgParam{num_bits, with_offset, nbins};
    AmctCommon::ActArqCalibration<float>(minVec.back(), maxVec.back(), scale, offset, hfmgParam);
#ifdef USE_CUDA
    if (deviceId < 0) {
#endif
        scaleTensor = torch::scalar_tensor(scaleData).to(torch::kFloat32);
        offsetTensor = torch::scalar_tensor(offsetData).to(torch::kInt32);
        return {scaleTensor, offsetTensor};
#ifdef USE_CUDA
    } else {
        const std::string deviceString = getDeviceName(deviceId);
        scaleTensor = torch::scalar_tensor(scaleData).to(torch::kFloat32);
        offsetTensor = torch::scalar_tensor(offsetData).to(torch::kInt32);
        scaleTensor = scaleTensor.to(deviceString);
        offsetTensor = offsetTensor.to(deviceString);
        return {scaleTensor, offsetTensor};
    }
#endif
}


std::vector<torch::Tensor> HfmgMergeHist(
    torch::Tensor hist,
    torch::Tensor histRange,
    torch::Tensor newHist,
    torch::Tensor newHistRange,
    const int deviceId,
    int nbins)
{
    // Move data to vector format
    std::vector<AmctCommon::DataBin<float>> dataBins;
    int statusCode = TransformHist(dataBins, hist, histRange, nbins);
    if (statusCode != AmctCommon::SUCCESS) {
        LOG_ERROR("HfmgMergeHist call TransformHist failed, please check!\n");
    }
    std::vector<AmctCommon::DataBin<float>> mergedDataBins;
    statusCode = TransformHist(mergedDataBins, newHist, newHistRange, nbins);
    if (statusCode != AmctCommon::SUCCESS) {
        LOG_ERROR("HfmgMergeHist call TransformHist failed, please check!\n");
    }
    std::vector<float> newHistRangeVec;
    TensorToVector(newHistRange, newHistRangeVec);

    std::vector<float> histRangeVec;
    TensorToVector(histRange, histRangeVec);

    float mergedBinWidth = (newHistRangeVec.back() - newHistRangeVec.front()) / nbins;

    bool sameRangeFlag = false;
    if (fabs(newHistRangeVec.back() - histRangeVec.back()) < FLT_EPSILON && \
            fabs(newHistRangeVec.front() - histRangeVec.front()) < FLT_EPSILON) {
        sameRangeFlag = true;
    }
    AmctCommon::HfmgMergeInter<float>(dataBins, mergedDataBins, sameRangeFlag,
        newHistRangeVec.front(), mergedBinWidth);

    std::vector<float> mergedHistVec(nbins);
    for (int index = 0; index < nbins; index++) {
        mergedHistVec[index] = mergedDataBins[index].count;
    }
    torch::Tensor mergedHist = torch::from_blob(mergedHistVec.data(),
        {static_cast<long>(mergedHistVec.size())}, torch::kFloat32);
#ifdef USE_CUDA
    if (deviceId < 0) {
#endif
        return {mergedHist.cpu()};

#ifdef USE_CUDA
    } else {
        const std::string deviceString = getDeviceName(deviceId);
        mergedHist = mergedHist.to(deviceString);
        return {mergedHist};
}
#endif
}


std::vector<torch::Tensor> HfmgForward(
    torch::Tensor hist,
    torch::Tensor histRange,
    const int deviceId,
    unsigned int num_bits,
    bool with_offset,
    unsigned int nbins)
{
    torch::Tensor calibratedFlag;
    torch::Tensor scaleTensor;
    torch::Tensor offsetTensor;

    std::vector<AmctCommon::DataBin<float>> dataBins;
    Status statusCode = TransformHist(dataBins, hist, histRange, nbins);
    if (statusCode != AmctCommon::SUCCESS) {
        LOG_ERROR("HfmgForward call TransformHist failed, please check!\n");
    }
    float scale = 1.0;
    int offset = 0;

#ifdef USE_CUDA
    if (deviceId < 0) {
#endif
        AmctCommon::HfmgAlgoParam hfmgParam = {
            static_cast<unsigned int>(num_bits), with_offset, static_cast<unsigned int>(nbins)};
        // Calibration kernel function
        statusCode = AmctCommon::HfmgCompute<float>(dataBins, scale, offset, hfmgParam);
        calibratedFlag = torch::scalar_tensor(statusCode);
        scaleTensor = torch::scalar_tensor(scale).to(torch::kFloat32);
        offsetTensor = torch::scalar_tensor(offset).to(torch::kInt32);
        return {calibratedFlag, scaleTensor, offsetTensor};

#ifdef USE_CUDA
    } else {
        const std::string deviceString = getDeviceName(deviceId);

        torch::Tensor binCounts = torch::zeros({nbins}, torch::kInt32);
        torch::Tensor l2Loss = torch::zeros({nbins}, torch::kFloat32);
        binCounts = binCounts.to(deviceString);
        l2Loss = l2Loss.to(deviceString);
        AmctCommon::HfmgAlgoParam hfmgParam = {
            static_cast<unsigned int>(num_bits), with_offset, static_cast<unsigned int>(nbins)};

        AmctCommon::HfmgDataQuantParam<float> quantParam;
        quantParam.scaleCpu = &scale;
        quantParam.offsetCpu = &offset;
        quantParam.binCountDevicePtr = binCounts.data_ptr<int32_t>();
        quantParam.l2LossDevicePtr = l2Loss.data_ptr<float>();
        quantParam.deviceId = deviceId;

        // Calibration kernel function
        statusCode = AmctCommon::HfmgQuantFunctor<util::GPUDevice, float>()(dataBins, quantParam, hfmgParam);
        scaleTensor = torch::scalar_tensor(scale);
        offsetTensor = torch::scalar_tensor(offset).to(torch::kInt32);
        scaleTensor = scaleTensor.to(deviceString);
        offsetTensor = offsetTensor.to(deviceString);
        calibratedFlag = torch::scalar_tensor(statusCode);
        return {calibratedFlag, scaleTensor, offsetTensor};
    }
#endif
}

torch::Tensor HfmgBackward(torch::Tensor grad)
{
    return grad;
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("hfmg_arq", &HfmgActArqCalibration, "HFMG ARQ calibration");
    m.def("hfmg_merge", &HfmgMergeHist, "HFMG merge");
    m.def("hfmg_forward", &HfmgForward, "HFMG forward");
    m.def("hfmg_backward", &HfmgBackward, "HFMG backward");
}
