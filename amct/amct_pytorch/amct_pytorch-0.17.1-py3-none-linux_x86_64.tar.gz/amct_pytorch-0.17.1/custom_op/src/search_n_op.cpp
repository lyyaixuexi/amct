/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief torch C++ backend api of shift n searching algorithm.
 *
 * @file search_n_torch.cpp
 *
 * @version 1.0
 */

#include <vector>
#include <algorithm>
#include <map>
#include <string>
#include <utility>
#include <sstream>

#include "search_n.h"
#include "search_n_op.h"
#include "search_n_kernel.h"
#include "util_op.h"

const int BASE_NUM = 2;
const int CHANNEL_DIM = 1;

void SearchNProcess(std::vector<std::vector<int>>& s32Data,
                    std::vector<int>& bestN,
                    const int deviceId)
{
#ifdef USE_CUDA
    if (deviceId >= 0) {
        const std::string deviceString = getDeviceName(deviceId);
        int channelNum = s32Data.size();
        int perChannelSize = s32Data[0].size();
        int searchNDataSize = channelNum * perChannelSize;
        SearchNGpuParam searchNGpuParam;
        searchNGpuParam.searchNDataSize = searchNDataSize;
        searchNGpuParam.deviceId = deviceId;

        torch::Tensor topData = torch::zeros({searchNDataSize}, torch::kFloat32);
        torch::Tensor searchNDataGpu = torch::zeros({searchNDataSize}, torch::kInt32);
        topData = topData.to(deviceString).contiguous();
        searchNDataGpu = searchNDataGpu.to(deviceString).contiguous();

        SearchNKernel(s32Data, bestN, topData.data_ptr<float>(),
            searchNDataGpu.data_ptr<int>(), searchNGpuParam);
    } else {
#endif
        AmctCommon::SearchShiftBits(s32Data, bestN);
#ifdef USE_CUDA
    }
#endif
}


std::vector<torch::Tensor> SearchNForward(
    torch::Tensor input,
    torch::Tensor deqScale,
    bool channelWise,
    const int deviceId)
{
    Status status = CheckCaliParams(input, deqScale);
    if (status != AmctCommon::SUCCESS) {
        return {torch::scalar_tensor(status),
                torch::zeros_like(deqScale).to(torch::kInt8)};
    }

    const int channleNum = input.sizes()[CHANNEL_DIM];
    input = input.transpose(1, 0).reshape({channleNum, -1});
    input = input.cpu().contiguous();
    deqScale = deqScale.cpu().contiguous();
    float* inputPtr = input.data_ptr<float>();
    float* deqData = deqScale.data_ptr<float>();
    std::vector<int> bestN;

    // quant to int32 range
    int minS32 = -static_cast<int>(pow(BASE_NUM, AMCTPytorch::QUANT_BIT - 1));
    int maxS32 = static_cast<int>(pow(BASE_NUM, AMCTPytorch::QUANT_BIT - 1) - 1);
    if (channelWise) {
        std::vector<std::vector<int>> s32Data(deqScale.numel(), std::vector<int>(input.numel() / deqScale.numel(), 0));
        int kernelSize = input.numel() / deqScale.numel();
        for (int i = 0; i < deqScale.numel(); i++) {
            for (int j = 0; j < kernelSize; j++) {
                s32Data[i][j] = static_cast<int>(round(inputPtr[i * kernelSize + j] / deqData[i]));
                AmctCommon::Clip(s32Data[i][j], minS32, maxS32);
            }
        }
        SearchNProcess(s32Data, bestN, deviceId);
    } else {
        std::vector<std::vector<int>> s32Data(1, std::vector<int>(input.numel(), 0));
        int kernelSize = input.numel() / deqScale.numel();
        for (int i = 0; i < deqScale.numel(); i++) {
            for (int j = 0; j < kernelSize; j++) {
                s32Data[0][i * kernelSize + j] = static_cast<int>(round(inputPtr[i * kernelSize + j] / deqData[i]));
                AmctCommon::Clip(s32Data[0][i * kernelSize + j], minS32, maxS32);
            }
        }
        SearchNProcess(s32Data, bestN, deviceId);
    }
    torch::Tensor calibratedFlag = torch::scalar_tensor(status);
    torch::Tensor shiftBit = torch::from_blob(bestN.data(),
        {static_cast<long>(bestN.size())}, torch::kInt32).to(torch::kInt8);

    return {calibratedFlag,
            shiftBit};
}

torch::Tensor SearchNBackward(torch::Tensor grad)
{
    return grad;
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("searchn_forward", &SearchNForward, "SearchN forward to find shift_bit");
    m.def("searchn_backward", &SearchNBackward, "SearchN backward");
}
