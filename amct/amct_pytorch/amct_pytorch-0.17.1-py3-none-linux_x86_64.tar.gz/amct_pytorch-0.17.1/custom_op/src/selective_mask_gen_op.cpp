/*
* Copyright (c) Huawei Technologies Co., Ltd. 2022-2022. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief torch C++ backend of arq algorithm.
 *
 * @file selective_mask_gen_op.cpp
 *
 * @version 1.0
 */

#include "selective_mask_gen_op.h"
#include <cmath>
#include "util.h"


static void GetOperatorShape(torch::IntArrayRef tensorSize, SelectiveMaskGenKernel::PruneParam pruneParam,
    std::vector<int64_t> &groupShape, std::vector<int64_t> &paddingShape, std::vector<int64_t> &unGroupShape)
{
    int channelNum = tensorSize[pruneParam.pruneAxis];
    int groupNum = static_cast<int>(ceil(static_cast<float>(channelNum) / pruneParam.m));
    int paddingSize = groupNum * pruneParam.m - channelNum;

    for (size_t axis = 0; axis < static_cast<size_t>(pruneParam.pruneAxis); ++axis) {
        groupShape.push_back(tensorSize[axis]);
        paddingShape.push_back(tensorSize[axis]);
        unGroupShape.push_back(tensorSize[axis]);
    }
    groupShape.push_back(groupNum);
    groupShape.push_back(pruneParam.m);
    paddingShape.push_back(paddingSize);
    unGroupShape.push_back(-1);
    for (size_t axis = pruneParam.pruneAxis + 1; axis < tensorSize.size(); ++axis) {
        groupShape.push_back(tensorSize[axis]);
        paddingShape.push_back(tensorSize[axis]);
        unGroupShape.push_back(tensorSize[axis]);
    }
    return;
}

torch::Tensor SelectiveMaskGen(
    torch::Tensor inputTensor,
    SelectiveMaskGenKernel::PruneParam pruneParam)
{
    // m <= n return mask full ones
    int channelNum = inputTensor.sizes()[pruneParam.pruneAxis];
    if (channelNum <= pruneParam.n) {
        torch::Tensor maskTensor = torch::ones({inputTensor.sizes()}, torch::kFloat32).to(inputTensor.device());
        return maskTensor;
    }

    // get shape : group, padding, un_group
    std::vector<int64_t> groupShape;
    std::vector<int64_t> paddingShape;
    std::vector<int64_t> unGroupShape;
    GetOperatorShape(inputTensor.sizes(), pruneParam, groupShape, paddingShape, unGroupShape);

    torch::Tensor wgtPadding = torch::cat({inputTensor.abs(),
        torch::zeros(paddingShape, torch::kFloat32).to(inputTensor.device())}, pruneParam.pruneAxis);
    torch::Tensor wgtGroup = wgtPadding.reshape({groupShape});

    // get topN index
    std::tuple<torch::Tensor, torch::Tensor> sortTuple = wgtGroup.topk(
        pruneParam.n, pruneParam.pruneAxis + 1, false);
    torch::Tensor sortIndices = std::get<1>(sortTuple);

    // get mask tensor
    torch::Tensor maskTensor = torch::ones_like(wgtGroup).to(inputTensor.device());
    maskTensor.scatter_(pruneParam.pruneAxis + 1, sortIndices, 0.0);
    std::vector<torch::Tensor> splitVector = torch::split(
        maskTensor.reshape(unGroupShape),
        inputTensor.sizes()[pruneParam.pruneAxis],
        pruneParam.pruneAxis);

    return splitVector[0];
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("selective_mask_gen", &SelectiveMaskGen, "m: n prune mask");

    py::class_<SelectiveMaskGenKernel::PruneParam>(m, "PruneParam")
        .def(py::init<int, int, int>())
        .def_readwrite("pruneAxis", &SelectiveMaskGenKernel::PruneParam::pruneAxis)
        .def_readwrite("m", &SelectiveMaskGenKernel::PruneParam::m)
        .def_readwrite("n", &SelectiveMaskGenKernel::PruneParam::n);
}