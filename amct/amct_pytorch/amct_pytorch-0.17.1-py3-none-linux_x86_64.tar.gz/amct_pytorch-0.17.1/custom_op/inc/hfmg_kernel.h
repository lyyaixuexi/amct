/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Declare HMFG Operator Forward Operation
 *
 * @file hfmg_kernel.h
 *
 * @version 1.0
 */


#ifndef HFMG_KERNEL_H
#define HFMG_KERNEL_H

#include <vector>
#include <string>
#include "hfmg.h"

namespace AmctCommon {
// Define the structure of data quantification
template <typename T>
struct HfmgDataQuantParam {
    float* scaleCpu;
    int* offsetCpu;
    int* binCountDevicePtr;
    T* l2LossDevicePtr;
    int deviceId = -1;
};

template <typename Device, typename T>
struct HfmgQuantFunctor {
    int operator()(std::vector<DataBin<T>>& dataBins, HfmgDataQuantParam<T>& quantParam, HfmgAlgoParam& hfmgParam);
};
}
#endif // HFMG_KERNEL_H