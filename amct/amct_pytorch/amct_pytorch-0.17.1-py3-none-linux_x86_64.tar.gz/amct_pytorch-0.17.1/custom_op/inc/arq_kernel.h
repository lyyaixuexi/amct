/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief CUDA arq header file
 *
 * @file arq_kernel.h
 *
 * @version 1.0
 */


#ifndef ARQ_KERNEL_H
#define ARQ_KERNEL_H

#include <string>

const int ARQ_WEIGHT_INDEX = 0;
const int ARQ_SCALE_INDEX = 0;
const int ARQ_OFFSET_INDEX = 1;


// Define the structure of data quantification
struct WeightQuantParam {
    float* scale;
    int* offset;
    int scaleNumber;
    int quantBits;
    int deviceId = -1;
};

template <typename Device, typename T>
struct ArqQuantFunctor {
    int operator()(
        const int size,
        const T* in,
        T* out,
        T* max,
        T* min,
        struct WeightQuantParam quantParam);
};


#endif
