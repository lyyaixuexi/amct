/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief activation_qat_quant algorithm custom op C++ implement
 *
 * @file ulq_scale_qat_op.h
 *
 * @version 1.0
 */

#ifndef ULQ_SCALE_QAT_OP_H
#define ULQ_SCALE_QAT_OP_H

#include <torch/extension.h>

#include "arq.h"
#include "util.h"

std::vector<torch::Tensor> UlqScaleRetrainForward(
    torch::Tensor input,
    torch::Tensor scale,
    torch::Tensor offset,
    int numBits,
    bool channelWise,
    bool arqInit,
    bool sRecFlag);

std::vector<torch::Tensor> UlqScaleRetrainBackward(
    torch::Tensor input,
    torch::Tensor gradOutputs,
    torch::Tensor scale,
    int numBits,
    bool sRecFlag);

template<class T>
Status FakeQuantByAxis(T *data, const std::vector<int>& dims, const int64_t coutAxis,
    const int numBits, const util::QuantFactors& factors);

#endif /* ULQ_SCALE_QAT_OP_H */