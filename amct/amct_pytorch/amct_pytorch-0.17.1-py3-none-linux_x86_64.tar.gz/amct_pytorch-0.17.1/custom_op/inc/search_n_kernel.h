/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Declare search shift N Operator Forward Operation for CUDA
 *
 * @file search_n_kernel.h
 *
 * @version 1.0
 */


#ifndef SEARCH_N_KERNEL_H
#define SEARCH_N_KERNEL_H

#include <vector>

struct SearchNGpuParam {
    int searchNDataSize;
    int deviceId = -1;
};

int SearchNKernel(const std::vector<std::vector<int>>& s32Data,
    std::vector<int>& bestN, float* topData, int* searchNDataGpu, SearchNGpuParam searchNGpuParam);

#endif /* SEARCH_N_KERNEL_H */
