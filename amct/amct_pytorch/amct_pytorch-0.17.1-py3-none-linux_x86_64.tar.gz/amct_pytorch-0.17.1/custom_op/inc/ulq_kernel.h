/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Declare ULQ Forward Operation for CUDA
 *
 * @file ulq_kernel.h
 *
 * @version 1.0
 */


#ifndef ULQ_KERNEL_H_
#define ULQ_KERNEL_H_

#include "ifmr.h"

const int INPUT_INDEX = 0;
const int CLIPMAX_INDEX = 1;
const int CLIPMIN_INDEX = 2;
const int OUTPUT_INDEX = 0;
const int SCALE_INDEX = 1;
const int OFFSET_INDEX = 2;
const int BATCH_NUM_INDEX = 3;

const bool WITH_OFFSET = true;
const float PERCENTILE = 0.999999;
const float SEARCH_STEP = 0.01;

template<typename T>
struct Input {
    const T* data;
    int length;
    T* clipMax;
    T* clipMin;
};

template<typename T>
struct Output {
    T* data;
    float* scale;
    int* offset;
};

template<typename Device, typename T>
struct UlqFunctor {
    int operator()(Input<T> input, Output<T> output, int quantBitNum);
};

#endif // ULQ_KERNEL_H_
