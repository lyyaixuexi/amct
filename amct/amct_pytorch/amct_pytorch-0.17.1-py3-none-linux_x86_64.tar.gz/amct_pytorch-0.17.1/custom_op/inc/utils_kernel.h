/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this
 * file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief the utils_kernel header file for CUDA
 *
 * @file utils_kernel.h
 *
 * @version 1.0
 */


#ifndef UTILS_KERNEL_H
#define UTILS_KERNEL_H

#include <mutex>
#include <semaphore.h>
#include <float.h>
#include <cmath>

#include "error_codes.h"
#include "util.h"


struct GpuDevice {
};

// CPUDevice and GPUDevice
struct ThreadPoolDevice {
};

using GPUDevice = struct GpuDevice;
using CPUDevice = struct ThreadPoolDevice;

template <typename T>
void ProcessZeroScaleGpu(T* scaleIn, int scaleLength);

#endif
