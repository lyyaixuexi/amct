/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief hfmg algorithm custom op C++ implement
 *
 * @file hfmg_op.h
 *
 * @version 1.0
 */

#ifndef HFMG_OP_H
#define HFMG_OP_H

#include <torch/extension.h>

#include "util_op.h"

std::vector<torch::Tensor> HfmgMergeHist(
    torch::Tensor hist,
    torch::Tensor histRange,
    torch::Tensor newHist,
    torch::Tensor newHistRange,
    const int deviceId,
    int nbins);

std::vector<torch::Tensor> HfmgForward(
    torch::Tensor hist,
    torch::Tensor histRange,
    const int deviceId,
    unsigned int num_bits,
    bool with_offset,
    unsigned int nbins);

std::vector<torch::Tensor> HfmgActArqCalibration(
    torch::Tensor min,
    torch::Tensor max,
    const int deviceId,
    unsigned int num_bits,
    bool with_offset,
    unsigned int nbins);

torch::Tensor HfmgBackward(torch::Tensor grad);

#endif /* HFMG_OP_H */
