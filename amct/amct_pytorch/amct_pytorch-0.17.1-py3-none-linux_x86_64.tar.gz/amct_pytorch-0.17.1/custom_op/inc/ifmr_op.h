/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief ifmr_quant algorithm custom op C++ implement
 *
 * @file ifmr.h
 *
 * @version 1.0
 */

#ifndef IFMR_OP_H
#define IFMR_OP_H

#include <torch/extension.h>

#include "util_op.h"


struct MaxMinPercentile {
    float max_percentile;
    float min_percentile;
};

std::vector<torch::Tensor> IfmrForward(
    torch::Tensor input, const int deviceId,
    int num_bits, bool with_offset,
    float maxPercentile, float minPercentile, float search_start,
    float search_end, float search_step);

torch::Tensor IfmrBackward(torch::Tensor grad);

#endif /* IFMR_OP_H */
