/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief shift n searching algorithm custom op C++ implement
 *
 * @file search_n.h
 *
 * @version 1.0
 */

#ifndef SEARCHN_OP_H
#define SEARCHN_OP_H

#include <torch/extension.h>


/* SearchNForward
   input shoule be ordered in N, C
*/
std::vector<torch::Tensor> SearchNForward(
    torch::Tensor input,
    torch::Tensor deqScale,
    bool channelWise,
    const int deviceId);

torch::Tensor SearchNBackward(torch::Tensor grad);

namespace AMCTPytorch {
    const unsigned int QUANT_BIT = 32;
    const unsigned int CLIP_BIT = 16;
    const int MAX_SHIFT_BIT = 16;
}

#endif /* SEARCHN_OP_H */
