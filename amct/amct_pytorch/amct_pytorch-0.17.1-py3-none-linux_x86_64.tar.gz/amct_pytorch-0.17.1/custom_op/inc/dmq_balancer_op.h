/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief dmq_balancer algorithm custom op C++ implement
 *
 * @file dmq_balancer.h
 *
 * @version 1.0
 */

#ifndef DMQ_BALANCER_OP_H
#define DMQ_BALANCER_OP_H

#include <torch/extension.h>

#include "util_op.h"
#include "util.h"


std::vector<torch::Tensor> DMQBalancerForward(
    torch::Tensor input,
    torch::Tensor weight,
    float migrationStrength,
    uint32_t channelNum);

#endif /* DMQ_BALANCER_OP_H */
