/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Declare IFMR Operator Forward Operation
 *
 * @file ifmr_kernel.h
 *
 * @version 1.0
 */


#ifndef IFMR_KERNEL_H
#define IFMR_KERNEL_H

#include <vector>
#include <string>

namespace AmctCommon {
// Define the structure of data quantification
struct IfmrQuantParam {
    int quantBitNum;
    bool withOffset;
    float maxPercentile;
    float minPercentile;
    float startRatio;
    float endRatio;
    float searchStep;
};

// Define the structure of data quantification
template <typename T>
struct DataQuantParam {
    float* scale;
    int* offset;
    float* scaleCpu;
    int* offsetCpu;
    T* ifmrData;
    T* quantError;
    int deviceId = -1;
};

// Define the structure of data quantification
template <typename T>
struct InputParam {
    std::vector<T> storeData;
    int size;
    const T* in;
};

// Define the structure of data quantification
template <typename T>
struct ErrorParam {
    int n;
    bool isMaxPos;
    T* beforeQuantData;
    T* quantError;
    T min;
    T max;
};

template <typename Device, typename T>
struct IfmrQuantFunctor {
    int operator()(std::vector<T>& quantIfmrData, struct IfmrQuantParam ifmrParam, struct DataQuantParam<T> quantParam);
};

template <typename T>
int CalScaleOffset(T max, T min, float& scaleCpu, int& offsetCpu, struct IfmrQuantParam ifmrParam);
}

#endif // IFMR_KERNEL_H
