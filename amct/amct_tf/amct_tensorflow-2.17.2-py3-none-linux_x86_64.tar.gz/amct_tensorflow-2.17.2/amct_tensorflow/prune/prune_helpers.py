#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Top APIs of AMCT_TORCH prune tool for user

"""

from amct_tensorflow.common.prune.active_prune_helper_base import ActivePruneHelperBase
from amct_tensorflow.common.prune.selective_prune_helper_base import SelectivePruneHelperBase
from amct_tensorflow.common.prune.passive_prune_helper_base import PassivePruneHelperBase
from amct_tensorflow.common.prune.concat_prune_helper_base import ConcatPruneHelperBase
from amct_tensorflow.common.prune.eltwise_prune_helper_base import EltwisePruneHelperBase
from amct_tensorflow.common.prune.disable_prune_helper_base import DisablePruneHelperBase
from amct_tensorflow.common.prune.split_prune_helper_base import SplitPruneHelperBase
from amct_tensorflow.utils.utils_vars import ELTWISE_TYPES
from amct_tensorflow.utils.utils_vars import PASSIVE_PRUNABLE_TYPES
from amct_tensorflow.utils.utils_vars import PRUNABLE_TYPES
from amct_tensorflow.utils.utils_vars import SELECTIVE_PRUNABLE_TYPES


class ActivePruneHelper(ActivePruneHelperBase):
    """
    Function:
        subclass of PruneHelper that handles PRUNABLE_TYPES nodes
    """
    prunable_types = PRUNABLE_TYPES

    @staticmethod
    def match_pattern(node):
        if node.type in PRUNABLE_TYPES and node.get_attr('filter_prune_enable') \
            and not ActivePruneHelper.is_tail(node):
            return True
        return False

    @staticmethod
    def is_tail(node):
        if not any(anchor.get_peer_input_anchor() for anchor in node.output_anchors):
            return True
        return False

    def get_cout_length(self):
        return self.node.get_attr('out_channels')


class SelectivePruneHelper(SelectivePruneHelperBase):
    """
    Function:
        subclass of PruneHelper that handles SELECTIVE_PRUNABLE_TYPES nodes
    """
    prunable_types = SELECTIVE_PRUNABLE_TYPES

    @staticmethod
    def match_pattern(node):
        if node.type in SELECTIVE_PRUNABLE_TYPES and \
            node.get_attr('selective_prune_enable'):
            return True
        return False

    def get_mask_shape(self):
        """
        Function: get the prune mask shape of self.node
        Param: None
        Return: a list
        """
        return self.node.get_attr('wgt_shape')


class PassivePruneHelper(PassivePruneHelperBase):
    """
    Function:
        subclass of PruneHelper that handles nodes that potentially can be consumers
    """
    prunable_types = PRUNABLE_TYPES

    @staticmethod
    def match_pattern(node):
        if node.type not in (
            PASSIVE_PRUNABLE_TYPES + PRUNABLE_TYPES + ['PoolReshape', 'FakeFusedBatchNormV3', 'Dropout']):
            return False
        return True


class ConcatPruneHelper(ConcatPruneHelperBase):
    """
    Function:
        subclass of PruneHelper that handles Concat Nodes
    """
    prunable_types = PRUNABLE_TYPES

    @staticmethod
    def match_pattern(node):
        if node.type not in ['ConcatV2', ]:
            return False
        return True

    def get_invalid_input_idx(self):
        invalid_input_idx = len(self.node.get_attr('concat_width'))
        return [invalid_input_idx]

    def _get_branch_cout_len(self, idx):
        concat_op = self.node.op
        concat_axis = self.node.get_attr('axis')
        if concat_op.inputs[idx].shape.rank:
            # shape is not unknown
            return concat_op.inputs[idx].shape.as_list()[concat_axis]
        return None


class EltwisePruneHelper(EltwisePruneHelperBase):
    """
    Function:
        subclass of PruneHelper that handles elt-wise Nodes
    """
    prunable_types = PRUNABLE_TYPES

    @staticmethod
    def match_pattern(node):
        if node.type not in ELTWISE_TYPES:
            return False
        return True


class DisablePruneHelper(DisablePruneHelperBase):
    """
    Function:
        subclass of PruneHelper that handles nodes need to be disabled
    """
    prunable_types = PRUNABLE_TYPES


class SplitPruneHelper(SplitPruneHelperBase):
    """
    Function:
        subclass of PruneHelper that handles Split Nodes
    """
    prunable_types = PRUNABLE_TYPES

    @staticmethod
    def match_pattern(node):
        if node.type not in ['Split', 'SplitV']:
            return False
        return True

    def get_split_info(self):
        split_info = self.node.get_attr('size_splits')
        return split_info

    def get_split_input_axis(self):
        return self.node.get_attr('input_axis')
