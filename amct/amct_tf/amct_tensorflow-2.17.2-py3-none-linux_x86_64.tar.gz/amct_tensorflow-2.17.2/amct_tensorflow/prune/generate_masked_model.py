#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Data structure of graph which contains graph topologic info

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import stat
from google.protobuf import text_format

from amct_tensorflow.graph.graph import Graph
from amct_tensorflow.prune.simplify_graphir import simplify_graph
from amct_tensorflow.optimizer.graph_optimizer import GraphOptimizer
from amct_tensorflow.optimizer_ir.insert_prune_mask_pass import InsertPruneMaskPass
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.common.prune.prune_recorder_helper import PruneRecordHelper
from amct_tensorflow.prune.prune_utils import create_operator
from amct_tensorflow.prune.prune_helpers import SelectivePruneHelper
from amct_tensorflow.proto import inner_scale_offset_record_tf_pb2
from amct_tensorflow.common.utils.util import FILE_MODE

__all__ = ['generate_masked_model']


def generate_masked_model(graph, prune_config, record_file, outputs):
    """
    Function:
        insert mask ops at the specified position in the given tf.graph,
        to achieve unstructured filter pruning.
    Inputs:
        graph: a tf.compat.v1.Graph.
        prune_config: a dictionary containing pruning paramters of each
            prunable layer parsed from config defination.
        record_file: a string, the path of txt file recording relationships
            between the prunable ops.
        outputs: a list containing the names of outputs of the model.
    """
    graph_ir = Graph(graph, prune_config, outputs)
    simplify_graph(graph_ir)
    record = find_prune_consumers(graph_ir)
    add_selective_prune_record(record, graph_ir)
    write_record(record, record_file)
    apply_mask(graph_ir)
    LOGGER.push_info_message("{:*^100s}".format('INSERT MASK COMPLETE'))


def find_prune_consumers(graph_ir):
    """
    Function:
        discover producer-consumer relationships betweein
        pruanble nodes in the graphIR.
    Inputs:
        graphIR: an inner representation object of tf.graph
    Outputs:
        record: relationships between nodes in proto format
    """
    record = inner_scale_offset_record_tf_pb2.InnerScaleOffsetRecord()
    record_helper = PruneRecordHelper(record, graph_ir)
    for node in graph_ir.nodes:
        operator = create_operator(node)
        if operator is not None:
            node.set_attr('prune_operator', operator)
            operator.process(record_helper)
    record_helper.delete_redundant_attr('branch_idx')
    return record


def add_selective_prune_record(record, graph_ir):
    """
    Function:
        add selective prune record to records
    Inputs:
        record: relationships between nodes in proto format,
        or empty when no filter prune in config
        graphIR: an inner representation object of tf.graph
    """
    record_helper = PruneRecordHelper(record, graph_ir)
    for node in graph_ir.nodes:
        if not SelectivePruneHelper.match_pattern(node):
            continue
        operator = SelectivePruneHelper(node)
        node.set_attr('prune_operator', operator)
        operator.process(record_helper)


def apply_mask(graph_ir):
    """
    Function:
        Insert mask ops in the tf.graph.
    """
    optimizer = GraphOptimizer()
    optimizer.add_pass(InsertPruneMaskPass())
    optimizer.do_optimizer(graph_ir)


def write_record(record, record_file):
    """
    Function:
        write the producer-consumer relationships between nodes
        to the given txt file.
    """
    file_flags = os.O_WRONLY + os.O_CREAT + os.O_TRUNC
    file_mode = stat.S_IRUSR + stat.S_IWUSR + stat.S_IRGRP
    with os.fdopen(os.open(record_file, file_flags, file_mode), 'w',
                   encoding='UTF-8', newline='') as fid:
        fid.write(text_format.MessageToString(record, as_utf8=True))
    os.chmod(record_file, FILE_MODE)
