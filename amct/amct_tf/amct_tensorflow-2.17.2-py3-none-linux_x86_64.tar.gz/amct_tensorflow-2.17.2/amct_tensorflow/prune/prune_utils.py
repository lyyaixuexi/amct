#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

the automatic calibration for Tensorflow.

"""

from amct_tensorflow.prune.prune_helpers import ActivePruneHelper
from amct_tensorflow.prune.prune_helpers import PassivePruneHelper
from amct_tensorflow.prune.prune_helpers import DisablePruneHelper
from amct_tensorflow.prune.prune_helpers import ConcatPruneHelper
from amct_tensorflow.prune.prune_helpers import EltwisePruneHelper
from amct_tensorflow.prune.prune_helpers import SplitPruneHelper


def create_operator(node):
    """
    Function:
        assign approperate helper for each node
    """
    if ActivePruneHelper.match_pattern(node):
        return ActivePruneHelper(node)

    if PassivePruneHelper.match_pattern(node):
        return PassivePruneHelper(node)

    if EltwisePruneHelper.match_pattern(node):
        return EltwisePruneHelper(node)

    if ConcatPruneHelper.match_pattern(node):
        return ConcatPruneHelper(node)

    if SplitPruneHelper.match_pattern(node):
        return SplitPruneHelper(node)

    return DisablePruneHelper(node)
