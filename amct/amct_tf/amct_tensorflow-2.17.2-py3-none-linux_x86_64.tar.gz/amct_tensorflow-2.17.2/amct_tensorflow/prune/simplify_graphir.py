#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Data structure of graph which contains graph topologic info

"""

from amct_tensorflow.optimizer.graph_optimizer import GraphOptimizer
from amct_tensorflow.optimizer_ir.replace_dropout_pass import ReplaceDropOutPass
from amct_tensorflow.optimizer_ir.cut_while_loop_pass import CutWhileLoopPass
from amct_tensorflow.optimizer_ir.replace_pool_reshape_pass import ReplacePoolReshapePass
from amct_tensorflow.optimizer_ir.replace_graphir_bn_pass import ReplaceGraphIRBNPass
from amct_tensorflow.optimizer_ir.remove_head_and_tail_pass import RemoveHeadAndTailPass
from amct_tensorflow.optimizer_ir.check_group_conv_pass import CheckGroupConvPass
from amct_tensorflow.utils.log import LOGGER

__all__ = ['simplify_graph']


def simplify_graph(graph_ir):
    """
    Function:
        Simplify the structure of given GraphIR
    """
    optimizer = GraphOptimizer()
    optimizer.add_pass(ReplaceGraphIRBNPass())
    optimizer.add_pass(ReplaceDropOutPass())
    optimizer.add_pass(CutWhileLoopPass())
    optimizer.add_pass(ReplacePoolReshapePass())
    optimizer.add_pass(RemoveHeadAndTailPass())
    optimizer.add_pass(CheckGroupConvPass())
    graph_ir = optimizer.do_optimizer(graph_ir)
    graph_ir.topologic_sort()# sort self.nodes
    LOGGER.push_info_message("{:*^100s}".format('SIMPLYFY COMPLETE'))
