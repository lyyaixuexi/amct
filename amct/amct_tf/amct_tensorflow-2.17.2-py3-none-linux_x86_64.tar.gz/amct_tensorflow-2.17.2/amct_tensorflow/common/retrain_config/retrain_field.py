#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

field defination in json config.

"""
from collections import OrderedDict
from .retrain_proto import DT_INT4
from .retrain_proto import DT_INT8


class ConfigItem():
    '''an class for ConfigItem filed'''
    def __init__(self, graph_querier, capacity, strong_check=True):
        '''inner method'''
        self.graph_querier = graph_querier
        self.capacity = capacity
        self.children = {}
        self.value = None
        self.strong_check = strong_check

    @staticmethod
    def check_type(name, variable, typeinfo, layer=None):
        '''inner method'''
        error_msg = "Type of %s should be %s, but is %s" \
                % (name, typeinfo, type(variable))
        if layer is not None:
            error_msg = "%s for layer %s" % (error_msg, layer)
        if not isinstance(variable, typeinfo):
            raise TypeError(error_msg)

    def set_strong_check(self, check_type):
        '''inner method'''
        self.strong_check = check_type

    def add_child(self, key, item):
        '''inner method'''
        self.children[key] = item

    def dump(self):
        '''inner method'''
        if self.children.keys():
            ordered_config = OrderedDict()
            for k, val in self.children.items():
                ordered_config[k] = val.dump()
            return ordered_config
        return self.value

    def build_util(self, key, cls, value, extra=None):
        '''inner method'''
        item = cls(self.graph_querier, self.capacity, self.strong_check)
        if extra:
            item.build(value, extra)
        else:
            item.build(value)
        self.add_child(key, item)

    def build_default_util(self, key, cls, extra=None):
        '''inner method'''
        item = cls(self.graph_querier, self.capacity, self.strong_check)
        if extra:
            item.build_default(extra)
        else:
            item.build_default()
        self.add_child(key, item)


class Version(ConfigItem):
    '''an object for Version filed'''
    def build(self, val):
        '''inner method'''
        self.check_type("Version", val, int)
        if val != 1:
            raise ValueError("version should be 1")
        self.value = 1

    def build_default(self):
        '''inner method'''
        self.value = 1


class BatchNum(ConfigItem):
    '''an object for BatchNum filed'''
    def build(self, val):
        '''inner method'''
        self.check_type("BatchNum", val, int)
        if val <= 0:
            raise ValueError("batch_num(%d) should be greater than zero." \
                             % val)
        self.value = val

    def build_default(self):
        '''inner method'''
        self.value = 1


class RetrainEnable(ConfigItem):
    '''an object for RetrainEnable filed'''
    def build(self, val, extra=None):
        '''inner method'''
        self.check_type("RetrainEnable", val, bool, extra[0])
        self.value = val

    def build_default(self):
        '''inner method'''
        self.value = True


class DataAlgo(ConfigItem):
    '''an object for DataAlgo filed'''
    def build(self, val, extra=None):
        '''inner method'''
        self.check_type('DataAlgo', val, str)
        if val != 'ulq_quantize':
            raise ValueError('DataAlgo only support ulq_quantize for layer %s'\
                    % (extra[0]))
        self.value = val

    def build_default(self):
        '''inner method'''
        self.value = 'ulq_quantize'


class ClipMax(ConfigItem):
    '''an object for ClipMax filed'''
    def build(self, val, extra):
        '''inner method'''
        self.check_type('ClipMax', val, float, extra[0])
        if val <= 0:
            raise ValueError('clip max should be larger than 0 for layer %s' \
                    % extra[0])
        self.value = val


class ClipMin(ConfigItem):
    '''an object for ClipMin filed'''
    def build(self, val, extra):
        '''inner method'''
        self.check_type('ClipMin', val, float, extra[0])
        if val >= 0:
            raise ValueError('clip min should be less than 0 for layer %s'\
                    % extra[0])
        self.value = val


class FixedMin(ConfigItem):
    '''an object for FixedMin filed'''
    def build(self, val, extra):
        '''inner method'''
        self.check_type('FixedMin', val, bool, extra[0])
        self.value = val


class DataType(ConfigItem):
    '''an object for DataType filed'''
    def build(self, val, extra):
        '''inner method'''
        self.check_type('dst_type', val, str, extra[0])
        if val not in [DT_INT4, DT_INT8]:
            raise ValueError(
                "now only support ['INT4', 'INT8'], but is {}".format(val))
        self.value = val

    def build_default(self, extra=None): # pylint: disable=W0613
        '''inner method'''
        self.value = DT_INT8


class RetrainDataConfig(ConfigItem):
    '''an object for RetrainDataConfig filed'''
    def build(self, val, extra):
        '''inner method'''
        self.check_type('RetrainDataConfig', val, dict, extra[0])
        key = 'algo'
        if key not in val.keys():
            self.build_default_util(key, DataAlgo)
        else:
            self.build_util(key, DataAlgo, val.get(key), extra)
            del val[key]

        if 'clip_max' in val.keys() and 'clip_min' in val.keys():
            self.build_util('clip_max', ClipMax, val.get('clip_max'), extra)
            self.build_util('clip_min', ClipMin, val.get('clip_min'), extra)
            del val['clip_max']
            del val['clip_min']
        if 'fixed_min' in val.keys():
            self.build_util('fixed_min', FixedMin, val.get('fixed_min'), extra)
            del val['fixed_min']

        if 'dst_type' in val.keys():
            self.build_util('dst_type', DataType, val.get('dst_type'), extra)
            del val['dst_type']
        else:
            self.build_default_util('dst_type', DataType)

        if val.keys():
            raise ValueError('Invalid keys in data config for layer %s'\
                    % extra[0])

    def build_default(self):
        '''inner method'''
        self.build_default_util('algo', DataAlgo)
        self.build_default_util('dst_type', DataType)


class WeightAlgo(ConfigItem):
    '''an object for WeightAlgo filed'''
    def build(self, val, extra=None):
        '''inner method'''
        self.check_type('WeightAlgo', val, str, extra[0])
        if val not in ['arq_retrain', 'ulq_retrain']:
            raise ValueError(
                'WeightAlgo only supports [arq_retrain, ulq_retrain] ' \
                    'for layer %s' % (extra[0]))
        self.value = val

    def build_default(self, extra=None): # pylint: disable=W0613
        '''inner method'''
        self.value = 'arq_retrain'


class ChannelWise(ConfigItem):
    '''an object for ChannelWise filed'''
    def build(self, val, extra):
        '''inner method'''
        self.check_type('ChannelWise', val, bool, extra[0])
        if extra[1] in [
                'Linear', 'MatMul', 'InnerProduct', 'Pooling', 'AvgPool'
        ] and val is True:
            raise ValueError(' %s layer can not be channewised' % extra[0])
        self.value = val

    def build_default(self, extra):
        '''inner method'''
        if extra[1] in [
                'Linear', 'MatMul', 'InnerProduct', 'Pooling', 'AvgPool'
        ]:
            self.value = False
        else:
            self.value = True


class RetrainWeightConfig(ConfigItem):
    '''an object for RetrainWeightConfig filed'''
    def build(self, val, extra):
        '''inner method'''
        self.check_type('RetrainWeightConfig', val, dict, extra[0])
        wts_algo = ''
        key = 'algo'
        if key not in val.keys():
            wts_algo = 'arq_retrain'
            self.build_default_util(key, WeightAlgo)
        else:
            wts_algo = val.get(key)
            self.build_util(key, WeightAlgo, val.get(key), extra)
            del val[key]

        if wts_algo == 'arq_retrain':
            self.build_config_by_key('channel_wise', ChannelWise, val, extra)
            self.build_config_by_key('dst_type', DataType, val, extra)
        elif wts_algo == 'ulq_retrain':
            self.build_config_by_key('dst_type', DataType, val, extra)
            self.build_config_by_key('channel_wise', ChannelWise, val, extra)
        else:
            raise ValueError("only support [arq_retrain, ulq_retrain], "
                             " but is {}".format(wts_algo))
        if val.keys():
            raise ValueError('Invalid keys in weight config for layer %s'\
                    % extra[0])

    def build_default(self, extra):
        '''inner method'''
        self.build_default_util('algo', WeightAlgo)
        self.build_default_util('channel_wise', ChannelWise, extra)
        self.build_default_util('dst_type', DataType)

    def build_config_by_key(self, key, cls, val, extra):
        '''inner method'''
        if key in val.keys():
            self.build_util(key, cls, val.get(key), extra)
            del val[key]
        else:
            self.build_default_util(key, cls, extra)


class RegularPruneEnable(ConfigItem):
    '''an object for RegularPruneEnable filed'''
    def build(self, val, extra=None):
        '''inner method'''
        self.check_type("RegularPruneEnable", val, bool, extra[0])
        self.value = val

    def build_default(self):
        '''inner method'''
        self.value = True


class PruneRatio(ConfigItem):
    '''an object for PruneRatio filed'''
    @staticmethod
    def build_default():
        '''inner method'''
        pass

    def build(self, val, extra=None):
        '''inner method'''
        self.check_type("PruneRatio", val, float, extra[0])
        if val <= 0 or val >= 1:
            raise ValueError('prune ration should be greater than 0 and less '\
                    'than 1 for layer %s' % extra[0])
        self.value = val


class AscendOptimized(ConfigItem):
    '''an object for AscendOptimized filed'''
    def build(self, val, extra=None):
        '''inner method'''
        self.check_type("AscendOptimized", val, bool, extra[0])
        self.value = val

    def build_default(self):
        '''inner method'''
        self.value = True


class NOutOfMType(ConfigItem):
    '''an object for NOutOfMType filed'''
    def __init__(self, graph_querier, capacity, strong_check=True):
        super().__init__(graph_querier, capacity, strong_check)
        self.support_n_out_of_m_type = ['M4N2']

    @staticmethod
    def build_default():
        '''inner method'''
        pass

    def build(self, val, extra=None):
        '''inner method'''
        self.check_type("NOutOfMType", val, str, extra[0])
        if val not in self.support_n_out_of_m_type:
            raise ValueError(
                'NOutOfMType only supports %s for layer %s' \
                % (self.support_n_out_of_m_type, extra[0]))
        self.value = val


class UpdateFreq(ConfigItem):
    '''an object for UpdateFreq filed'''
    @staticmethod
    def build_default():
        '''inner method'''
        pass

    def build(self, val, extra=None):
        '''inner method'''
        self.check_type("UpdateFreq", val, int, extra[0])
        if val < 0:
            raise ValueError('selective prune update freq should be no less than 0 '\
                    'for layer %s' % extra[0])
        self.value = val


class PruneType(ConfigItem):
    '''an object for PruneType filed'''
    __default_value = 'no_prune_enable'

    def __init__(self, graph_querier, capacity, strong_check=True):
        super().__init__(graph_querier, capacity, strong_check)
        self.support_algos = ['filter_prune', 'selective_prune']

    @property
    def val(self):
        '''
        get value of current algo
        Params: None
        Return: value, a string
        '''
        return self.value

    def build(self, val, extra=None):
        '''inner method'''
        self.check_type('PruneType', val, str, extra[0])
        if val not in self.support_algos :
            raise ValueError(
                'PruneType only supports %s for layer %s' \
                % (self.support_algos, extra[0]))
        self.value = val

    def build_default(self, extra=None): # pylint: disable=W0613
        '''inner method'''
        self.value = self.__default_value


class RegularPruneAlgo(ConfigItem):
    '''an object for RegularPruneAlgo filed'''
    def __init__(self, graph_querier, capacity, strong_check=True):
        super().__init__(graph_querier, capacity, strong_check)
        self.support_algos = ['balanced_l2_norm_filter_prune', 'l1_selective_prune']

    @property
    def val(self):
        '''
        get value of current algo
        Params: None
        Return: value, a string
        '''
        return self.value

    def build(self, val, extra=None):
        '''inner method'''
        self.check_type('RegularPruneAlgo', val, str, extra[0])
        if val not in self.support_algos :
            raise ValueError(
                'RegularPruneAlgo only supports %s for layer %s' \
                % (self.support_algos, extra[0]))
        self.value = val

    def build_default(self, extra=None): # pylint: disable=W0613
        '''inner method'''
        pass


class BcpPruneConfig(ConfigItem):
    '''an object for BcpPruneConfig filed'''
    fields = {
        'prune_ratio': PruneRatio,
        'ascend_optimized': AscendOptimized,
    }

    def build(self, val, extra):
        '''inner method'''
        self.check_type('BcpPruneConfig', val, dict, extra[0])

        def add_one_field(key, field, val):
            if key not in val.keys():
                self.build_default_util(key, field)
            else:
                self.build_util(key, field, val.get(key), extra)
                del val[key]

        for key in ['prune_ratio', 'ascend_optimized']:
            add_one_field(key, self.fields.get(key), val)

        if val.keys():
            raise ValueError('Invalid keys %s in prune config for layer %s'\
                    % (val.keys(), extra[0]))

    def build_default(self):
        '''inner method'''
        for key, field in self.fields.items():
            self.build_default_util(key, field)

    def build_config_by_key(self, key, cls, val, extra):
        '''inner method'''
        if key in val.keys():
            self.build_util(key, cls, val.get(key), extra)
            del val[key]
        else:
            self.build_default_util(key, cls, extra)


class RegularPruneConfig(ConfigItem):
    '''an object for PruneConfig filed'''
    fields = {
        'prune_type': PruneType,
        'algo': RegularPruneAlgo,
        # for balanced_l2_norm_filter_prune
        'prune_ratio': PruneRatio,
        'ascend_optimized': AscendOptimized,
        # for l1_selective_prune
        'n_out_of_m_type': NOutOfMType,
        'update_freq': UpdateFreq
    }

    def build(self, val, extra):
        '''inner method'''
        self.check_type('PruneConfig', val, dict, extra[0])

        def add_one_field(key, field, val):
            if key not in val.keys():
                self.build_default_util(key, field)
            else:
                self.build_util(key, field, val.get(key), extra)
                del val[key]

        for key in ['prune_type', 'algo']:
            add_one_field(key, self.fields.get(key), val)

        if self.children.get('algo').val == 'balanced_l2_norm_filter_prune':
            for key in ['prune_ratio', 'ascend_optimized']:
                add_one_field(key, self.fields.get(key), val)
        elif self.children.get('algo').val == 'l1_selective_prune':
            for key in ['n_out_of_m_type', 'update_freq']:
                add_one_field(key, self.fields.get(key), val)

        if val.keys():
            raise ValueError('Invalid keys in prune config for layer %s'\
                    % extra[0])

    def build_default(self):
        '''inner method'''
        for key, field in self.fields.items():
            self.build_default_util(key, field)

    def build_config_by_key(self, key, cls, val, extra):
        '''inner method'''
        if key in val.keys():
            self.build_util(key, cls, val.get(key), extra)
            del val[key]
        else:
            self.build_default_util(key, cls, extra)


class LayerConfig(ConfigItem):
    '''an object for LayerConfig filed'''
    fields = {
        'retrain_enable': RetrainEnable,
        'retrain_data_config': RetrainDataConfig,
        'retrain_weight_config': RetrainWeightConfig,
        'regular_prune_enable': RegularPruneEnable,
        'regular_prune_config': RegularPruneConfig,
    }

    @staticmethod
    def retrain_fields():
        """
        Get fields for quant retrain
        Params: None
        Returns: a list
        """
        return ['retrain_enable', 'retrain_data_config', 'retrain_weight_config']

    @staticmethod
    def prune_fields():
        """
        Get fields for prune retrain
        Params: None
        Returns: a list
        """
        return ['regular_prune_enable', 'regular_prune_config']

    def build(self, val, extra):
        '''inner method'''
        self.check_type('LayerConfig', val, dict)
        for key, cls in self.fields.items():
            if key not in val.keys():
                if key == 'retrain_weight_config':
                    self.build_default_util(key, cls, extra)
                else:
                    self.build_default_util(key, cls)
            else:
                if key == 'retrain_enable':
                    self.build_util(key, cls, val.get(key), extra)
                else:
                    self.build_util(key, cls, val.get(key), extra)
                del val[key]

    def build_default(self, extra):
        '''inner method'''
        for key, cls in self.fields.items():
            if key == 'retrain_weight_config':
                self.build_default_util(key, cls, extra)
            else:
                self.build_default_util(key, cls)


class RootConfig(ConfigItem):
    '''an object for RootConfig filed'''
    def check_layer_config_legal(self, layer):
        '''check layer config legal'''
        weight_config = self.children.get(layer).children.get('retrain_weight_config').children
        act_config = self.children.get(layer).children.get('retrain_data_config').children
        if 'dst_type' in weight_config:
            weight_dst = weight_config.get('dst_type').value
            act_dst = act_config.get('dst_type').value
            if weight_dst != act_dst:
                raise RuntimeError(
                    "Now do not support activation and weights with"
                    " different data_type, activation is {} and weight "
                    "is {}".format(act_dst, weight_dst))
            if "AvgPool" in layer and self.children.get(layer).children.get('retrain_enable').value:
                if weight_dst == 'INT4':
                    raise RuntimeError(
                        'Now AvgPool Layer does not support INT4')

    def build(self, value, extra):
        '''inner method'''
        self.check_type('RootConfig', value, dict)
        # handle version
        key = 'version'
        self._build(key, value)

        # handle batch_num
        if self.capacity.is_enable('BATCH_NUM'):
            key = 'batch_num'
            self._build(key, value)
        else:
            if 'batch_num' in value.keys():
                raise ValueError("unsupported batch_num")
        all_disable = True
        for layer, layer_config in value.items():
            if layer not in extra.keys():
                raise ValueError("unsupported layer %s" % {layer})
            if layer_config.get('retrain_enable') or layer_config.get('regular_prune_enable'):
                all_disable = False
            self.build_util(layer, LayerConfig, layer_config,
                            (layer, extra[layer]))
            self.check_layer_config_legal(layer)
            del extra[layer]
        disable_config = {}
        for layer, layer_type in extra.items():
            disable_config['retrain_enable'] = False
            self.build_util(layer, LayerConfig, disable_config,
                            (layer, layer_type))

        if all_disable:
            raise ValueError('No layer retrain enabled')

    def build_default(self, extra):
        '''inner method'''
        key = 'version'
        self.build_default_util(key, Version)
        if self.capacity.is_enable('BATCH_NUM'):
            key = 'batch_num'
            self.build_default_util(key, BatchNum)
        if not extra:
            raise ValueError('No layer retrain enabled')
        for layer, layer_type in extra.items():
            self.build_default_util(layer, LayerConfig, (layer, layer_type))

    def get_global_keys(self):
        '''Get global config's keys '''
        global_keys = ['version']
        if self.capacity.is_enable('BATCH_NUM'):
            global_keys.append('batch_num')
        return global_keys

    def _build(self, key, value):
        class_dict = {"version": Version, "batch_num": BatchNum}
        if key not in value and self.strong_check:
            raise ValueError("must has %s" % {key})
        if key not in value:
            self.build_default_util(key, class_dict.get(key))
        else:
            self.build_util(key, class_dict.get(key), value.get(key))
            del value[key]
