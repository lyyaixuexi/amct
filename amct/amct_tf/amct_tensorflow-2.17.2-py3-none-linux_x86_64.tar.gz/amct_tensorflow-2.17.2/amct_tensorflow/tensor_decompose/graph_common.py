#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2020-2021. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Common tools for graph decomposition.

"""
import os
import copy
import tensorflow as tf # pylint: disable=E0401


__all__ = ['GraphDecomposer', 'get_data_format', 'to_tensor_name',
           'check_obj_type', 'check_file_existence']


class GraphDecomposer():  # pylint: disable=R0903
    """
    Function: Decompose graph.
    APIs: decompose_one_layer
    """

    def __init__(self):
        """
        Function: Init GraphDecomposer.
        """
        # map from old to new vars,
        # to handle weights sharing among convolutions
        self._var_map = {}

    @staticmethod
    def _get_new_contex(context, root, suffix, use_new_context):
        """
        Function: Check and get new contex according to different cases.
        Parameter:
            context: The original context.
            root: Root of the new context.
            suffix: Suffix of the new context.
            use_new_context: Whether to use new context.
        Return: The processed context.
        """
        if use_new_context:
            if len(root) > 0:
                context = os.path.join(root, suffix)
            else:
                context = suffix
        return context

    @staticmethod
    def _modify_attr(pos, data_format, mode, attr, def_val):
        """
        Function: Modify convolution (conv2d) attribute according to different
            decomposition cases.
        Parameter:
            pos: Order flag of the decomposed weights.
            data_format: Data format.
            mode: Decomposition mode.
            attr: Attribute to be modified.
            def_val: Default value of a single item of the attribute.
        Return: The modified attribute.
        """
        if not isinstance(attr, list):
            return copy.deepcopy(attr)
        h_idx, w_idx = {'NHWC': (1, 2), 'NCHW': (2, 3)}.get(data_format)
        if (pos == 'first' and mode in ['FCSK', 'SCFK']) or \
            (pos == 'last' and mode in ['FCFK', 'SCSK']):
            modify_idx = w_idx
        else:
            modify_idx = h_idx
        if len(attr) == 4:
            new_attr = copy.deepcopy(attr)
        elif len(attr) == 1:
            new_attr = [copy.copy(def_val) for i in range(4)]
            new_attr[h_idx] = attr[0]
            new_attr[w_idx] = attr[0]
        elif len(attr) == 2:
            new_attr = [copy.copy(def_val) for i in range(4)]
            new_attr[h_idx] = attr[0]
            new_attr[w_idx] = attr[1]
        else:
            raise ValueError('Wrong length attribute: {}'.format(attr))
        new_attr[modify_idx] = copy.copy(def_val)
        return new_attr

    @staticmethod
    def _create_variable(data, shape, weights_name, dtype, context_info):
        """
        Function: Create a new variable.
        Parameter:
            data: Data used for initializer.
            shape: Shape of the variable to be created.
            weights_name: Name of the variable to be created.
            dtype: Data type of the variable to be created.
            context_info: Context information.
        Return:
            The created variable.
        """
        context = context_info['context']
        use_new_context = context_info['use_new']
        if use_new_context:
            scope = tf.compat.v1.variable_scope(None, default_name=context)
        else:
            scope = tf.compat.v1.variable_scope(context)
        with scope:
            weights_var = tf.compat.v1.get_variable(
                name=weights_name,
                shape=shape,
                initializer=tf.compat.v1.constant_initializer(data),
                dtype=dtype,
                trainable=True,
                collections=[
                    tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                    tf.compat.v1.GraphKeys.MODEL_VARIABLES
                ],
                use_resource=False)
        return weights_var

    @staticmethod
    def _relink_tensor(input_tensor, output_tensor):
        """
        Function: Replace the input of all the consumers of input_tensor with
            output_tensor.
        Parameter:
            input_tensor: The tensor to be replaced.
            output_tensor: The newer tensor to replace with.
        """
        for consumer in input_tensor.consumers():
            index = 0
            for producer in consumer.inputs:
                if input_tensor is producer:
                    break
                index += 1
            if index == len(consumer.inputs):
                raise ValueError('Failed to find input index in consumer.')
            consumer._update_input(  # pylint: disable=W0212
                index, output_tensor)

    @staticmethod
    def _create_conv2d(pos, from_op, node, weights, input_tensor):
        """
        Function: Create a new convolution (conv2d) according to different
            orders of the decomposed tensors.
        Parameter:
            pos: Order flag of the decomposed weights.
            from_op: The convolution to be copied from.
            node: Information of the decomposed weights.
            weights: Weights of the convolution to be created.
            input_tensor: Input tensor of the convolution to be created.
        Return: The newly created convolution tensor.
        """
        name = node['conv2d_name']
        mode = node['mode']
        if mode not in ['FCFK', 'FCSK', 'SCFK', 'SCSK']:
            raise ValueError('Wrong decomposition mode: {}'.format(mode))
        data_format = get_data_format(from_op.get_attr('data_format'))
        strides = GraphDecomposer._modify_attr(
            pos, data_format, mode, from_op.get_attr('strides'), 1)
        dilations = GraphDecomposer._modify_attr(
            pos, data_format, mode, from_op.get_attr('dilations'), 1)
        padding = from_op.get_attr('padding')
        if padding in [b'VALID', 'VALID', b'SAME', 'SAME']:
            pass
        else:
            if padding in [b'EXPLICIT', 'EXPLICIT']:
                padding = from_op.get_attr('explicit_paddings')
            if not isinstance(padding, list) and len(padding) == 8:
                raise ValueError("Unknown padding: {}".format(padding))
            padding = [padding[i * 2:(i + 1) * 2] for i in range(4)]
            padding = GraphDecomposer._modify_attr(
                pos, data_format, mode, padding, [0, 0])
        output_tensor = tf.compat.v1.nn.conv2d(
            input_tensor,
            filter=weights,
            strides=strides,
            dilations=dilations,
            padding=padding,
            data_format=data_format,
            name=name)
        return output_tensor

    def decompose_one_layer(self, conv_op, nodes, context=None):
        """
        Function: Decompose single convolution in graph.
        Parameter:
            conv_op: Convolution tensor to be decomposed.
            nodes: List of information of the decomposed tensors and weights.
            context [optional]: The name scope and variable scope to use. By
                default (context=None), names from "nodes" are uses.
        Return:
            added_node_names: List of the added convolution names after
                decomposition.
            decom_nodes: Decomposing information of the decomposed tensor.
            new_vars: The created new variables.
        """
        use_new_context = (context is None)
        added_node_names = []
        decom_nodes = {}
        new_vars = []
        output_tensor = conv_op.inputs[0]
        for pos in ['first', 'last']:
            node = nodes[pos]
            if node is None:
                decom_nodes[pos] = None
            else:
                context = GraphDecomposer._get_new_contex(
                    context, conv_op.name,
                    node['conv2d_name'], use_new_context)
                context_info = {"context": context, "use_new": use_new_context}
                weights_var, is_new_var = self._create_weights(
                    conv_op.inputs[1], node, pos, context_info)
                if use_new_context and is_new_var and len(context) > 0:
                    context = "{}{}".format(context, '/')# reuse the same context
                with tf.compat.v1.name_scope(context):
                    output_tensor = self._create_conv2d(
                        pos, conv_op, node,
                        weights_var.read_value(), output_tensor)
                decom_conv2d_name = to_tensor_name(output_tensor.name)
                added_node_names.append(decom_conv2d_name)
                decom_nodes[pos] = {
                    'conv2d': decom_conv2d_name,
                    'weights': to_tensor_name(weights_var.name),
                    'weights_shape': node['weights_shape'],
                    'mode': node['mode']}
                if is_new_var:
                    new_vars.append(weights_var)
        self._relink_tensor(conv_op.outputs[0], output_tensor)

        return added_node_names, decom_nodes, new_vars

    def _create_weights(self, ori_weights, node, pos, context_info):
        """
        Function: Create new weights or use existing weights.
        Parameter:
            ori_weights: Original weights before decomposition.
            node: Information of the decomposed weights.
            pos: Order flag of the decomposed weights.
            context_info: Context information.
        Return:
            weights_var: The returned weights variable.
            is_new_var: If the returned weights is newly created or an existing
                one.
        """
        ori_weights_name = ori_weights.name
        if ori_weights_name not in self._var_map:
            self._var_map[ori_weights_name] = {}

        if pos not in self._var_map.get(ori_weights_name):
            weights_var = self._create_variable(
                node['weights'],
                node['weights_shape'],
                node['weights_name'],
                ori_weights.dtype,
                context_info)
            self._var_map.get(ori_weights_name)[pos] = weights_var
            is_new_var = True
        else:
            weights_var = self._var_map.get(ori_weights_name).get(pos)
            is_new_var = False
        return weights_var, is_new_var


def to_tensor_name(name):
    """
    Function: Convert a tensor's value name (ends with ':#') to tensor name.
    Parameter:
        name: A tensor's value name.
    Return: The tensor name of the value.
    """
    pos = name.rfind(':')
    if pos >= 0:
        name = name[:pos]
    return name


def get_data_format(data_format):
    """
    Function: Check and get data format.
    Parameter:
        data_format: The data format to be checked.
    Return: The formatted data format ('NCHW' or 'NHWC').
    """
    if data_format in (b'NCHW', 'NCHW'):
        return 'NCHW'
    if data_format in (b'NHWC', 'NHWC'):
        return 'NHWC'
    raise ValueError("Invalid data format: {}".format(data_format))


def check_obj_type(obj, obj_name, expected_type):
    """
    Function: Check object type.
    Parameter:
        obj: The object to check.
        obj_name: Name of the object.
        expected_type: Expected type of the object.
    """
    if not isinstance(obj, expected_type):
        raise TypeError("\'{}\' type is wrong. Expected type \'{}\', "
                        "got \'{}\' instead".format(obj_name,
                                                    expected_type.__name__,
                                                    type(obj).__name__))


def check_file_existence(file_path):
    """
    Function: Check whether a file exists.
    Parameter:
        file_path: File path to check.
    """
    if not os.access(file_path, os.F_OK):
        raise IOError('{} does not exist!'.format(file_path))
    if not os.path.isfile(file_path):
        raise IOError('{} is not a file!'.format(file_path))
