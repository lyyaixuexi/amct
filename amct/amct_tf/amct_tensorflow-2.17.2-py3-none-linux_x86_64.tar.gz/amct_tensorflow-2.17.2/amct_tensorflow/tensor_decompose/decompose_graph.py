#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2020-2021. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Func decompose_graph.

"""
import os
import pickle
import traceback
import tensorflow as tf # pylint: disable=E0401
from amct_tensorflow.tensor_decompose.graph_common import GraphDecomposer
from amct_tensorflow.tensor_decompose.graph_common import check_obj_type
from amct_tensorflow.tensor_decompose.graph_common import check_file_existence
from amct_tensorflow.utils.log import LOGGER


__all__ = ['decompose_graph']


def decompose_graph(save_path, graph=None):
    """
    Function: Decompose graph after building model code. It is useful to embed
        in existing code for training or testing.
    Parameter:
        save_path: Path of the saved decomposed ckpt file, which is the same as
            the save_path used in auto_decomposition, i.e., if the decomposed
            model files are: "path/new_model.index", "path/new_model.pkl" and
            "path/new_model.data-00000-of-00001", then set save_path to
            "path/new_model". Only the ".pkl" file is required here.
        graph [optional]: Graph to be decomposed. By default (graph=None), the
            default graph of tensorflow is used.
    Return: List of the added nodes' names after decomposition.
    """
    decom_pkl_path, graph = _check_input(save_path, graph)
    with open(decom_pkl_path, "rb") as pkl_file:
        decom_info_list = pickle.load(pkl_file)

    graph_decomposer = GraphDecomposer()
    added_node_names = []
    with graph.as_default():
        LOGGER.push_info_message("decompose_graph start.")
        for decom_info in decom_info_list:
            ori_conv2d_name = decom_info['ori_conv2d_name']
            conv_op = _get_conv_op(
                graph, ori_conv2d_name, decom_info['ori_weights_shape'])
            decom_nodes = decom_info['decom_nodes']
            nodes = {}
            for pos in ['first', 'last']:
                decom_node = decom_nodes[pos]
                if decom_node is None:
                    nodes[pos] = None
                else:
                    nodes[pos] = {
                        'weights': 0.0,  # init weights
                        'weights_shape': decom_node['weights_shape'],
                        'weights_name': decom_node['weights'],
                        'conv2d_name': decom_node['conv2d'],
                        'mode': decom_node['mode']
                        }
            decom_result = graph_decomposer.decompose_one_layer(
                conv_op, nodes, context="")
            added_node_names.extend(decom_result[0])
            LOGGER.push_info_message('Decompose {} -> {}'.format(
                ori_conv2d_name, decom_result[0]))
        LOGGER.push_info_message("decompose_graph complete.")

    return added_node_names


def _get_conv_op(graph, ori_conv2d_name, ori_weights_shape):
    """
    Function: Check and get a convolution tensor.
    Parameter:
        graph: Current graph.
        ori_conv2d_name: Name of the convolution tensor to get.
        ori_weights_shape: Shape of the convolution tensor's weights.
    Return: The obtained convolution tensor.
    """
    try:
        conv_op = graph.get_operation_by_name(ori_conv2d_name)
    except Exception as e:
        msg = "{}\nInput decomposition information does not match " \
                "graph.".format(traceback.format_exc())
        raise ValueError(msg) from e
    weights = conv_op.inputs[1]
    if weights.shape != ori_weights_shape:
        raise ValueError("Original weights shape from input information does "
                         "not match the weights of \'{}\'".format(
                             ori_conv2d_name))
    return conv_op


def _check_input(save_path, graph):
    """
    Function: Check input parameters for decompose_graph.
    Parameter:
        save_path: Path of the saved decomposed ckpt file.
        graph: Graph to be decomposed.
    Return:
        decom_pkl_path: The ".pkl" file to be loaded.
        graph: Graph to be decomposed.
    """
    check_obj_type(save_path, "save_path", str)
    save_path = os.path.realpath(save_path)
    decom_pkl_path = save_path + ".pkl"
    check_file_existence(decom_pkl_path)
    if graph is None:
        graph = tf.compat.v1.get_default_graph()
    else:
        check_obj_type(graph, "graph", tf.compat.v1.Graph)
    return decom_pkl_path, graph
