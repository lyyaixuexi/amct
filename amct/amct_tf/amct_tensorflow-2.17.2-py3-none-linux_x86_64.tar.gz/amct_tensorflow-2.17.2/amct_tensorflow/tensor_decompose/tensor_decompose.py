#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2020-2021. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Func auto_decomposition.

"""
import os
import glob
import stat
import pickle
import traceback
import numpy as np
import tensorflow as tf # pylint: disable=E0401
from amct_tensorflow.common.decomposition.decomposition import \
    tensor_decomposition
from amct_tensorflow.common.decomposition.decomposition import DecomposeMode
from amct_tensorflow.tensor_decompose.graph_common import GraphDecomposer
from amct_tensorflow.tensor_decompose.graph_common import get_data_format
from amct_tensorflow.tensor_decompose.graph_common import to_tensor_name
from amct_tensorflow.tensor_decompose.graph_common import check_obj_type
from amct_tensorflow.tensor_decompose.graph_common import check_file_existence
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.common.utils.files import check_files_exist


__all__ = ['auto_decomposition']


def auto_decomposition(meta_path, ckpt_path, save_path):
    """
    Function: Decompose input tensorflow model and output the decomposed model.
    Parameter:
        meta_path: Input meta file path.
        ckpt_path: Input ckpt file path, e.g., if the original model files are:
            "path/model.data-00000-of-00001" and "path/model.index", then set
            ckpt_path to "path/model".
        save_path: Path to save decomposed model, similar to ckpt_path,
            e.g., set save_path to "path/new_model", the saved files will be:
            "path/new_model.index", "path/new_model.pkl", "checkpoint",
            "path/new_model.data-00000-of-00001" and "path/new_model.meta".
            The ".pkl" file is used to decompose graph with code, see
            decompose_graph for details.
    Return: List of the added convolution names after decomposition.
    """
    LOGGER.push_info_message("auto_decomposition start.")
    meta_path, ckpt_path, save_path = _check_input(
        meta_path, ckpt_path, save_path)
    sess = _load_model(meta_path, ckpt_path)
    conv_info_list = _get_conv_info_list(sess)

    # decompose weights
    for conv_info in conv_info_list:
        # (K_h, K_w, C_in, C_out) -> (C_out, C_in, K_h, K_w)
        tensor = np.transpose(conv_info['weights_numpy'], (3, 2, 0, 1))
        LOGGER.push_info_message('Processing {}'.format(conv_info['name']))
        decom_res = tensor_decomposition(
            tensor, stride=conv_info['stride'],
            group=1, dilation=conv_info['dilation'])
        conv_info['decom_weights'] = _transfer_to_4dim(decom_res)

    # modify graph
    with sess.graph.as_default():
        added_node_names, decom_info_list, vars_to_init = \
            _decompose_graph(conv_info_list)

    if len(added_node_names) > 0:
        _save_model(save_path, ckpt_path, sess, vars_to_init, decom_info_list)
    else:
        LOGGER.push_info_message("No tensor meets decomposition conditions. "
                                 "No files are saved.")
    sess.close()
    LOGGER.push_info_message("auto_decomposition complete.")
    return added_node_names


def _get_conv_info_list(sess):
    """
    Function: Get a list of conv2d information from session's graph.
    Parameter:
        sess: Current session.
    Return: List of conv2d information.
    """
    ops = sess.graph.get_operations()
    conv_ops = [op for op in ops if op.type.lower() == 'conv2d']
    conv_info_list = []
    with sess.as_default():
        for conv_op in conv_ops:
            conv_info_list.append(_get_conv_info(conv_op))
    return conv_info_list


def _check_input(meta_path, ckpt_path, save_path):
    """
    Function: Check input parameters for auto_decomposition.
    Parameter:
        meta_path: Input meta file path.
        ckpt_path: Input ckpt file path.
        save_path: Path to save decomposed model.
    Return:
        meta_path: Standardized input meta file path.
        ckpt_path: Standardized input ckpt file path.
        save_path: Standardized path to save decomposed model.
    """
    check_obj_type(meta_path, "meta_path", str)
    check_obj_type(ckpt_path, "ckpt_path", str)
    check_obj_type(save_path, "save_path", str)
    meta_path = os.path.realpath(meta_path)
    ckpt_path = os.path.realpath(ckpt_path)
    save_path = os.path.realpath(save_path)
    check_file_existence(meta_path)
    check_file_existence(ckpt_path + ".index")
    data_exists = False
    data_pattern = ".data-{}-of-{}".format("[0-9]" * 5, "[0-9]" * 5)
    for data_path in glob.glob(ckpt_path + data_pattern):
        if os.path.isfile(data_path):
            data_exists = True
            break
    if not data_exists:
        raise IOError('Cannot find file: {}.data-?????-of-?????'.format(
            ckpt_path))
    return meta_path, ckpt_path, save_path


def _load_model(meta_path, ckpt_path):
    """
    Function: Load model from meta file and ckpt file.
    Parameter:
        meta_path: Input meta file path.
        ckpt_path: Input ckpt file path.
    Return: The loaded session.
    """
    graph = tf.compat.v1.Graph()
    sess = tf.compat.v1.Session(graph=graph, config=tf.compat.v1.ConfigProto(
        log_device_placement=False, allow_soft_placement=True))
    with sess.graph.as_default():
        with sess.as_default() as cur_sess:
            try:
                saver = tf.compat.v1.train.import_meta_graph(meta_path)
            except Exception as e:
                msg = "{}\nFailed to load meta file: {}".format(
                    traceback.format_exc(), meta_path)
                raise ValueError(msg) from e
            if saver is None:
                raise ValueError("Graph is empty, please check the input meta "
                                 "file: {}".format(meta_path))
            try:
                saver.restore(cur_sess, ckpt_path)
            except Exception as e:
                msg = "{}\nFailed to load model, please check input files." \
                    .format(traceback.format_exc())
                raise ValueError(msg) from e
    return sess


def _save_model(save_path, ckpt_path, sess, vars_to_init, decom_info_list):
    """
    Function: Save model after decomposition.
    Parameter:
        save_path: Path to save decomposed model.
        ckpt_path: Input ckpt file path.
        sess: Current session.
        vars_to_init: Variables to initialize.
        decom_info_list: A list to store decomposition information.
    """
    dir_mode = stat.S_IRWXU + stat.S_IRGRP + stat.S_IXGRP
    file_mode = stat.S_IRUSR + stat.S_IWUSR + stat.S_IRGRP
    save_root = os.path.split(save_path)[0]
    if os.path.isfile(save_root):
        raise ValueError("Failed to create path, {} is a file.".format(
            save_root))
    os.makedirs(save_root, dir_mode, exist_ok=True)
    pkl_save_path = save_path + ".pkl"
    check_files_exist([
        pkl_save_path,
        os.path.join(save_root, "checkpoint"),
        save_path + ".data-00000-of-00001",
        save_path + ".index",
        save_path + ".meta"])
    with open(pkl_save_path, "wb") as pkl_file:
        pickle.dump(decom_info_list, pkl_file)
    os.chmod(pkl_save_path, file_mode)
    with sess.graph.as_default():
        with sess.as_default() as cur_sess:
            if len(vars_to_init) > 0:
                cur_sess.run(tf.compat.v1.variables_initializer(vars_to_init))
            useful_var = _get_ckpt_variables(ckpt_path) + vars_to_init
            saver = tf.compat.v1.train.Saver(
                useful_var, save_relative_paths=True)
            saver.save(cur_sess, save_path)
    os.chmod(os.path.join(save_root, "checkpoint"), file_mode)
    os.chmod(save_path + ".data-00000-of-00001", file_mode)
    os.chmod(save_path + ".index", file_mode)
    os.chmod(save_path + ".meta", file_mode)
    LOGGER.push_info_message("Files are saved to: {}".format(save_root))


def _get_conv_info(conv_op):
    """
    Function: Get detailed convolution information.
    Parameter:
        conv_op: Convolution tensor.
    Return: The collected convolution information.
    """
    data_format = get_data_format(conv_op.get_attr('data_format'))
    if data_format == 'NHWC':
        stride_h, stride_w = conv_op.node_def.attr["strides"].list.i[1:3]
        dilation_h, dilation_w = conv_op.node_def.attr["dilations"].list.i[1:3]
    elif data_format == 'NCHW':
        stride_h, stride_w = conv_op.node_def.attr["strides"].list.i[2:4]
        dilation_h, dilation_w = conv_op.node_def.attr["dilations"].list.i[2:4]
    else:
        raise NotImplementedError(
            'Unsupported data format: {}'.format(data_format))
    weights = conv_op.inputs[1]
    weights_numpy = weights.eval().astype(np.float64)
    conv_info = {'name': conv_op.name,
                 'op': conv_op,
                 'stride': (stride_h, stride_w),
                 'dilation': (dilation_h, dilation_w),
                 'weights_numpy': weights_numpy,
                 'weights_name': weights.name}
    return conv_info


def _get_ckpt_variables(ckpt_path):
    """
    Function: Get all saved variables from ckpt file.
    Parameter:
        ckpt_path: Input ckpt file path.
    Return: List of variable names.
    """
    var_list = tf.compat.v1.global_variables()
    reader = tf.compat.v1.train.NewCheckpointReader(ckpt_path)
    var_dict = {var.op.name: var for var in var_list}

    available_vars = []
    for var_name, var in var_dict.items():
        if reader.has_tensor(to_tensor_name(var_name)):
            available_vars.append(var)

    return available_vars


def _transfer_to_4dim(res_dict):
    """
    Function: Transfer tensors to 4 dimensions (K_h, K_w, C_in, C_out).
    Parameter:
        res_dict: Decomposed tensors dict.
    Return: Decomposed 4D tensors dict.
    """
    res = {}
    for key, value in res_dict.items():
        if key == 'mode':
            res[key] = value
        elif value is None:
            res[key] = None
        elif len(value.shape) == 2:
            # (C_out, *) -> (K_h, K_w, C_in, C_out)
            res[key] = value[:, :, np.newaxis, np.newaxis].transpose(
                (2, 3, 1, 0))
        elif len(value.shape) == 4:
            # (C_out, C_in, K_h, K_w) -> (K_h, K_w, C_in, C_out)
            res[key] = value.transpose((2, 3, 1, 0))
    return res


def _decompose_graph(conv_info_list):
    """
    Function: Decompose graph with decomposed tensors.
    Parameter:
        conv_info_list: list of convolution information.
    Return:
        added_node_names: New nodes names list.
        decom_info_list: List of decomposition information.
        added_vars: New variables list.
    """
    added_node_names = []
    decom_info_list = []
    added_vars = []

    graph_decomposer = GraphDecomposer()
    for conv_info in conv_info_list:
        mode = conv_info['decom_weights']['mode']
        if mode != DecomposeMode.UNCHANGE:
            conv_op = conv_info['op']
            nodes = {}
            for pos in ['first', 'last']:
                weights = conv_info['decom_weights'][pos]
                if weights is None:
                    nodes[pos] = None
                else:
                    nodes[pos] = {
                        'weights': weights,
                        'weights_shape': weights.shape,
                        'weights_name': 'weights',
                        'conv2d_name': 'decom_{}'.format(pos),
                        'mode': mode.name
                        }
            new_nodes, decom_nodes, new_vars = \
                graph_decomposer.decompose_one_layer(conv_op, nodes)
            added_node_names.extend(new_nodes)
            decom_info = {
                'ori_conv2d_name': conv_info['name'],
                'ori_weights_shape': conv_info['weights_numpy'].shape,
                'decom_nodes': decom_nodes}
            decom_info_list.append(decom_info)
            added_vars.extend(new_vars)
            LOGGER.push_info_message('Decompose {} -> {}'.format(
                conv_info['name'], new_nodes))

    return added_node_names, decom_info_list, added_vars
