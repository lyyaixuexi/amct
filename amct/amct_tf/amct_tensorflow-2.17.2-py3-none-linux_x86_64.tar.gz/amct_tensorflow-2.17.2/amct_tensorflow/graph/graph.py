#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Data structure of graph which contains graph topologic info

"""
import tensorflow as tf

from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.graph.node import Node
from amct_tensorflow.graph.node import FakeOP
from amct_tensorflow.common.graph_base.graph_base import GraphBase


class Graph(GraphBase):
    """
    Function:
        a inner representation of tf.Graph
    """
    def __init__(self, graph, prune_config, outputs):
        """
        Function:
            initialise GraphIR object
        Inputs:
            graph: a tf.compat.v1.Graph.
            prune_config: a dictionary containing pruning paramters of each
                prunable layer parsed from config defination.
            outputs: a list containing the names of outputs of the model.
        """
        super().__init__(graph)
        self.graph = graph
        self.prune_config = prune_config
        self.skip_layers = []
        self.groups = {}# store elt-wise op and corresponding brothers
        self.outputs = outputs
        self._init_graph()# convert graph to graphir

    def get_operations(self):
        """
        Function: get all nodes in the graphIR
        """
        return self._nodes

    def extract_sub_graph(self):
        """
        Function: extract subgraph according to outputs by BFS
        """
        graph_def = self.graph.as_graph_def()
        # extract graph according to model's outputs
        sub_graph_def = tf.compat.v1.graph_util.extract_sub_graph(graph_def, self.outputs)
        return [node.name for node in sub_graph_def.node]

    def create_fake_node(self,
                        node_name,
                        node_type,
                        anchors,
                        node_index):
        """
        Function:   append an additional node to the graphIR, that does not
                    exist ih the original tf.graph
        """
        in_anchor = anchors[0]
        out_anchors = anchors[1]
        fake_op = FakeOP(name=node_name,
                        op_type=node_type,
                        op_input=in_anchor,
                        op_outputs=out_anchors)
        fake_node = Node(node_index, fake_op)
        self.nodes.append(fake_node)
        return fake_node

    def _init_graph(self):
        """
        Function: initialise all nodes in the graph and get them connected
        """
        output_record = {}
        all_ops = self.graph.get_operations()
        sub_op_names = self.extract_sub_graph()
        # parse supported ops
        for op in all_ops:
            if op.name not in sub_op_names:
                continue
            op_node = Node(self._tail, op)
            config = self.prune_config.get(op.name)
            if config and config.get('regular_prune_enable'):
                prune_config = config.get('regular_prune_config')
                if prune_config.get('prune_type') == "filter_prune":
                    op_node.set_attr('filter_prune_enable', True)
                    op_node.set_attr('prune_ratio', prune_config.get('prune_ratio'))
                    op_node.set_attr('ascend_optimized', prune_config.get('ascend_optimized'))
                elif prune_config.get('prune_type') == "selective_prune":
                    op_node.set_attr('selective_prune_enable', True)
                    op_node.set_attr('n_out_of_m_type', prune_config.get('n_out_of_m_type'))
                    op_node.set_attr('update_freq', prune_config.get('update_freq'))
            else:
                op_node.set_attr('prune_ratio', 0)
            for output_anchor in op_node._output_anchors:
                output_record[output_anchor.name] = [op_node, output_anchor.index]
            self.nodes.append(op_node)

        # add links between nodes
        for node in self.nodes:
            for input_anchor in node._input_anchors:
                if input_anchor.name not in output_record:
                    continue
                src_node, src_index = output_record[input_anchor.name]
                self.add_edge(src_node, src_index, node, input_anchor.index)
        LOGGER.push_info_message("{:*^100s}".format('INITIALISATION COMPLETE'))
