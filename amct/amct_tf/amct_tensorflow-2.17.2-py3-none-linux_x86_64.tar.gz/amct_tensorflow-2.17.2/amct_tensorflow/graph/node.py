#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Data structure of node which contains LayerParameter info

"""

import tensorflow as tf
from amct_tensorflow.common.graph_base.node_base import NodeBase
from amct_tensorflow.graph.anchor import InputAnchor
from amct_tensorflow.graph.anchor import OutputAnchor
from amct_tensorflow.capacity import CAPACITY
from tensorflow.python.framework import tensor_util

PRUNE_AXIS = {
        'Conv2D': 3,
        'MatMul': 1,
        'Conv2DBackpropInput': 2,
        'BiasAdd': 0,
        'FusedBatchNormV3':0,
        'FusedBatchNorm':0,
        'FusedBatchNormV2':0,
        'DepthwiseConv2dNative':2
}
IN_AXIS = {
        'Conv2D': 2,
        'MatMul': 0,
        'Conv2DBackpropInput': 3,
        'BiasAdd': 0,
        'FusedBatchNormV3':0,
        'FusedBatchNorm':0,
        'FusedBatchNormV2':0,
        'DepthwiseConv2dNative':2
}


class Node(NodeBase):
    """
    Function: inner representation of tf.operation
    """
    def __init__(self, node_index, op):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        node_id = op.name
        super().__init__(node_id, node_index, None)
        self._basic_info['type'] = op.type
        self.op = op
        self.node_def = op.node_def
        self.prune_producers = []
        self._init_anchor()
        self._init_node()

    def __repr__(self):
        return '< name: {}, inputs: {}, outputs:{}>'.format(
            self._basic_info.get('name'),
            [x.name for x in self._input_anchors],
            [x.name for x in self._output_anchors])

    def replace_input_anchor(self, ind, input_name):
        """Function: replace input anchor of node"""
        if ind > len(self._input_anchors):
            raise RuntimeError("Replacing index out of range")
        self._input_anchors[ind] = InputAnchor(self, ind, input_name)

    def is_head(self):
        '''Function: check if node has any producer'''
        return not any(anchor.get_peer_output_anchor() for anchor in self.input_anchors)

    def is_tail(self):
        '''Function: check if node has any consumer'''
        if self.type == 'Output':
            return False
        for idx in range(len(self.output_anchors)):
            consumers, _ = self.get_consumers(idx)
            if consumers:
                return all(consumer.type == 'Output' for consumer in consumers)
        return True

    def _init_anchor(self):
        """Function: init input/output anchors for node"""
        # init input anchors
        for index, input_tensor in enumerate(self.op.inputs):
            self._input_anchors.append(InputAnchor(self, index,
                                                    input_tensor.name))
        # init output anchors
        for index, output_tensor in enumerate(self.op.outputs):
            self._output_anchors.append(OutputAnchor(self, index,
                                                        output_tensor.name))

    def _init_node(self):
        '''Function: resgister the op's pruneing-relative infomation for NodeIR'''
        self.set_attr('selective_prune_enable', False)
        self.set_attr('update_freq', 0)
        self.set_attr('n_out_of_m_type', None)
        self.set_attr('selective_prune_records', None)
        self.set_attr('selective_prune_mask_tensor', None)
        self.set_attr('filter_prune_enable', False)
        self.set_attr('prune_ratio', 0)
        self.set_attr('in_channels', None)
        self.set_attr('out_channels', None)
        self.set_attr('in_channel_tensors', [])
        self.set_attr('out_channel_tensor', None)
        self.set_attr('active_prune_records', None)
        self.set_attr('passive_prune_records', None)
        self.set_attr('passive_prune_split', {})# number of pruned channels for each split
        self.set_attr('is_group_conv', False)
        self.set_attr('ascend_optimized', False)
        wgt_names = []# tensor names stored in checkpoint file
        path_to_wgt = []# intermediate nodes' names beweem prunable node and wgt node
        try:# NCHW or NHWC
            data_format = self.op.get_attr('data_format').decode('utf-8')
        except (ValueError, AttributeError):
            data_format = None
        self.set_attr('data_format', data_format)
        if self.op.type in CAPACITY.get_value('PRUNABLE_TYPES') \
            + CAPACITY.get_value('PASSIVE_PRUNABLE_TYPES'):
            self.set_attr('prune_axis', PRUNE_AXIS.get(self.op.type))
            self.set_attr('in_axis', IN_AXIS.get(self.op.type))
            self._init_cp_node(wgt_names, path_to_wgt)
        elif self.op.type in CAPACITY.get_value('SPECIAL_OPS'):
            self._init_special_node()
        if self.op.type in CAPACITY.get_value('SELECTIVE_PRUNABLE_TYPES'):
            self.set_attr('selective_prune_axis', IN_AXIS.get(self.op.type))
            self._init_sp_node(wgt_names, path_to_wgt)
        self.set_attr('wgt_names', wgt_names)
        self.set_attr('path_to_wgt', path_to_wgt)

    def _init_cp_node(self, wgt_names, path_to_wgt):
        '''Function: initialise PRUNABLE_TYPES and PASSIVE_PRUNABLE_TYPES'''
        if self.op.type in ['FusedBatchNormV3', 'FusedBatchNorm', 'FusedBatchNormV2']:
            for wgt_idx in range(1, 5):
                weight_in_tensor = self.op.inputs[wgt_idx]
                weight_tensor, path = find_weight_tensor(
                    weight_in_tensor, [self.op.name, weight_in_tensor.op.name])
                wgt_names.append(weight_tensor.op.name)
                path_to_wgt += path
        else:
            weight_in_tensor = self.op.inputs[1]
            weight_tensor, path = find_weight_tensor(
                weight_in_tensor, [self.op.name, weight_in_tensor.op.name])
            wgt_names.append(weight_tensor.op.name)
            path_to_wgt += path
        if weight_tensor.op.type in ['Placeholder', 'PlaceholderWithDefault']:
            self._basic_info['type'] = "".join([self.op.type, "_placeholder"])
        in_channels = self.op.inputs[1].shape.as_list()[IN_AXIS.get(self.op.type)]
        out_channels = self.op.inputs[1].shape.as_list()[PRUNE_AXIS.get(self.op.type)]
        if self.op.type == 'MatMul':
            if self.op.get_attr('transpose_b'):
                in_channels, out_channels = out_channels, in_channels
                self.set_attr('prune_axis', 0)
                self.set_attr('in_axis', 1)
        self.set_attr('in_channels', in_channels)
        self.set_attr('out_channels', out_channels)
        return wgt_names

    def _init_sp_node(self, wgt_names, path_to_wgt):
        '''Function: initialise SELECTIVE_PRUNABLE_TYPES'''
        if not wgt_names:
            weight_in_tensor = self.op.inputs[1]
            weight_tensor, path = find_weight_tensor(
                weight_in_tensor, [self.op.name, weight_in_tensor.op.name])
            wgt_names.append(weight_tensor.op.name)
            path_to_wgt += path
            if weight_tensor.op.type in ['Placeholder', 'PlaceholderWithDefault']:
                self._basic_info['type'] = "".join([self.op.type, "_placeholder"])
        in_channels = self.op.inputs[1].shape.as_list()[IN_AXIS.get(self.op.type)]
        if self.op.type == 'MatMul':
            if self.op.get_attr('transpose_b'):
                self.set_attr('selective_prune_axis', 1)
                in_channels = self.op.inputs[1].shape.as_list()[PRUNE_AXIS.get(self.op.type)]
        self.set_attr('in_channels', in_channels)
        self.set_attr('wgt_shape', self.op.inputs[1].shape.as_list())
        return wgt_names

    def _init_special_node(self):
        '''Function: initialise split, concat ops'''
        if self.op.type == 'SplitV':
            size_splits = read_node_def_value(self.op.inputs[1].op)
            split_dim = read_node_def_value(self.op.inputs[-1].op)
            self.set_attr('size_splits', size_splits)
            self.set_attr('split_dim', split_dim)
            self.set_attr('input_axis', 0)
        elif self.op.type == 'Split':
            num_split = self.op.get_attr('num_split')
            input_shape = str(self.op.inputs[1].shape)
            if input_shape != '<unknown>':
                new_size = [int(self.op.inputs[1].shape[-1])//num_split]*num_split
                self.set_attr('size_splits', new_size)
            split_dim = read_node_def_value(self.op.inputs[0].op)
            self.set_attr('split_dim', split_dim)
            self.set_attr('input_axis', 1)
        elif self.op.type == 'ConcatV2':
            axis = read_node_def_value(self.op.inputs[-1].op)
            self.set_attr('axis', axis)
            num_branch = self.op.get_attr('N')
            concat_width = []
            for input_tensor in self.op.inputs[:num_branch]:
                if not input_tensor.shape :
                    # preprocess tensors may have shape of none
                    continue
                producer_out_width = input_tensor.shape.as_list()[axis]
                if not producer_out_width:# axis of concat is not "NHWC"'s 'C'
                    producer_out_width = input_tensor.shape.as_list()[-1]
                concat_width.append(producer_out_width)
            self.set_attr('concat_width', concat_width)


def read_node_def_value(op):
    """Function: parse op's node_def and read its value attr"""
    node_def = op.node_def
    value_array = tensor_util.MakeNdarray(node_def.attr['value'].tensor)
    return value_array.tolist()


def find_weight_tensor(tensor, path):
    """
    Function:
        Recursively find weight node's output tensor for each prunable layer
    Inputs:
        tensor: prunable node's input tensor that points to the corresponding weight node
        path: list of intermediate nodes' names between prunable node and its weight node
    Returns:
        read_tensor: weight node's output tensor
        path: list of intermediate ndoes' names
    """
    if ('read' in tensor.name and tensor.op.type == 'Identity') or \
        tensor.op.type == 'ReadVariableOp':
        wgt_node_name = tensor.op.inputs[0].op.name
        return tensor.op.inputs[0], path + [wgt_node_name]
    if tensor.op.type in ['Const', 'Placeholder', 'PlaceholderWithDefault']:
        return tensor, path
    read_tensor = None
    result_path = path
    for input_tensor in tensor.op.inputs:
        if not tf.is_tensor(read_tensor):
            read_tensor, result_path = find_weight_tensor(input_tensor, path+[input_tensor.op.name])
    return read_tensor, result_path


class FakeOP():
    """Function: A mock class for op"""
    def __init__(self, name, op_type, op_input, op_outputs):
        self.name = name
        self.type = op_type
        self.inputs = op_input if isinstance(op_input, list) else [op_input]
        self.outputs = op_outputs if isinstance(op_outputs, list) else [op_outputs]
        self.node_def = None

    @staticmethod
    def get_attr(key):
        return None
