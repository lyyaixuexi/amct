#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

load c++ custom ops.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import ctypes
import glob
from multiprocessing import Queue
from multiprocessing import Process

import tensorflow as tf
from tensorflow.python.framework import ops

from amct_tensorflow.utils.utils_vars import EPSILON
from amct_tensorflow.utils.utils_vars import BASE
from amct_tensorflow.utils.utils_vars import ONE
from amct_tensorflow.utils.utils_vars import ZERO
from amct_tensorflow.utils.log import LOGGER

CUR_DIR = os.path.split(os.path.realpath(__file__))[0]
NCX_LIB_PATH = os.path.join(CUR_DIR, 'libamct_ncx.so')


def import_npu_lib():
    '''load lib of npu'''
    from npu_bridge import npu_bridge_handle
    return npu_bridge_handle


def dp_pow(operation, quant_bit_num):
    '''Deploy the pow operator on the executable default device.'''
    device = ''
    if len(operation.device.split(':')) > 1:
        device = '/device:XLA_GPU:' + operation.device.split(':')[-1]
    with tf.compat.v1.device(device):
        pow_tensor = tf.compat.v1.pow(BASE, quant_bit_num)
    return pow_tensor


def is_whl_package():
    """judge whether the package is whl package"""
    with open(os.path.join(CUR_DIR, '..', '.version')) as fid:
        lines = fid.readlines()
    contents = [line.strip() for line in lines]
    return 'sdist' not in contents


def is_ascend_package():
    """judge whether the package is ascend package"""
    with open(os.path.join(CUR_DIR, '..', '.version')) as fid:
        lines = fid.readlines()
    contents = [line.strip() for line in lines]
    return 'ascend' in contents


def targz_use_gpu():
    """judge if targz package use gpu"""
    with open(os.path.join(CUR_DIR, '..', '.version')) as fid:
        lines = fid.readlines()
    contents = [line.strip() for line in lines]
    return 'gpu' in contents


def detect_gpu_env(com_queue):
    '''Check whether gpu is available'''
    os.environ['TF_CPP_MIN_LOG_LEVEL'] = '1'
    ret = tf.test.is_gpu_available()
    com_queue.put(ret)


def whl_use_gpu():
    """judge if whl package use gpu"""
    com_queue = Queue()
    pro = Process(target=detect_gpu_env, args=(com_queue, ))
    pro.start()
    pro.join()
    return com_queue.get(True)


class AmctOps():
    """
    Collect all AMCT custom ops
    """
    def __init__(self):
        self.ops = []

    def __getattr__(self, key):
        for custom_op in self.ops:
            if hasattr(custom_op, key):
                return getattr(custom_op, key)
        return None

    def add_op(self, custom_op):
        """add custom op"""
        self.ops.append(custom_op)


class Lib():
    """
    Function: manage dynamic library
    APIs: set_lib, get_lib
    """
    _instance = None

    def __new__(cls, *args, **kw):
        if cls._instance is None:
            cls._instance = object.__new__(cls, *args, **kw)
        return cls._instance

    def __init__(self):
        if not hasattr(self, '_lib'):
            self._lib = None
            self._ascend_lib = None

    def set_lib(self, binary_name):
        '''set library'''
        LOGGER.push_debug_message('binary_name is {}'.format(binary_name),
                                  module_name='load_custom_op')
        custom_ops = glob.glob(
            os.path.join(CUR_DIR, '../../', 'amct_tensorflow_ops*.so'))
        kernel_lib = os.path.join(CUR_DIR, binary_name)
        if not is_whl_package():
            ctypes.cdll.LoadLibrary(kernel_lib)
        else:
            custom_ops.append(kernel_lib)

        self._lib = AmctOps()
        for custom_op in custom_ops:
            self._lib.add_op(tf.compat.v1.load_op_library(custom_op))
        if is_ascend_package():
            self._ascend_lib = import_npu_lib()
        else:
            self._ascend_lib = self._lib

    def get_lib(self):
        '''get library'''
        return self._lib

    def get_ascend_lib(self):
        '''get library'''
        return self._ascend_lib


def load_ascend():
    '''
    load c++ ascend custom ops.
    '''
    load()
    return Lib().get_ascend_lib()


def load(binary_name='libquant'):
    '''
    load c++ custom ops.
    '''
    if Lib().get_lib():
        return Lib().get_lib()

    version = tf.__version__
    if is_whl_package() and version != '1.15.0':
        print('Warning: This software implementation is for TensorFlow1.15.0!',
              'It may work incorrectly on TensorFlow{}!'.format(version))
    elif version not in ['1.15.0', '2.6.5']:
        print(
            'Warning: This software implementation is for TensorFlow1.15.0 '
            'and TensorFlow2.6.5!',
            'It may work incorrectly on TensorFlow{}!'.format(version))

    gpu_flag = whl_use_gpu() if is_whl_package() else targz_use_gpu()

    if gpu_flag:
        binary_name = ''.join([binary_name, '_gpu'])
    binary_name = ''.join([binary_name, '.so'])
    Lib().set_lib(binary_name)
    return Lib().get_lib()


def _diff(data, clip_max, clip_min, quant_bit_num=8):
    steps = tf.compat.v1.subtract(
        tf.compat.v1.cast(dp_pow(data.op, quant_bit_num),
                          tf.compat.v1.float32), ONE)
    temp = tf.compat.v1.divide(
        tf.compat.v1.multiply(data, steps),
        tf.compat.v1.add(tf.compat.v1.subtract(clip_max, clip_min), EPSILON))
    result = tf.compat.v1.multiply(
        tf.compat.v1.divide(ONE, steps),
        tf.compat.v1.subtract(tf.compat.v1.round(temp), temp))
    return result


def _broadcast(source, target):
    return tf.compat.v1.broadcast_to(source, tf.compat.v1.shape(target))


@ops.RegisterGradient("ActivationRetrain")
def _activation_retrain_grad(
        operation,
        grad_output,
        grad_scale,
        grad_offset,
        grad_clip_max_out,
        grad_clip_min_out):
    inputs = {
        'data': operation.inputs[0],
        'clip_max_ori': operation.outputs[3],
        'clip_min_ori': operation.outputs[4]
    }

    outputs = {'scale': operation.outputs[1], 'offset': operation.outputs[2]}
    quant_bit_num = tf.compat.v1.constant(operation.get_attr('quant_bit_num'))

    outputs['offset'] = tf.compat.v1.negative(
        tf.compat.v1.add(
            dp_pow(operation, tf.compat.v1.subtract(quant_bit_num, 1)),
            outputs.get('offset')))

    clip_max = tf.compat.v1.multiply(
        outputs.get('scale'),
        tf.compat.v1.subtract(
            tf.compat.v1.cast(
                tf.compat.v1.add(outputs.get('offset'),
                                 dp_pow(operation, quant_bit_num)),
                tf.compat.v1.float32), ONE))
    clip_min = tf.compat.v1.multiply(
        outputs.get('scale'),
        tf.compat.v1.cast(outputs.get('offset'), tf.compat.v1.float32))

    zero_tensor = _broadcast(tf.compat.v1.constant(ZERO), grad_output)

    gradient = tf.compat.v1.where(tf.compat.v1.less(inputs.get('data'), clip_min),
                                  zero_tensor, grad_output)
    gradient = tf.compat.v1.where(
        tf.compat.v1.greater(inputs.get('data'), clip_max), zero_tensor, gradient)

    # Define different scopes
    data_less_min = tf.compat.v1.less(inputs.get('data'), clip_min)
    data_greater_max = tf.compat.v1.greater(inputs.get('data'), clip_max)
    data_else = tf.compat.v1.logical_and(
        tf.compat.v1.greater_equal(inputs.get('data'), clip_min),
        tf.compat.v1.less_equal(inputs.get('data'), clip_max))

    # Compute the gradient of clip max and min
    grad_clip_max = tf.compat.v1.where(
        data_less_min,
        _broadcast(
            _diff(inputs.get('clip_min_ori'), inputs.get('clip_max_ori'),
                  inputs.get('clip_min_ori'), quant_bit_num), grad_output),
        zero_tensor)

    grad_clip_max = tf.compat.v1.where(
        data_greater_max,
        _broadcast(
            tf.compat.v1.add(
                _diff(inputs.get('clip_min_ori'), inputs.get('clip_max_ori'),
                      inputs.get('clip_min_ori'), quant_bit_num), ONE),
            grad_output), grad_clip_max)

    grad_clip_max = tf.compat.v1.where(
        data_else,
        _diff(inputs.get('data'), inputs.get('clip_max_ori'), inputs.get('clip_min_ori'),
              quant_bit_num), grad_clip_max)

    grad_clip_min = tf.compat.v1.where(
        data_less_min,
        _broadcast(
            tf.compat.v1.subtract(
                ONE,
                _diff(inputs.get('clip_min_ori'), inputs.get('clip_max_ori'),
                      inputs.get('clip_min_ori'), quant_bit_num)), grad_output),
        zero_tensor)

    grad_clip_min = tf.compat.v1.where(
        data_greater_max,
        _broadcast(
            tf.compat.v1.negative(
                _diff(inputs.get('clip_min_ori'), inputs.get('clip_max_ori'),
                      inputs.get('clip_min_ori'), quant_bit_num)), grad_output),
        grad_clip_min)
    grad_clip_min = tf.compat.v1.where(
        data_else,
        tf.compat.v1.negative(
            _diff(inputs.get('data'), inputs.get('clip_max_ori'),
                  inputs.get('clip_min_ori'), quant_bit_num)), grad_clip_min)

    grad_clip_max = tf.compat.v1.reduce_sum(
        tf.compat.v1.multiply(grad_clip_max, grad_output))
    grad_clip_min = tf.compat.v1.reduce_sum(
        tf.compat.v1.multiply(grad_clip_min, grad_output))

    if operation.get_attr('fixed_min'):
        grad_clip_min = tf.compat.v1.multiply(grad_clip_min, ZERO)

    grad_clip_max = tf.compat.v1.reshape(grad_clip_max, [1])
    grad_clip_min = tf.compat.v1.reshape(grad_clip_min, [1])
    grad_batch_num = tf.compat.v1.Variable(ZERO, tf.compat.v1.float32)
    return gradient, grad_clip_max, grad_clip_min, grad_batch_num


@ops.RegisterGradient("WeightRetrain")
def _weight_retrain_grad(
        operation,
        grad_output,
        grad_scale,
        grad_offset):
    return grad_output


def _get_grad_scale_scale_rec(weight, scale, int_min, int_max):
    quant_weight = tf.compat.v1.multiply(weight, scale)
    quant_weight_less_min = tf.compat.v1.less(quant_weight, int_min)
    quant_weight_greater_max = tf.compat.v1.greater(quant_weight, int_max)
    grad_scale = tf.compat.v1.negative(
        tf.compat.v1.divide(
            tf.compat.v1.subtract(tf.compat.v1.round(quant_weight),
                                  quant_weight), tf.compat.v1.pow(scale, BASE)))
    grad_scale = tf.compat.v1.where(
        quant_weight_less_min,
        tf.compat.v1.negative(
            tf.compat.v1.divide(int_min, tf.compat.v1.pow(scale, BASE))),
        grad_scale)
    grad_scale = tf.compat.v1.where(
        quant_weight_greater_max,
        tf.compat.v1.negative(
            tf.compat.v1.divide(int_max, tf.compat.v1.pow(scale, BASE))),
        grad_scale)
    return grad_scale


def _get_grad_scale(weight, scale, int_min, int_max):
    clip_min = tf.compat.v1.multiply(int_min, scale)
    clip_max = tf.compat.v1.multiply(int_max, scale)
    weight_less_min = tf.compat.v1.less(weight, clip_min)
    weight_greater_max = tf.compat.v1.greater(weight, clip_max)
    grad_scale = tf.compat.v1.subtract(
        tf.compat.v1.round(tf.compat.v1.divide(weight, scale)),
        tf.compat.v1.divide(weight, scale))
    grad_scale = tf.compat.v1.where(weight_less_min, int_min, grad_scale)
    grad_scale = tf.compat.v1.where(weight_greater_max, int_max, grad_scale)
    return grad_scale


def _get_coef(operation, weight, quant_bit_num, scale_shape):
    half_stages = tf.compat.v1.subtract(
        dp_pow(operation, tf.compat.v1.subtract(quant_bit_num, 1)), 1)
    weight_shape = weight.shape.as_list()
    channel_size = 1
    for index, value in enumerate(scale_shape):
        if value == 1:
            channel_size *= weight_shape[index]
    coef = tf.compat.v1.reciprocal(
        tf.compat.v1.sqrt(
            tf.compat.v1.multiply(
                tf.compat.v1.cast(channel_size, tf.compat.v1.float32),
                tf.compat.v1.cast(half_stages, tf.compat.v1.float32))))
    return coef


@ops.RegisterGradient("WeightUlq")
def _weight_ulq_grad(
        operation,
        grad_output,
        grad_scale_w,
        grad_offset_w):
    weight = operation.inputs[0]
    scale = operation.inputs[1]

    quant_bit_num = tf.compat.v1.constant(operation.get_attr('quant_bit_num'))
    int_min = tf.compat.v1.cast(
        tf.compat.v1.negative(
            dp_pow(operation, tf.compat.v1.subtract(quant_bit_num, 1))),
        tf.compat.v1.float32)
    int_min = _broadcast(int_min, weight)
    int_max = tf.compat.v1.cast(
        tf.compat.v1.subtract(
            dp_pow(operation, tf.compat.v1.subtract(quant_bit_num, 1)), 1),
        tf.compat.v1.float32)
    int_max = _broadcast(int_max, weight)

    s_rec_flag = operation.get_attr('s_rec_flag')
    if s_rec_flag:
        grad_scale = _get_grad_scale_scale_rec(weight, scale, int_min, int_max)
    else:
        grad_scale = _get_grad_scale(weight, scale, int_min, int_max)

    scale_shape = scale.shape.as_list()
    coef = _get_coef(operation, weight, quant_bit_num, scale_shape)
    grad_scale = tf.compat.v1.multiply(grad_scale, coef)
    grad_scale = tf.compat.v1.multiply(grad_output, grad_scale)
    if scale_shape == []:
        grad_scale = tf.compat.v1.reduce_sum(grad_scale)
    else:
        axis = [index for index, value in enumerate(scale_shape) if value == 1]
        grad_scale = tf.compat.v1.reduce_sum(grad_scale,
                                             axis=axis,
                                             keepdims=True)

    return grad_output, grad_scale


@ops.RegisterGradient("Mask")
def _mask_wgt_grad(operation, grad_output):
    mask_broadcast = tf.compat.v1.broadcast_to(
        operation.inputs[1], grad_output.shape)
    return [grad_output*mask_broadcast, None]


@ops.RegisterGradient("MaskGen")
def _mask_gen_grad(operation, grad_output):
    num = len(operation.inputs)
    return [None]*num


@ops.RegisterGradient("BalancedL2Norm")
def _bcp_grad(operation, grad_output):
    num = len(operation.inputs)
    return [None]*num


@ops.RegisterGradient("SelectiveMaskGen")
def _selective_mask_grad(operation, grad_output):
    num = len(operation.inputs)
    return [None]*num
