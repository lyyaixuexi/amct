#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0
"""


from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os

from amct_tensorflow.interface.config_parser import create_quant_config
from amct_tensorflow.interface.quantize_model import quantize_model
from amct_tensorflow.interface.quantize_model import quantize_preprocess
from amct_tensorflow.interface.save_model import save_model
from amct_tensorflow.interface.convert_model import convert_model
from amct_tensorflow.interface.convert_model import convert_qat_model
from amct_tensorflow.utils.log import set_logging_level
from amct_tensorflow.interface.retrain_conf_parser import create_quant_retrain_config
from amct_tensorflow.interface.generate_retrain_model import create_quant_retrain_model
from amct_tensorflow.interface.save_retrain_model import save_quant_retrain_model
from amct_tensorflow.interface.accuracy_based_auto_calibration import accuracy_based_auto_calibration
from amct_tensorflow.interface.perf_based_auto_calibration import perf_based_auto_calibration
from amct_tensorflow.common.auto_calibration.auto_calibration_evaluator_base\
        import AutoCalibrationEvaluatorBase as CalibrationEvaluatorBase
from amct_tensorflow.interface.prune_model import create_prune_retrain_model
from amct_tensorflow.interface.prune_model import save_prune_retrain_model
from amct_tensorflow.interface.compress_model import create_compressed_retrain_model
from amct_tensorflow.interface.compress_model import save_compressed_retrain_model
from amct_tensorflow.interface.auto_mixed_precision_search import auto_mixed_precision_search
from amct_tensorflow.interface.evaluator import GraphEvaluator
from amct_tensorflow.interface.operation_approximator import create_approximation_calibrator
from amct_tensorflow.interface.save_approximation_graph import save_approximation_graph
from amct_tensorflow.interface.auto_channel_prune_search import auto_channel_prune_search
CUR_DIR = os.path.split(os.path.realpath(__file__))[0]


def get_version():
    """get version form .version file """
    with open(os.path.join(CUR_DIR, '.version')) as fid:
        lines = fid.readlines()
    contents = [line.strip() for line in lines]
    version = contents[0]
    version = version + 'ascend' if 'ascend' in contents else version
    return version


__version__ = get_version()

__all__ = [
    '__version__',
    'set_logging_level',
    'create_quant_config',
    'quantize_model',
    'save_model',
    'create_quant_retrain_config',
    'create_quant_retrain_model',
    'save_quant_retrain_model',
    'convert_model',
    'accuracy_based_auto_calibration',
    'perf_based_auto_calibration',
    'convert_qat_model',
    'create_prune_retrain_model',
    'save_prune_retrain_model',
    'create_compressed_retrain_model',
    'save_compressed_retrain_model',
    'auto_mixed_precision_search',
    'GraphEvaluator',
    'create_approximation_calibrator',
    'save_approximation_graph',
    'auto_channel_prune_search',
    'quantize_preprocess'
]


if 'ascend' in __version__:
    from amct_tensorflow.interface_ascend.config_parser_ascend import create_quant_config_ascend
    from amct_tensorflow.interface_ascend.quantize_model_ascend import quantize_model_ascend
    from amct_tensorflow.interface_ascend.save_model_ascend import save_model_ascend


    __all__.extend([
        'create_quant_config_ascend', 'quantize_model_ascend', 'save_model_ascend',
    ])
