#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

automatic calibration helper

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
from collections import OrderedDict
import numpy as np
import tensorflow as tf
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.pattern.match_group_conv import find_group_conv
from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.utils.retrain_alg import _insert_enter_op
from amct_tensorflow.common.utils import files as files_util
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.capacity import CAPACITY


class TensorDumpInfo:
    """" record dump info for one dump position. """
    def __init__(self, op_name, input_index):
        """init func.

        Args:
            op_name (string): name of operation, where to dump data.
            input_index (int): operation.input[input_index] to do dump.
        """
        self.op_name = op_name
        self.input_index = input_index
        self.name_prefix = "{}_in{}".format(self.op_name.replace('/', '_'), input_index)
        self.file_names = []
        self.shape_list = []
        self.iter = None

    def __iter__(self):
        """ override __iter__ """
        self.iter = iter(self.file_names)
        self.shape_list.clear()
        return self

    def __next__(self):
        """ override __next__ """
        file_name = next(self.iter)
        data = files_util.parse_dump_data(file_name, with_type=True)
        self.shape_list.append(data.shape)
        return data

    def add_data_file(self, file_names):
        """ Add data of dump.

        Args:
            file_names (list of string): data file of this dump position.
        """
        self.file_names.extend(file_names)


class LayerDataInfo:
    """ record dump info for each layer."""
    def __init__(self, layer_name):
        """init func.

        Args:
            layer_name (string): name of one layer.
        """
        self.name = layer_name
        self.tensor_info = {}
        self.output_shape = []

    def __iter__(self):
        """ override __iter__ """
        for info in self.tensor_info.values():
            iter(info)
        return self

    def __next__(self):
        """ override __next__ """
        data_dict = {}
        for info in self.tensor_info.values():
            data_dict[info.name_prefix] = next(info)

        return data_dict

    def add_dump_position(self, position_info):
        """ Add dump position.

        Args:
            position_info (dict): key is indicating the layer's input; value indicating where to insert dump.
        """
        for input_key, position in position_info.items():
            self.tensor_info[input_key] = TensorDumpInfo(position[0].name, position[1])

    def set_output_shape(self, output_shape):
        """ Set output_shape for this layer.

        Args:
            output_shape (list of list): each item is a shape, and there are several shapes from different batch.
        """
        self.output_shape = output_shape

    def prepare_data(self, dump_dir):
        """ Prepare data for all input. To get data by parse from dump_dir.

        Args:
            dump_dir (string): where to find data.
        """
        for info in self.tensor_info.values():
            file_names = files_util.find_dump_file(dump_dir, info.name_prefix)
            info.add_data_file(file_names)

    def get_shape_info(self):
        """ get shape of this layer, including input and output. """
        shape_info = {'output_shape': self.output_shape}
        for input_key, info in self.tensor_info.items():
            shape_info[input_key] = info.shape_list

        return shape_info


class LayerOutputAnalyzer:
    """ The helper class for accuracy based auto calibration"""
    def __init__(self, ori_graph, fake_quant_graph, quant_layers, group_convs, dump_dir, sensitivity):
        """ Init func"""
        self.ori_graph = ori_graph
        self.fake_quant_graph = fake_quant_graph
        self.quant_layers = quant_layers
        self.group_convs = group_convs
        self.dump_dir = dump_dir
        self.sensitivity = sensitivity

        self.similarity_records = OrderedDict()
        self.shape_info = OrderedDict()
        self.graph_data_info = {}

    @staticmethod
    def seprate_group_conv(graph, quant_config, quant_layers):
        """ In the graph, seprate group_convs and general layers from quant layers.

        Args:
            graph (tf.Graph): graph to do quant
            quant_config (dict): quant config for graph
            quant_layers (list of string): the layers to seprate

        Returns:
            list: general layers
            dict: key is name of group_conv, value is list of conv name in group_conv.
        """
        # find group conv do calibration
        group_convs_candidates = find_group_conv(graph)

        group_convs = {}
        for candidate in group_convs_candidates:
            enable_global_conv, _ = candidate.check_cali(quant_config)
            if enable_global_conv:
                group_conv_name = candidate.get_name('split_name')
                group_convs[group_conv_name] = candidate
        # seprate group_convs from quant_layers
        for _, group_conv in group_convs.items():
            sub_conv_names = group_conv.get_name("conv_names")
            quant_layers = list(set(quant_layers) - set(sub_conv_names))

        return quant_layers, group_convs

    def get_sensitivity(self):
        """ calculate the similarity of single layer model and fake quant single layer model. """
        self.dump_dir = os.path.realpath(self.dump_dir)
        if not os.path.isdir(self.dump_dir):
            raise RuntimeError('dump_dir {} does not exists!'.format(self.dump_dir))
        self.analyze_group_conv()
        self.analyze_layer()

        return self.similarity_records, self.shape_info

    def analyze_group_conv(self):
        """ calculate the similarity for group_conv. """
        for layer_name, group_conv in self.group_convs.items():
            split_name = group_conv.get_name('split_name')
            concat_name = group_conv.get_name('concat_name')
            self._prepare_data_info(split_name)
            cos_sim_list = []
            original_outputs = self.run_single_group_conv(split_name, concat_name)
            fake_quant_outputs = self.run_fq_single_group_conv(split_name, concat_name)
            for original_output, fake_quant_output in zip(original_outputs, fake_quant_outputs):
                if original_output.shape != fake_quant_output.shape:
                    raise ValueError("shape of original output differ from shape of fake_quant output for layer {}"
                                     .format(layer_name))
                current_cos_sim = self.sensitivity.compare(original_output, fake_quant_output)
                cos_sim_list.append(current_cos_sim)
            sensitivity = np.mean(cos_sim_list)
            self.similarity_records[split_name] = sensitivity
            self.shape_info[split_name] = self.graph_data_info[split_name].get_shape_info()
            single_shape = {
                'output_shape': [
                    group_conv.split_data_shape(output_shape)
                    for output_shape in self.shape_info[split_name]['output_shape']
                ],
                'input_idx_0':
                [group_conv.split_data_shape(input_shape) for input_shape in self.shape_info[split_name]['input_idx_1']]
            }
            for conv_name in group_conv.get_name('conv_names'):
                self.similarity_records[conv_name] = sensitivity / group_conv.get_attr('group_size')
                self.shape_info[conv_name] = single_shape
            self.similarity_records[layer_name] = np.mean(cos_sim_list)
            LOGGER.logi("sensitivity of GroupConv follow by {} is {}".format(split_name, sensitivity))

    def analyze_layer(self):
        """ calculate the similarity for general layer. """
        for layer_name in self.quant_layers:
            self._prepare_data_info(layer_name)
            cos_sim_list = []
            original_outputs = self.run_single_layer_model(layer_name)
            fake_quant_outputs = self.run_fake_single_layer_model(layer_name)
            for original_output, fake_quant_output in zip(original_outputs, fake_quant_outputs):
                if original_output.shape != fake_quant_output.shape:
                    raise ValueError("shape of original output differ from shape of fake_quant output for layer {}"
                                     .format(layer_name))
                current_cos_sim = self.sensitivity.compare(original_output, fake_quant_output)
                cos_sim_list.append(current_cos_sim)
            # mean for several batch
            self.similarity_records[layer_name] = np.mean(cos_sim_list)
            self.shape_info[layer_name] = self.graph_data_info[layer_name].get_shape_info()
            LOGGER.logi("sensitivity of layer {} is {} ".format(layer_name, np.mean(cos_sim_list)))

        LOGGER.logd('******** similarity_records ******** ', 'LayerOutputAnalyzer')
        for key, value in self.similarity_records.items():
            LOGGER.logd('{} : {} '.format(key, value), 'LayerOutputAnalyzer')

    def run_single_group_conv(self, split_name, concat_name):
        """ run the original group conv subgraph to get the output tensor"""
        graph = self.ori_graph
        with graph.as_default():
            layer_data_info = self.graph_data_info[split_name]
            layer_data_info.prepare_data(self.dump_dir)
            # insert placeholder for layer input
            replaced_tensors, is_enter = self._replace_dump_input(graph, layer_data_info, 'origin')
            # find the output tensor of layer
            output_tensor = graph.get_operation_by_name(concat_name).outputs[0]
            # run layer's output
            enter_tensors = self._find_layer_enter_tensor(
                is_enter, [replaced_tensors[key][0] for key in replaced_tensors],
                graph.get_operation_by_name(split_name).outputs[0].consumers())
            numpy_datas = self._run_layer(graph, layer_data_info, output_tensor, enter_tensors)
            # relink to real input tensor to layer input
            for key in replaced_tensors:
                new_tensor, old_tensor, operation = replaced_tensors[key]
                replace_inputs_tensor(old_tensor, new_tensor, [operation])

            output_shape = [data.shape for data in numpy_datas]
            layer_data_info.set_output_shape(output_shape)

        return numpy_datas

    def run_fq_single_group_conv(self, split_name, concat_name):
        """ run the fake quant group conv subgraph to get the output tensor"""
        graph = self.fake_quant_graph
        with graph.as_default():
            layer_data_info = self.graph_data_info[split_name]
            layer_data_info.prepare_data(self.dump_dir)
            # insert placeholder for layer input
            replaced_tensors, is_enter = self._replace_dump_input(graph, layer_data_info, 'fakequant')
            # find the output tensor of layer
            concat_op = graph.get_operation_by_name(concat_name)
            dequant_op = concat_op.outputs[0].consumers()[0]
            if dequant_op.type != 'AscendDequant':
                raise RuntimeError('AscendDequant should be found but get {}({}) after Concat/ConcatV2({})'.format(
                    dequant_op.type, dequant_op.name, concat_op.name))
            # run layer's output
            enter_tensors = self._find_quant_layer_enter_tensor(
                is_enter, [replaced_tensors[key][0] for key in replaced_tensors],
                graph.get_operation_by_name(split_name).outputs[0].consumers(), concat_op.outputs[0].consumers()[0])
            numpy_datas = self._run_layer(graph, layer_data_info, dequant_op.outputs[0], enter_tensors)
            # relink to real input tensor to layer input
            for key in replaced_tensors:
                new_tensor, old_tensor, operation = replaced_tensors[key]
                replace_inputs_tensor(old_tensor, new_tensor, [operation])

        return numpy_datas

    def run_single_layer_model(self, layer_name):
        """ run the original subgraph to get the output tensor"""
        graph = self.ori_graph
        # find the object_op
        with graph.as_default():
            object_op = graph.get_operation_by_name(layer_name)
            layer_data_info = self.graph_data_info[layer_name]
            layer_data_info.prepare_data(self.dump_dir)

            # insert placeholder for layer input
            replaced_tensors, is_enter = self._replace_dump_input(graph, layer_data_info, 'origin')
            # find the output tensor of layer
            if len(object_op.outputs[0].consumers()) == 1 and object_op.outputs[0].consumers()[0].type == 'BiasAdd':
                output_tensor = object_op.outputs[0].consumers()[0].outputs[0]
            else:
                output_tensor = object_op.outputs[0]
            # run layer's output
            enter_tensors = self._find_layer_enter_tensor(
                is_enter, [replaced_tensors[key][0] for key in replaced_tensors], [object_op])
            numpy_datas = self._run_layer(graph, layer_data_info, output_tensor, enter_tensors)
            # relink to real input tensor to layer input
            for key in replaced_tensors:
                new_tensor, old_tensor, operation = replaced_tensors[key]
                replace_inputs_tensor(old_tensor, new_tensor, [operation])

            output_shape = [data.shape for data in numpy_datas]
            layer_data_info.set_output_shape(output_shape)

        return numpy_datas

    def run_fake_single_layer_model(self, layer_name):
        """ run the fake quant subgraph to get the output tensor"""
        graph = self.fake_quant_graph
        with graph.as_default():
            object_op = graph.get_operation_by_name(layer_name)
            layer_data_info = self.graph_data_info[layer_name]
            layer_data_info.prepare_data(self.dump_dir)
            # insert placeholder for layer input
            replaced_tensors, is_enter = self._replace_dump_input(graph, layer_data_info, 'fakequant')
            # find the output tensor of layer
            if len(object_op.outputs[0].consumers()) == 1 and object_op.outputs[0].consumers()[0].type == 'BiasAdd':
                layer_output = object_op.outputs[0].consumers()[0].outputs[0]
            else:
                layer_output = object_op.outputs[0]
            if len(layer_output.consumers()) != 1:
                raise RuntimeError("operation{} with AscendQuant couldn't have more than one consumers.".format(
                    object_op.name))
            tail_op = layer_output.consumers()[0]
            if tail_op.type != 'AscendDequant':
                raise RuntimeError('except AscendDequant after {} but get {}({})'.format(
                    object_op.name, tail_op.name, tail_op.type))
            enter_tensors = self._find_quant_layer_enter_tensor(
                is_enter, [replaced_tensors[key][0] for key in replaced_tensors], [object_op], tail_op)
            # run layer's output
            numpy_datas = self._run_layer(graph, layer_data_info, tail_op.outputs[0], enter_tensors)
            # relink to real input tensor to layer input
            for key in replaced_tensors:
                new_tensor, old_tensor, operation = replaced_tensors[key]
                replace_inputs_tensor(old_tensor, new_tensor, [operation])

        return numpy_datas

    def _prepare_data_info(self, layer_name):
        """ Find name prefix of input dump file for quant layers.

        Args:
            layer_names (list of string): layers to find dump file
        """
        with self.ori_graph.as_default():
            object_op = self.ori_graph.get_operation_by_name(layer_name)
            position_info = QuantOpInfo.locate_dump_position(object_op)
            layer_info = LayerDataInfo(layer_name)
            layer_info.add_dump_position(position_info)
            self.graph_data_info[layer_name] = layer_info

    @staticmethod
    def _replace_dump_input(graph, layer_data_info, mode):
        # link the object input tensor to a placeholder
        if mode not in ['origin', 'fakequant']:
            raise ValueError("not except {}, only support ['origin', 'fakequant']".format(mode))
        with graph.as_default():
            replaced_tensors = {}
            for key, dump_info in layer_data_info.tensor_info.items():
                new_name = "{}_placeholder".format(dump_info.name_prefix)
                operation = graph.get_operation_by_name(dump_info.op_name)
                # find which to insert
                pre_op = operation.inputs[dump_info.input_index].op
                if mode == 'fakequant' and pre_op.type == 'AscendQuant':
                    operation = pre_op
                    old_tensor = operation.inputs[0]
                else:
                    old_tensor = operation.inputs[dump_info.input_index]
                new_tensor = tf.compat.v1.placeholder(old_tensor.dtype, name=new_name)
                new_tensor, is_enter = LayerOutputAnalyzer._decorate_enter(graph, dump_info.op_name, new_tensor)
                replace_inputs_tensor(new_tensor, old_tensor, [operation])
                replaced_tensors[key] = [new_tensor, old_tensor, operation]
        return replaced_tensors, is_enter

    @staticmethod
    def _run_layer(graph, layer_data_info, output_tensor, enter_tensors):
        def modify_feed_dict(data_dict):
            feed_dict = {}
            for key, value in data_dict.items():
                feed_dict["{}_placeholder:0".format(key)] = value
            return feed_dict

        numpy_outputs = []
        with tf.compat.v1.Session(graph=graph) as sess:
            sess.run(tf.compat.v1.global_variables_initializer())
            data_iter = iter(layer_data_info)
            for input_data in data_iter:
                data_dict = modify_feed_dict(input_data)
                if enter_tensors:
                    enter_tensors_value = sess.run(enter_tensors, feed_dict=data_dict)
                    data_dict = dict(zip(enter_tensors, enter_tensors_value))
                data_numpy = sess.run(output_tensor, feed_dict=data_dict)
                numpy_outputs.append(data_numpy)
        return numpy_outputs

    @staticmethod
    def _decorate_enter(graph, op_name, tensor):
        """use enter to modify the input parameters.

        Args:
            graph (tf.Graph): the graph to modify
            op_name (string): check use enter or not from this op
            tensor (tf.Tensor): decorate tensor
        """
        operation = graph.get_operation_by_name(op_name)
        if operation.type in CAPACITY.get_value('QUANTIZABLE_TYPES'):
            # search weight maybe easier
            _, weight_index = QuantOpInfo.get_quant_index(operation)
            if len(operation.inputs) > weight_index:
                operation = operation.inputs[weight_index].op
        info_length, frame_name, is_constant, parallel_iterations = GraphChecker.get_dependency_enter_info(operation)

        if not info_length:
            return tensor, False
        return _insert_enter_op(tensor, frame_name, is_constant, parallel_iterations), True

    @staticmethod
    def _find_layer_enter_tensor(is_enter, dump_data_in_tensors, quantizable_ops):
        """ Find enter tensor for layer.

        Args:
            is_enter (bool): is enter or not.
            dump_data_in_tensors (list of tf.Tensor): the tensors of dump_data placeholder's output
            quantizable_ops (list of tf.Operation): operations to quant

        Returns:
            list of tf.Tensor: enter's output tensor for this layer
        """
        if not is_enter:
            return []
        # add dump data tensor
        enter_tensors = [tensor.name for tensor in dump_data_in_tensors]
        for object_op in quantizable_ops:
            # add weight of quantizable operation
            _, weight_index = QuantOpInfo.get_quant_index(object_op)
            enter_tensors.append(object_op.inputs[weight_index].name)
            # add bias of quantizable operation
            if len(object_op.outputs[0].consumers()) == 1 and object_op.outputs[0].consumers()[0].type == 'BiasAdd':
                bias_add_op = object_op.outputs[0].consumers()[0]
                enter_tensors.append(bias_add_op.inputs[1].name)
        return enter_tensors

    @staticmethod
    def _find_quant_layer_enter_tensor(is_enter, dump_data_in_tensors, quantizable_ops, dequant_op):
        """ Find enter tensor for layer.

        Args:
            is_enter (bool): is enter or not.
            dump_data_in_tensors (list of tf.Tensor): the tensors of dump_data placeholder's output
            quantizable_ops (list of tf.Operation): operations to quant
            dequant_op (tf.Operation): dequant of this layer

        Returns:
            list of tf.Tensor: enter's output tensor for this layer
        """
        if not is_enter:
            return []
        # add dump data tensor
        enter_tensors = [tensor.name for tensor in dump_data_in_tensors]
        for object_op in quantizable_ops:
            # add weight of quantizable operation
            _, weight_index = QuantOpInfo.get_quant_index(object_op)
            ascend_weight_quant = object_op.inputs[weight_index].op
            enter_tensors.append(ascend_weight_quant.inputs[0].name)
            # add bias of quantizable operation
            if len(object_op.outputs[0].consumers()) == 1 and object_op.outputs[0].consumers()[0].type == 'BiasAdd':
                bias_add_op = object_op.outputs[0].consumers()[0]
                enter_tensors.append(bias_add_op.inputs[1].op.inputs[0].name)

            enter_tensors.append(dequant_op.inputs[1].name)
        return enter_tensors
