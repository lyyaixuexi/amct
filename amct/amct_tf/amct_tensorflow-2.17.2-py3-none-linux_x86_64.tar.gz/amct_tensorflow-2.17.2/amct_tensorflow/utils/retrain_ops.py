#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert operations for quantization including 'calibration', 'fake_quant' and
'deploy'.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.utils.retrain_alg import ulq
from amct_tensorflow.utils.retrain_alg import arq_retrain
from amct_tensorflow.utils.retrain_alg import ulq_retrain


def quant_act(act_input, context, act_kwargs):
    """
    Function: Quantize inputs in 'calibration' mode.
    Inputs:
        inputs: a tensor to be quantized.
        context: a string, context for created nodes.
        quant_type: a string, the quantization type including 'activation'
            and 'weight'.
        quant_kwargs: a dictionary, including quantization parameters.
        quant_op_type: a string, the type of inputs's conusumer.
    Returns:
        outputs: a tensor quantized.
    """
    act_input = tf.compat.v1.check_numerics(
        act_input, "Error: Exit Infinite value before data quantization!")
    if act_kwargs['algo'] == 'ulq_quantize':
        context = _add_context_to_name(context, act_kwargs['algo'])
        output = ulq(act_input, context, act_kwargs)

    return output


def quant_wgt(wgt_input, context, wgt_kwargs, obj_type):
    ''' quant wgt '''
    act_input = tf.compat.v1.check_numerics(
        wgt_input, "Error: Exit Infinite value before data quantization!")
    if wgt_kwargs['algo'] == 'arq_retrain':
        context = _add_context_to_name(context, wgt_kwargs['algo'])
        output = arq_retrain(act_input, context, obj_type, wgt_kwargs)
    elif wgt_kwargs['algo'] == 'ulq_retrain':
        context = _add_context_to_name(context, wgt_kwargs['algo'])
        output = ulq_retrain(act_input, context, obj_type, wgt_kwargs)
    return output


def _add_context_to_name(context, name):
    """Adds the context to the name if it exists."""
    if not context:
        return name
    return os.path.join(context, name)
