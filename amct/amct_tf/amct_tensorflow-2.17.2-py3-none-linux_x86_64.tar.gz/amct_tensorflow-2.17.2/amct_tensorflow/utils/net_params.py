#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

help to get operation's param info like flops, bitops.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_tensorflow.common.utils.net_params import ParamsHelper
from amct_tensorflow.utils.quant_op_info import QuantOpInfo


class ParamsHelperTf:
    """ help to get node's param info like flops, bitops. """
    @staticmethod
    def get_flops(operation, shape_infos):
        """ Get flops for operation.

        Args:
            operation (tf.Operation): to get its flops.
            shape_infos (dict): including list of input_shape and output_shape.

        Raises:
            ValueError: the operation's type is not support.
            ValueError: the operation's input_shape or output_shape is empty.

        Returns:
            float: average flops value.
        """
        mapping_func = {
            'Conv2D': 'calc_conv_flops',
            'DepthwiseConv2dNative': 'calc_depthwise_conv_flops',
            'Conv2DBackpropInput': 'calc_deconv_flops',
            'MatMul': 'calc_matmul_flops',
            'BatchMatMulV2': 'calc_batch_matmul_flops',
            'BatchMatMul': 'calc_batch_matmul_flops',
            'AvgPool': 'calc_avgpool_flops'
        }

        if operation.type not in mapping_func:
            raise ValueError("operation [{}] do not support yet.".format(operation.type))

        flops_list = []
        for batch in range(len(shape_infos['output_shape'])):
            shape_info = {}
            for key in shape_infos:
                shape_info[key] = shape_infos[key][batch]
            flops = getattr(ParamsHelperTf, mapping_func.get(operation.type))(operation, shape_info)
            flops_list.append(flops)
        if not flops_list:
            raise ValueError('invalid shape_infos {} to get FLOPs.'.format(shape_infos))
        flops = sum(flops_list) / len(flops_list)

        return flops

    @staticmethod
    def calc_conv_flops(operation, shape_info):
        """ Calculate flops for conv operation.

        Args:
            operation (tf.Operation): to get its flops.
            shape_info (dict): key is 'output_shape' and 'input_shape', value is shape info.

        Returns:
            int: flops value, which include batch_size info.
        """
        output_shape = shape_info['output_shape']
        if QuantOpInfo.get_data_format(operation) == 'NCHW':
            out_channel, out_h, out_w = output_shape[1], output_shape[2], output_shape[3]
        else:
            out_h, out_w, out_channel = output_shape[1], output_shape[2], output_shape[3]
        # get weight shape
        weight_shape = operation.inputs[1].shape.as_list()
        k_h, k_w, in_channel = weight_shape[0], weight_shape[1], weight_shape[2]

        flops = ParamsHelper.calc_conv_flops(in_channel=in_channel,
                                             out_channel=out_channel,
                                             k_h=k_h,
                                             k_w=k_w,
                                             out_h=out_h,
                                             out_w=out_w,
                                             group=1,
                                             has_bias=ParamsHelperTf.has_bias(operation))
        flops *= output_shape[0]
        return flops

    @staticmethod
    def calc_depthwise_conv_flops(operation, shape_info):
        """ Calculate flops for depthwise_conv operation.

        Args:
            operation (tf.Operation): to get its flops.
            shape_info (dict): key is 'output_shape' and 'input_shape', value is shape info.

        Returns:
            int: flops value, which include batch_size info.
        """
        output_shape = shape_info['output_shape']
        if QuantOpInfo.get_data_format(operation) == 'NCHW':
            out_channel, out_h, out_w = output_shape[1], output_shape[2], output_shape[3]
        else:
            out_h, out_w, out_channel = output_shape[1], output_shape[2], output_shape[3]

        # get weight shape
        weight_shape = operation.inputs[1].shape.as_list()
        k_h, k_w, in_channel, _ = \
            weight_shape[0], weight_shape[1], weight_shape[2], weight_shape[3]

        flops = ParamsHelper.calc_conv_flops(in_channel=in_channel,
                                             out_channel=out_channel,
                                             k_h=k_h,
                                             k_w=k_w,
                                             out_h=out_h,
                                             out_w=out_w,
                                             group=in_channel,
                                             has_bias=ParamsHelperTf.has_bias(operation))
        flops *= output_shape[0]
        return flops

    @staticmethod
    def calc_deconv_flops(operation, shape_info):
        """ Calculate flops for deconv operation.

        Args:
            operation (tf.Operation): to get its flops.
            shape_info (dict): key is 'output_shape' and 'input_shape', value is shape info.

        Returns:
            int: flops value.
        """
        if QuantOpInfo.get_data_format(operation) == 'NCHW':
            out_channel = shape_info['output_shape'][1]
        else:
            out_channel = shape_info['output_shape'][3]
        # get in shape
        input_shape = shape_info['input_idx_2']
        if QuantOpInfo.get_data_format(operation) == 'NCHW':
            in_channel, in_h, in_w = input_shape[1], input_shape[2], input_shape[3]
        else:
            in_h, in_w, in_channel = input_shape[1], input_shape[2], input_shape[3]

        # get weight shape
        weight_shape = operation.inputs[1].shape.as_list()
        k_h, k_w, _, in_channel = \
            weight_shape[0], weight_shape[1], weight_shape[2], weight_shape[3]

        flops = ParamsHelper.calc_deconv_flops(in_channel=in_channel,
                                               out_channel=out_channel,
                                               k_h=k_h,
                                               k_w=k_w,
                                               in_h=in_h,
                                               in_w=in_w,
                                               group=1,
                                               has_bias=ParamsHelperTf.has_bias(operation))
        flops *= input_shape[0]
        return flops

    @staticmethod
    def calc_matmul_flops(operation, shape_info):
        """ Calculate flops for matmul operation.

        Args:
            operation (tf.Operation): to get its flops.
            shape_info (dict): key is 'output_shape' and 'input_shape', value is shape info.

        Returns:
            int: flops value, which include batch_size info.
        """
        output_shape = shape_info['output_shape']
        input_shape = shape_info['input_idx_0']
        # modify shape to satisfy [N, C1, C2, ..., M, K] * [N, C1, C2, ..., K, L] = [N, C1, C2, ..., M, L]
        if operation.get_attr('transpose_a'):
            input_shape[-2], input_shape[-1] = input_shape[-1], input_shape[-2]
        flops = ParamsHelper.calc_matmul_flops(input_shape, output_shape, has_bias=False)
        flops *= output_shape[0]
        return flops

    @staticmethod
    def calc_batch_matmul_flops(operation, shape_info):
        """ Calculate flops for matmul operation.

        Args:
            operation (tf.Operation): to get its flops.
            shape_info (dict): key is 'output_shape' and 'input_shape', value is shape info.

        Returns:
            int: flops value, which include batch_size info.
        """
        output_shape = shape_info['output_shape']
        input_shape = shape_info['input_idx_0']
        # modify shape to satisfy [N, C1, C2, ..., M, K] * [N, C1, C2, ..., K, L] = [N, C1, C2, ..., M, L]
        if operation.get_attr('adj_x'):
            input_shape[-2], input_shape[-1] = input_shape[-1], input_shape[-2]
        flops = ParamsHelper.calc_matmul_flops(input_shape, output_shape, has_bias=False)
        flops *= output_shape[0]
        return flops

    @staticmethod
    def calc_avgpool_flops(operation, shape_info):
        """ Calculate flops for avgpool operation.

        Args:
            operation (tf.Operation): to get its flops.
            shape_info (dict): key is 'output_shape' and 'input_shape', value is shape info.

        Returns:
            int: flops value, which include batch_size info.
        """
        # assume it as depthwise conv
        output_shape = shape_info['output_shape']
        input_shape = shape_info['input_idx_0']
        ksize = operation.get_attr('ksize')

        if QuantOpInfo.get_data_format(operation) == 'NCHW':
            out_channel, out_h, out_w = output_shape[1], output_shape[2], output_shape[3]
            in_channel = input_shape[1]
            k_h, k_w = ksize[2], ksize[3]
        else:
            k_h, k_w = ksize[1], ksize[2]
            in_channel = input_shape[3]
            out_h, out_w, out_channel = output_shape[1], output_shape[2], output_shape[3]

        flops = ParamsHelper.calc_conv_flops(in_channel=in_channel,
                                             out_channel=out_channel,
                                             k_h=k_h,
                                             k_w=k_w,
                                             out_h=out_h,
                                             out_w=out_w,
                                             group=in_channel,
                                             has_bias=False)
        flops *= output_shape[0]
        return flops

    @staticmethod
    def get_bitops(flops, wts_bits, act_bits):
        """ Get bitops by flops.

        Args:
            flops (float): flops value.
            wts_bits (int): bit of weight.
            act_bits (int): bit of activation.

        Returns:
            float: bitops value
        """
        bitops = ParamsHelper.cal_bitops(flops, wts_bits, act_bits)
        return bitops

    @staticmethod
    def has_bias(operation):
        """ whether operation has bias or not.

        Args:
            operation (tf.Operation): an operation

        Returns:
            bool: operation has bias or not
        """
        has_bias = len(operation.outputs[0].consumers()) == 1 and operation.outputs[0].consumers()[0].type == 'BiasAdd'
        return has_bias
