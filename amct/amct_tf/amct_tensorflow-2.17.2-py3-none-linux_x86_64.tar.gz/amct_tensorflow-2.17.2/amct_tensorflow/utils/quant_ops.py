#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert operations for quantization including 'calibration', 'fake_quant' and
'deploy'.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.utils.quantize_alg import quantize_activation
from amct_tensorflow.utils.quantize_alg import quantize_ifmr_ascend
from amct_tensorflow.utils.quantize_alg import quantize_arq
from amct_tensorflow.utils.quantize_alg import quantize_nuq
from amct_tensorflow.utils.quantize_alg import search_n

__all__ = [
    "quant_calibration", "quant_int_op", "relink_tensor",
    "create_context", "replace_inputs_tensor", "add_context_to_name",
    "clip_by_value", "get_next_single_op", "get_retrain_quant_factor",
    "is_scalar"
]


def quant_calibration(inputs, context, quant_type, quant_kwargs,
                      quant_op_type):
    """
    Function: Quantize inputs in 'calibration' mode.
    Inputs:
        inputs: a tensor to be quantized.
        context: a string, context for created nodes.
        quant_type: a string, the quantization type including 'activation'
            and 'weight'.
        quant_kwargs: a dictionary, including quantization parameters.
        quant_op_type: a string, the type of inputs's conusumer.
    Returns:
        outputs: a tensor quantized.
        custom_outputs: a output tensor of quantification custom operator
    """
    context = create_context(context, quant_type)
    inputs[0] = tf.compat.v1.check_numerics(
        inputs[0], "Error: Exit Infinite value before data quantization!")

    if quant_type == 'weight':
        outputs, custom_outputs = quantize_arq(inputs, context, quant_op_type,
                                               quant_kwargs)
    elif quant_type == 'weight_nuq':
        outputs, custom_outputs = quantize_nuq(inputs, context, quant_op_type,
                                               quant_kwargs)
    elif quant_type == 'activation':
        outputs, custom_outputs = quantize_activation(inputs, context, quant_kwargs)
    elif quant_type == 'activation_ascend':
        outputs, custom_outputs = quantize_ifmr_ascend(inputs, context, quant_kwargs)
    elif quant_type == 'search_n':
        outputs, custom_outputs = search_n(inputs, context, quant_kwargs)
    else:
        raise RuntimeError("%s isn't a valid quantize type." % (quant_type))
    return outputs, custom_outputs


def quant_int_op(inputs, scale, offset, num_bits, is_div=True):
    """
    Functions: Insert 'deploy_quant' operations. Quantize data to int8 by:
            1. without considering need_offset or not
            2. the scale can be used in multiply or divide
    Inputs:
        inputs: a tensor to be quantized.
        scale: a tensor, the parameter for quantization.
        offset: a tensor, the parameter for quantization.
        num_bits: a number, indicating the bit for quantization.
        is_div: a bool, indicating how to cope with scale. Do inputs/scale
            when it's True and  inputs*scale otherwise.
    Returns:
        inputs_quant: a tensor quantized
    """
    half_stage = 2**(num_bits - 1)
    left_bound = tf.compat.v1.constant(-half_stage, dtype=tf.compat.v1.float32)
    right_bound = tf.compat.v1.constant(half_stage - 1, dtype=tf.compat.v1.float32)
    ori_type = inputs.dtype
    inputs = tf.compat.v1.cast(inputs, dtype=tf.compat.v1.float32)
    if is_div:
        inputs_div = tf.compat.v1.divide(inputs, scale)
    else:
        inputs_div = tf.compat.v1.multiply(inputs, scale)
    inputs_round = tf.compat.v1.round(inputs_div) + offset
    inputs_quant = clip_by_value(inputs_round, left_bound, right_bound)
    inputs_quant = tf.compat.v1.cast(inputs_quant, dtype=ori_type)
    return inputs_quant


def create_context(context, quant_type):
    """
    Function: Create context for different quant_type.
    Inputs:
        context: the current context.
        quant_type: a string, the type of quantization indicating which part
            to quantize.
    Returns:
        context_new: a new context.
    """
    quant_type_dict = {
        'activation': 'act_quant',
        'activation_ascend': 'act_quant',
        'weight': 'weight_quant',
        'weight_nuq': 'weight_nuq_quant',
        'dequant': 'dequant',
        'bias': 'bias_quant',
        'replace_add': 'bias_add',
        'replace_bn': 'bn_replace',
        'replace_relu6': 'relu6_replace',
        'search_n': 'search_n_quant',
        'anti': 'anti_quant',
        'dump': 'dump',
        'fast_softmax': 'fast_softmax'
    }
    if quant_type_dict.get(quant_type):
        name = quant_type_dict.get(quant_type)
    else:
        raise RuntimeError("unexpected quant_type: %s " % (quant_type))
    context_new = add_context_to_name(context, name)

    return context_new


def add_context_to_name(context, name):
    """Adds the context to the name if it exists."""
    if not context:
        return name
    return ''.join([context, '/', name])


def clip_by_value(inputs, left_bound, right_bound):
    """
    Functions: Clip the inputs in the range [left_bound, right_bound].
    Inputs:
        inputs: a tensor to be cliped.
        left_bound: a tensor with 0-D shape or the same shape as inputs. The
            minimum value for clipping.
        left_bound: a tensor with 0-D shape or the same shape as inputs. The
            minimum value for clipping.
    Returns:
        outputs: a tensor whose element is clipped into
            [left_bound, right_bound].
    """
    outputs = tf.compat.v1.minimum(inputs, right_bound)
    outputs = tf.compat.v1.maximum(outputs, left_bound)

    return outputs


def relink_tensor(old_producer, new_producer, consumer):
    """ Change link from old_producer->consumer to new_producer->consumer."""

    if consumer not in old_producer.consumers():
        raise ValueError("consumer is not old_producer's consumers.")

    index = 0
    for producer in consumer.inputs:
        if old_producer is producer:
            break
        index += 1

    if index == len(consumer.inputs):
        raise ValueError('failed to find input index in consumer.')

    consumer._update_input(index, new_producer)  # pylint: disable=W0212

    return True


def replace_inputs_tensor(tensor_new, tensor_old, consumers):
    """ Replace tensor_old with tensor_new in the graph.

    Inputs:
        tensor_new: a tf.compat.v1.Tensor.
        tensor_old: a tf.compat.v1.Tensor.
        consumers: operations tensor_new will linked to.
    """
    for consumer in consumers:
        relink_tensor(tensor_old, tensor_new, consumer)


def get_next_single_op(ops):
    """Get next op of the object."""
    next_op = None
    if len(ops) == 1:
        next_op = ops[0]
    return next_op


def get_retrain_quant_factor(value_tensor):
    """Get retrain quant factor from value_tensor."""
    try:
        quant_factor = \
            value_tensor.consumers()[0].outputs[0].consumers()[0].inputs[0]
    except IndexError as e:
        raise IndexError("retrain quant factor of %s is not exist!"
                         % (value_tensor.name)) from e
    return quant_factor


def is_scalar(value_tensor):
    """Check whether the value_tensor is a scalar input."""
    while value_tensor.op.type == 'Identity':
        value_tensor = value_tensor.op.inputs[0]
    if value_tensor.op.type in ['Const', 'VariableV2'] and \
        value_tensor.shape == []:
        return True
    return False
