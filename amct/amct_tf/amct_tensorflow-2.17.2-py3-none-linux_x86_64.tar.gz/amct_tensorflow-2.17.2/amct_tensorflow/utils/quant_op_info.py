#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

get quant info from quntizable op.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.capacity import CAPACITY


class QuantOpInfo():
    '''
    Find infomation of quant_op.
    '''
    @staticmethod
    def get_scale_shape(inputs, channel_wise, op_type):
        """
        Function: Get the weights' scale's shape according to
            channel_wise and op_type.
        Inputs:
            inputs: the tensor to be quantized.
            channel_wise: a bool, parameter of quantization.
            op_type: a string, the type of operation to be quantized.
        Returns:
            shape: a list, the shape of scale.
            scale_length : a number, the length of scale.
        """
        if op_type not in CAPACITY.get_value('QUANTIZABLE_TYPES'):
            raise RuntimeError("%s is not supported." % (op_type))

        if op_type in ["MatMul", "BatchMatMul", "BatchMatMulV2"] or not channel_wise:
            scale_shape = []
            scale_length = 1
        else:
            input_shape = inputs.get_shape()
            if op_type == "Conv2D":
                # filter_shape arranged as [h, w, cin, cout]
                scale_shape = [1, 1, 1, input_shape[-1]]
                scale_length = input_shape[-1]
            elif op_type == "DepthwiseConv2dNative":
                # filter_shape arranged as [h, w, cin, channel_multiplier]
                scale_shape = [1, 1, input_shape[-2], input_shape[-1]]
                scale_length = input_shape[-2] * input_shape[-1]
            elif op_type == 'Conv2DBackpropInput':
                # filter_shape arranged as [h, w, cout, cin]
                scale_shape = [1, 1, input_shape[-2], 1]
                scale_length = input_shape[-2]
            elif op_type == 'Conv3D':
                # filter_shape arranged as [depth, height, width, cin, cout]
                scale_shape = [1, 1, 1, 1, input_shape[-1]]
                scale_length = input_shape[-1]

        return scale_shape, scale_length

    @staticmethod
    def get_scale_shape_for_nuq(inputs, op_type):
        """
        Function: Get the weights' scale's shape according to
            channel_wise and op_type.
        Inputs:
            inputs: the tensor to be quantized.
            op_type: a string, the type of operation to be quantized.
        Returns:
            shape: a list, the shape of scale.
            scale_length : a number, the length of scale.
        """
        if op_type not in CAPACITY.get_value('NUQ_QUANTIZABLE_TYPES'):
            raise RuntimeError("%s is not supported." % (op_type))
        if op_type == "MatMul":
            scale_shape = []
            scale_length = 1
        else:
            input_shape = inputs.get_shape()
            # filter_shape arranged as [h, w, cin, cout]
            scale_shape = [1, 1, 1, input_shape[-1]]
            scale_length = input_shape[-1]

        return scale_shape, scale_length

    @staticmethod
    def get_op_scale_shape(quant_op, channel_wise):
        """
        Function: Get the weights' scale's shape according to
            channel_wise.
        Inputs:
            operation: the operation to be quantized.
            channel_wise: a bool, parameter of quantization.
        Returns:
            shape: a list, the shape of scale.
            scale_length : a number, the length of scale.
        """
        _, weight_index = QuantOpInfo.get_quant_index(quant_op)
        return QuantOpInfo.get_scale_shape(
            quant_op.inputs[weight_index], channel_wise, quant_op.type)

    @staticmethod
    def get_quant_index(quant_op):
        """
        Function: get act's index and weight's index of quant_op.
        Inputs:
            quant_op: tf.compat.v1.Operation, it's type should be in QUANTIZABLE_TYPES.
        Returns:
            act_index: the act's index in inputs of quant_op.
            weight_index: the weight's index in inputs of quant_op.
        """
        if quant_op.type not in CAPACITY.get_value('QUANTIZABLE_TYPES'):
            raise RuntimeError("%s is not supported." % (quant_op.type))

        if quant_op.type == 'Conv2DBackpropInput':
            act_index = 2
            weight_index = 1
        else:
            act_index = 0
            weight_index = 1

        return act_index, weight_index

    @staticmethod
    def get_reduce_dims(quant_op):
        """Get reduce dimension for weight to sum expect on it's out_channel.

        Inputs:
            quant_op: an operation.
        Return:
            reduce_dims: a list, reduce dimension for weight to sum expect on
                it's out_channel.
            reshape_dims: a list, the dimension indicating how the deqscale
                should be resheped.
        """
        op_type = quant_op.type
        if op_type not in CAPACITY.get_value('QUANTIZABLE_TYPES'):
            raise RuntimeError(
                "only %s are supported, but get %s." %
                (CAPACITY.get_value('QUANTIZABLE_TYPES'), op_type))

        if op_type == 'MatMul':
            reduce_dims = [0]
            reshape_dims = [1, -1]
        elif op_type in ["BatchMatMul", "BatchMatMulV2"]:
            reduce_dims = [0]
            reshape_dims = [-1]
        else:
            # reshape dimension for dequant
            data_format = quant_op.get_attr('data_format')
            LOGGER.push_debug_message("data_format: %s" % (data_format),
                                      "get_layers")
            if data_format in (b'NHWC', 'NHWC'):
                reshape_dims = [1, 1, 1, -1]
            elif data_format in (b'NCHW', 'NCHW'):
                reshape_dims = [1, -1, 1, 1]
            elif data_format in (b'NDHWC', 'NDHWC'):
                reshape_dims = [1, 1, 1, 1, -1]
            else:  # NCDHW
                reshape_dims = [1, -1, 1, 1, 1]

            # reduce dimension for weight to sum
            if op_type == 'Conv2D':
                reduce_dims = [0, 1, 2]
            if op_type == 'DepthwiseConv2dNative':
                reduce_dims = [0, 1]
            if op_type == 'Conv2DBackpropInput':
                reduce_dims = [0, 1, 3]
            if op_type == 'Conv3D':
                reduce_dims = [0, 1, 2, 3]
            if op_type == 'AvgPool':
                reduce_dims = [0]

        return reduce_dims, reshape_dims

    @staticmethod
    def get_data_format(operation):
        '''get data_format '''
        data_format = operation.get_attr('data_format')
        if data_format in (b'NCHW', 'NCHW'):
            return 'NCHW'
        if data_format in (b'NHWC', 'NHWC'):
            return 'NHWC'
        if data_format in (b'NDHWC', 'NDHWC'):
            return 'NDHWC'
        if data_format in (b'NCDHW', 'NCDHW'):
            return 'NCDHW'

        raise ValueError("data_format must be a bytes and valid data_format but is {}.".format(data_format))

    @staticmethod
    def locate_dump_position(object_op):
        """ Locate where to insert dump, including operation and its input index.

        Args:
            object_op (Operation): to insert dump for it.

        Returns:
            dict: key is object_op's input/output index, value is dump_position with operation and its input index.
        """
        position_info = {}
        if object_op.type in ["Split"]:
            position_info['input_idx_1'] = (object_op, 1)
            return position_info
        # dump for data
        act_index, _ = QuantOpInfo.get_quant_index(object_op)
        if object_op.type in ('Conv2D', 'Conv3D') and object_op.inputs[act_index].op.type == 'Pad' \
            and len(object_op.inputs[act_index].op.outputs[0].consumers()) == 1:
            pre_op = object_op.inputs[act_index].op
            position_info['input_idx_{}'.format(act_index)] = (pre_op, 0)
        else:
            position_info['input_idx_{}'.format(act_index)] = (object_op, act_index)
        # dump for other special node
        if object_op.type == 'Conv2DBackpropInput':
            position_info['input_idx_0'] = (object_op, 0)
        if object_op.type in ['BatchMatMulV2', 'BatchMatMul']:
            position_info['input_idx_1'] = (object_op, 1)

        return position_info

    @staticmethod
    def get_cin_index(quant_op):
        """
        get cin index in activation tensor and weight tensor of quant_op
        Inputs:
            quant_op: an operation.
        Return:
            act_cin_idx, wgt_cin_idx
        """
        op_type = quant_op.type
        if op_type not in CAPACITY.get_value('QUANTIZABLE_TYPES'):
            raise RuntimeError(
                "only %s are supported, but get %s." %
                (CAPACITY.get_value('QUANTIZABLE_TYPES'), op_type))

        if op_type == 'MatMul':
            act_cin_idx = 1
            wgt_cin_idx = 1 if quant_op.get_attr('transpose_b') else 0
        elif op_type in ["BatchMatMul", "BatchMatMulV2"]:
            act_cin_idx = -1
            wgt_cin_idx = -2
        else:
            data_format = QuantOpInfo.get_data_format(quant_op)
            if data_format in ['NCHW', 'NCDHW']:
                act_cin_idx = 1
            elif data_format in ['NHWC', 'NDHWC']:
                act_cin_idx = -1

            if op_type == 'Conv2DBackpropInput':  # HWCoCi
                wgt_cin_idx = -1
            else:  # HWCiCo/DHWCiCo
                wgt_cin_idx = -2

        return act_cin_idx, wgt_cin_idx

    @staticmethod
    def get_cin_length(quant_op):
        """
        Get cin length of quant_op
        Inputs:
            quant_op: an operation.
        Return:
            cin length
        """
        _, weight_index = QuantOpInfo.get_quant_index(quant_op)
        weight_shape = quant_op.inputs[weight_index].shape
        _, weight_cin_idx = QuantOpInfo.get_cin_index(quant_op)
        return weight_shape[weight_cin_idx]