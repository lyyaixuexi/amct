#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
ERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quantization algorithm module(ARQ IFMR).

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from tensorflow.python.ops import gen_control_flow_ops

from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.lib.load_custom_op import load

_RETRAIN_OP = load()

__all__ = ["ulq"]


def add_act_op(act_input, act_kwargs): # pylint: disable=too-many-locals
    '''inner method'''
    min_val = 0.0
    max_val = 0.0
    keys = act_kwargs.keys()
    ifmr_init = True
    if 'clip_min' in keys and 'clip_max' in keys:
        min_val = act_kwargs['clip_min']
        max_val = act_kwargs['clip_max']
        ifmr_init = False

    fixed_min = False
    if 'fixed_min' in keys and act_kwargs['fixed_min']:
        fixed_min = True

    init_min = tf.compat.v1.constant([min_val])
    init_max = tf.compat.v1.constant([max_val])
    clip_max, clip_min, batch_num = prepare_act_variables(init_max, init_min)
    if act_kwargs.get('dst_type') == 'INT4':
        quant_bit_num = 4
    else:
        quant_bit_num = 8

    clip_max, clip_min, batch_num = _decorate_enter(act_input, act_kwargs.get('quant_op_names')[0],
        [clip_max, clip_min, batch_num])
    quant_data, scale_d, offset_d, _, _ = _RETRAIN_OP.activation_retrain(
        act_input,
        clip_max,
        clip_min,
        batch_num,
        fixed_min=fixed_min,
        ifmr_init=ifmr_init,
        layer_names=act_kwargs['quant_op_names'],
        quant_bit_num=quant_bit_num)

    return quant_data, scale_d, offset_d


def prepare_act_variables(init_max, init_min):
    '''prepare_act_variables'''
    clip_max = tf.compat.v1.get_variable(
        'clip_max',
        initializer=init_max,
        dtype=tf.compat.v1.float32,
        trainable=True,
        collections=[
            tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
            tf.compat.v1.GraphKeys.MODEL_VARIABLES
        ],
        use_resource=False)

    clip_min = tf.compat.v1.get_variable(
        'clip_min',
        initializer=init_min,
        dtype=tf.compat.v1.float32,
        trainable=True,
        collections=[
            tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
            tf.compat.v1.GraphKeys.MODEL_VARIABLES
        ],
        use_resource=False)

    batch_num = tf.compat.v1.get_variable(
        'batch_num',
        initializer=tf.compat.v1.constant(0.0),
        dtype=tf.compat.v1.float32,
        trainable=False,
        collections=[
            tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
            tf.compat.v1.GraphKeys.MODEL_VARIABLES
        ],
        use_resource=False)
    return clip_max, clip_min, batch_num


def ulq(act_input, context, act_kwargs):
    """
    Function:Quantize inputs with the algorithm 'ARQ'.
    Inputs:
        inputs:
            inputs[0]: a tensor to be quantized to get scale and offset.
            inputs[1]: a list, tensors to be fake quantized
        context: a string, context for created nodes.
        op_type: a string, type for quantized op
        quant_kwargs: a dictionary, including quantization parameters.
    Returns:
        weight_quants: a list of tensor quantized.
        scale_w: a output tensor of the quant_arq op.
    """
    with tf.compat.v1.variable_scope(context + '_ULQ_RETRAIN',
                                     values=[act_input],
                                     reuse=tf.compat.v1.AUTO_REUSE) as scope:
        scope.set_partitioner(None)

        act_outputs = add_act_op(act_input, act_kwargs)
        output = act_outputs[0]

    return output


def arq_retrain(wgt_input, context, op_type, wgt_kwargs): # pylint: disable=too-many-locals
    """
    Function:Quantize inputs with the algorithm 'ARQ'.
    Inputs:
        inputs: a tensor to be quantized.
        context: a string, context for created nodes.
        quant_kwargs: a dictionary, including quantization parameters.
        num_bits: a number, indicating the bit for quantization.
    Returns:
        outputs: a tensor quantized.
    """

    with tf.compat.v1.variable_scope(context + '_ARQ_RETRAIN',
                                     values=[wgt_input],
                                     reuse=tf.compat.v1.AUTO_REUSE) as scope:
        scope.set_partitioner(None)

        if op_type == 'Conv2DBackpropInput':
            wgt_input_to_arq = tf.compat.v1.transpose(wgt_input,
                                                      perm=[0, 1, 3, 2],
                                                      name='weight_transpose')
        else:
            wgt_input_to_arq = wgt_input

        _, scale_length = QuantOpInfo.get_scale_shape(
            wgt_input, wgt_kwargs.get('channel_wise'), op_type)

        if wgt_kwargs.get('dst_type') == 'INT4':
            quant_bit_num = 4
        else:
            quant_bit_num = 8
        outputs = _RETRAIN_OP.weight_retrain(
            wgt_input_to_arq,
            scale_length=scale_length,
            layer_names=wgt_kwargs['quant_op_names'],
            quant_bit_num=quant_bit_num)

        if op_type == 'Conv2DBackpropInput':
            wgt_output = tf.compat.v1.transpose(outputs[0],
                                                perm=[0, 1, 3, 2],
                                                name='weight_de_transpose')
        else:
            wgt_output = outputs[0]

        output = wgt_output
        return output


def ulq_retrain(wgt_input, context, op_type, wgt_kwargs): # pylint: disable=too-many-locals
    """
    Function:Quantize inputs with the algorithm 'ULQ'.
    Inputs:
        inputs: a tensor to be quantized.
        context: a string, context for created nodes.
        op_type: a string, the type of operator
        wgt_kwargs: a dictionary, including quantization parameters.
    Returns:
        output: a tensor quantized.
    """
    with tf.compat.v1.variable_scope(context + '_ULQ_RETRAIN',
                                     values=[wgt_input],
                                     reuse=tf.compat.v1.AUTO_REUSE) as scope:
        scope.set_partitioner(None)

        if op_type == 'Conv2DBackpropInput':
            wgt_input_to_ulq = tf.compat.v1.transpose(wgt_input,
                                                      perm=[0, 1, 3, 2],
                                                      name='weight_transpose')
        else:
            wgt_input_to_ulq = wgt_input

        scale_shape, scale_length = QuantOpInfo.get_scale_shape(
            wgt_input, wgt_kwargs.get('channel_wise'), op_type)

        if op_type == 'Conv2DBackpropInput':
            scale_shape = [1, 1, 1, scale_shape[-2]]

        scale_var = tf.compat.v1.get_variable(
            'scale',
            shape=scale_shape,
            dtype=tf.compat.v1.float32,
            trainable=True,
            collections=[
                tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                tf.compat.v1.GraphKeys.MODEL_VARIABLES
            ])

        batch_num = tf.compat.v1.get_variable(
            'batch_num',
            initializer=tf.compat.v1.constant(0.0),
            dtype=tf.compat.v1.float32,
            trainable=False,
            collections=[
                tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                tf.compat.v1.GraphKeys.MODEL_VARIABLES
            ])

        if wgt_kwargs['dst_type'] == 'INT4':
            quant_bit_num = 4
        else:
            quant_bit_num = 8

        one_value = tf.compat.v1.constant(1.0)
        half_value = tf.compat.v1.constant(0.5)
        # handle tf.while_loop
        scale_var, batch_num, one_value, half_value = _decorate_enter(
            wgt_input, wgt_kwargs.get('quant_op_names')[0], [scale_var, batch_num, one_value, half_value])

        def true_fn():
            scale_inited = tf.compat.v1.identity(scale_var)
            return scale_inited

        def false_fn():
            scale_init = _RETRAIN_OP.weight_ulq_init(
                wgt_input_to_ulq,
                scale_var,
                scale_length=scale_length,
                quant_bit_num=quant_bit_num,
                s_rec_flag=False)

            scale_assign = tf.compat.v1.assign(scale_var, scale_init)
            batch_num_assign = tf.compat.v1.assign(batch_num, one_value)
            with tf.compat.v1.control_dependencies([scale_assign,
                                                    batch_num_assign]):
                scale_inited = tf.compat.v1.identity(scale_var)
            return scale_inited

        scale_cond = tf.compat.v1.cond(tf.compat.v1.greater(batch_num, half_value), true_fn, false_fn)

        outputs = _RETRAIN_OP.weight_ulq(
            wgt_input_to_ulq,
            scale_cond,
            scale_length=scale_length,
            layer_names=wgt_kwargs['quant_op_names'],
            quant_bit_num=quant_bit_num,
            s_rec_flag=False)

        if op_type == 'Conv2DBackpropInput':
            wgt_output = tf.compat.v1.transpose(outputs[0],
                                                perm=[0, 1, 3, 2],
                                                name='weight_de_transpose')
        else:
            wgt_output = outputs[0]

        output = wgt_output
        return output


def _insert_enter_op(target, frame_name, is_constant, parallel_iterations):
    """
    Function: insert enter ops with regard to target dtype.
    Inputs:
        target: a tensor to be add to tf.enter op.
        frame_name:str, frame name of tf.while.
        is_constant: bool, to specify wether the target is set to constant.
        parallel_iterations: int， the parallel iteration num.
    Returns:
        target
    """
    if isinstance(target, tf.TensorShape):
        target = gen_control_flow_ops.enter(
            target,
            frame_name=frame_name,
            is_constant=is_constant,
            parallel_iterations=parallel_iterations)
    else:
        if '_ref' in target.dtype.name:
            target = gen_control_flow_ops.ref_enter(
                target,
                frame_name=frame_name,
                is_constant=is_constant,
                parallel_iterations=parallel_iterations)
        else:
            target = gen_control_flow_ops.enter(
                target,
                frame_name=frame_name,
                is_constant=is_constant,
                parallel_iterations=parallel_iterations)
    return target


def _decorate_enter(input_tensor, op_name, target_list):
    """
    Function: use enter to modify the input parameters.
    Inputs:
        input_tensor: a tensor, data or weight tensor.
        op_name:str, the op name of the input_tensor.
        target_list: list of tensors to add to while context.
    Returns:
        list of tensors: processed tensors, new tensor if theres's enter and origin tensor if not.
    """
    inputs = input_tensor.graph.get_operation_by_name(op_name).inputs

    if len(inputs) > 1:
        info_length, frame_name, is_constant, parallel_iterations = \
            GraphChecker.get_dependency_enter_info(inputs[1].op)
        if info_length:
            processed_list = []
            for target in target_list:
                target = _insert_enter_op(target, frame_name, is_constant, parallel_iterations)
                processed_list.append(target)
            return processed_list

    return target_list
