#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

dump json file that contains fusion info, quantize op, and new op that
amct_tensorflow tool inserted.
"""
import os
import json
from copy import deepcopy
from datetime import datetime
from datetime import timezone
from datetime import timedelta

from amct_tensorflow.common.utils.util import FILE_MODE
from amct_tensorflow.common.utils import files as files_util

BASIC_INFO = {
    'name': 'op_name',
    'type': 'op_type',
}
ORIGINAL_OP_NMAES = {
    'key': '_datadump_original_op_names',
    'value': {
        'list': {
            'val_type': 1,
            's': []
        }
    }
}
DEFAULT_OUTPUT_DESC = {
    "attr": [
        {
            "key": "_datadump_data_type",
            "value": {
                "s": "DT_FLOAT"
            }
        },
        {
            "key": "_datadump_origin_format",
            "value": {
                "s": "NHWC"
            }
        },
        {
            "key": "_datadump_origin_name",
            "value": {
                "s": ""
            }
        },
        {
            "key": "_datadump_origin_output_index",
            "value": {
                "i": 0
            }
        }
    ]
}


def split_name_scope(op_name):
    """split name_scope and op name according to tensorflow rule"""
    split_names = op_name.split('/')
    if len(split_names) == 1:
        name_scope = ''
        name = split_names[0]
    else:
        name_scope = '/'.join(split_names[:-1])
        name = split_names[-1]
    return name_scope, name


class OpRecord(): # pylint: disable=too-few-public-methods
    """struct of op record"""
    def __init__(self, tf_op):
        self.record_op = tf_op
        self.producers = []
        self.consumers = []
        self.fusion_info = []


class QuantizeInfoDumper():
    """Class to dump json file that contains quantized info and fusion info
       done by amct_tensorflow tool.
    """
    def __init__(self):
        """ Create a empty dict for store dump ops info
        """
        self._ops = {}

    def add_op(self, op_record):
        """Add one basic op info
           op_record: An OpRecord instance
        """
        self._ops[op_record.record_op.name] = deepcopy(BASIC_INFO)
        self._ops.get(op_record.record_op.name)['name'] = op_record.record_op.name
        self._ops.get(op_record.record_op.name)['type'] = op_record.record_op.type

    def set_original_names(self, op_name, original_names):
        """Set op's represented original op names
           op_name: op to set original names
           original_names: original names to set
        """
        self._ops.get(op_name)['attr'] = [deepcopy(ORIGINAL_OP_NMAES)]
        self._ops.get(op_name).get('attr')[0].get('value').get('list')['s'] = original_names

    def set_output_desc(self, op_name, index, name):
        """Set op's represented original output op
           op_name: op to set original output
           index: index of original output index
           name: op name of original output
        """
        self._ops.get(op_name)['output_desc'] = [deepcopy(DEFAULT_OUTPUT_DESC)]
        self._ops.get(op_name).get('output_desc')[0].get('attr')[3].get('value')['i'] = index
        self._ops.get(op_name).get('output_desc')[0].get('attr')[2].get('value')['s'] = name

    def dump(self, save_path, save_prefix):
        """Dump quantized and fusion info to json file
           save_path: path to save json file
           save_prefix: prefix of json file ('prefix_quant.json')
        """
        ops = []
        for _, value in self._ops.items():
            ops.append(value)

        dump_info = {}
        dump_info['graph'] = [{'op': ops}]

        if save_prefix != '':
            dump_info['name'] = save_prefix
        else:
            time = datetime.now(tz=timezone(offset=timedelta(hours=8)))
            time_str = '{:0>4}{:0>2}{:0>2}{:0>2}{:0>2}{:0>2}{:0>2}'.format( \
                time.year, time.month, time.day, time.hour, time.minute, \
                time.second, time.microsecond // 10000)
            dump_info['name'] = 'default_{}'.format(time_str)

        dump_file = os.path.join(save_path, \
            '{}_quant.json'.format(save_prefix))

        files_util.create_path(save_path)
        files_util.check_files_exist([dump_file])
        with open(dump_file, 'w') as write_file:
            json.dump(dump_info, write_file, indent=4)
        os.chmod(dump_file, FILE_MODE)


class QuantInfoGenerator(): # pylint: disable=attribute-defined-outside-init
    """Class to record quantize operation infomation, and dump it to json
       file.
    """
    __instance = None
    __initialized = False

    def __new__(cls, *args, **kw):
        if cls.__instance is None:
            cls.__instance = object.__new__(cls, *args, **kw)
        return cls.__instance

    @staticmethod
    def parse_graph(graph):
        """Parse graph structure to op records
           graph: graph of tensorflow to parse
        """
        op_records = {}
        # record all op in graph
        ops = graph.get_operations()
        for tf_op in ops:
            op_records[tf_op.name] = OpRecord(tf_op)
            # record producers according to input tensor
            for input_tensor in tf_op.inputs:
                op_records.get(tf_op.name).producers.append(
                    input_tensor.op.name)
            for output_tensor in tf_op.outputs:
                consumer_names = []
                for consumer in output_tensor.consumers():
                    consumer_names.append(consumer.name)
                op_records.get(tf_op.name).consumers.append(consumer_names)
        return op_records

    def init(self, original_graph):
        """Init original graph, should call at first.
           original_graph: user original tensorflow graph
        """
        QuantInfoGenerator.__initialized = True
        self._original_graph = self.parse_graph(original_graph)
        self._bias_add_record_info = {}
        self._output_anchors = {}

    def uninit(self):
        """Uninit QuantInfoGenerator, clear init flag
        """
        self._original_graph = {}
        self._bias_add_record_info = {}
        self._output_anchors = {}
        QuantInfoGenerator.__initialized = False

    def has_fusion_info(self, op_name):
        """Check whether current op have fusion info
           Inputs: op_name: name of op to check
           Outputs: True: current op have fusion info
                    False: current op have no fusion info
        """
        if QuantInfoGenerator.__initialized:
            result = False
            if QuantInfoGenerator.__initialized:
                if op_name in self._original_graph and \
                    self._original_graph[op_name].fusion_info:
                    result = True
                elif op_name in self._bias_add_record_info:
                    result = True
            return result
        return False

    def set_fusion_anchor(self, op_name, fusion_ops):
        """Set fusion info to current op as an search anchor
           op_name: name of op that set anchor to
           fusion_ops: fusion info as anchor
        """
        if QuantInfoGenerator.__initialized:
            if op_name in self._original_graph:
                update_fusion_ops = []
                for fusion_op in fusion_ops:
                    if fusion_op in self._original_graph:
                        update_fusion_ops.append(fusion_op)
                    elif fusion_op in self._bias_add_record_info:
                        update_fusion_ops.extend(
                            self._bias_add_record_info[fusion_op])
                if update_fusion_ops:
                    self._original_graph[op_name].fusion_info = \
                        update_fusion_ops

    def set_bias_add_anchor(self, op_name, original_ops):
        """Set bias add info to current op as an search anchor
           op_name: name of op that set anchor to
           original_ops: bias add info as anchor
        """
        if QuantInfoGenerator.__initialized:
            self._bias_add_record_info[op_name] = []
            for original_op in original_ops:
                if original_op in self._original_graph \
                    and self._original_graph[original_op].fusion_info:
                    self._bias_add_record_info[op_name].extend(
                        self._original_graph[original_op].fusion_info)
                elif original_op in self._bias_add_record_info:
                    self._bias_add_record_info[op_name].extend(
                        self._bias_add_record_info[original_op])
                else:
                    self._bias_add_record_info[op_name].append(original_op)

    def set_output_anchor(self, op_name, produce_op):
        """Set output info to current op as an search anchor
           op_name: name of op that set anchor to
           produce_op: output info as anchor
        """
        if QuantInfoGenerator.__initialized:
            if produce_op in self._original_graph:
                if self._original_graph[produce_op].fusion_info:
                    original_ops = self._original_graph[produce_op].fusion_info
                else:
                    original_ops = [produce_op]
            elif produce_op in self._bias_add_record_info:
                original_ops = self._bias_add_record_info[produce_op]
            else:
                raise RuntimeError('Cannot find info of {}'.format(produce_op))
            self._output_anchors[op_name] = original_ops

    def update_graph(self, graph):
        """Update graph records according to original graph and new one
           graph: new graph after modified
        """
        if QuantInfoGenerator.__initialized:
            # update record info according to modified graph
            self._dump_info = QuantizeInfoDumper()
            op_records = self.parse_graph(graph)
            # record all basic info
            for op_name, op_record in op_records.items():
                self._dump_info.add_op(op_record)
                if op_name in self._original_graph and \
                    self._original_graph[op_name].fusion_info:
                    self._dump_info.set_original_names(
                        op_name, self._original_graph[op_name].fusion_info)
                elif op_name in self._bias_add_record_info:
                    self._dump_info.set_original_names(
                        op_name, self._bias_add_record_info[op_name])
                elif op_name in self._output_anchors:
                    self._dump_info.set_original_names(
                        op_name, self._output_anchors[op_name])
                    self._dump_info.set_output_desc(
                        op_name, 0, self._output_anchors[op_name][-1])
                elif op_name not in self._original_graph:
                    if op_record.record_op.type != 'Const':
                        anchor_info = self._find_anchor(op_records, op_name)
                        if anchor_info is not None:
                            self._dump_info.set_original_names(op_name,
                                                               anchor_info)
                    else:
                        self._find_anchor_for_const_op(op_records, op_name)

    def dump_info_to_json(self, save_path, save_prefix):
        """Dump quantized and fusion info to json file
           save_path: path to save json file
           save_prefix: prefix of json file ('prefix_quant.json')
        """
        if QuantInfoGenerator.__initialized:
            self._dump_info.dump(save_path, save_prefix)

    def _find_anchor(self, op_records, op_name):
        """Find anchor info of current op
           op_records: records to search from
           op_name: name of op to search
        """
        if op_name in op_records:
            for op_point in op_records[op_name].consumers[0]:
                if op_point in self._original_graph:
                    if self._original_graph[op_point].fusion_info:
                        return self._original_graph[op_point].fusion_info
                    return [op_point]
                if op_point in self._bias_add_record_info:
                    return self._bias_add_record_info[op_point]
                if op_point in self._output_anchors:
                    return self._output_anchors[op_point]
                return self._find_anchor(op_records, op_point)
        return None

    def _find_anchor_for_const_op(self, op_records, op_name):
        """Try found anchor for const op
           op_name: name of const op
        """
        name_scope, _ = split_name_scope(op_name)
        if name_scope != '':
            _, bigger_op = split_name_scope(name_scope)
            if bigger_op in ('act_quant', 'weight_quant'):
                const_read_name = '{}/Sub'.format(name_scope)
            elif bigger_op == 'bias_quant':
                const_read_name = '{}/Maximum'.format(name_scope)
            elif bigger_op == 'dequant':
                const_read_name = '{}/RealDiv'.format(name_scope)
            elif bigger_op in ('Maximum', 'Minimum'):
                const_read_name = name_scope
            else:
                const_read_name = None
            if const_read_name is not None:
                anchor_info = self._find_anchor(op_records, const_read_name)
                if anchor_info is not None:
                    self._dump_info.set_original_names(op_name, anchor_info)
