#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Parse record file.
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_tensorflow.proto import \
    scale_offset_record_pb2 # pylint: disable=no-name-in-module
from amct_tensorflow.proto import \
    inner_scale_offset_record_pb2 # pylint: disable=no-name-in-module

from amct_tensorflow.capacity import CAPACITY
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.configuration.get_layers import OpSelector
from amct_tensorflow.common.utils.parse_record_file import RecordFileParserBase

__all__ = ["RecordFileParser", "ConvertModelRecordFileParser"]


class RecordFileParser(RecordFileParserBase):
    """
    Function: Parse the information of compression from record_file using
              defination from inner_scale_offset_record.proto
    APIs: read_record_file, parse
    """
    def __init__(self, record_file, graph, model_name, enable_quant=True, enable_prune=False, prune_idx=None):
        """
        Function: init object
        Inputs:
            record_file: a string, the file to parse.
            graph: tf.compat.v1.Graph, the graph corresponding to record_file.
            model_name: a string, the model's name.
        """
        capacity = {
            'FUSE_TYPES': CAPACITY.get_value('FUSE_TYPES'),
            'QUANTIZABLE_TYPES': CAPACITY.get_value('QUANTIZABLE_TYPES'),
            'SHIFT_N_TYPES': CAPACITY.get_value('SHIFT_N_TYPES'),
            'PRUNABLE_TYPES': CAPACITY.get_value('PRUNABLE_TYPES'),
            'NO_WEIGHT_QUANT_TYPES': CAPACITY.get_value('NO_WEIGHT_QUANT_TYPES'),
        }

        config = {
            "capacity": capacity,
            "records_pb2": inner_scale_offset_record_pb2,
            "op_quirer": QuantOpInfo,
            "graph_querier": OpSelector,
            "graph_checker": GraphChecker
        }
        super(RecordFileParser, self).__init__(
            record_file, graph, model_name, config,
            config.get('records_pb2').InnerScaleOffsetRecord(),
            enable_quant, enable_prune, prune_idx=prune_idx)


class ConvertModelRecordFileParser(RecordFileParserBase):
    """
    Function: Parse the information of compression from record_file using
              defination from scale_offset_record.proto
    APIs: read_record_file, parse
    """
    def __init__(self, record_file, graph, model_name):
        """
        Function: init object
        Inputs:
            record_file: a string, the file to parse.
            graph: tf.compat.v1.Graph, the graph corresponding to record_file.
            model_name: a string, the model's name.
        """
        capacity = {
            'SHIFT_N_TYPES': CAPACITY.get_value('SHIFT_N_TYPES'),
            'QUANTIZABLE_TYPES': CAPACITY.get_value('QUANTIZABLE_TYPES'),
            'FUSE_TYPES': CAPACITY.get_value('FUSE_TYPES'),
            'NO_WEIGHT_QUANT_TYPES':
            CAPACITY.get_value('NO_WEIGHT_QUANT_TYPES'),
        }
        config = {
            "records_pb2": scale_offset_record_pb2,
            "capacity": capacity,
            "op_quirer": QuantOpInfo,
            "graph_querier": OpSelector,
            "graph_checker": GraphChecker
        }
        RecordFileParserBase.__init__(self, record_file, graph, model_name,
                                      config)
