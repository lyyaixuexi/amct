#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

log

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os

from amct_tensorflow.common.utils.log_base import LoggerBase
from amct_tensorflow.common.utils.log_base import check_level

DEFAULT_LOG_FILE_DIR = os.path.join(os.getcwd(), 'amct_log')
LOG_NAME = 'amct_tensorflow.log'


class Logger(LoggerBase):
    """
    Function: Record debug,info,warning,error level log
    API: push_debug_message, push_info_message, push_warning_message,
         push_error_message
    """
    def __init__(self,
                 log_dir,
                 log_name,
                 print_level='info',
                 save_level='info'):
        """
        Function: Create logger
        Parameter: log_dir: directory of log
                   log_name: name of log
                   print_level: level of printing
                   save_level: level of saving
        Return: None
        """
        check_level(print_level.upper(), 'print_level')
        check_level(save_level.upper(), 'save_level')
        LoggerBase.__init__(self, log_dir, log_name)
        self.set_debug_level(print_level, save_level)

    def push_debug_message(self, debug_message, module_name="AMCT"):
        """
        Function: Record debug log
        Parameter:
            debug_message: debug log
            module_name: name of module
        Return: None
        """
        self.logd(debug_message, module_name)

    def push_info_message(self, info_message, module_name="AMCT"):
        """
        Function: Record info log
        Parameter:
            info_message: info log
            module_name: name of module
        Return:None
        """
        self.logi(info_message, module_name)

    def push_warning_message(self, warning_message, module_name="AMCT"):
        """
        Function: Record warning log
        Parameter:
            warning_message: warning log
            module_name: name of module
        Return:None
        """
        self.logw(warning_message, module_name)

    def push_error_message(self, error_message, module_name="AMCT"):
        """
        Function: Record error log
        Parameter:
            error_message: error log
            module_name: name of module
        Return:None
        """
        self.loge(error_message, module_name)


LOGGER = Logger(log_dir=DEFAULT_LOG_FILE_DIR,
                log_name=LOG_NAME,
                print_level='info',
                save_level='info')


def set_logging_level(print_level='info', save_level='info'):
    """
    Function: Set LOGGER's debug level
    Parameter: print_level: 'debug', 'info', 'warning', 'error'
               save_level: 'debug', 'info', 'warning', 'error'
    Return:None
    """
    LOGGER.set_debug_level(print_level, save_level)
