#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Common data definition module.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import json
from amct_tensorflow.capacity import CAPACITY

CUR_DIR = os.path.split(os.path.realpath(__file__))[0]

QUANTIZABLE_TYPES = CAPACITY.get_value('QUANTIZABLE_TYPES')
CONVERT_QAT_QUANTIZABLE_TYPES = CAPACITY.get_value(
    'CONVERT_QAT_QUANTIZABLE_TYPES')
NUQ_QUANTIZABLE_TYPES = CAPACITY.get_value('NUQ_QUANTIZABLE_TYPES')
CHANNEL_WISE_TYPES = CAPACITY.get_value('CHANNEL_WISE_TYPES')
SHIFT_N_TYPES = CAPACITY.get_value('SHIFT_N_TYPES')
NO_WEIGHT_QUANT_TYPES = CAPACITY.get_value('NO_WEIGHT_QUANT_TYPES')
DUAL_ACTIVATION_QUANT_TYPES = CAPACITY.get_value('DUAL_ACTIVATION_QUANT_TYPES')
SHIFT_N_ENABLE = bool(SHIFT_N_TYPES)

MULT_OUTPUT_TYPES = CAPACITY.get_value('MULT_OUTPUT_TYPES')
ELTWISE_TYPES = CAPACITY.get_value('ELTWISE_TYPES')
ADD_TYPES = CAPACITY.get_value('ADD_TYPES')

FUSE_TYPES = CAPACITY.get_value('FUSE_TYPES')
FUSE_BN_TYPES = CAPACITY.get_value('FUSE_BN_TYPES')
FUSE_MUL_TYPES = CAPACITY.get_value('FUSE_MUL_TYPES')

AMCT_OPERATIONS = CAPACITY.get_value('AMCT_OPERATIONS')

TRANSPARENT_TYPES = CAPACITY.get_value('TRANSPARENT_TYPES')

DELETE_IDENTITY = CAPACITY.get_value('DELETE_IDENTITY')

PATTERN_FILE = CAPACITY.get_value('PATTERN_FILE')

with open(os.path.realpath(os.path.join(CUR_DIR, '../', PATTERN_FILE[0])), 'r') \
    as file_pattern:
    PATTERN_CONFIG = json.load(file_pattern)

QUANT_BIAS_BITS = 32
ZERO = 0.0
ONE = 1.0
BASE = 2
EPSILON = 1E-6

ACT_CALI = 'insert_act_cali'
WTS_CALI = 'insert_wts_cali'
SEARCH_N = 'insert_search_n'

CLUSTER_CENTER = 'cluster_center'
QUANT_LAYER_SUFFIX = ('AscendQuant', 'AscendDequant', 'AscendAntiQuant')
AMCT_QAT_OPS = ("ActivationRetrain", "WeightRetrain")

# channel prune
AMCT_PRUNE_OPS = ("BalancedL2Norm", "MaskGen", "Mask")
PRUNABLE_TYPES = CAPACITY.get_value('PRUNABLE_TYPES')
PASSIVE_PRUNABLE_TYPES = CAPACITY.get_value('PASSIVE_PRUNABLE_TYPES')
ELTWISE_TYPES = CAPACITY.get_value('ELTWISE_TYPES')
SPECIAL_OPS = CAPACITY.get_value('SPECIAL_OPS')
SAFE_OPS = CAPACITY.get_value('SAFE_OPS')
COND_OPS = CAPACITY.get_value('COND_OPS')
PRUNE_KNOWN_OPS = PRUNABLE_TYPES + PASSIVE_PRUNABLE_TYPES + ELTWISE_TYPES + SPECIAL_OPS + SAFE_OPS + COND_OPS

# selective prune
SELECTIVE_PRUNABLE_TYPES = CAPACITY.get_value('SELECTIVE_PRUNABLE_TYPES')

# TensorQuantize
TENSOR_QUANTIZABLE_TYPES = CAPACITY.get_value('TENSOR_QUANTIZABLE_TYPES')

# Op approximation
OP_APPROXIMATION_TYPES = CAPACITY.get_value('OP_APPROXIMATION_TYPES')
