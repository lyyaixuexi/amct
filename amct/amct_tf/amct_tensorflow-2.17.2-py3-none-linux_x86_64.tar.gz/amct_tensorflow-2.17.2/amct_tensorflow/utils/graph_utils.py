#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Utils for tf.compat.v1.Graph.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import tensorflow as tf
from google import protobuf

from amct_tensorflow.common.utils import files as files_util
from amct_tensorflow.common.utils.util import FILE_MODE
from amct_tensorflow.utils.log import LOGGER


class GraphUtils:
    """ Utils for processing tf.compat.v1.Graph.
    """
    @staticmethod
    def handle_graph_def(graph_def):
        """Handel graphdef for it to be import as graph """
        for node in graph_def.node:
            GraphUtils.handle_node(node)

    @staticmethod
    def handle_ref_node(graph_node):
        '''inner method'''
        if graph_node.op == 'RefSwitch':
            graph_node.op = 'Switch'
            for index in range(len(graph_node.input)):
                if 'moving_' in graph_node.input[index]:
                    graph_node.input[index] = graph_node.input[index] + '/read'
        if graph_node.op == 'RefMerge':
            graph_node.op = 'Merge'
            for index in range(len(graph_node.input)):
                if 'moving_' in graph_node.input[index]:
                    graph_node.input[index] = graph_node.input[index] + '/read'
        if graph_node.op == 'RefEnter':
            graph_node.op = 'Enter'
            for index in range(len(graph_node.input)):
                if 'moving_' in graph_node.input[index]:
                    graph_node.input[index] = graph_node.input[index] + '/read'

    @staticmethod
    def handle_node(graph_node):
        '''inner method'''
        GraphUtils.handle_ref_node(graph_node)
        if graph_node.op == 'AssignSub':
            graph_node.op = 'Sub'
            if 'use_locking' in graph_node.attr:
                del graph_node.attr['use_locking']
        if graph_node.op == 'AssignAdd':
            graph_node.op = 'Add'
            if 'use_locking' in graph_node.attr:
                del graph_node.attr['use_locking']
        if graph_node.op == 'Assign':
            graph_node.op = 'Identity'
            if 'use_locking' in graph_node.attr:
                del graph_node.attr['use_locking']
            if 'validate_shape' in graph_node.attr:
                del graph_node.attr['validate_shape']
            if len(graph_node.input) == 2:
                graph_node.input[0] = graph_node.input[1]
                del graph_node.input[1]

    @staticmethod
    def savetopb(sess, outputs, file_name):
        """
        Function: Save sess.graph to a model.pb
        Inputs:
            sess: tf.compat.v1.Session where graph and value of parameters stored.
            outputs: a list containing the names of outputs in graph.
            file_name: a string, the path where to store model file and the
                model's name for saving.
        Return: output_graph_def: Final deploy model
        """
        # get graph_def for saving
        graph_def = sess.graph.as_graph_def()

        for node in graph_def.node:
            if node.op == 'AscendQuant':
                if 'quant_bits' in node.attr:
                    del node.attr['quant_bits']
            if node.name.endswith('_full_precision_for_amct'):
                node.name = node.name[:-len('_full_precision_for_amct')]
            for idx, input_name in enumerate(node.input):
                if '_full_precision_for_amct' in input_name:
                    node.input[idx] = input_name.replace('_full_precision_for_amct', '')

        output_graph_def = tf.compat.v1.graph_util.convert_variables_to_constants(
            sess, graph_def, outputs)
        # save
        files_util.check_files_exist([file_name])
        with tf.compat.v1.io.gfile.GFile(file_name, 'wb') as fid:
            serialized_graph = output_graph_def.SerializeToString()
            fid.write(serialized_graph)
            LOGGER.push_info_message("The model is saved in {}"\
                .format(file_name), "save_model")

        # set permission 640
        os.chmod(file_name, FILE_MODE)
        return output_graph_def

    @staticmethod
    def parse_pb_to_graph(pb_model, outputs=None):
        """
        Function: parse pb_model to a graph.
        Inputs:
            pb_model: model to be converted.
        Returns:
            graph: tf.compat.v1.Graph parserd from pb_model.
        """
        graph_def = tf.compat.v1.GraphDef()
        with tf.compat.v1.io.gfile.GFile(pb_model, 'rb') as fid:
            try:
                graph_def.ParseFromString(fid.read())
            except protobuf.message.DecodeError as e:
                raise RuntimeError("parse error, please check %s" % (pb_model)) from e

        # extract graph according to model's outputs
        if outputs:
            graph_def = tf.compat.v1.graph_util.extract_sub_graph(graph_def, outputs)

        graph = tf.compat.v1.Graph()
        with graph.as_default():
            # parse to get graph from pb_model
            tf.compat.v1.import_graph_def(graph_def, name='')

        return graph
