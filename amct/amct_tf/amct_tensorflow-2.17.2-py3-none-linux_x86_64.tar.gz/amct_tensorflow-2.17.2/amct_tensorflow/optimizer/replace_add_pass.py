#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace add/addv2 to bias_add for all layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from tensorflow.python.ops import gen_control_flow_ops

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.optimizer.bn_fusion_utils import get_data_format
from amct_tensorflow.optimizer.bn_fusion_utils import is_tail_layer
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.utils.quant_ops import create_context

from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.utils.utils_vars import ADD_TYPES
from amct_tensorflow.configuration.check_graph import GraphChecker

_CUSTOM_OP = load()

__all__ = ['ReplaceAddPass']


class ReplaceAddPass(BaseFusionPass):
    """
    Function: Replace add/addv2 to bias_add for all layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, is_replace=False, outputs=None):
        """
        Function: init ReplaceAddPass object
        Inputs:
            is_replace: a bool, whether to replace the layer
            outputs: a list that is names of out ops
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.is_replace = is_replace
        if outputs is None:
            outputs = []
        self.outputs = outputs

    @staticmethod
    def get_tensor_and_op(object_op):
        """Get data tensor, bias tensor and quant operation."""
        data_index, bias_add_index, quant_op, _ = GraphChecker.get_add_index(object_op)
        data_tensor = object_op.inputs[data_index]
        bias_tensor = object_op.inputs[bias_add_index]
        if bias_tensor.op.type == 'Enter':
            bias_tensor = bias_tensor.op.inputs[0]
        real_length = GraphChecker.get_add_length(quant_op, bias_tensor.shape)
        if real_length == 0:
            bias_tensor = tf.compat.v1.reshape(bias_tensor, [1])
        else:
            bias_tensor = tf.compat.v1.squeeze(bias_tensor)
        expect_length = GraphChecker.get_cout_channel(quant_op)
        bias_tensor = tf.compat.v1.broadcast_to(bias_tensor, [expect_length])
        return data_tensor, bias_tensor, quant_op

    def match_pattern(self, operation):
        """
        Function: Matches the op that can be replaced with biasadd.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type in ADD_TYPES and operation.type != 'BiasAdd':
            if GraphChecker.check_biasadd(operation):
                return True
        return False

    def do_pass(self, object_op):
        """
        Function: replace add/addv2 to bias_add.
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        assign_list = []
        layer_context, _ = split_name_scope(object_op.name)
        context = create_context(layer_context, quant_type='replace_add')

        data_tensor, bias_tensor, quant_op = ReplaceAddPass.get_tensor_and_op(object_op)

        # replace object_op node by replace_object_op node
        with tf.compat.v1.variable_scope(None,
                                         default_name=context,
                                         values=[data_tensor]):
            bias_add = bias_tensor
            if self.outputs and self.is_replace:
                bias_add = tf.compat.v1.get_variable(
                    'bias_add_replaced',
                    shape=bias_tensor.shape,
                    dtype=bias_tensor.dtype,
                    trainable=False,
                    collections=[
                        tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                        tf.compat.v1.GraphKeys.MODEL_VARIABLES
                    ],
                    use_resource=False)
                assign_list.append(tf.compat.v1.assign(bias_add, bias_tensor))
            # check if add is in a while loop
            info_length, frame_name, is_constant, parallel_iterations = \
                 GraphChecker.get_dependency_enter_info(object_op.inputs[1].op)
            if info_length:
                if self.is_replace:
                    bias_add = gen_control_flow_ops.ref_enter(
                        bias_add,
                        frame_name=frame_name,
                        is_constant=is_constant,
                        parallel_iterations=parallel_iterations)
                else:
                    bias_add = gen_control_flow_ops.enter(
                        bias_add,
                        frame_name=frame_name,
                        is_constant=is_constant,
                        parallel_iterations=parallel_iterations)
            try:
                replace_object_op_out = tf.compat.v1.nn.bias_add(
                    value=data_tensor,
                    bias=bias_add,
                    data_format=get_data_format(quant_op.get_attr('data_format')))
            except ValueError:
                replace_object_op_out = tf.compat.v1.nn.bias_add(
                    value=data_tensor, bias=bias_add)

        if is_tail_layer(object_op) and not self.outputs:
            LOGGER.push_warning_message(
                'Replace ADD at the end of the network! ' \
                'You need to replace the old output node by the new output ' \
                'node in inference process! \n' \
                '{}The name of the old output node is \'{}\'\n' \
                '{}The name of the new output node is \'{}\''.format(
                    '>'*30, object_op.outputs[0].name,
                    '<'*30, replace_object_op_out.name),
                module_name='replace_add_pass')

        if object_op.outputs:
            object_op_out = object_op.outputs[0]
            consumers_object_op_out = object_op_out.consumers()
            replace_inputs_tensor(replace_object_op_out, object_op_out,
                                  consumers_object_op_out)
        replace_inputs_tensor(
            tf.compat.v1.placeholder(data_tensor.dtype),
            data_tensor, [object_op])

        if object_op.name in self.outputs:
            index = self.outputs.index(object_op.name)
            self.outputs[index] = replace_object_op_out.op.name
        return assign_list, []
