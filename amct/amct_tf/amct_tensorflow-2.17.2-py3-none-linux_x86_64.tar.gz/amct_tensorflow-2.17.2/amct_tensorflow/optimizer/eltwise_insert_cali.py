#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert quant_arq op for quantizable layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.optimizer.insert_bias_quant_pass import cmp_data_format
from amct_tensorflow.optimizer.bn_fusion_utils import is_tail_layer
from amct_tensorflow.optimizer.bn_fusion_utils import get_data_format
from amct_tensorflow.optimizer.insert_arq_pass import InsertARQPass
from amct_tensorflow.optimizer.insert_search_n_pass import \
    InsertSearchNQuantPass
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.utils import quant_ops
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.pattern.match_eltwise import EltwiseAddUnion

from amct_tensorflow.utils.utils_vars import SHIFT_N_TYPES
from amct_tensorflow.utils.utils_vars import NO_WEIGHT_QUANT_TYPES
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.common.utils import vars_util
from amct_tensorflow.utils.utils_vars import ACT_CALI
from amct_tensorflow.utils.utils_vars import WTS_CALI
from amct_tensorflow.utils.utils_vars import SEARCH_N

_CUSTOM_OP = load()

__all__ = ['EltwiseInsertCaliPass']


class EltwiseInsertCaliPass(BaseFusionPass):
    """
    Function: Insert quant_arq op for quantized layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, quant_config=None, skip_layers=None, weight_fakequant=True):
        """
        Function: init object of EltwiseInsertCaliPass
        Inputs:
            quant_config: a dictionary containing quant config
            skip_layers: a dict, containing skip quantize layers
        Return: None
        """
        BaseFusionPass.__init__(self)
        if skip_layers is None:
            skip_layers = {ACT_CALI: [], WTS_CALI: [], SEARCH_N: []}
        if quant_config is None:
            quant_config = {}
        self.quant_config = quant_config
        self.skip_layers = skip_layers
        self.weight_fakequant = weight_fakequant

        self.structure = {}
        self.tail_ops = []

    def match_pattern(self, operation):
        """
        Function: Match quantizable operation to be quantized.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        try:
            eltwise_add_union = EltwiseAddUnion(operation, self.quant_config)
        except RuntimeError:
            return False

        union_ops = eltwise_add_union.get_union_ops()
        brother_ops = find_union_quant_brothers(union_ops[0],
                                                self.quant_config)
        brother_ops.extend(
            find_union_quant_brothers(union_ops[1], self.quant_config))
        brother_ops = [op for op in brother_ops if op not in union_ops]
        self.structure[operation.name] = {
            'eltwise_add_union': eltwise_add_union,
            'brother_ops': brother_ops}
        ops_be_quant = union_ops + brother_ops
        self.skip_layers.get(WTS_CALI).extend(op.name for op in ops_be_quant)
        self.skip_layers.get(SEARCH_N).extend([op.name for op in ops_be_quant])
        self.skip_layers.get(ACT_CALI).extend([op.name for op in ops_be_quant])
        return True

    def do_pass(self, object_op):
        """
        Function: Insert arq, ifmr and search_n for union_ops in object_op's
            pattern
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing tensor need to be run to get value
        """
        eltwise_add_union = self.structure.get(object_op.name).get('eltwise_add_union')
        brother_ops = self.structure.get(object_op.name).get('brother_ops')

        wgt_cali_output = insert_weight_cali(
            object_op, eltwise_add_union, self.quant_config, self.weight_fakequant)

        act_cali_output = insert_act_cali(
            object_op, eltwise_add_union, brother_ops, self.quant_config)

        wgt_act_param = [act_cali_output, wgt_cali_output, self.weight_fakequant]
        insert_search_n_cali(object_op, eltwise_add_union, brother_ops,
                             self.quant_config, wgt_act_param)

        return [], []


def insert_act_cali(object_op, eltwise_add_union, brother_ops, quant_config):
    '''
    Function: insert act quant(calibration) for union_ops in object_op's
        pattern
    Inputs:
        object_op: the pattern's first eltwise add node
        eltwise_add_union: class EltwiseAddUnion, object_op's pattern
        brother_ops: brother_ops of head op in eltwise_add_union
        quant_config: a dictionary containing the quant config
    Returns:
        act_cali_output: the output tensor of [quant_ifmr | quant_hfmg] op
    '''
    pattern_union_ops = eltwise_add_union.get_union_ops()
    union_ops = pattern_union_ops + brother_ops

    # concat act
    def concat_inputs():
        '''concat input for act_quant '''
        act_inputs = []
        for quant_op in union_ops:
            act_index, _ = QuantOpInfo.get_quant_index(quant_op)
            act_inputs.append(quant_op.inputs[act_index])
        input_concat = tf.compat.v1.concat(
            [tf.compat.v1.reshape(inputs, [-1]) for inputs in act_inputs], 0)
        return input_concat

    input_concat = concat_inputs()

    # get quant params
    def get_quant_kwargs():
        '''get quant_kwargs for weight_quant'''
        quant_kwargs = quant_config.get(
            union_ops[0].name).get('activation_quant_params')
        quant_kwargs['batch_num'] = quant_config.get('batch_num')
        if quant_kwargs.get('asymmetric') is None:
            need_offset = quant_config.get('activation_offset')
        else:
            need_offset = quant_kwargs['asymmetric']
        quant_kwargs['need_offset'] = need_offset
        quant_kwargs['quant_op_names'] = [op.name for op in union_ops]
        quant_kwargs['record_file_name'] = quant_config.get('record_file')
        quant_kwargs['num_bits'] = quant_config.get('num_bits', 8)
        return quant_kwargs

    quant_kwargs = get_quant_kwargs()

    # insert operaions and add control depency
    def insert_act_calibration_op():
        '''insert act calibration op and add control depency '''
        tail_ops = eltwise_add_union.get_tail_ops()
        tail_tensors = [op.inputs[0] for op in tail_ops]
        layer_context, _ = split_name_scope(object_op.name)
        act_identities, act_cali_output = quant_ops.quant_calibration(
            [input_concat, tail_tensors], layer_context, 'activation',
            quant_kwargs, 'Conv2D')
        for index, act_identity in enumerate(act_identities):
            quant_ops.relink_tensor(tail_tensors[index], act_identity,
                                    tail_ops[index])
        return act_cali_output

    act_cali_output = insert_act_calibration_op()

    for name in [op.name for op in union_ops]:
        LOGGER.push_info_message('doing layer:%s insert act_quant' % name,
                                 module_name='EltwiseInsertCaliPass')
    return act_cali_output


def insert_weight_cali(object_op, eltwise_add_union, quant_config, weight_fakequant=True):
    '''
    Function: insert weight quant(calibration) for union_ops in object_op's
        pattern
    Inputs:
        object_op: the pattern's first eltwise add node
        eltwise_add_union: class EltwiseAddUnion, object_op's pattern
        quant_config: a dictionary containing the quant config
    Returns:
        wgt_cali_out: weight calibration output tensor
    '''

    def _insert_arq_union_ops(object_op, eltwise_add_union, quant_config):
        union_ops = eltwise_add_union.get_union_ops()
        # get quant params
        quant_kwargs = quant_config.get(
            union_ops[0].name).get('weight_quant_params')
        quant_kwargs['quant_op_names'] = eltwise_add_union.get_union_op_names()
        quant_kwargs['record_file_name'] = quant_config.get('record_file')
        quant_kwargs['num_bits'] = quant_config.get('num_bits', vars_util.INT8_BIT)
        quant_kwargs['do_fakequant'] = weight_fakequant

        # concat inputs
        weight_inputs = []
        for quant_op in union_ops:
            _, weight_index = QuantOpInfo.get_quant_index(quant_op)
            weight_inputs.append(quant_op.inputs[weight_index])
        input_concat = tf.compat.v1.concat(
            [tf.compat.v1.reshape(inputs, [-1]) for inputs in weight_inputs], 0)

        # insert wts_quant
        layer_context, _ = split_name_scope(object_op.name)
        weight_quants, wgt_cali_out = quant_ops.quant_calibration(
            [input_concat, weight_inputs], layer_context, 'weight',
            quant_kwargs, 'Conv2D')
        for index, weight_quant in enumerate(weight_inputs):
            quant_ops.relink_tensor(weight_quant, weight_quants[index],
                                    union_ops[index])

        for name in eltwise_add_union.get_union_op_names():
            LOGGER.push_info_message(
                'doing layer:%s insert weight_quant' % name,
                module_name='EltwiseInsertCaliPass')
        return wgt_cali_out
    wgt_cali_out = _insert_arq_union_ops(object_op, eltwise_add_union, quant_config)
    return wgt_cali_out


def insert_search_n_cali(object_op, eltwise_add_union, brother_ops,
                         quant_config, wgt_act_param):
    '''
    Function: insert search_n(calibration) for union_ops in object_op's
        pattern
    Inputs:
        object_op: the pattern's first eltwise add node
        eltwise_add_union: class EltwiseAddUnion, object_op's pattern
        brother_ops: brother_ops of head op in eltwise_add_union
        quant_config: a dictionary containing the quant config
        wgt_act_param: the output tensor of [quant_arq | quant_ifmr | quant_hfmg] op
    Returns: None
    '''
    union_ops = eltwise_add_union.get_union_ops()
    union_op_names = eltwise_add_union.get_union_op_names()

    if False in (check_search_n(op) for op in union_ops):
        LOGGER.push_debug_message(
            'cannot search n for eltwise structure {%s: %s}' %
            (object_op.name, union_op_names),
            module_name='EltwiseInsertCaliPass')
        return

    wgt_act_output = wgt_act_param[0:2]
    quant_kwargs = get_searchn_quant_kwargs(union_ops, quant_config,
                                            wgt_act_output)

    # concat inputs
    def concat_inputs():
        ''' concat inputs for search_n '''
        search_inputs = [get_layer_tail(op).outputs[0] for op in union_ops]
        if quant_kwargs['data_format'] == 'NCHW':
            search_inputs = [
                tf.compat.v1.transpose(inputs, perm=[0, 2, 3, 1])
                for inputs in search_inputs
            ]
            quant_kwargs['data_format'] = 'NHWC'

        channel_num = search_inputs[0].shape[-1]
        inputs_concat = tf.compat.v1.concat(
            [tf.compat.v1.reshape(inputs, [-1, channel_num]) for inputs in search_inputs], 0)
        return inputs_concat

    inputs_concat = concat_inputs()

    # insert search_n_quant and add control depency
    tail_tensors = [op.inputs[0] for op in eltwise_add_union.get_tail_ops()]

    def insert_searchn():
        '''insert search_n_quant and add control depency '''
        tail_consumers = [tensor.consumers() for tensor in tail_tensors]

        layer_context, _ = split_name_scope(object_op.name)
        search_n_outputs, _ = quant_ops.quant_calibration(
            [inputs_concat, tail_tensors], layer_context, 'search_n',
            quant_kwargs, 'Conv2D')

        for index, outputs in enumerate(search_n_outputs):
            quant_ops.replace_inputs_tensor(outputs, tail_tensors[index],
                                            tail_consumers[index])

    insert_searchn()

    for union_op_name in union_op_names:
        LOGGER.push_info_message('doing layer:%s insert search_n_quant' %
                                 union_op_name,
                                 module_name='EltwiseInsertCaliPass')

    # insert search_n for brother_ops
    is_weight_fakequant = wgt_act_param[-1]
    for brother_op in brother_ops:
        if brother_op.type not in NO_WEIGHT_QUANT_TYPES:
            InsertARQPass.insert_arq_single_op(
                brother_op, quant_config, False, is_weight_fakequant)
            LOGGER.push_info_message(
                'doing layer:%s insert weight_quant' % brother_op.name,
                module_name='EltwiseInsertCaliPass')
        bro_wgt_act_output = InsertSearchNQuantPass.get_calibration_scales(brother_op)
        insert_searchn_brother_op(brother_op, quant_config, bro_wgt_act_output,
                                  tail_tensors)


def insert_searchn_brother_op(brother_op, quant_config, wgt_act_output,
                              tail_tensors):
    ''' insert search_n for brother_op'''
    layer_context, _ = split_name_scope(brother_op.name)
    tail_consumers = [tensor.consumers() for tensor in tail_tensors]

    quant_kwargs = InsertSearchNQuantPass.gen_searchn_param(
        brother_op, wgt_act_output, quant_config)
    layer_outputs = get_layer_tail(brother_op).outputs[0]
    search_n_outputs, _ = quant_ops.quant_calibration(
        [layer_outputs, tail_tensors], layer_context, 'search_n',
        quant_kwargs, brother_op.type)

    for index, outputs in enumerate(search_n_outputs):
        quant_ops.replace_inputs_tensor(outputs, tail_tensors[index],
                                        tail_consumers[index])
    LOGGER.push_info_message('doing layer:%s insert search_n_quant' %
                             brother_op.name,
                             module_name='EltwiseInsertCaliPass')


def get_searchn_quant_kwargs(union_ops, quant_config, wgt_act_output):
    ''' get quant_kwargs for search_n'''
    union_op_names = [union_op.name for union_op in union_ops]
    union_op_types = [union_op.type for union_op in union_ops]
    quant_kwargs = quant_config.get(union_op_names[0]).\
        get('activation_quant_params')
    if quant_kwargs.get('act_algo') is None or \
            quant_kwargs.get('act_algo') == 'ifmr':
        quant_kwargs['searchn_version'] = 'V1'
    else:
        quant_kwargs['searchn_version'] = 'V2'

    quant_kwargs['batch_num'] = quant_config.get('batch_num')
    quant_kwargs['quant_op_names'] = union_op_names
    quant_kwargs['quant_op_types'] = union_op_types
    quant_kwargs['record_file_name'] = quant_config.\
        get('record_file')

    quant_kwargs['channel_wise'] = quant_config.get(union_op_names[0]).\
        get('weight_quant_params').get('channel_wise')
    _, shift_n_length = QuantOpInfo.get_scale_shape(
        union_ops[0].inputs[1], quant_kwargs['channel_wise'],
        union_ops[0].type)

    quant_kwargs['shift_n_length'] = shift_n_length
    quant_kwargs['data_format'] = get_data_format(
        union_ops[0].get_attr('data_format'))

    quant_kwargs['act_cali_output'] = wgt_act_output[0]
    quant_kwargs['wgt_cali_output'] = wgt_act_output[1]

    return quant_kwargs


def get_layer_tail(operation):
    '''
    Get layer's out tensor. layer's out is biasAdd'out when there's BiasAdd
    otherwise conv's out.
    '''
    layer_tail_op = operation
    if len(operation.outputs[0].consumers()) == 1:
        next_op = operation.outputs[0].consumers()[0]
        if GraphChecker.check_biasadd(next_op) and cmp_data_format(
                operation, next_op):
            layer_tail_op = next_op

    return layer_tail_op


def check_search_n(operation):
    '''check whether an operation can do search_n '''
    is_search_n = False
    if operation.type in SHIFT_N_TYPES:
        layer_tail_op = get_layer_tail(operation)
        if not is_tail_layer(layer_tail_op):
            is_search_n = True
    return is_search_n


def find_union_quant_brothers(operation, quant_config):
    '''
    Function: Find operation's brother ops to do same quant. op_b is op_a's
        brother op, if op_b's act_quant_param is same with op_a's
        act_quant_param, they do same quant.
            Add
           // \
        op_a  op_b
    Inputs:
        operation: tf.compat.v1.Operation
    Returns:
        union_quant_brothers: a list, brother ops to do same quant
    '''
    input_tensor = operation.inputs[0]
    brothers = input_tensor.consumers()
    brothers.remove(operation)

    union_quant_brothers = []
    layer_act_config = quant_config.get(
        operation.name).get('activation_quant_params')
    for brother in brothers:
        if quant_config.get(brother.name) is None:
            continue
        if layer_act_config == quant_config.get(
                brother.name).get('activation_quant_params'):
            union_quant_brothers.append(brother)

    return union_quant_brothers
