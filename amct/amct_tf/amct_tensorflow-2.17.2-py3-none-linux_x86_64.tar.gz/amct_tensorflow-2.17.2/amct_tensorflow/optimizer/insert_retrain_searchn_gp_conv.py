#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert search_n op for group conv.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from collections import namedtuple

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.pattern.match_pattern import PatternHelper
from amct_tensorflow.optimizer.insert_retrain_search_n_pass import \
    InsertRetrainSearchNPass

from amct_tensorflow.pattern.match_group_conv import pattern_group_conv
from amct_tensorflow.pattern.match_group_conv import GROUP_CONV_SPLIT
from amct_tensorflow.utils.utils_vars import FUSE_BN_TYPES

_CUSTOM_OP = load()

InsertPosition = namedtuple('InsertPosition',
    ['insert_op', 'conv_ops', 'small_bn_flag', 'op_list', 'output_dict', 'bn_op'])

__all__ = ['InsertRetrainSearchnGpConv']


class InsertRetrainSearchnGpConv(BaseFusionPass):
    """
    Function: Insert retrain search_n op for group conv.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, quant_config=None, skip_layers=None, output_nodes=None):
        """
        Function: init object
        Inputs:
            quant_config: a dictionary containing quant config
            skip_layers: a list containing skip quantize layers
            output_nodes: a list that is names of out ops
        Return: None
        """
        BaseFusionPass.__init__(self)
        if quant_config is None:
            quant_config = {}
        if skip_layers is None:
            skip_layers = []
        if output_nodes is None:
            output_nodes = []
        self.quant_config = quant_config
        self.skip_layers = skip_layers
        self.output_nodes = output_nodes
        self.context_num = 0

    @staticmethod
    def get_insert_position(object_op):
        """
        Function: Obtains the location of the search node to be inserted.
        Inputs:
            object_op: op to process
        Returns:
            insert_op: insert searchn after this op
            conv_ops: a list of quantized operation
            small_bn_flag: a bool that indicates whether there is a structure
                of BN small operators
            op_list: an operator list in BN small operator structure
            output_dict: An important operator information dictionary in the
                structure of BN small operators
            bn_op: a big BN operation
        """
        bn_op = None
        group_conv = pattern_group_conv(object_op)
        concat_op = group_conv.get_concat()
        conv_ops = group_conv.get_convs()
        bn_pattern = PatternHelper.match_batch_norm_by_main_op(concat_op)
        if bn_pattern.flag:
            insert_op = bn_pattern.op_list[0]
        elif len(concat_op.outputs[0].consumers()) == 1:
            concat_consumer = concat_op.outputs[0].consumers()[0]
            if concat_consumer.type in FUSE_BN_TYPES \
                and not concat_consumer.get_attr('is_training'):
                bn_op = concat_consumer
                insert_op = bn_op
            else:
                insert_op = concat_op
        else:
            insert_op = concat_op

        return InsertPosition._make(
            [insert_op, conv_ops, bn_pattern.flag, bn_pattern.op_list, bn_pattern.output_dict, bn_op])

    def match_pattern(self, operation):
        """
        Function: Match quantizable operation to be quantized.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        is_matched = False
        if operation.type in GROUP_CONV_SPLIT:
            group_conv = pattern_group_conv(operation)
            if group_conv is not None:
                is_matched = True
                convs = group_conv.get_name('conv_names')
                if not self.quant_config.get(convs[0]).get('retrain_enable'):
                    is_matched = False
                for conv in convs[1:]:
                    if self.quant_config.get(conv) != self.quant_config.get(convs[0]):
                        is_matched = False
                        break
        return is_matched

    def do_pass(self, object_op):
        """
        Function: Insert retrain search_n for object_op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        # get the position of insertion
        insert_pos = InsertRetrainSearchnGpConv.get_insert_position(object_op)

        scale_offset, no_weight_flag = \
            InsertRetrainSearchNPass.get_scale_offset(insert_pos.conv_ops)
        scale_w_length = 1
        for dim in scale_offset[2].shape:
            scale_w_length *= int(dim)

        # get the parameter information of BN
        if insert_pos.small_bn_flag:
            bn_param = InsertRetrainSearchNPass.get_small_bn_param(
                insert_pos.op_list, insert_pos.output_dict, scale_w_length)
        else:
            bn_param = InsertRetrainSearchNPass.get_big_bn_param(
                insert_pos.bn_op, scale_w_length)

        # insert the searchn operator of retrain
        op_list = [insert_pos.conv_ops, insert_pos.bn_op, insert_pos.insert_op, self.output_nodes]
        record_param = [scale_offset, bn_param]
        self.quant_config['no_weight_flag'] = no_weight_flag
        self.quant_config['retrain_group'] = True
        self.context_num = InsertRetrainSearchNPass.insert_record_and_search_n(
            op_list, record_param, scale_w_length, self.quant_config,
            self.context_num)
        self.quant_config['retrain_group'] = False
        return [], []
