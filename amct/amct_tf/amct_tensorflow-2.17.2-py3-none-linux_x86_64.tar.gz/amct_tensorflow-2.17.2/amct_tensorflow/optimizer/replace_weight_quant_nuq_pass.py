#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace WeightQuantNuq to 'weight_quant_nuq ops' for quantized layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from tensorflow.python.ops import gen_control_flow_ops

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.utils.quant_info_generator import QuantInfoGenerator
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.lib.load_custom_op import load_ascend
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.utils.quant_ops import create_context
from amct_tensorflow.utils.log import LOGGER

_CUSTOM_OP = load_ascend()

__all__ = ['ReplaceWeightQuantNuqPass']


class ReplaceWeightQuantNuqPass(BaseFusionPass):
    """
    Function: Replace WeightQuantNuq to 'weight_quant_nuq ops' for quantized layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, outputs=None):
        """
        Function: init object
        Inputs: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        if not outputs:
            raise RuntimeError("param 'outputs' cannot be empty for weights "
                               "to be quantized to int8.")
        self.outputs = outputs

    def match_pattern(self, operation):
        """
        Function: Match WeightQuantNuq op.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type == 'WeightQuantNuq':
            return True
        return False

    def do_pass(self, object_op):
        """
        Function: Replace WeightQuantNuq to 'weight_quant_nuq ops'
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables. weight_int should be updated by assign_weight.
            run_list: a list containing trensor need to be run to get value
        """
        context, _ = split_name_scope(
            str(object_op.get_attr('layer_name'), encoding='utf-8'))
        context = create_context(context, quant_type='weight')
        # inser weight_quant
        weight = object_op.inputs[0]
        # check if weight is in a while loop
        info_length, frame_name, is_constant, parallel_iterations = \
                GraphChecker.get_dependency_enter_info(weight.op)
        if info_length:
            weight = weight.op.inputs[0]
        offset = object_op.inputs[2]
        quant_out = object_op.outputs[0]
        quant_consumers = quant_out.consumers()
        if quant_consumers[0].type == 'Cast':
            quant_out = quant_consumers[0].outputs[0]
            quant_consumers = quant_out.consumers()

        with tf.compat.v1.variable_scope(None,
                                         default_name=context,
                                         values=[weight]):
            weight_quant = tf.compat.v1.cast(quant_out, tf.compat.v1.int8)
            weight_int = tf.compat.v1.get_variable(
                'weight_int',
                shape=weight_quant.shape,
                dtype=tf.compat.v1.int8,
                trainable=False,
                collections=[
                    tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                    tf.compat.v1.GraphKeys.MODEL_VARIABLES
                ],
                use_resource=False)

            # if object_op is in while loop, add enter nodes before assign
            if info_length:
                weight_int = gen_control_flow_ops.ref_enter(
                    weight_int,
                    frame_name=frame_name,
                    is_constant=is_constant,
                    parallel_iterations=parallel_iterations)
                offset = gen_control_flow_ops.enter(
                    offset,
                    frame_name=frame_name,
                    is_constant=is_constant,
                    parallel_iterations=parallel_iterations)
            assign_weight = tf.compat.v1.assign(weight_int, weight_quant)

            # chage weight_int to int9
            outputs = _CUSTOM_OP.ascend_weight_quant(
                weight_int,
                offset,
                T='float32',
                dst_type='INT8')

        replace_inputs_tensor(outputs, quant_out, quant_consumers)
        # Set dump anchor to compute op
        if quant_consumers and \
            not QuantInfoGenerator().has_fusion_info(quant_consumers[0].name):
            QuantInfoGenerator().set_fusion_anchor(
                quant_consumers[0].name, [quant_consumers[0].name])

        LOGGER.push_debug_message(
            "finish replacing WeightQuantNuq for %s" %
            (object_op.get_attr('layer_name')), "ReplaceWeightQuantNuqPass")

        return [assign_weight], []
