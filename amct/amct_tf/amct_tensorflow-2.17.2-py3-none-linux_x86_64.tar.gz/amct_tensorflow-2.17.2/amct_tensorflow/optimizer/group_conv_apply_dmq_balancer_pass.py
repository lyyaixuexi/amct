#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2023. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert Mul op for dmq_balance layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils import quant_ops
from amct_tensorflow.pattern.match_group_conv import pattern_group_conv
from amct_tensorflow.optimizer.apply_dmq_balancer_pass import ApplyDMQBalancerPass

from amct_tensorflow.pattern.match_group_conv import GROUP_CONV_SPLIT
from amct_tensorflow.utils.log import LOGGER

__all__ = ['GroupConvApplyDMQBalancerPass']


class GroupConvApplyDMQBalancerPass(BaseFusionPass):
    """
    Function: Insert mul op for dmq_balancer layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, quant_config=None, records=None, skip_layers=None, outputs=None, is_replace=False):
        """
        Function: init object of GroupConvApplyDMQBalancerPass
        Inputs:
            quant_config: a dict containing quant config. (quantize_model phase)
            records: a dict containing record.
            skip_layers: a list containing skip quantize layers.
            outputs: a list, graph outputs, needed when is_replace=True and new weights will be assigned.
            is_replace: a bool, True: new weights should be assigned. (save_model phase)
                                False: mul op be inserted to weights, no tensor to be assigned. (quantize_model phase)
        Return: None
        """
        BaseFusionPass.__init__(self, outputs)
        self.quant_config = quant_config
        self.records = {} if records is None else records
        self.skip_layers = [] if skip_layers is None else skip_layers
        self.tensor_balance_factor = []
        self.structure = {}
        if is_replace and not outputs:
            raise RuntimeError(
                "param 'outputs' cannot be empty when is_replace is True")
        self.is_replace = is_replace


    def apply_balance_scale_to_activation(self, group_conv):
        '''
        insert mul op before split op
        '''
        split_op = group_conv.get_split()
        activation = split_op.inputs[1]
        # broadcast tensor balance factor to activation shape
        balance_scale = tf.compat.v1.constant([1/scale for scale in self.tensor_balance_factor], dtype=activation.dtype)
        reshape_dim = group_conv.get_attr('reshape_dims')
        balance_scale = tf.compat.v1.reshape(balance_scale, reshape_dim)

        # multiply activation and scale
        balanced_act = tf.compat.v1.multiply(activation, balance_scale)

        quant_ops.relink_tensor(activation, balanced_act, split_op)


    def match_pattern(self, operation):
        """
        Function: Match quantizable operation to be quantized.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        # Find the split operation
        if operation.type not in GROUP_CONV_SPLIT:
            return False
        # match the group_conv structure
        group_conv = pattern_group_conv(operation)
        if group_conv is None:
            return False
        # check the act quant parameter is same for conv nodes
        if self.quant_config:
            enable_cali, _ = group_conv.check_cali(self.quant_config)
            if not enable_cali:
                return False
            if not self.quant_config.get(group_conv.get_name('conv_names')[0]).get('dmq_balancer_param'):
                return False
        # check all group conv have tensor_balance_factor
        for conv_name in group_conv.get_name('conv_names'):
            if not self.records.get(conv_name) or not self.records.get(conv_name).get('tensor_balance_factor'):
                if self.quant_config:
                    raise ValueError("config indicates dmq_balancer in layer: %s, " \
                                    "but no tensor_balance_factor found in record." \
                                    "please check quant_preprocess and calibration is done!" % conv_name)
                return False

        self.structure[operation.name] = group_conv
        self.skip_layers.extend(group_conv.get_name('conv_names'))
        return True

    def do_pass(self, object_op):
        """
        Function: Insert quant_arq(for weight) before object_op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        group_conv = self.structure.get(object_op.name)

        LOGGER.push_debug_message('doing group_conv:%s apply dmq_balancer' %
                                  group_conv.get_name('name'),
                                  'GroupConvApplyDMQBalancerPass')
        self.tensor_balance_factor = []
        for conv_name in group_conv.get_name('conv_names'):
            self.tensor_balance_factor.extend(self.records.get(conv_name).get('tensor_balance_factor'))
        # insert scale op to activation
        for conv_name in group_conv.get_name('conv_names'):
            LOGGER.push_info_message('doing layer:%s apply dmq_balancer to activation' %
                                     conv_name, 'GroupConvApplyDMQBalancerPass')
        self.apply_balance_scale_to_activation(group_conv)

        # assign weights
        assign_list = []
        for conv in group_conv.get_convs():
            LOGGER.push_debug_message('doing layer:%s apply dmq_balancer to weight' %
                                      conv.name, 'GroupConvApplyDMQBalancerPass')
            conv_assign_list, _ = ApplyDMQBalancerPass.apply_balance_scale_to_weight(
                conv, self.records.get(conv.name).get('tensor_balance_factor'), self.is_replace)
            assign_list.extend(conv_assign_list)

        return assign_list, _
