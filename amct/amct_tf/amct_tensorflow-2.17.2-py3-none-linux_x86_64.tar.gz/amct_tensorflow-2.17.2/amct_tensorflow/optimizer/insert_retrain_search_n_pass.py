#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert search_n op for quantizable layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
import tensorflow as tf  # pylint: disable=E0401

from amct_tensorflow.pattern.utils import get_layer_ops_by_type
from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.utils.quant_ops import get_next_single_op
from amct_tensorflow.utils.quant_ops import is_scalar
from amct_tensorflow.utils import quant_ops
from amct_tensorflow.optimizer.conv_bn_fusion_pass import \
    match_conv_bn_pattern
from amct_tensorflow.optimizer.fuse_mul_pass import \
    match_quant_mul_pattern

from amct_tensorflow.utils.utils_vars import SHIFT_N_TYPES
from amct_tensorflow.utils.utils_vars import FUSE_TYPES
from amct_tensorflow.utils.utils_vars import FUSE_MUL_TYPES
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.utils.retrain_alg import _decorate_enter

_CUSTOM_OP = load()

__all__ = ['InsertRetrainSearchNPass']


class InsertRetrainSearchNPass(BaseFusionPass):
    """
    Function: Insert retrain search_n op for quantized layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, quant_config=None, skip_layers=None, output_nodes=None):
        """
        Function: init object
        Inputs:
            quant_config: a dictionary containing quant config
            skip_layers: a list containing skip quantize layers
            output_nodes: a list that is names of out ops
        Return: None
        """
        BaseFusionPass.__init__(self)
        if quant_config is None:
            quant_config = {}
        if skip_layers is None:
            skip_layers = []
        if output_nodes is None:
            output_nodes = []
        self.quant_config = quant_config
        self.skip_layers = skip_layers
        self.output_nodes = output_nodes
        self.context_num = 0

    @staticmethod
    def insert_record_and_search_n(  # pylint: disable=R0914
            op_list, record_param, scale_w_length, quant_config, context_num):
        """
        Function: Insert record operator and searchn operator of retrain
        Inputs:
            op_list: a list of opertion.
                [main_ops, bn_op, insert_op, output_nodes]
            record_param: a list of record parameters.
                [scale_offset, bn_param]
            scale_w_length: the length of scale_w
            quant_config: a dictionary containing quant config
            context_num: a int num of context management counter
        Returns:
            context_num: a int num of context management counter.
        """
        main_ops, bn_op, insert_op, output_nodes = op_list
        scale_offset, bn_param = record_param
        dst_type = quant_config[
            main_ops[0].name]["retrain_data_config"]["dst_type"]
        mul_param = InsertRetrainSearchNPass.get_mul_param(main_ops[0], bn_op)
        control_op_list = scale_offset[0].consumers() + \
            scale_offset[1].consumers()
        for control_op in control_op_list[:]:
            if 'scale' in control_op.name or 'offset' in control_op.name:
                control_op_list.remove(control_op)

        # handle tf.while_loop case
        bn_param[0], bn_param[1], bn_param[2], mul_param[0] = _decorate_enter(
            scale_offset[0], op_list[0][0].name, [bn_param[0], bn_param[1], bn_param[2], mul_param[0]])
        with tf.compat.v1.control_dependencies(control_op_list):
            record_out = _CUSTOM_OP.record_scale_offset(
                scale_offset[0],
                scale_offset[1],
                scale_offset[2],
                scale_offset[3],
                bn_param[0],
                bn_param[1],
                bn_param[2],
                mul_param[0],
                dst_type=dst_type,
                layer_names=[main_op.name for main_op in main_ops],
                record_file_path=quant_config.get('record_file'),
                scale_w_length=0 if quant_config['no_weight_flag'] else scale_w_length,
                is_training=bn_param[3],
                T='float32')

        LOGGER.push_info_message(
            'doing layer:%s insert retrain search_n_quant' % main_ops[0].name,
            module_name='insert_retrain_search_n_pass')
        if len(main_ops[0].inputs) > 1:
            context = main_ops[0].inputs[1].op.name
        else:
            context = '%d_' % context_num
            context_num += 1

        # insert retrain search_n
        quant_kwargs = InsertRetrainSearchNPass.gen_searchn_param(
            main_ops, record_out, scale_w_length, quant_config)
        if dst_type == 'INT4':
            quant_kwargs['do_searchn'] = False
        InsertRetrainSearchNPass.insert_search_n(output_nodes, main_ops,
                                                 insert_op, context,
                                                 quant_kwargs)
        return context_num

    @staticmethod
    def gen_searchn_param(main_ops, record_out, scale_w_length, quant_config):
        '''gen searchn param for main_ops'''
        quant_kwargs = {}
        quant_kwargs['batch_num'] = quant_config.get('batch_num')
        quant_kwargs['quant_op_names'] = [main_op.name for main_op in main_ops]
        quant_kwargs['record_file_name'] = quant_config.get('record_file')
        quant_kwargs['act_cali_output'] = record_out[0]
        quant_kwargs['wgt_cali_output'] = record_out[1]
        if main_ops[0].type == 'AvgPool':
            channel_wise = False
            shift_n_length = 1
            data_sequence = bytes('NHWC', encoding="utf8")
            if main_ops[0].get_attr('data_format') == data_sequence:
                weight_shape = main_ops[0].get_attr('ksize')[1:3]
            else:
                weight_shape = main_ops[0].get_attr('ksize')[2:]
            area_factor = 1 / (weight_shape[0] * weight_shape[1])
            quant_kwargs['wgt_cali_output'] = area_factor
        elif len(main_ops) == 1:
            weights = main_ops[0].inputs[1]
            channel_wise = quant_config.get(main_ops[0].name).\
                get('retrain_weight_config').get('channel_wise')
            _, shift_n_length = QuantOpInfo.get_scale_shape(
                weights, channel_wise, main_ops[0].type)
        else:
            channel_wise = True
            shift_n_length = scale_w_length

        quant_kwargs['channel_wise'] = channel_wise
        quant_kwargs['shift_n_length'] = shift_n_length
        try:
            quant_kwargs['data_format'] = main_ops[0].get_attr('data_format')
        except ValueError:
            quant_kwargs['data_format'] = 'NHWC'

        quant_kwargs['retrain_group'] = bool(quant_config.get('retrain_group'))
        quant_kwargs['is_retrain_node'] = True
        return quant_kwargs

    @staticmethod
    def get_insert_position(object_op):
        """
        Function: Obtains the location of the search node to be inserted.
        Inputs:
            object_op: op to process
        Returns:
            compute_op: insert searchn after this op
        """
        compute_op = object_op
        if object_op.type == 'AvgPool':
            return compute_op
        next_op = get_next_single_op(object_op.outputs[0].consumers())
        if next_op is not None:
            if GraphChecker.check_biasadd(next_op):
                compute_op = next_op
        if object_op.type in FUSE_TYPES:
            if match_conv_bn_pattern(compute_op, [False]):
                compute_op = compute_op.outputs[0].consumers()[0]
        if object_op.type in FUSE_MUL_TYPES:
            if match_quant_mul_pattern(compute_op):
                compute_op = compute_op.outputs[0].consumers()[0]
        return compute_op

    @staticmethod
    def insert_search_n(output_nodes, main_ops, insert_op, context,
                        quant_kwargs):
        """
        Function: Do insert search_n after compute_op
        Inputs:
            output_nodes: a list of output nodes.
            main_ops: ops to process
            insert_op: insert searchn after this op
            context: op context
            quant_kwargs: dictionary of quantization parameter
        Returns:
            None
        """
        outputs = insert_op.outputs[0]
        search_n_outputs, _ = quant_ops.quant_calibration([outputs, [outputs]],
                                                          context, 'search_n',
                                                          quant_kwargs,
                                                          main_ops[0].type)

        output_nodes.append(search_n_outputs[0])

    @staticmethod
    def get_scale_offset(main_ops):
        """
        Function: Get the scale and offset tensor of the operation.
        Inputs:
            main_ops: op to be matched
        Returns:
            scale_offset: a list that is retrain quant factors.
            no_weight_flag: a bool that indicates whether a weight exists.
        """
        no_weight_flag = True
        scale_offset = [
            tf.compat.v1.constant(np.ones([1]) * -1, dtype=tf.compat.v1.float32),
            tf.compat.v1.constant(np.ones([1]) * -1, dtype=tf.compat.v1.int32),
            tf.compat.v1.constant(np.ones([1]) * -1, dtype=tf.compat.v1.float32),
            tf.compat.v1.constant(np.ones([1]) * -1, dtype=tf.compat.v1.int32),
        ]
        act_ops = get_layer_ops_by_type(main_ops[0].graph, ['ActivationRetrain'])
        wts_ops = get_layer_ops_by_type(main_ops[0].graph,
                                        ['WeightRetrain', 'WeightUlq'])
        for act_op in act_ops:
            for layer_name in act_op.get_attr('layer_names'):
                if layer_name == bytes(main_ops[0].name, encoding="utf8"):
                    scale_offset[0] = act_op.outputs[1]
                    scale_offset[1] = act_op.outputs[2]
                    break
        scale_ws = []
        offset_ws = []
        for wts_op in wts_ops:
            for layer_name in wts_op.get_attr('layer_names'):
                for main_op in main_ops:
                    if layer_name == bytes(main_op.name, encoding="utf8"):
                        no_weight_flag = False
                        scale_w = wts_op.outputs[1]
                        offset_w = wts_op.outputs[2]

                        # broadcast scale/offset to cout length for group conv with channel-wise false
                        if len(main_ops) > 1 and scale_w.shape == 1:
                            scale_w = tf.compat.v1.tile(
                                tf.compat.v1.reshape(scale_w, [1]),
                                [int(main_ops[0].inputs[1].shape[-1])])
                            offset_w = tf.compat.v1.tile(
                                tf.compat.v1.reshape(offset_w, [1]),
                                [int(main_ops[0].inputs[1].shape[-1])])
                        scale_ws.append(scale_w)
                        offset_ws.append(offset_w)
                        break
        control_op_list = InsertRetrainSearchNPass.get_control_op_list(
            scale_ws)
        if len(scale_ws) > 1:
            with tf.compat.v1.control_dependencies(control_op_list):
                scale_offset[2] = tf.compat.v1.concat(scale_ws, axis=-1)
                scale_offset[3] = tf.compat.v1.concat(offset_ws, axis=-1)
        elif len(scale_ws) == 1:
            scale_offset[2] = scale_ws[0]
            scale_offset[3] = offset_ws[0]
        return scale_offset, no_weight_flag

    @staticmethod
    def get_control_op_list(scale_ws):
        '''obtain control ops of scale_ws'''
        control_op_list = []
        for scale in scale_ws:
            control_op_list.extend(scale.consumers())
        for control_op in control_op_list[:]:
            if 'scale' in control_op.name or 'offset' in control_op.name:
                control_op_list.remove(control_op)
        return control_op_list

    @staticmethod
    def get_big_bn_param(bn_op, scale_w_length):
        """
        Function: Get the big bn parameters tensor of the operation.
        Inputs:
            bn_op: op to be matched
            scale_w_length: the length of the scale_w
        Returns:
            bn_param: a list that is bn parameters.
                [scale, variance, epsilon, is_training]
        """
        bn_param = []
        if bn_op and not bn_op.get_attr('is_training'):
            bn_param.append(bn_op.inputs[1])
            bn_param.append(bn_op.inputs[4])
            bn_param.append(
                tf.compat.v1.constant(bn_op.get_attr('epsilon'),
                                      dtype=tf.compat.v1.float32))
            bn_param.append(bn_op.get_attr('is_training'))
        else:
            bn_param.append(
                tf.compat.v1.constant(np.ones([scale_w_length]),
                                      dtype=tf.compat.v1.float32))
            bn_param.append(
                tf.compat.v1.constant(np.ones([scale_w_length]),
                                      dtype=tf.compat.v1.float32))
            bn_param.append(
                tf.compat.v1.constant([0.0], dtype=tf.compat.v1.float32))
            bn_param.append(False)

        return bn_param

    @staticmethod
    def get_small_bn_param(bn_op_list, bn_output_dict, scale_w_length):
        """
        Function: Get the small bn parameters tensor of the operation.
        Inputs:
            bn_op_list: a operation list of not fused bn opearion.
            bn_output_dict: a dict of bn params.
            scale_w_length: the length of the scale_w
        Returns:
            bn_param: a list that is bn parameters.
                [scale, variance, epsilon, is_training]
        """
        bn_param = []
        scale_index = bn_output_dict.get('scale')
        variance_index = bn_output_dict.get('variance')
        epsilon_index = bn_output_dict.get('epsilon')

        if scale_index is None:
            bn_param.append(
                tf.compat.v1.constant(np.ones([scale_w_length]),
                                      dtype=tf.compat.v1.float32))
        else:
            bn_param.append(bn_op_list[scale_index].outputs[0])
        bn_param.append(bn_op_list[variance_index].outputs[0])
        bn_param.append(bn_op_list[epsilon_index].outputs[0])
        bn_param.append(False)
        return bn_param

    @staticmethod
    def get_mul_param(operation, bn_op):
        """
        Function: Get the mul parameters tensor of the operation.
        Inputs:
            operation: op to be matched
            bn_op: a operation that is Batch Normalization.
        Returns:
            mul_param: a list that is mul parameters.
        """
        mul_param = []
        mul_op = None
        if operation.type in FUSE_MUL_TYPES:
            compute_op = operation
            next_op = get_next_single_op(operation.outputs[0].consumers())
            if next_op is not None:
                if GraphChecker.check_biasadd(next_op):
                    compute_op = next_op
            if bn_op:
                compute_op = bn_op
            if match_quant_mul_pattern(compute_op):
                mul_op = compute_op.outputs[0].consumers()[0]

        if mul_op:
            if is_scalar(mul_op.inputs[0]):
                mul_param.append(mul_op.inputs[0])
            else:
                mul_param.append(mul_op.inputs[1])
        else:
            mul_param.append(
                tf.compat.v1.constant([1.0], dtype=tf.compat.v1.float32))

        return mul_param

    def match_pattern(self, operation):
        """
        Function: Match quantizable operation to be quantized.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        is_matched = False
        if operation.type in SHIFT_N_TYPES \
            and operation.name in self.quant_config.keys() \
            and operation.name not in self.skip_layers \
            and self.quant_config.get(operation.name).get('retrain_enable'):
            is_matched = True
        return is_matched

    def do_pass(self, object_op):
        """
        Function: Insert retrain search_n(for output) after object_op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        # get the position of insertion
        insert_op = InsertRetrainSearchNPass.get_insert_position(object_op)

        scale_offset, no_weight_flag = \
            InsertRetrainSearchNPass.get_scale_offset([object_op])
        scale_w_length = 1
        for dim in scale_offset[2].shape:
            scale_w_length *= int(dim)

        # get the parameter information of BN
        bn_op = None
        if object_op.type in FUSE_TYPES:
            compute_op = object_op
            next_op = get_next_single_op(object_op.outputs[0].consumers())
            if next_op is not None:
                if GraphChecker.check_biasadd(next_op):
                    compute_op = next_op
            if match_conv_bn_pattern(compute_op, [False]):
                bn_op = compute_op.outputs[0].consumers()[0]
        bn_param = InsertRetrainSearchNPass.get_big_bn_param(
            bn_op, scale_w_length)

        # insert the searchn operator of retrain
        op_list = [[object_op], bn_op, insert_op, self.output_nodes]
        record_param = [scale_offset, bn_param]
        self.quant_config['no_weight_flag'] = no_weight_flag
        self.context_num = InsertRetrainSearchNPass.insert_record_and_search_n(
            op_list, record_param, scale_w_length, self.quant_config,
            self.context_num)
        return [], []
