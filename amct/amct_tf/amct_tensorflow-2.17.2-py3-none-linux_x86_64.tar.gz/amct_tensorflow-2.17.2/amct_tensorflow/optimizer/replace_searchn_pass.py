#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace Searchn(per_channel) to Searchn(per_tensor) for quantized layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.lib.load_custom_op import load

from amct_tensorflow.utils.utils_vars import QUANTIZABLE_TYPES
from amct_tensorflow.utils.log import LOGGER

_CUSTOM_OP = load()

__all__ = ['ReplaceSearchnPass']


class ReplaceSearchnPass(BaseFusionPass):
    """
    Function: Replace Searchn(per_channel) to Searchn(per_tensor).
    APIs: match_pattern, do_pass,
    """
    def __init__(self):
        """
        Function: init object
        Inputs: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.searchn_ops_map = {}
        for operation in tf.compat.v1.get_default_graph().get_operations():
            if operation.type not in ['SearchN', 'SearchNV2']:
                continue
            for layer_name in operation.get_attr('layer_names'):
                self.searchn_ops_map[layer_name] = operation

    @staticmethod
    def trace_ops(ops, link_softmax_ops, recursion_depth):
        '''a recursive function for traverse the op type upward.'''
        recursion_depth += 1
        if recursion_depth < 20:
            for single_op in ops:
                if single_op.type not in QUANTIZABLE_TYPES:
                    search_ops = [input_tensor.op for input_tensor in single_op.inputs]
                    ReplaceSearchnPass.trace_ops(search_ops, link_softmax_ops, recursion_depth)
                else:
                    link_softmax_ops.append(single_op)

    def match_pattern(self, operation):
        """
        Function: Match Softmax op.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type == "Softmax":
            return True
        return False

    def do_pass(self, object_op):
        """
        Function: Replace Searchn(per_channel) to Searchn(per_tensor)
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing tensor need to be run to get value
        """
        link_softmax_ops = []
        recursion_depth = 0
        ReplaceSearchnPass.trace_ops([object_op.inputs[0].op], link_softmax_ops, recursion_depth)

        for link_softmax_op in link_softmax_ops:
            if link_softmax_op.name.encode('utf-8') not in self.searchn_ops_map:
                continue
            searchn_op = self.searchn_ops_map[link_softmax_op.name.encode('utf-8')]
            context, _ = split_name_scope(searchn_op.name)
            # add new 'searchn op'
            if searchn_op.type == "SearchN":
                with tf.compat.v1.variable_scope(None, default_name=context, values=[searchn_op.inputs[0]]):
                    shift_n = _CUSTOM_OP.search_n(
                        searchn_op.inputs[0],
                        enable=searchn_op.inputs[1],
                        scale_d=searchn_op.inputs[2],
                        scale_w=searchn_op.inputs[3],
                        shift_n_length=searchn_op.get_attr('shift_n_length'),
                        channel_wise=searchn_op.get_attr('channel_wise'),
                        data_format=searchn_op.get_attr('data_format'),
                        batch_num=searchn_op.get_attr('batch_num'),
                        layer_names=searchn_op.get_attr('layer_names'),
                        record_file_path=searchn_op.get_attr('record_file_path'),
                        retrain_group=searchn_op.get_attr('retrain_group'),
                        do_searchn=searchn_op.get_attr('do_searchn'),
                        per_tensor=True)
            if searchn_op.type == "SearchNV2":
                with tf.compat.v1.variable_scope(None, default_name=context,
                                                    values=[searchn_op.inputs[0]]):
                    shift_n = _CUSTOM_OP.search_nv2(
                        searchn_op.inputs[0],
                        enable=searchn_op.inputs[1],
                        scale_d=searchn_op.inputs[2],
                        scale_w=searchn_op.inputs[3],
                        shift_n_length=searchn_op.get_attr('shift_n_length'),
                        channel_wise=searchn_op.get_attr('channel_wise'),
                        data_format=searchn_op.get_attr('data_format'),
                        batch_num=searchn_op.get_attr('batch_num'),
                        layer_names=searchn_op.get_attr('layer_names'),
                        layer_types=searchn_op.get_attr('layer_types'),
                        record_file_path=searchn_op.get_attr('record_file_path'),
                        retrain_group=searchn_op.get_attr('retrain_group'),
                        do_searchn=searchn_op.get_attr('do_searchn'),
                        per_tensor=True)
            replace_inputs_tensor(shift_n, searchn_op.outputs[0], searchn_op.outputs[0].consumers())
            replace_inputs_tensor(
                tf.compat.v1.placeholder(searchn_op.inputs[0].dtype), searchn_op.inputs[0], [searchn_op])

            LOGGER.push_info_message(
                "finish replacing Searchn to Searchn(per_tensor) for %s" % (link_softmax_op.name),
                "ReplaceSearchnPass")
        return [], []
