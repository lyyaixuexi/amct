#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert act_cali for quantized layer, 1) insert IFMR/HFMG 2) insert Dump 3)insert IFMR/HFMG + Dump

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_ops import create_context
from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.utils import quant_ops
from amct_tensorflow.utils.quantize_alg import insert_dump
from amct_tensorflow.utils.utils_vars import QUANTIZABLE_TYPES
from amct_tensorflow.utils.utils_vars import TENSOR_QUANTIZABLE_TYPES
from amct_tensorflow.utils.utils_vars import DUAL_ACTIVATION_QUANT_TYPES
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.common.utils import vars_util

_CUSTOM_OP = load()

__all__ = ['InsertActCaliPass']


class InsertActCaliPass(BaseFusionPass):
    """
    Function: Insert act_cali for quantized layer, 1) insert IFMR/HFMG 2) insert Dump 3)insert IFMR/HFMG + Dump
    APIs: match_pattern, do_pass,
    """
    def __init__(self, quant_config=None, skip_layers=None, dump_config=None, mode='cali_dump',
                 on_ascend=False, outputs=None):
        """
        Function: init object of InsertActCaliPass
        Inputs:
            quant_config: a dictionary containing quant config
            skip_layers: a list containing skip quantize layers
            mode: str, 'cali', 'dump', and 'cali_dump'
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.quant_config = {} if quant_config is None else quant_config
        self.skip_layers = {} if skip_layers is None else skip_layers
        self.dump_config = {} if dump_config is None else dump_config
        self.mode = mode
        self.outputs = outputs
        self.on_ascend = on_ascend
        self.tensor_quant_config = {}
        self.ifmr_res = {
            'scales_d': [],
            'offsets_d': [],
            'scales_w': [],
            'offsets_w': [],
            'activation_layers_name': [], # layer_name for scale_d
            'weight_layers_name':[], # layer_name for scale_w
            'record_file': self.quant_config.get('record_file')
        }

    @staticmethod
    def add_record_op(graph, outputs, ifmr_res):
        """Add record operation for ifmr result in graph """
        if not ifmr_res['scales_d']:
            return

        output_op = None
        for graph_output in outputs:
            has_consumer = False
            graph_output_op = graph.get_operation_by_name(graph_output)
            for output in graph_output_op.outputs:
                if output.consumers():
                    has_consumer = True
                    break
            if not has_consumer:
                output_op = graph_output_op
                break
        if output_op is None:
            raise RuntimeError("graph's outputs have consumers")

        with graph.as_default():
            record_out = _CUSTOM_OP.record_quant_factors(
                ifmr_res['scales_d'],
                ifmr_res['offsets_d'],
                T=tf.compat.v1.float32,
                layer_names=ifmr_res['activation_layers_name'],
                record_file_path=ifmr_res['record_file'],
                input_stamp='data')
        # add record op to ensure conv to NPU
        outputs.append(record_out.op.name)

        if ifmr_res.get('scales_w'):
            with graph.as_default():
                record_out = _CUSTOM_OP.record_quant_factors(
                    ifmr_res['scales_w'],
                    ifmr_res['offsets_w'],
                    T=tf.compat.v1.float32,
                    layer_names=ifmr_res['weight_layers_name'],
                    record_file_path=ifmr_res['record_file'],
                    input_stamp='weight')
        outputs.append(record_out.op.name)

    @staticmethod
    def dump(object_op, act_index, global_dump_config):
        """ Add dump in object_op.input[act_index]

        Args:
            object_op (tf.Operation): the operation to insert dump.
            act_index (int): insert dump in which input of object_op.
            global_dump_config (dict): dump config for graph.
        """
        dump_config = {}
        dump_config['dump_dir'] = global_dump_config.dump_dir
        dump_config['name_prefix'] = "{}_in{}".format(object_op.name.replace('/', '_'), act_index)
        dump_config['batch_num'] = global_dump_config.batch_num
        input_tensor = object_op.inputs[act_index]
        layer_context, _ = split_name_scope(object_op.name)
        context = create_context(layer_context, 'dump')
        output_tensor = insert_dump(input_tensor, context, dump_config)
        quant_ops.relink_tensor(input_tensor, output_tensor, object_op)

    def supplement_pass(self):
        """
        Function: supplement graph modify after do_pass
        Inputs: None
        Return: None
        """
        if not self.on_ascend:
            return

        self.add_record_op(self.graph, self.outputs, self.ifmr_res)

    def match_pattern(self, operation):
        """
        Function: Match quantizable operation to be quantized.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type in QUANTIZABLE_TYPES \
            and operation.name in self.quant_config.keys() \
            and operation.name not in self.skip_layers:
            return True
        # check tensor_quantize
        if operation.type in TENSOR_QUANTIZABLE_TYPES \
            and self.quant_config.get('tensor_quantize'):
            for tensor_quantize in self.quant_config.get('tensor_quantize'):
                if tensor_quantize.get('layer_name') == operation.name:
                    self.tensor_quant_config[operation.name] = {}
                    self.tensor_quant_config.get(operation.name)['act_index'] \
                        = tensor_quantize.get('input_index')
                    self.tensor_quant_config.get(operation.name)['activation_quant_params'] \
                        = tensor_quantize.get('activation_quant_params')
                    return True
        return False

    def do_pass(self, object_op):
        """
        Function: Insert quant_ifmr(for act) before object_op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing tensor need to be run to get value
        """
        LOGGER.push_info_message('doing layer:%s insert act_quant' %
                                 object_op.name,
                                 module_name='quantize_model')
        # dump is necessary
        if 'dump' in self.mode and self.dump_config:
            self.add_dump_op(object_op)
        if 'cali' not in self.mode:
            return [], []
        # prepare op info
        quantize_op_name = object_op.name
        tensor_quantize_config = self.tensor_quant_config.get(quantize_op_name)
        is_two_activation_quant = object_op.type in DUAL_ACTIVATION_QUANT_TYPES
        # insert act_quant
        if not tensor_quantize_config:
            act_index, _ = QuantOpInfo.get_quant_index(object_op)
            quant_kwargs = self.quant_config.get(
                quantize_op_name).get('activation_quant_params')
            quant_kwargs['quant_op_names'] = [quantize_op_name]
        else: # tensor_quantize
            act_index = tensor_quantize_config.get('act_index')
            quant_kwargs = tensor_quantize_config.get('activation_quant_params')
            quant_kwargs['quant_op_names'] = [
                '%s:%s' % (quantize_op_name, tensor_quantize_config.get('act_index'))]

        quant_kwargs['batch_num'] = self.quant_config.get('batch_num')
        if quant_kwargs.get('asymmetric') is None:
            need_offset = self.quant_config.get('activation_offset')
        else:
            need_offset = quant_kwargs['asymmetric']
        quant_kwargs['need_offset'] = need_offset if not is_two_activation_quant else False
        quant_kwargs['record_file_name'] = self.quant_config.get('record_file')
        quant_kwargs['num_bits'] = quant_kwargs.get('num_bits', vars_util.INT8_BIT)
        quant_kwargs['input_stamp'] = 'data'
        self._insert_act_quant(act_index, object_op, quant_kwargs, tensor_quantize_config)
        # insert act_quant for weight input
        if is_two_activation_quant:
            act_index = 1
            quant_kwargs['input_stamp'] = 'weight'
            self._insert_act_quant(act_index, object_op, quant_kwargs, tensor_quantize_config)
        return [], []

    def add_dump_op(self, object_op):
        """ Add dump operation for object_op

        Args:
            object_op (tf.Operation): add dump for object_op
        """
        if self.dump_config.batch_num is None:
            self.dump_config.batch_num = self.quant_config.get('batch_num')
        # not add dump for tensor_quant_config
        if self.tensor_quant_config.get(object_op.name):
            return
        # add dump for input featuremap
        position_info = QuantOpInfo.locate_dump_position(object_op)
        for position in position_info.values():
            self.dump(position[0], position[1], self.dump_config)

    def _insert_act_quant(self, act_index, object_op, quant_kwargs, tensor_quantize_config):
        '''add act quant op'''
        if not tensor_quantize_config and not object_op.type == 'AvgPool' \
            and object_op.inputs[act_index].op.type == 'Pad' \
            and len(object_op.inputs[act_index].op.outputs[0].consumers()) == 1:
            object_op = object_op.inputs[act_index].op
            act_index = 0
        layer_context, _ = split_name_scope(object_op.name)
        context = create_context(layer_context, quant_type='activation')
        inputs = object_op.inputs[act_index]
        cali_type = 'activation_ascend' if self.on_ascend else 'activation'
        outputs, quant_factors = quant_ops.quant_calibration(
            [inputs, [inputs]], context, cali_type, quant_kwargs,
            object_op.type)

        if not self.on_ascend:
            quant_ops.relink_tensor(inputs, outputs[0], object_op)
            return
        # on_ascend
        if quant_kwargs.get('input_stamp') == 'data':
            self.ifmr_res.get('scales_d').append(quant_factors.get('scale_d'))
            self.ifmr_res.get('offsets_d').append(
                tf.compat.v1.cast(quant_factors.get('offset_d'), tf.compat.v1.int32))
            self.ifmr_res.get('activation_layers_name').append(quant_kwargs.get('quant_op_names'))
        else:
            # input_stamp is "weight"
            # record scale_d for inputs[1] as scale_w
            self.ifmr_res.get('scales_w').append(quant_factors.get('scale_d'))
            self.ifmr_res.get('offsets_w').append(
                tf.compat.v1.cast(quant_factors.get('offset_d'), tf.compat.v1.int32))
            self.ifmr_res.get('weight_layers_name').append(quant_kwargs.get('quant_op_names'))
