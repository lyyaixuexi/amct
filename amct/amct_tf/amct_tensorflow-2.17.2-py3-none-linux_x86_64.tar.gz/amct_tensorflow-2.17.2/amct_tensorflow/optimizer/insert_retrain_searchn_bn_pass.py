#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert search_n op for quantizable layer(structure of small operators with BN).

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.optimizer.fuse_mul_pass import \
    match_quant_mul_pattern
from amct_tensorflow.pattern.match_pattern import PatternHelper
from amct_tensorflow.optimizer.insert_retrain_search_n_pass import \
    InsertRetrainSearchNPass

from amct_tensorflow.utils.utils_vars import SHIFT_N_TYPES
from amct_tensorflow.utils.utils_vars import FUSE_TYPES
from amct_tensorflow.utils.utils_vars import ADD_TYPES

_CUSTOM_OP = load()

__all__ = ['InsertRetrainSearchnBnPass']


class InsertRetrainSearchnBnPass(BaseFusionPass):
    """
    Function: Insert retrain search_n op for quantized layer
        (structure of small operators with BN).
    APIs: match_pattern, do_pass,
    """
    def __init__(self, quant_config=None, skip_layers=None, output_nodes=None):
        """
        Function: init object
        Inputs:
            quant_config: a dictionary containing quant config
            skip_layers: a list containing skip quantize layers
            output_nodes: a list that is names of out ops
        Return: None
        """
        BaseFusionPass.__init__(self)
        if quant_config is None:
            quant_config = {}
        if skip_layers is None:
            skip_layers = []
        if output_nodes is None:
            output_nodes = []
        self.quant_config = quant_config
        self.skip_layers = skip_layers
        self.output_nodes = output_nodes
        self.context_num = 0

    @staticmethod
    def get_insert_position(object_op):
        """
        Function: Obtains the location of the search node to be inserted.
        Inputs:
            object_op: op to process
        Returns:
            compute_op: insert searchn after this op
        """
        compute_op = object_op
        if match_quant_mul_pattern(compute_op):
            compute_op = compute_op.outputs[0].consumers()[0]
        return compute_op

    def match_pattern(self, operation):
        """
        Function: Match quantizable operation to be quantized.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        is_matched = False
        if operation.type in ADD_TYPES and operation.type != 'BiasAdd':
            bn_pattern = PatternHelper.match_batch_norm_by_add(
                operation)
            if bn_pattern.flag and bn_pattern.quantized_op.type in SHIFT_N_TYPES \
                and bn_pattern.quantized_op.type in FUSE_TYPES:
                if bn_pattern.quantized_op.name in self.quant_config.keys() \
                    and bn_pattern.quantized_op.name not in self.skip_layers \
                    and self.quant_config.get(bn_pattern.quantized_op.name).get('retrain_enable'):
                    self.skip_layers.append(bn_pattern.quantized_op.name)
                    is_matched = True
        return is_matched

    def do_pass(self, object_op):
        """
        Function: Insert retrain search_n(for output) after object_op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        bn_op = object_op
        bn_pattern = PatternHelper.match_batch_norm_by_add(
            object_op)

        # get the position of insertion
        insert_op = InsertRetrainSearchnBnPass.get_insert_position(bn_op)

        scale_offset, no_weight_flag = \
            InsertRetrainSearchNPass.get_scale_offset([bn_pattern.quantized_op])

        scale_w_length = 1
        for dim in scale_offset[2].shape:
            scale_w_length *= int(dim)

        # get the parameter information of BN
        bn_param = InsertRetrainSearchNPass.get_small_bn_param(
            bn_pattern.op_list, bn_pattern.output_dict, scale_w_length)

        # insert the searchn operator of retrain
        op_list = [[bn_pattern.quantized_op], bn_op, insert_op, self.output_nodes]
        record_param = [scale_offset, bn_param]
        self.quant_config['no_weight_flag'] = no_weight_flag
        self.context_num = InsertRetrainSearchNPass.insert_record_and_search_n(
            op_list, record_param, scale_w_length, self.quant_config,
            self.context_num)
        return [], []
