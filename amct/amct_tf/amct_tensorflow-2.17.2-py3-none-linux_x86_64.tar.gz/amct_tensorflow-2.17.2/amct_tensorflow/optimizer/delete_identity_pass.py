#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Remove the useless identity node from the graph.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.optimizer.bn_fusion_utils import is_tail_layer
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.lib.load_custom_op import load

from amct_tensorflow.utils.utils_vars import DELETE_IDENTITY
from amct_tensorflow.utils.log import LOGGER

_CUSTOM_OP = load()

__all__ = ['DeleteIdentityPass']


class DeleteIdentityPass(BaseFusionPass):
    """
    Function: Remove the useless identity node from the graph.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, outputs=None):
        """
        Function: init DeleteIdentityPass object
        Inputs: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self._outputs = outputs

    def match_pattern(self, operation):
        """
        Function: Matches the identity operation that can be deleted.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if self._outputs and operation.name in self._outputs:
            return False
        if not is_tail_layer(operation) and \
            operation.type == 'Identity' and \
            len(operation.control_inputs) == 0:
            upper_operation = operation
            while upper_operation.type == 'Identity':
                upper_operation = upper_operation.inputs[0].op
            if upper_operation.type in DELETE_IDENTITY:
                return True
        return False

    def do_pass(self, object_op):
        """
        Function: Delete the useless identity node from the graph.
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        object_op_in = object_op.inputs[0]
        object_op_out = object_op.outputs[0]
        consumers_object_op_out = object_op_out.consumers()

        replace_inputs_tensor(object_op_in, object_op_out,
                              consumers_object_op_out)

        replace_inputs_tensor(
            tf.compat.v1.placeholder(
                object_op.inputs[0].dtype),
            object_op.inputs[0], [object_op])

        LOGGER.push_debug_message(
            "doing layer: delete identity op[%s]!" % object_op.name,
            "DeleteIdentityPass")

        return [], []
