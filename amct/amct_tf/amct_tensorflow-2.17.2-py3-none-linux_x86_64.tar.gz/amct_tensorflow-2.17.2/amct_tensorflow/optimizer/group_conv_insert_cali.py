#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert weight calibration and act calibration op for group_conv.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.optimizer.insert_arq_pass import InsertARQPass
from amct_tensorflow.optimizer.insert_act_cali_pass import InsertActCaliPass
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.utils import quant_ops
from amct_tensorflow.pattern.match_group_conv import pattern_group_conv
from amct_tensorflow.pattern.match_group_conv import GROUP_CONV_SPLIT
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.common.utils import vars_util
from amct_tensorflow.utils.utils_vars import ACT_CALI
from amct_tensorflow.utils.utils_vars import WTS_CALI
from amct_tensorflow.utils.utils_vars import SEARCH_N
_CUSTOM_OP = load()

__all__ = ['GroupConvInsertCaliPass']


class GroupConvInsertCaliPass(BaseFusionPass):
    """
    Function: Insert quant_arq op for quantized layer.
    APIs: match_pattern, do_pass,
    """

    def __init__(self, quant_config=None, skip_layers=None, dump_config=None, mode='cali_dump', on_ascend=False,
                 outputs=None, weight_fakequant=True):
        """
        Function: init object of GroupConvInsertCaliPass
        Inputs:
            quant_config: a dictionary containing quant config
            skip_layers: a dict, containing skip quantize layers
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.quant_config = {} if quant_config is None else quant_config
        self.skip_layers = {ACT_CALI: [], WTS_CALI: [], SEARCH_N: []} if skip_layers is None else skip_layers
        self.dump_config = {} if dump_config is None else dump_config
        self.mode = mode
        self.on_ascend = on_ascend
        self.outputs = outputs
        self.ifmr_res = {
            'scales_d': [],
            'offsets_d': [],
            'activation_layers_name': [],
            'record_file': self.quant_config.get('record_file')
        }
        self.weight_fakequant = weight_fakequant
        self.output_op = None
        self.structure = {}

    def match_pattern(self, operation):
        """
        Function: Match quantizable operation to be quantized.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        # Find the split operation
        if operation.type not in GROUP_CONV_SPLIT:
            return False
        # match the group_conv structure
        group_conv = pattern_group_conv(operation)
        if group_conv is None:
            return False
        # check the act quant parameter is same for conv nodes
        enable_cali, _ = group_conv.check_cali(self.quant_config)
        if not enable_cali:
            return False
        self.structure[operation.name] = group_conv
        self.skip_layers.get(WTS_CALI).extend(group_conv.get_name('conv_names'))
        self.skip_layers.get(ACT_CALI).extend(group_conv.get_name('conv_names'))
        return True

    def supplement_pass(self):
        """
        Function: supplement graph modify after do_pass
        Inputs: None
        Return: None
        """
        if not self.on_ascend:
            return

        InsertActCaliPass.add_record_op(self.graph, self.outputs, self.ifmr_res)

    def do_pass(self, object_op):
        """
        Function: Insert arq, ifmr and search_n for union_ops in object_op's
            pattern
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing tensor need to be run to get value
        """
        group_conv = self.structure.get(object_op.name)

        LOGGER.push_debug_message('doing group_conv:%s insert quant' %
                                  group_conv.get_name('name'),
                                  'GroupConvInsertCaliPass')
        # insert act quant
        for conv_name in group_conv.get_name('conv_names'):
            LOGGER.push_info_message('doing layer:%s insert act_quant' %
                                     conv_name, 'GroupConvInsertCaliPass')

        split_op = group_conv.get_split()
        # dump is necessary
        if 'dump' in self.mode and self.dump_config:
            if self.dump_config.batch_num is None:
                self.dump_config.batch_num = self.quant_config.get('batch_num')
            InsertActCaliPass.dump(split_op, 1, self.dump_config)
        if 'cali' not in self.mode:
            return [], []
        inputs = split_op.inputs[1]
        quant_kwargs = group_conv.get_quant_info('act_config')
        quant_kwargs['quant_op_names'] = group_conv.get_name('conv_names')
        quant_kwargs['record_file_name'] = self.quant_config.get('record_file')
        quant_kwargs['num_bits'] = self.quant_config.get('num_bits', vars_util.INT8_BIT)
        if quant_kwargs.get('asymmetric') is None:
            need_offset = self.quant_config.get('activation_offset')
        else:
            need_offset = quant_kwargs['asymmetric']
        quant_kwargs['need_offset'] = need_offset
        quant_kwargs['batch_num'] = self.quant_config.get('batch_num')

        outputs, quant_factors = quant_ops.quant_calibration(
            [inputs, [inputs]], split_op.name,
            'activation_ascend' if self.on_ascend else 'activation',
            quant_kwargs, 'Conv2D')
        # relink outputs
        if not self.on_ascend:
            quant_ops.relink_tensor(inputs, outputs[0], split_op)
        else:
            self.ifmr_res.get('scales_d').append(quant_factors.get('scale_d'))
            self.ifmr_res.get('offsets_d').append(
                tf.compat.v1.cast(quant_factors.get('offset_d'), tf.compat.v1.int32))
            self.ifmr_res.get('activation_layers_name').append(
                quant_kwargs.get('quant_op_names'))

        # insert weight quant
        assign_lists = []
        run_lists = []
        for conv in group_conv.get_convs():
            LOGGER.push_info_message('doing layer:%s insert weight_quant' %
                                     conv.name,
                                     'GroupConvInsertCaliPass')
            assign_list, run_list = InsertARQPass.insert_arq_single_op(
                conv, self.quant_config, self.on_ascend, self.weight_fakequant)
            assign_lists.extend(assign_list)
            run_lists.extend(run_list)

        return assign_lists, run_lists
