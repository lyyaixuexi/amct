#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert Quant for quantizable layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401
import numpy as np

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.utils.quant_ops import create_context
from amct_tensorflow.utils.utils_vars import QUANTIZABLE_TYPES
from amct_tensorflow.utils.utils_vars import TENSOR_QUANTIZABLE_TYPES
from amct_tensorflow.utils.utils_vars import DUAL_ACTIVATION_QUANT_TYPES
from amct_tensorflow.utils.log import LOGGER

_CUSTOM_OP = load()

__all__ = ['InsertQuantPass', 'insert_quant']


class InsertQuantPass(BaseFusionPass):
    """
    Function: Insert Quant for quantized layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, records=None):
        """
        Function: init object
        Inputs:
            records: a dictionary containing quant factors
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records
        for key in list(self.records.keys()):
            if ':' in key:
                node_name, input_index = key.split(':')
                self.records[node_name] = self.records[key]
                self.records[node_name]['tensor_quantize'] = True
                self.records[node_name]['act_index'] = int(input_index)

    def match_pattern(self, operation):
        """
        Function: Match quantizable operation to be quantized.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type in QUANTIZABLE_TYPES + TENSOR_QUANTIZABLE_TYPES \
            and operation.name in self.records:
            return True
        return False

    def do_pass(self, object_op):
        """
        Function: Insert Quant(for act) before object_op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        is_tensor_quantize = self.records.get(object_op.name).get('tensor_quantize')
        is_two_activation_quant = object_op.type in DUAL_ACTIVATION_QUANT_TYPES
        scale_value = self.records.get(object_op.name).get('data_scale')
        offset_value = self.records.get(object_op.name).get('data_offset')
        num_bits = self.get_dst_type(object_op.name)
        # insert act_quant
        quantized_op_name = object_op.name
        if is_tensor_quantize:
            act_index = self.records.get(object_op.name).get('act_index')
        else:
            act_index, _ = QuantOpInfo.get_quant_index(object_op)

        if not is_tensor_quantize and not object_op.type == 'AvgPool' \
            and object_op.inputs[act_index].op.type == 'Pad' \
            and len(object_op.inputs[act_index].op.outputs[0].consumers()) == 1:
            object_op = object_op.inputs[act_index].op
            act_index = 0
        insert_quant(object_op, act_index, quantized_op_name,
                        [scale_value, offset_value], num_bits)
        if is_tensor_quantize:
            insert_antiquant(object_op, act_index, quantized_op_name,
                                   [scale_value, offset_value])
        if is_two_activation_quant:
            # add quant op for inputs[1]
            scale_value = self.records.get(object_op.name).get('weight_scale')
            offset_value = self.records.get(object_op.name).get('weight_offset')
            act_index = 1
            if not is_tensor_quantize and object_op.inputs[act_index].op.type == 'Pad' \
                and len(object_op.inputs[act_index].op.outputs[0].consumers()) == 1:
                object_op = object_op.inputs[act_index].op
                act_index = 0
            insert_quant(object_op, act_index, quantized_op_name,
                        [scale_value, offset_value], num_bits)

        LOGGER.push_debug_message(
            "finish inserting Quant for %s" % (object_op.name),
            "InsertQuantPass")

        return [], []


def insert_quant(object_op, act_index, quantized_op_name, scale_offset_value,
                 num_bits):
    """
    Function: insert Quant(act) for quantized_op
    Inputs:
        object_op: an op, the op to be insert quant
        act_index: a number, the act's index in object_op's inputs
        quantized_op_name: the name of quantized op
        scale_offset_value: a list of np.array, the act's scale and the act's
            offset
        num_bits: a number, quant bits
    Returns: None
    """
    layer_context, _ = split_name_scope(object_op.name)
    context = create_context(layer_context, quant_type='activation')

    data_in_op = object_op.inputs[act_index].op
    data_in_index = object_op.inputs[act_index].value_index
    data = data_in_op.outputs[data_in_index]

    with tf.compat.v1.variable_scope(
            None, ''.join([context, '_temp']), [data]):
        act_quant = _CUSTOM_OP.quant(data,
                                     scale=1.0 / scale_offset_value[0],
                                     offset=scale_offset_value[1],
                                     layer_name=quantized_op_name,
                                     quant_bits=num_bits)

    replace_inputs_tensor(act_quant, object_op.inputs[act_index],
                          [object_op])


def insert_antiquant(object_op, act_index, quantized_op_name, scale_offset_value,):
    """
    Function: insert anti-Quant(act) for quantized_op
    Inputs:
        object_op: an op, the op to be insert quant
        act_index: a number, the act's index in object_op's inputs
        quantized_op_name: the name of quantized op
        scale_offset_value: a list of np.array, the act's scale and the act's
            offset
    Returns: None
    """
    layer_context, _ = split_name_scope(object_op.name)
    context = create_context(layer_context, quant_type='activation')

    data_in_op = object_op.inputs[act_index].op
    data_in_index = object_op.inputs[act_index].value_index
    data = data_in_op.outputs[data_in_index]
    with tf.compat.v1.variable_scope(None, ''.join([context, '_temp_antiquant']), [data]):
        # inser act_antiquant
        act_anti_quant = _CUSTOM_OP.anti_quant(
            data,
            scale=scale_offset_value[0].astype(np.float),
            offset=-scale_offset_value[1].astype(np.int32),
            layer_name=quantized_op_name)

    replace_inputs_tensor(act_anti_quant, object_op.inputs[act_index],
                          [object_op])
