#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Adjust group_conv's Quant and Dequant. Quant is placed before Split and
Dequant is placed after Concat.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import numpy as np
import tensorflow as tf

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.optimizer.insert_dequant_pass import insert_dequant
from amct_tensorflow.optimizer.insert_quant_pass import insert_quant
from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.pattern.match_group_conv import construct_group_conv
from amct_tensorflow.pattern.match_group_conv import find_concat_in
from amct_tensorflow.pattern.match_group_conv import GROUP_CONV_SPLIT
from amct_tensorflow.lib.load_custom_op import load

from amct_tensorflow.utils.log import LOGGER

_CUSTOM_OP = load()

__all__ = ['AdjustGroupConvPass']


class AdjustGroupConvPass(BaseFusionPass):
    """
    Function: Adjust group_conv's Quant and Dequant. Quant is placed before
        Split and Dequant is placed after Concat.
    APIS: match_pattern, do_pass
    """
    def __init__(self, records=None, outputs=None):
        """
        Function: init object
        Inputs:
            records: a dict containing the quant factors parsed from
                record file.
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.structure = dict()

        if outputs is None:
            self.outputs = list()
        else:
            self.outputs = outputs
        if not outputs:
            raise RuntimeError("param 'outputs' cannot be empty for dequant "
                               "may change the outputs of graph.")

        if records is None:
            self.records = dict()
        else:
            self.records = records

    def match_pattern(self, operation):
        """
        Function: Match pattern of "group_conv" with "Quant + Dequant"
            in branch. if matched, operation is split of group_conv.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type in GROUP_CONV_SPLIT:
            group_conv = pattern_group_conv_quant(operation)
            if group_conv:
                enable_save, _ = group_conv.check_save(self.records)
                if enable_save:
                    self.structure[operation.name] = {'group_conv': group_conv}
                    return True
        return False

    def do_pass(self, object_op):
        """
        Function: Adjust 'Quant' to split and 'Dequant' to concat.
        Inputs:
            object_node: node to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """

        group_conv = self.structure.get(object_op.name).get('group_conv')
        # Step1: delete 'Quant' befor each conv
        _delete_group_conv_quant(object_op)
        LOGGER.push_debug_message('delate Quant ops before convs',
                                  'AdjustGroupConvPass')

        # Step2: add 'Quant' before split
        group_conv_quant_params = group_conv.get_quant_info('act_factor')
        act_index = 1

        num_bits = self.get_dst_type(group_conv.names['conv_names'][0])

        insert_quant(object_op, act_index, object_op.name, [
            group_conv_quant_params.get('data_scale'),
            group_conv_quant_params.get('data_offset')
        ], num_bits)
        self.records[object_op.name] = dict()
        self.records[object_op.name]['data_scale'] = group_conv_quant_params.get('data_scale')
        self.records[object_op.name]['data_offset'] = group_conv_quant_params.get('data_offset')
        LOGGER.push_debug_message('Insert Quant op before split',
                                  'AdjustGroupConvPass')

        # Step3: delete 'Dequant' after each conv
        _delete_group_conv_dequant(group_conv)
        LOGGER.push_debug_message('delate Dequant ops after convs',
                                  'AdjustGroupConvPass')

        # Step4: add 'Dequant' after concat
        # uniform convs' scale_w, offset_w, n to be channel_wise.
        uniform_quant_factors(group_conv, self.records)
        # concat convs' paramters
        quant_param, quant_value = self.concat_conv_param(group_conv, num_bits)
        # insert dequant operation
        concat_op = group_conv.get_concat()
        deq_quant = insert_dequant(concat_op, concat_op, 0, quant_value,
                                   quant_param)

        # update outputs if object_op in outputs
        if concat_op.name in self.outputs:
            index = self.outputs.index(concat_op.name)
            self.outputs[index] = deq_quant.op.name

        LOGGER.push_debug_message('Insert Dequant op after concat',
                                  'AdjustGroupConvPass')

        return [], []

    def concat_conv_param(self, group_conv, num_bits):
        '''concat convs' paramters'''
        dq_shape = group_conv.get_attr('reshape_dims')
        concat_dim = group_conv.get_attr('concat_dim')
        concat_weight_scale, concat_shif_n, concat_weight_offset = \
            concat_group_conv_quant_factors(
                group_conv, self.records, concat_dim)
        quant_param = collections.OrderedDict()
        quant_param['num_bits'] = num_bits
        quant_param['dq_shape'] = dq_shape
        quant_value = collections.OrderedDict()
        quant_value['act_scale_value'] = group_conv.get_quant_info(
            'act_factor').get('data_scale')
        quant_value['weight_scale_value'] = concat_weight_scale
        quant_value['weight_offset_value'] = concat_weight_offset
        quant_value['shift_n_value'] = concat_shif_n
        return quant_param, quant_value


def pattern_type_link(head_op, target_op_types, output_indexs):
    """
    Function: Find several ops whose link match target_op_types
        and output_indexs.
        target_op_types = [type1, type2, ..., typen]
        output_indexs = [index1, index2, ..., indexn]
        target_ops = [target_op1, target_op2, ..., target_opn]
        target_op1's type is type1, target_op2's type is type2, and so on.
        head_op.outputs[index1] has one consumer target_op1,
        target_op1.outputs[index2] has one consumer target_op2, and so on.
        if output_indexs = [1, 2, 0, 0], find the op as follows
                head_op
                /  |  \
                  op1
                /  |  \
                      op2
                      /  \
                     op3
                      |
                    op4
    Returns:
        target_ops: a list containing the ops match pattern. List is empty
            if doesn't find matched pattern.
    """
    def consumer_target(tensor, target_type):
        '''Find only consumer matching target_type. '''
        if len(tensor.consumers()) != 1:
            return None
        post_op = tensor.consumers()[0]
        if post_op.type != target_type:
            return None
        return post_op

    target_ops = list()
    current_op = head_op
    pattern_ok = True
    for index, target_op_type in enumerate(target_op_types):
        output_index = output_indexs[index]
        next_op = consumer_target(current_op.outputs[output_index],
                                  target_op_type)
        if next_op is None:
            pattern_ok = False
            break
        current_op = next_op
        target_ops.append(next_op)

    if pattern_ok:
        return target_ops

    return []


def pattern_group_conv_quant(split_op):
    """
    Function: find a group_conv with quant behaviours.
        patterns are as follows:
                split                          split
                /   \\                         /   \
            Quant   Quant                  Quant   Quant
              |       |                      |       |
             conv   conv                    conv   conv
              |       |                      |       |
          biasadd   biasadd              Dequant   Dequant
              |       |                       \\     /
          Dequant   Dequant                    concat
               \\    /
                concat
    Returns:
        group_conv: return an object of GroupConv if find, otherwise
            return None.
    """
    def _update_global_concat_op(global_concat_op, target_ops):
        if not target_ops:
            global_concat_op = None
            return global_concat_op
        if global_concat_op:
            if global_concat_op.name != target_ops[-1].name:
                global_concat_op = None
        else:
            global_concat_op = target_ops[-1]
        return global_concat_op

    def _find_group_conv_quant(split_op, has_bias, concat_type, conv_type):
        ''' find a group_conv with Quant and Dequant in branch. '''
        group_size = len(split_op.outputs)
        if has_bias:
            # conv + bias_add + quant behaviours
            target_op_types = [
                'Quant', conv_type, 'BiasAdd', 'DeqQuant', concat_type
            ]
            output_indexs = [0, 0, 0, 0, 0]
        else:
            # conv + quant behaviours
            target_op_types = ['Quant', conv_type, 'DeqQuant', concat_type]
            output_indexs = [0, 0, 0, 0]

        conv_names = list()
        bias_names = list()
        global_concat_op = None
        for output_index in range(group_size):
            output_indexs[0] = output_index
            target_ops = pattern_type_link(split_op, target_op_types,
                                           output_indexs)
            global_concat_op = _update_global_concat_op(
                global_concat_op, target_ops)
            if global_concat_op is None:
                break
            conv_names.append(target_ops[1].name)
            if has_bias:
                bias_names.append(target_ops[2].name)

        if global_concat_op:
            try:
                group_conv = construct_group_conv(split_op, conv_names,
                                                  bias_names,
                                                  global_concat_op.name, None)
                return group_conv
            except RuntimeError:
                return None
        return None

    kwargs_types = {'1': {'has_bias': False, 'concat_type': 'ConcatV2', 'conv_type': 'Conv2D'},
                    '2': {'has_bias': True, 'concat_type': 'ConcatV2', 'conv_type': 'Conv2D'},
                    '3': {'has_bias': False, 'concat_type': 'Concat', 'conv_type': 'Conv2D'},
                    '4': {'has_bias': True, 'concat_type': 'Concat', 'conv_type': 'Conv2D'},
                    '5': {'has_bias': False, 'concat_type': 'ConcatV2', 'conv_type': 'Conv3D'},
                    '6': {'has_bias': True, 'concat_type': 'ConcatV2', 'conv_type': 'Conv3D'},
                    '7': {'has_bias': False, 'concat_type': 'Concat', 'conv_type': 'Conv3D'},
                    '8': {'has_bias': True, 'concat_type': 'Concat', 'conv_type': 'Conv3D'}}
    for key in kwargs_types:
        group_conv = _find_group_conv_quant(split_op, **kwargs_types[key])
        if group_conv:
            return group_conv
    return group_conv


def uniform_quant_factors(group_conv, quant_factors):
    """
    Function: uniform quant_factors(scale_w, offset_w, n) of each conv in
        group_conv to be channel_wise.
    Inputs:
        group_conv: an object of GroupConv
        quant_factors: a dict containing the quant factors parsered from
    Returns: None
    """
    def _uniform_conv_quant_factors(conv, layer_factors):
        ''' uniform conv's scale, offset, n to be channel_wise. '''
        scale_array = layer_factors.get('weight_scale')
        offset_array = layer_factors.get('weight_offset')
        shift_n_array = layer_factors.get('shift_n')
        if not scale_array.shape:
            scale_shape, scale_length = QuantOpInfo.get_scale_shape(
                conv.inputs[1], True, conv.type)
            scale_array = scale_array.repeat(scale_length).reshape(scale_shape)
            offset_array = offset_array.repeat(scale_length).reshape(
                scale_shape)
            shift_n_array = shift_n_array.repeat(scale_length).reshape(
                scale_shape)
            layer_factors['weight_scale'] = scale_array
            layer_factors['weight_offset'] = offset_array
            layer_factors['shift_n'] = shift_n_array

        return scale_array, offset_array

    for conv in group_conv.get_convs():
        _uniform_conv_quant_factors(conv, quant_factors.get(conv.name))


def concat_group_conv_quant_factors(group_conv, quant_factors, concat_dim):
    """
    Function: concat convs' quant_factors to be group_conv's quant_factors.
        only weight_scale and shift_n are needed to be concated.
    Inputs:
        group_conv: an object of GroupConv
        quant_factors: a dictionary containing all quant factors
        concat_dim: a number, dimision to cancat weight in 'C'
    Returns:
        concat_weight_scale: np.array, concated weight_scale
        concat_shif_n: np.array, concated shif_n.
    """
    concat_weight_scale = None
    concat_shif_n = None
    concat_weight_offset = None
    for conv_name in group_conv.get_name('conv_names'):
        if concat_weight_scale is None:
            concat_weight_scale = quant_factors.get(conv_name).get(
                'weight_scale')
        else:
            concat_weight_scale = np.concatenate(
                (concat_weight_scale,
                 quant_factors.get(conv_name).get('weight_scale')),
                axis=concat_dim)
        if concat_shif_n is None:
            concat_shif_n = quant_factors.get(conv_name).get('shift_n')
        else:
            concat_shif_n = np.concatenate(
                (concat_shif_n, quant_factors.get(conv_name).get('shift_n')),
                axis=concat_dim)
        if concat_weight_offset is None:
            concat_weight_offset = quant_factors.get(conv_name).get(
                'weight_offset')
        else:
            concat_weight_offset = np.concatenate(
                (concat_weight_offset,
                 quant_factors.get(conv_name).get('weight_offset')),
                axis=concat_dim)

    return concat_weight_scale, concat_shif_n, concat_weight_offset


def _delete_group_conv_quant(split_op):
    ''' delete group_conv's 'Quant' before convs. '''
    for quant_in in split_op.outputs:
        quant_op = quant_in.consumers()[0]
        quant_out = quant_op.outputs[0]
        conv = quant_out.consumers()[0]
        replace_inputs_tensor(quant_in, quant_out, [conv])
        replace_inputs_tensor(tf.compat.v1.placeholder(quant_in.dtype), quant_in, [quant_op])


def _delete_group_conv_dequant(group_conv):
    ''' delete group_conv's 'Dequant' after convs. '''
    concat_op = group_conv.get_concat()
    group_size = group_conv.group_size
    for index in range(group_size):
        dequant_out = find_concat_in(concat_op, index)
        dequant_op = dequant_out.op
        dequant_in = dequant_op.inputs[0]
        replace_inputs_tensor(dequant_in, dequant_out, [concat_op])
        replace_inputs_tensor(tf.compat.v1.placeholder(dequant_in.dtype), dequant_in, [dequant_op])
