#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Delete FakeQuantWithMinMaxVars, FakeQuantWithMinMaxVarsPerChannel and
bypass nodes in graph.
"""


from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from collections import namedtuple
import numpy as np
import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.common.utils import vars_util
from amct_tensorflow.configuration.get_layers import OpSelector
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.optimizer.base_fusion_pass import extract_graph_def_from_sess
from amct_tensorflow.utils.graph_utils import GraphUtils
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.utils.quant_ops import create_context
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.utils_vars import CHANNEL_WISE_TYPES
from amct_tensorflow.utils.utils_vars import CONVERT_QAT_QUANTIZABLE_TYPES


_CUSTOM_OP = load()

BYPASS_NODE = ['Identity', 'MaxPool', 'Pad', 'Reshape', 'Transpose']
ACT_INDEX = 0
WEIGHT_INDEX = 1
NEED_WEIGHT_FOLD = 10

Consumers = namedtuple('Consumers', ['act_replace', 'weight_fold', 'act_quant', 'weight_quant'])


class DeleteFakeQuantPass(BaseFusionPass): # pylint: disable=R0902
    """
    Delete FakeQuantWithMinMaxVars,
    FakeQuantWithMinMaxVarsPerChannel and bypass nodes.

    Args:
        records_helper (ScaleOffsetRecordHelper): record helper.
        graph (tf.compat.v1.Graph): a TensorFlow graph.
        outputs (list): a list of output nodes name.
        replace (bool): whether to replace fake quantized node with
        a quantized anti-quantized node pair.
    """
    def __init__(self, records_helper, outputs, replace=False):
        BaseFusionPass.__init__(self)
        self.record_helper = records_helper
        self.outputs = outputs
        self.replace = replace
        self.quantized_op = dict()

    @staticmethod
    def _check_scale(scale: np.ndarray):
        eps = np.finfo(np.float32).eps
        scale = np.where(scale < eps, 1, scale)

        if (scale == np.inf).any():
            LOGGER.push_error_message('Cannot support scale is INF!', 'DeleteFakeQuantPass')
            raise ValueError('Cannot support scale is INF!')

        if (1 / scale <= eps).any():
            LOGGER.push_error_message('Cannot support scale greater than 1/{}!'.format(eps), 'DeleteFakeQuantPass')
            raise ValueError('Cannot support scale greater than 1/{}!'.format(eps))

        return scale

    def set_up(self, graph): # pylint: disable=W0221
        self.graph = graph
        self.convert_qat_quantable_layers = OpSelector.get_support_convert_layers(graph) # pylint: disable=W0201

    def tear_down(self):
        for consumer, bypass_list in self.quantized_op.items():
            if len(bypass_list) == 1:
                bypass_ops = bypass_list[0]
                if GraphChecker.get_dependency_with_placeholder(bypass_ops[0]):
                    if self.replace:
                        self._replace_fake_quant_op(bypass_ops)
                    else:
                        self._delete_fake_quant_op(bypass_ops)
                        LOGGER.push_warning_message(
                            'Deleting operation "{}" directly may result in abnormal accuracy!'.format(
                                bypass_ops[0].name), 'DeleteFakeQuantPass')
                else:
                    self._fold_weight_fake_quant_op(bypass_ops)

                self.record_helper.delete_key(consumer.name)
            else:
                for bypass_ops in bypass_list:
                    self._delete_fake_quant_op(bypass_ops)

        for operation in self.graph.get_operations():
            if operation.type in ['FakeQuantWithMinMaxVars', 'FakeQuantWithMinMaxVarsPerChannel']:
                with self.graph.as_default():
                    placeholder = tf.compat.v1.placeholder(operation.inputs[0].dtype)
                    replace_inputs_tensor(placeholder, operation.inputs[0], [operation])

        for key in self.record_helper.keys:
            if not self.record_helper.check_record(key, self.record_helper.get_record(key)):
                self.record_helper.delete_key(key)

    def match_pattern(self, operation):
        if operation.type in ['FakeQuantWithMinMaxVars', 'FakeQuantWithMinMaxVarsPerChannel']:
            if operation.get_attr('num_bits') != 8:
                LOGGER.push_error_message(
                    'Cannot convert operation "{}" with "num_bits" feature unequal to 8!'.format(operation.name),
                    'DeleteFakeQuantPass')
                raise RuntimeError(
                    'Cannot convert operation "{}" with "num_bits" feature unequal to 8!'.format(operation.name))
            return True
        return False

    def do_pass(self, object_op):
        consumers = self._find_consumers(object_op)

        for bypass_ops in consumers.act_replace:
            if self.replace:
                self._replace_fake_quant_op(bypass_ops)
            else:
                self._delete_fake_quant_op(bypass_ops)
                LOGGER.push_warning_message(
                    'Deleting operation "{}" directly may result in abnormal accuracy!'.format(object_op.name),
                    'DeleteFakeQuantPass')

        for bypass_ops in consumers.weight_fold:
            self._fold_weight_fake_quant_op(bypass_ops)

        for bypass_ops in consumers.act_quant:
            consumer = bypass_ops[-1]
            scale_d, offset_d = self._calculate_quantize_factor(object_op, True)
            self.record_helper.record_activation_scale_offset(consumer.name, scale_d[0], offset_d[0])
            if consumer.type == 'AvgPool':
                self._delete_fake_quant_op(bypass_ops)
            else:
                if consumer in self.quantized_op:
                    self.quantized_op[consumer].append(bypass_ops)
                else:
                    self.quantized_op[consumer] = [bypass_ops]

        for bypass_ops in consumers.weight_quant:
            consumer = bypass_ops[-1]
            scale_w, offset_w = self._calculate_quantize_factor(object_op)
            self.record_helper.record_weights_scale_offset(consumer.name, scale_w, offset_w)
            if consumer in self.quantized_op:
                self.quantized_op[consumer].append(bypass_ops)
            else:
                self.quantized_op[consumer] = [bypass_ops]

        return [], []

    def run(self, graph):
        self.set_up(graph)

        matched_operations = []
        for operation in graph.get_operations():
            if self.match_pattern(operation):
                matched_operations.append(operation)

        with graph.as_default():
            for _, operation in enumerate(matched_operations):
                self.do_pass(operation)

        self.tear_down()

        with tf.compat.v1.Session(config=tf.compat.v1.ConfigProto(allow_soft_placement=True), graph=graph) as sess:
            graph_def = extract_graph_def_from_sess(sess, self.outputs)

        graph = tf.compat.v1.Graph()
        with graph.as_default():
            GraphUtils.handle_graph_def(graph_def)
            tf.compat.v1.import_graph_def(graph_def, name='')

        return graph, matched_operations

    def _find_consumers(self, operation):
        act_replace = list()
        weight_fold = list()
        act_quant = list()
        weight_quant = list()

        consumers = operation.outputs[0].consumers()
        bypass_dict = dict(zip(consumers, [[operation]] * len(consumers)))

        while bypass_dict:
            consumer, bypass_ops = bypass_dict.popitem()
            bypass_ops = bypass_ops.copy()
            bypass_ops.append(consumer)

            if consumer.type not in CHANNEL_WISE_TYPES and operation.type == 'FakeQuantWithMinMaxVarsPerChannel':
                LOGGER.push_error_message(
                    'Cannot convert operation "{}" because operation "{}" has per-channel feature!'.format(
                        operation.name, consumer.name), 'DeleteFakeQuantPass')
                raise RuntimeError(
                    'Cannot convert operation "{}" because operation "{}" has per-channel feature!'.format(
                        operation.name, consumer.name))

            if consumer.type in BYPASS_NODE:
                grand_consumers = consumer.outputs[0].consumers()
                if not grand_consumers:
                    if GraphChecker.get_dependency_with_placeholder(operation):
                        act_replace.append(bypass_ops)
                    else:
                        weight_fold.append(bypass_ops)
                    continue
                for grand_consumer in grand_consumers:
                    bypass_dict[grand_consumer] = bypass_ops

            elif consumer.type in CONVERT_QAT_QUANTIZABLE_TYPES:
                act_bypass, weight_bypass = self._quantable_bypass_nodes(bypass_ops, act_replace, weight_fold)
                if act_bypass:
                    act_quant.append(act_bypass)
                if weight_bypass:
                    weight_quant.append(weight_bypass)

            else:
                if GraphChecker.get_dependency_with_placeholder(operation):
                    act_replace.append(bypass_ops)
                else:
                    weight_fold.append(bypass_ops)

        return Consumers._make([act_replace, weight_fold, act_quant, weight_quant])

    def _quantable_bypass_nodes(self, bypass_ops, act_replace, weight_fold):
        act_quant = list()
        weight_quant = list()

        if bypass_ops[-1].name not in self.convert_qat_quantable_layers:
            if GraphChecker.get_dependency_with_placeholder(bypass_ops[0]):
                act_replace.append(bypass_ops)
            else:
                weight_fold.append(bypass_ops)
            return act_quant, weight_quant

        index = None
        output_tensor = bypass_ops[-2].outputs[0]
        for index, input_tensor in enumerate(bypass_ops[-1].inputs):
            if input_tensor is output_tensor:
                break

        if (index == ACT_INDEX and bypass_ops[-1].type != 'Conv2DBackpropInput') \
            or (index == 2 and bypass_ops[-1].type == 'Conv2DBackpropInput'):

            if bypass_ops[0].type == 'FakeQuantWithMinMaxVarsPerChannel':
                LOGGER.push_error_message(
                    'Cannot convert operation "{}" because operation "{}" has per-channel feature!'.format(
                        bypass_ops[0].name, bypass_ops[-1].name), 'DeleteFakeQuantPass')
                raise RuntimeError(
                    'Cannot convert operation "{}" because operation "{}" has per-channel feature!'.format(
                        bypass_ops[0].name, bypass_ops[-1].name))

            act_quant.extend(bypass_ops)

        elif index == WEIGHT_INDEX:
            if GraphChecker.get_dependency_with_placeholder(bypass_ops[0]):
                act_replace.append(bypass_ops)
            else:
                weight_quant.extend(bypass_ops)

        return act_quant, weight_quant

    def _calculate_quantize_factor(self, fake_quant_op, with_offset=False):
        min_tensor = fake_quant_op.inputs[1]
        max_tensor = fake_quant_op.inputs[2]
        session = tf.compat.v1.Session(graph=self.graph)
        min_value = min_tensor.eval(session=session)
        max_value = max_tensor.eval(session=session)
        session.close()

        if with_offset:
            min_value = np.where(min_value <= 0, min_value, 0)
            max_value = np.where(max_value >= 0, max_value, 0)

            if fake_quant_op.get_attr('narrow_range'):
                scale = (max_value - min_value) / 254
            else:
                scale = (max_value - min_value) / 255

            scale = self._check_scale(scale)
            offset = -128 - np.round(min_value / scale)
            offset = offset.astype(np.int32)
        else:
            abs_max_value = np.where(np.abs(max_value) > np.abs(min_value), max_value, min_value)

            if fake_quant_op.get_attr('narrow_range'):
                scale = np.abs(abs_max_value) / np.where(abs_max_value > 0, 127, 127)
            else:
                scale = np.abs(abs_max_value) / np.where(abs_max_value > 0, 127, 128)

            scale = self._check_scale(scale)
            offset = np.zeros(scale.shape, dtype=np.int32)
        scale = scale.tolist()
        offset = offset.tolist()
        if not isinstance(scale, list):
            scale = [scale]
        if not isinstance(offset, list):
            offset = [offset]
        return scale, offset

    def _fold_weight_fake_quant_op(self, bypass_ops):
        object_op = bypass_ops[0]
        weight_tensor = object_op.outputs[0]
        session = tf.compat.v1.Session(graph=self.graph)
        weight = weight_tensor.eval(session=session)
        session.close()
        with self.graph.as_default():
            new_tensor = tf.compat.v1.constant(weight)

        if weight_tensor.consumers():
            replace_inputs_tensor(new_tensor, weight_tensor, [bypass_ops[1]])

    def _delete_fake_quant_op(self, bypass_ops):
        object_op = bypass_ops[0]
        if object_op.name in self.outputs:
            index = self.outputs.index(object_op.name)
            del self.outputs[index]
            producer = object_op.inputs[0].op
            self.outputs.insert(index, producer.name)
        else:
            if object_op.outputs[0].consumers():
                replace_inputs_tensor(object_op.inputs[0], object_op.outputs[0], [bypass_ops[1]])

        LOGGER.push_debug_message('Delete operation "{}" successfully!'.format(object_op.name), 'DeleteFakeQuantPass')

    def _replace_fake_quant_op(self, bypass_ops):
        if bypass_ops[0].type == 'FakeQuantWithMinMaxVarsPerChannel':
            LOGGER.push_error_message(
                'Cannot convert operation "{}" because the type is "FakeQuantWithMinMaxVarsPerChannel"!'.format(
                    bypass_ops[0].name), 'DeleteFakeQuantPass')
            raise RuntimeError(
                'Cannot convert operation "{}" because the type is "FakeQuantWithMinMaxVarsPerChannel"!'.format(
                    bypass_ops[1].name))

        object_op = bypass_ops[0]
        name_scope, _ = split_name_scope(object_op.name)
        scale, offset = self._calculate_quantize_factor(object_op, True)
        context = create_context(name_scope, quant_type='activation')
        scale = scale[0]
        offset = offset[0]
        with tf.compat.v1.variable_scope(None, default_name=context, values=object_op.inputs):
            quant = _CUSTOM_OP.quant(
                object_op.inputs[0],
                scale=1.0 / scale,
                offset=np.array(offset).astype(np.float32),
                layer_name=object_op.name,
                quant_bits=vars_util.INT8_BIT)

        anti_context = create_context(name_scope, quant_type='anti')
        with tf.compat.v1.variable_scope(None, default_name=anti_context, values=object_op.inputs):
            anti_quant = _CUSTOM_OP.anti_quant(
                quant,
                scale=scale,
                offset=-np.array(offset).astype(np.float32),
                layer_name=object_op.name)

        if object_op.name in self.outputs:
            index = self.outputs.index(object_op.name)
            del self.outputs[index]
            self.outputs.insert(index, anti_quant.op.name)
        else:
            if object_op.outputs[0].consumers():
                replace_inputs_tensor(anti_quant, object_op.outputs[0], [bypass_ops[1]])

        LOGGER.push_debug_message('Replace operation "{}" successfully!'.format(object_op.name), 'DeleteFakeQuantPass')
        LOGGER.push_warning_message(
            'Replacing operation "{}" may result in abnormal accuracy!'.format(object_op.name), 'DeleteFakeQuantPass')
