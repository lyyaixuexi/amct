#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace DeqQuant to 'dequant ops' for quantized layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.utils_vars import OP_APPROXIMATION_TYPES
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.common.utils.files import find_dump_file
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.common.approximation.softmax_approximation import SoftmaxCalibrator
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils import quant_ops
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor


_CUSTOM_OP = load()

__all__ = ['ReplaceSoftmaxPass']


class ReplaceSoftmaxPass(BaseFusionPass):
    """
    Function: Replace Softmax to FastSoftmax to speed performance.
    APIs: match_pattern, do_pass
    """
    def __init__(self, approx_config, outputs):
        """
        Function: init object
        Inputs:
            approx_config: config for approximate
            outputs: a list of output node name
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.approx_config = approx_config
        self.outputs = outputs

    @staticmethod
    def _check_dump_data(dump_dir, prefix, batch_num):
        dump_files = find_dump_file(dump_dir, prefix)
        if len(dump_files) != batch_num:
            raise RuntimeError('The number of dumped data with prefix {} in dir {} is {}, '
                               'unequal to batch_num {}'.format(prefix, dump_dir, len(dump_files), batch_num))

    @staticmethod
    def _delete_dump_data(dump_op):
        dump_dir = dump_op.get_attr("dump_dir").decode()
        prefix = dump_op.get_attr("name_prefix").decode()
        if not LOGGER.is_file_debug_level():
            dump_files = find_dump_file(dump_dir, prefix)
            for file_name in dump_files:
                os.remove(file_name)
            if not os.listdir(dump_dir):
                os.rmdir(dump_dir)

    def match_pattern(self, operation):
        """
        Function: Match Softmax op.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type not in OP_APPROXIMATION_TYPES:
            return False
        if operation.name not in self.approx_config.keys():
            return False
        approx_kwagrs = self.approx_config.get(operation.name)
        if not approx_kwagrs['approximate_enable'] or \
            approx_kwagrs['approximate_algo'] != 'FastSoftmax':
            return False

        dump_op = operation.inputs[0].op
        if dump_op.type != 'Dump':
            return False

        return True

    def do_pass(self, object_op):
        """
        Function: Replace Softmax to FastSoftmax
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        # check dump data
        dump_op = object_op.inputs[0].op
        coef_a, coef_b, clip_value = self._get_approximate_coef(dump_op)

        layer_context, _ = split_name_scope(object_op.name)
        context = quant_ops.create_context(layer_context, 'fast_softmax')
        input_tensor = object_op.inputs[0]
        old_tensor = object_op.outputs[0]
        consumers = old_tensor.consumers()

        with tf.compat.v1.variable_scope(None,
                                         default_name=context,
                                         values=[input_tensor],
                                         reuse=None) as scope:
            scope.set_partitioner(None)
            new_tensor = _CUSTOM_OP.fast_softmax(input_tensor, a=coef_a, b=coef_b,
                                                 clip_value=clip_value)
        replace_inputs_tensor(new_tensor, old_tensor, consumers)

        # if softmax is output node, need to update outputs
        if len(consumers) == 0 and object_op.name in self.outputs:
            self.outputs[self.outputs.index(object_op.name)] = new_tensor.op.name

        self._delete_dump_data(dump_op)
        LOGGER.logi('doing layer:%s replace softmax' %
                     object_op.name, module_name='ReplaceSoftmaxPass')

        return [], []

    def _get_approximate_coef(self, dump_op):
        dump_dir = dump_op.get_attr("dump_dir").decode()
        prefix = dump_op.get_attr("name_prefix").decode()
        batch_num = dump_op.get_attr("batch_num")
        self._check_dump_data(dump_dir, prefix, batch_num)
        calibrator = SoftmaxCalibrator(dump_dir, prefix)
        coef_a, coef_b, clip_value = calibrator.calibrate()
        return coef_a, coef_b, clip_value
