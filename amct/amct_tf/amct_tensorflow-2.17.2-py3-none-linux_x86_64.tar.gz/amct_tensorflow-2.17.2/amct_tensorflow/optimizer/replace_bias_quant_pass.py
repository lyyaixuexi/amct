#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace BiasQuant to 'bias_quant ops' for quantized layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401
from tensorflow.python.ops import gen_control_flow_ops

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.utils.quant_ops import create_context
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_info_generator import QuantInfoGenerator
from amct_tensorflow.lib.load_custom_op import load

from amct_tensorflow.utils.log import LOGGER

_CUSTOM_OP = load()

__all__ = ['ReplaceBiasQuantPass']


class ReplaceBiasQuantPass(BaseFusionPass):
    """
    Function: Replace BiasQuant to 'bias_quant ops' for quantized layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, outputs=None):
        """
        Function: init object
        Inputs: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        if not outputs:
            raise RuntimeError("param 'outputs' cannot be empty for biasadd "
                               "to be quantized to int8.")
        self.outputs = outputs

    @staticmethod
    def check_bias_range(bias_quant, left_bound, right_bound, layer_name):
        """
        Function: check bias_quant's data range
        Inputs:
            bias_quant: a tensor that is data after bias quantization
            left_bound: a tensor with 0-D shape or the same shape as inputs.
                The minimum value for clipping.
            right_bound: a tensor with 0-D shape or the same shape as inputs.
                The maximum value for clipping.
            layer_name: a string that is the name of quant layer.
        Returns:
            op_list: a list containing the check ops.
        """
        greater_op = tf.compat.v1.debugging.assert_greater_equal(
            bias_quant, left_bound,
            message='Quantized bias of layer "{}" exceed int32 range: ' \
            '[{}, {}], please add it to skip layer.'.format(
                layer_name, left_bound, right_bound))
        less_op = tf.compat.v1.debugging.assert_less_equal(
            bias_quant, right_bound,
            message='Quantized bias of layer "{}" exceed int32 range: ' \
            '[{}, {}], please add it to skip layer.'.format(
                layer_name, left_bound, right_bound))
        return [greater_op, less_op]

    def match_pattern(self, operation):
        """
        Function: Match Quant op.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type == 'BiasQuant':
            return True
        return False

    def do_pass(self, object_op):
        """
        Function: Replace BiasQuant to 'bias_quant ops'
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        layer_name = str(object_op.get_attr('layer_name'), encoding='utf-8')
        context, _ = split_name_scope(layer_name)
        context = create_context(context, quant_type='bias')
        # inser bias_quant
        num_bits = object_op.get_attr('quant_bits')
        bias = object_op.inputs[0]
        # check if bias is in a while loop
        info_length, frame_name, is_constant, parallel_iterations = \
                GraphChecker.get_dependency_enter_info(bias.op)
        if info_length:
            bias = bias.op.inputs[0]
        deq_scale = object_op.inputs[1]
        quant_out = object_op.outputs[0]
        quant_consumers = quant_out.consumers()
        if quant_consumers[0].type == 'Cast':
            quant_out = quant_consumers[0].outputs[0]
            quant_consumers = quant_out.consumers()

        with tf.compat.v1.variable_scope(None,
                                         default_name=context,
                                         values=[bias]):
            deq_scale = tf.compat.v1.identity(deq_scale)
            bias = tf.compat.v1.cast(bias, tf.compat.v1.float32)
            bias_quant = tf.compat.v1.round(
                tf.compat.v1.divide(bias, deq_scale))
            # change the data_range
            check_ops = ReplaceBiasQuantPass.check_bias_range(
                bias_quant, -2.**(num_bits - 1), 2.**(num_bits - 1) - 1,
                layer_name)

            # store quantized weight in a variable
            with tf.compat.v1.control_dependencies(check_ops):
                bias_quant = tf.compat.v1.cast(bias_quant, tf.compat.v1.int32)
            bias_int = tf.compat.v1.get_variable(
                'bias_int',
                shape=bias_quant.shape,
                dtype=tf.compat.v1.int32,
                trainable=False,
                collections=[
                    tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                    tf.compat.v1.GraphKeys.MODEL_VARIABLES
                ],
                use_resource=False)
            assign_biasadd = tf.compat.v1.assign(bias_int, bias_quant)

            if info_length:
                bias_int = gen_control_flow_ops.enter(bias_int,
                                                    frame_name=frame_name,
                                                    is_constant=is_constant,
                                                    parallel_iterations=parallel_iterations)

            bias_float = tf.compat.v1.cast(bias_int, tf.compat.v1.float32)
        replace_inputs_tensor(bias_float, quant_out, quant_consumers)
        # Set dump anchor to compute op
        if not QuantInfoGenerator().has_fusion_info(layer_name):
            QuantInfoGenerator().set_fusion_anchor(
                layer_name, [layer_name])
        LOGGER.push_debug_message(
            "finish replacing BiasQuant for %s" %
            (object_op.get_attr('layer_name')), "ReplaceBiasQuantPass")

        return [assign_biasadd], []
