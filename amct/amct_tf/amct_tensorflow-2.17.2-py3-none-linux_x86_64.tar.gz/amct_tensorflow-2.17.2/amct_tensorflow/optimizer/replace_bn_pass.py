#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace bulk BN to Integrating BN for all layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from collections import namedtuple
import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.utils.quant_ops import create_context
from amct_tensorflow.pattern.match_pattern import PatternHelper
from amct_tensorflow.optimizer.bn_fusion_utils import is_tail_layer
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor

from amct_tensorflow.utils.utils_vars import ADD_TYPES
from amct_tensorflow.utils.utils_vars import PATTERN_CONFIG
from amct_tensorflow.utils.log import LOGGER

_CUSTOM_OP = load()

OpInfo = namedtuple('OpInfo', ['op_list', 'op_index', 'input_index', 'output_dict', 'epsilon', 'config_name'])

__all__ = ['ReplaceBNPass']


class ReplaceBNPass(BaseFusionPass):
    """
    Function: Replace bulk BN to Integrating BN for all layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, outputs=None):
        """
        Function: init ReplaceBNPass object
        Inputs:
            outputs: a list that is names of out ops
        Return: None
        """
        BaseFusionPass.__init__(self)
        if outputs is None:
            outputs = []
        self.outputs = outputs

    def match_pattern(self, operation):
        """
        Function: Matches the operation that can be replaced with bn..
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type in ADD_TYPES and operation.type != 'BiasAdd':
            for config_name, pattern_config in PATTERN_CONFIG.items():
                flag, _ = PatternHelper.match_pattern(operation,
                                                      pattern_config)
                if flag and 'training_false' in config_name:
                    return True
        return False

    def do_pass(self, object_op):
        """
        Function: Replace bulk BN to Integrating BN.
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        layer_context, _ = split_name_scope(object_op.name)
        context = create_context(layer_context, quant_type='replace_bn')

        # replace object_op node by replace_object_op node
        with tf.compat.v1.name_scope(context):
            op_info = _get_op_info(object_op)
            if not check_fusable(op_info.op_list[op_info.op_index].inputs[op_info.input_index].op):
                return [], []
            center = True
            if 'center_false' in op_info.config_name:
                center = False
            if 'nchw' in op_info.config_name or 'ncdhw' in op_info.config_name:
                bn_out = tf.compat.v1.layers.batch_normalization(
                    op_info.op_list[op_info.op_index].inputs[op_info.input_index],
                    axis=1,
                    epsilon=op_info.epsilon,
                    center=center)
            else:
                bn_out = tf.compat.v1.layers.batch_normalization(
                    op_info.op_list[op_info.op_index].inputs[op_info.input_index],
                    epsilon=op_info.epsilon,
                    center=center)
            # check if bn_out.op is Integrating BN
            # bn_out.op would be bulk BN with 5D input under tf1.15.0
            if len(bn_out.op.inputs) != 5:
                return [], []
        _relink_bn_tensor(op_info.output_dict, op_info.op_list, bn_out.op)
        if is_tail_layer(object_op) and not self.outputs:
            LOGGER.push_warning_message(
                'Replace BN at the end of the network! ' \
                'You need to replace the old output node by the new output ' \
                'node in inference process! \n' + \
                '>'*30 + 'The name of the old output node is \'{}\'\n'.format(
                    object_op.outputs[0].name) + \
                '<'*30 + 'The name of the new output node is \'{}\''.format(
                    bn_out.name),
                module_name='replace_bn_pass')

        if object_op.outputs:
            object_op_out = object_op.outputs[0]
            consumers_object_op_out = object_op_out.consumers()
            replace_inputs_tensor(bn_out, object_op_out,
                                  consumers_object_op_out)
        replace_inputs_tensor(
            tf.compat.v1.placeholder(
                op_info.op_list[op_info.op_index].inputs[op_info.input_index].dtype),
            op_info.op_list[op_info.op_index].inputs[op_info.input_index], [op_info.op_list[op_info.op_index]])

        if object_op.name in self.outputs:
            index = self.outputs.index(object_op.name)
            self.outputs[index] = bn_out.op.name

        return [], []


def _get_op_info(object_op):
    """ Obtains BN information from the matched pattern structure.
    """
    pattern_config = dict()
    config_name = None
    for config_name, pattern_config in PATTERN_CONFIG.items():
        flag, op_list = PatternHelper.match_pattern(object_op, pattern_config)
        if flag and 'training_false' in config_name:
            break
    end_dict = pattern_config.get('END')
    output_dict = pattern_config.get('OUTPUT')
    keys = list(end_dict.keys())[0]

    with tf.compat.v1.Session(config=tf.compat.v1.ConfigProto(allow_soft_placement=True)) as sess:
        global_vars = tf.compat.v1.global_variables()
        global_vars_names = [cur_var.name for cur_var in global_vars]
        epsilon_tensor = \
            _get_valid_tensor(op_list[output_dict.get('epsilon')])
        if epsilon_tensor.name in \
            global_vars_names:
            cur_index = global_vars_names.index(
                epsilon_tensor.name)
            sess.run(
                tf.compat.v1.variables_initializer([global_vars[cur_index]]))
        epsilon = sess.run(epsilon_tensor)
    return OpInfo._make([op_list, int(keys), end_dict[keys][0], output_dict, epsilon, config_name])


def _get_valid_tensor(operation):
    """ Obtains a valid tensor. """
    if len(operation.inputs) == 0:
        return operation.outputs[0]
    return operation.inputs[0]


def _relink_bn_tensor(output_dict, op_list, bn_operation):
    """ Reconnect the input of the bulk BN operator to the integrated BN
        operator.
    """
    bn_input_tensor_dict = {
        'scale': 1,
        'offset': 2,
        'mean': 3,
        'variance': 4
    }
    for key, op_index in output_dict.items():
        if key != 'epsilon':
            input_tensor = _get_valid_tensor(op_list[op_index])
            replace_inputs_tensor(
                input_tensor,
                bn_operation.inputs[bn_input_tensor_dict.get(key)],
                [bn_operation])


def check_fusable(producer_op):
    """Check if upstream Conv exists such that the pattern is Conv(biasAdd)+BN"""
    if producer_op.type in ('Conv2D', 'Conv3D'):
        return True
    if producer_op.type == 'BiasAdd':
        if producer_op.inputs[0].op.type in ('Conv2D', 'Conv3D'):
            return True
    return False
