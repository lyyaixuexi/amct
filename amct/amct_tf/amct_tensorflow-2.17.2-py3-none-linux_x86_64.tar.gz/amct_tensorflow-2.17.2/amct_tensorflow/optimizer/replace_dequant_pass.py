#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace DeqQuant to 'dequant ops' for quantized layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401
from tensorflow.python.ops import gen_control_flow_ops # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.optimizer.bn_fusion_utils import get_data_format
from amct_tensorflow.lib.load_custom_op import load_ascend
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.utils.quant_ops import create_context
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_info_generator import QuantInfoGenerator
from amct_tensorflow.configuration.check_graph import GraphChecker

from amct_tensorflow.utils.log import LOGGER

_CUSTOM_OP = load_ascend()

__all__ = ['ReplaceDeQuantPass']


class ReplaceDeQuantPass(BaseFusionPass):
    """
    Function: Replace DeqQuant to 'dequant ops' for quantized layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, outputs=None, on_ascend=False):
        """
        Function: init object
        Inputs:
            outputs: a list
        Return: None
        """
        BaseFusionPass.__init__(self)
        if outputs is None:
            self.outputs = []
        else:
            self.outputs = outputs
        if not self.outputs:
            raise RuntimeError("param 'outputs' cannot be empty for dequant "
                               "may change the outputs of graph.")
        self.on_ascend = on_ascend

    def match_pattern(self, operation):
        """
        Function: Match Quant op.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type == 'DeqQuant':
            return True
        return False

    def do_pass(self, object_op):
        """
        Function: Replace DeqQuant to 'dequant ops'
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        data = object_op.inputs[0]
        data_flag = 'float32'
        if data.op.type == 'Cast':
            data = data.op.inputs[0]
            data_flag = 'float16'
        dqscale = object_op.inputs[1]
        quant_out = object_op.outputs[0]
        consumers = quant_out.consumers()

        context, _ = split_name_scope(
            str(object_op.get_attr('layer_name'), encoding='utf-8'))
        context = create_context(context, quant_type='dequant')
        with tf.compat.v1.variable_scope(None,
                                         default_name=context,
                                         values=[data]):
            ksize = object_op.get_attr('ksize')
            dqscale = _get_enter_scale(object_op, dqscale)
            pre_op = object_op.inputs[0].op
            if object_op.inputs[0].op.type == 'ConcatV2':
                pre_op = object_op.inputs[0].op.inputs[0].op
            if object_op.inputs[0].op.type == 'Concat':
                pre_op = object_op.inputs[0].op.inputs[1].op
            if self.on_ascend:
                try:
                    deq_quant = _CUSTOM_OP.ascend_dequant(data, deq_scale=dqscale,
                        data_format=get_data_format(pre_op.get_attr('data_format')), ksize=ksize)
                except ValueError:
                    deq_quant = _CUSTOM_OP.ascend_dequant(data, deq_scale=dqscale, ksize=ksize)
            else:
                try:
                    deq_quant = _CUSTOM_OP.ascend_dequant(
                        data,
                        T=data_flag,
                        deq_scale=dqscale,
                        data_format=get_data_format(
                            pre_op.get_attr('data_format')),
                        ksize=ksize)
                except ValueError:
                    deq_quant = _CUSTOM_OP.ascend_dequant(
                        data,
                        T=data_flag,
                        deq_scale=dqscale,
                        ksize=ksize)

        replace_inputs_tensor(deq_quant, quant_out, consumers)

        QuantInfoGenerator().set_output_anchor(
            deq_quant.op.name,
            str(object_op.get_attr('layer_name'), encoding='utf-8'))

        # update outputs if object_op in outputs
        if object_op.name in self.outputs:
            index = self.outputs.index(object_op.name)
            self.outputs[index] = deq_quant.op.name

        LOGGER.push_debug_message(
            "finish replacing DeqQuant for %s" %
            (object_op.get_attr('layer_name')), "ReplaceDeQuantPass")

        return [], []


def _get_enter_scale(object_op, dqscale):
    """
    Function: Use enter to modify the deqscale.'
    Inputs:
        object_op: op to process.
        dqscale: inverse quantization factor.
    Returns:
        dqscale: modified inverse quantization factor.
    """
    inputs = object_op.inputs[0].op.inputs
    if len(inputs) > 1:
        info_length, frame_name, is_constant, parallel_iterations = \
            GraphChecker.get_dependency_enter_info(inputs[1].op)
        if info_length:
            dqscale = gen_control_flow_ops.enter(
                dqscale,
                frame_name=frame_name,
                is_constant=is_constant,
                parallel_iterations=parallel_iterations)
    return dqscale
