#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

optimizer module

"""


from .adjust_group_conv_bn_pass import AdjustGroupConvBNPass
from .adjust_group_conv_pass import AdjustGroupConvPass
from .base_fusion_pass import BaseFusionPass
from .conv_bn_fusion_pass import ConvBnFusionPass
from .delete_fake_quant_pass import DeleteFakeQuantPass
from .delete_identity_pass import DeleteIdentityPass
from .delete_retrain_pass import DeleteRetrainPass
from .eltwise_insert_cali import EltwiseInsertCaliPass
from .fuse_mul_pass import FuseMulPass
from .graph_optimizer import GraphOptimizer
from .group_conv_insert_cali import GroupConvInsertCaliPass
from .insert_arq_pass import InsertARQPass
from .insert_nuq_pass import InsertNUQPass
from .insert_bias_quant_pass import InsertBiasQuantPass
from .insert_dequant_pass import InsertDeQuantPass
from .insert_act_cali_pass import InsertActCaliPass
from .insert_quant_pass import InsertQuantPass
from .insert_retrain_gp_conv_pass import InsertRetrainGroupConvPass
from .insert_retrain_pass import  InsertRetrainPass
from .insert_retrain_search_n_pass import InsertRetrainSearchNPass
from .insert_retrain_searchn_bn_pass import InsertRetrainSearchnBnPass
from .insert_retrain_searchn_gp_conv import InsertRetrainSearchnGpConv
from .insert_search_n_pass import InsertSearchNQuantPass
from .insert_weight_quant_pass import InsertWeightQuantPass
from .insert_weight_quant_nuq_pass import InsertWeightQuantNuqPass
from .mult_output_with_quant_pass import MultQuantOptimizerPass
from .quant_fusion_pass import QuantFusionPass
from .replace_add_pass import ReplaceAddPass
from .adjust_add_position import AdjustAddPosition
from .replace_anti_quant_pass import ReplaceAntiQuantPass
from .replace_bias_quant_pass import ReplaceBiasQuantPass
from .replace_bn_branch_pass import ReplaceBnbranchPass
from .replace_bn_pass import ReplaceBNPass
from .replace_dequant_pass import ReplaceDeQuantPass
from .replace_quant_pass import ReplaceQuantPass
from .replace_weight_quant_pass import ReplaceWeightQuantPass
from .replace_weight_quant_nuq_pass import ReplaceWeightQuantNuqPass
from .weight_quant_fusion_pass import WeightQuantFusionPass
from .matmul_bn_fusion_pass import MatmulBnFusionPass
from .get_quant_info_pass import GetQuantInfoPass
from .replace_searchn_pass import ReplaceSearchnPass
from .replace_relu6_pass import ReplaceRelu6Pass
from .replace_half_precision_op_pass import ReplaceHalfPrecisionOpPass
from .adjust_batchtospace_bn_pass import AdjustBatchToSpaceBNPass
from .insert_dmq_balancer_pass import InsertDMQBalancerPass
from .apply_dmq_balancer_pass import ApplyDMQBalancerPass
from .group_conv_apply_dmq_balancer_pass import GroupConvApplyDMQBalancerPass


__all__ = [
    'AdjustGroupConvBNPass',
    'AdjustGroupConvPass',
    'BaseFusionPass',
    'ConvBnFusionPass',
    'DeleteFakeQuantPass',
    'DeleteIdentityPass',
    'DeleteRetrainPass',
    'EltwiseInsertCaliPass',
    'FuseMulPass',
    'GraphOptimizer',
    'GroupConvInsertCaliPass',
    'InsertARQPass',
    'InsertNUQPass',
    'InsertBiasQuantPass',
    'InsertDeQuantPass',
    'InsertActCaliPass',
    'InsertQuantPass',
    'InsertRetrainGroupConvPass',
    'InsertRetrainPass',
    'InsertRetrainSearchNPass',
    'InsertRetrainSearchnBnPass',
    'InsertRetrainSearchnGpConv',
    'InsertSearchNQuantPass',
    'InsertWeightQuantPass',
    'InsertWeightQuantNuqPass',
    'MultQuantOptimizerPass',
    'QuantFusionPass',
    'ReplaceAddPass',
    'AdjustAddPosition',
    'ReplaceAntiQuantPass',
    'ReplaceBiasQuantPass',
    'ReplaceBnbranchPass',
    'ReplaceBNPass',
    'ReplaceDeQuantPass',
    'ReplaceQuantPass',
    'ReplaceWeightQuantPass',
    'ReplaceWeightQuantNuqPass',
    'WeightQuantFusionPass',
    'MatmulBnFusionPass',
    'GetQuantInfoPass',
    'ReplaceSearchnPass',
    'ReplaceRelu6Pass',
    'AdjustBatchToSpaceBNPass',
    'ReplaceHalfPrecisionOpPass',
    'InsertDMQBalancerPass',
    'ApplyDMQBalancerPass',
    'GroupConvApplyDMQBalancerPass'
]
