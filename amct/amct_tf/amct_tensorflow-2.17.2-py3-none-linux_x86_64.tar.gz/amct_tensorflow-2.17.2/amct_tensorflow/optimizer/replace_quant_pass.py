#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace Quant to 'quant ops' for quantized layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_info_generator import QuantInfoGenerator
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.utils.quant_ops import create_context
from amct_tensorflow.lib.load_custom_op import load_ascend

from amct_tensorflow.utils.log import LOGGER

_CUSTOM_OP = load_ascend()

__all__ = ['ReplaceQuantPass']


class ReplaceQuantPass(BaseFusionPass):
    """
    Function: Replace Quant to 'quant ops' for quantized layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self):
        """
        Function: init object
        Inputs: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    def match_pattern(self, operation):
        """
        Function: Match Quant op.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type == "Quant":
            return True
        return False

    def do_pass(self, object_op):
        """
        Function: Replace Quant(for act) to 'quant ops'
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        # get params
        context, _ = split_name_scope(
            str(object_op.get_attr('layer_name'), encoding='utf-8'))
        context = create_context(context, quant_type='activation')
        num_bits = object_op.get_attr('quant_bits')
        dst_type = 'INT4' if num_bits == 4 else 'INT8'
        data = object_op.inputs[0]
        quant_out = object_op.outputs[0]
        if len(quant_out.consumers()) >= 1 and quant_out.consumers()[0].type == 'Cast':
            quant_out = quant_out.consumers()[0].outputs[0]
        quant_consumers = quant_out.consumers()
        # add new 'quant ops'
        with tf.compat.v1.variable_scope(None,
                                         default_name=context,
                                         values=[data]):
            act_quant = _CUSTOM_OP.ascend_quant(
                data,
                scale=object_op.get_attr('scale'),
                offset=object_op.get_attr('offset'),
                dst_type=dst_type)

        replace_inputs_tensor(act_quant, quant_out, quant_consumers)
        # Set dump anchor to compute op
        if quant_consumers and \
            not QuantInfoGenerator().has_fusion_info(quant_consumers[0].name):
            QuantInfoGenerator().set_fusion_anchor(
                quant_consumers[0].name, [quant_consumers[0].name])
        LOGGER.push_debug_message(
            "finish replacing Quant for %s" %
            (object_op.get_attr('layer_name')), "ReplaceQuantPass")

        return [], []
