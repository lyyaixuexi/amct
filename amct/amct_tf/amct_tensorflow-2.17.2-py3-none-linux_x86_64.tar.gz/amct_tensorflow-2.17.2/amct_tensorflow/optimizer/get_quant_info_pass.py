#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Get the quantization information of the quantization node.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from collections import namedtuple
import numpy as np

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.lib.load_custom_op import load

from amct_tensorflow.utils.utils_vars import QUANTIZABLE_TYPES
from amct_tensorflow.utils.utils_vars import NO_WEIGHT_QUANT_TYPES
from amct_tensorflow.utils.utils_vars import DUAL_ACTIVATION_QUANT_TYPES
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.pattern.match_group_conv import GROUP_CONV_CONCAT
from amct_tensorflow.pattern.match_group_conv import GROUP_CONV_SPLIT
from amct_tensorflow.utils.utils_vars import FUSE_BN_TYPES

_CUSTOM_OP = load()

OpInfo = namedtuple('GroupOpInfo', ['is_matched', 'quant_op', 'dequant_op', 'group_ops', 'skip_fusion'])

__all__ = ['GetQuantInfoPass']


class GetQuantInfoPass(BaseFusionPass):
    """
    Function: Get the quantization information of the quantization node.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, quant_info):
        """
        Function: init object
        Inputs:
            records: a dictionary containing quant factors
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.quant_info = quant_info
        self.outputs = []
        self.structure = {}

    @staticmethod
    def match_single_operation(operation):
        """
        Function: Matching a single quantization node
        Inputs:
            operation: op to match
        Returns:
            is_matched: a bool whether is matched.
            quant_op: a operation that quantize activation.
            dequant_op: a operation that dequantize outputs.
            skip_fusion: a bool whether is skiped fusion.
        """
        is_matched = False
        quant_op = None
        dequant_op = None
        skip_fusion = False
        act_index, _ = QuantOpInfo.get_quant_index(operation)
        pre_operation = operation.inputs[act_index].op
        if pre_operation.type == 'Pad':
            pre_operation = pre_operation.inputs[0].op
        if pre_operation.type == 'AscendQuant':
            last_operation = operation.outputs[0].consumers()[0]
            if last_operation.type == 'BiasAdd':
                last_operation = last_operation.outputs[0].consumers()[0]
            if last_operation.type == 'AscendDequant':
                quant_op = pre_operation
                dequant_op = last_operation
                is_matched = True
                if len(last_operation.outputs[0].consumers()) == 1:
                    last_operation = last_operation.outputs[0].consumers()[0]
                    if last_operation.type in FUSE_BN_TYPES:
                        skip_fusion = True

        return OpInfo._make([is_matched, quant_op, dequant_op, None, skip_fusion])

    @staticmethod
    def match_group_operation(operation):
        """
        Function: Matching a group quantization nodes
        Inputs:
            operation: op to match
        Returns:
            is_matched: .
            quant_op: .
            dequant_op: .
            skip_fusion: .
        """
        is_matched = False
        quant_op = None
        dequant_op = None
        skip_fusion = False
        group_ops = []
        act_index, _ = QuantOpInfo.get_quant_index(operation)
        pre_operation = operation.inputs[act_index].op
        if pre_operation.type not in GROUP_CONV_SPLIT:
            return OpInfo._make([is_matched, quant_op, dequant_op, group_ops, skip_fusion])

        group_ops = [output.consumers()[0] for output in pre_operation.outputs]
        pre_operation = pre_operation.inputs[1].op
        if pre_operation.type == 'AscendQuant':
            last_operation = operation.outputs[0].consumers()[0]
            if last_operation.type == 'BiasAdd':
                last_operation = last_operation.outputs[0].consumers()[0]
            if last_operation.type in GROUP_CONV_CONCAT:
                last_operation = last_operation.outputs[0].consumers()[0]
                if last_operation.type == 'AscendDequant':
                    quant_op = pre_operation
                    dequant_op = last_operation
                    is_matched = True
                    if len(last_operation.outputs[0].consumers()) == 1:
                        last_operation = \
                            last_operation.outputs[0].consumers()[0]
                        if last_operation.type in FUSE_BN_TYPES:
                            skip_fusion = True
        return OpInfo._make([is_matched, quant_op, dequant_op, group_ops, skip_fusion])

    @staticmethod
    def parser_uint64(uint64_deq_scales):
        """Parser the data of uint64 to get deqscale and shift n."""
        deq_scales = []
        shift_ns = []
        for uint64_deq_scale in uint64_deq_scales:
            value = np.array(uint64_deq_scale, dtype=np.uint64)
            value = value << np.uint32(32)
            value = value >> np.uint32(32)
            value = value.astype(np.uint32)
            deq_scale = np.frombuffer(value, np.float32)
            deq_scales.append(deq_scale)

            value = np.array(uint64_deq_scale, dtype=np.uint64)
            value = value << np.uint32(24)
            value = value >> np.uint32(56)
            shift_n = value.astype(np.uint8)
            shift_ns.append(shift_n)

        return np.array(deq_scales), np.array(shift_ns)

    @staticmethod
    def get_weight_quant_op(object_op):
        """Get the quantization node of weight."""
        if object_op.type in NO_WEIGHT_QUANT_TYPES + DUAL_ACTIVATION_QUANT_TYPES:
            return None
        weight_quant_op = object_op.inputs[1].op
        if weight_quant_op.type == 'Enter':
            weight_quant_op = weight_quant_op.inputs[0].op
        if weight_quant_op.type == 'AscendWeightQuant':
            return weight_quant_op
        return None

    def match_pattern(self, operation):
        """
        Function: Match quantization node.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        is_matched = False
        skip_fusion = False
        auxi_layer = []
        layer_name = operation.name
        layer_type = operation.type

        if operation.type in QUANTIZABLE_TYPES:
            op_info = GetQuantInfoPass.match_single_operation(operation)
            is_matched = op_info.is_matched
            skip_fusion = op_info.skip_fusion
            ops = [operation, op_info.quant_op, op_info.dequant_op, None]
            if is_matched:
                self._add_items(False, ops, skip_fusion)
                return is_matched

            op_info = GetQuantInfoPass.match_group_operation(operation)
            is_matched = op_info.is_matched
            skip_fusion = op_info.skip_fusion
            ops = [operation, op_info.quant_op, op_info.dequant_op, op_info.group_ops]
            if is_matched:
                self._add_items(True, ops, skip_fusion)
                return is_matched
            layer_info = {'layer_name': layer_name, 'auxi_layer': auxi_layer, 'layer_type': layer_type}
            self.quant_info.add_items(layer_info, is_matched, skip_fusion)

        return is_matched

    def do_pass(self, object_op):
        """
        Function: Insert Quant(for act) before object_op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        assign_list = []
        run_list = []

        quant_op, dequant_op = self.structure[object_op.name]['auxi_ops']
        weight_quant_op = GetQuantInfoPass.get_weight_quant_op(object_op)

        record = {}
        record['data_scale'] = 1 / quant_op.get_attr('scale')
        record['data_offset'] = int(quant_op.get_attr('offset'))
        self.quant_info.add_total_records(object_op.name, record)

        if weight_quant_op is not None:
            if object_op.type == 'Conv2DBackpropInput':
                cin = weight_quant_op.inputs[0].shape[3]
                cout = weight_quant_op.inputs[0].shape[2]
            elif object_op.type == 'MatMul':
                cin = weight_quant_op.inputs[0].shape[0]
                cout = weight_quant_op.inputs[0].shape[1]
            elif object_op.type == 'Conv2D':
                cin = weight_quant_op.inputs[0].shape[2]
                cout = weight_quant_op.inputs[0].shape[3]
            elif object_op.type == 'Conv3D':
                cin = weight_quant_op.inputs[0].shape[3]
                cout = weight_quant_op.inputs[0].shape[4]
            elif object_op.type == 'DepthwiseConv2dNative':
                cin = weight_quant_op.inputs[0].shape[2]
                cout = weight_quant_op.inputs[0].shape[2]
            self.quant_info.add_cin_cout_info(object_op.name, [cin, cout])
            channel_wise = bool(weight_quant_op.inputs[1].shape)
            self.quant_info.set_config_channelwise(object_op.name,
                                                   channel_wise)
            run_list.append(weight_quant_op.inputs[1])
            run_list.append(dequant_op.inputs[1])
        else:
            run_list.append(dequant_op.inputs[1])

        LOGGER.push_debug_message(
            "finish get quant info for %s" % (object_op.name),
            "GetQuantInfoPass")

        return assign_list, run_list

    def reset_run_list(self, object_op, run_list_value):
        """
        Function: save value from tensor in run_list
        Inputs:
            object_op: op to process
            run_list_value: value of tensors in run_list.
        Returns: None
        """
        scale_d = self.quant_info.get_total_records()[
            object_op.name]['data_scale']
        if len(run_list_value) == 2:
            deq_scale_uint64 = run_list_value[1]
            if self.structure.get(object_op.name).get('is_group'):
                channel = run_list_value[0].size
                index = object_op.inputs[0].value_index
                deq_scale_uint64 = run_list_value[1][index *
                                                     channel:(index + 1) *
                                                     channel]
            deq_scales, shift_ns = GetQuantInfoPass.parser_uint64(
                deq_scale_uint64)
            weight_scale = deq_scales / scale_d
            weight_offset = run_list_value[0]
            shift_n = shift_ns
        else:
            deq_scales, shift_ns = GetQuantInfoPass.parser_uint64(
                run_list_value[0])
            weight_scale = deq_scales / scale_d
            weight_offset = 0
            shift_n = shift_ns

        self.quant_info.set_total_records(object_op.name, weight_scale,
                                          weight_offset, shift_n)

    def _add_items(self, is_group, ops, skip_fusion):
        operation, quant_op, dequant_op, group_ops = ops
        layer_name = operation.name
        layer_type = operation.type
        auxi_layer = [quant_op.name, dequant_op.name]
        if not is_group:
            group_layer = [operation.name]
        else:
            group_layer = [group_op.name for group_op in group_ops]
        if group_layer not in self.quant_info.get_group_layers():
            self.quant_info.add_group_layers(group_layer)
        layer_info = {'layer_name': layer_name, 'auxi_layer': auxi_layer, 'layer_type': layer_type}
        self.quant_info.add_items(layer_info, True, skip_fusion)
        self.structure[layer_name] = {
            'is_group': is_group,
            'auxi_ops': [quant_op, dequant_op]
        }
