#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Change pattern from MatMul + Reshape + add/addv2/bias_add to
    MatMul + bias_add + Reshape

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.optimizer.bn_fusion_utils import is_tail_layer
from amct_tensorflow.utils.quant_ops import relink_tensor
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_ops import create_context

from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.utils.utils_vars import ADD_TYPES
from amct_tensorflow.configuration.check_graph import GraphChecker


__all__ = ['AdjustAddPosition']


class AdjustAddPosition(BaseFusionPass):
    """
    Function: Adjust add/addv2/bias_add position after reshape.
    APIs: match_pattern, do_pass
    """
    def __init__(self):
        """
        Function: init AdjustAddPosition object
        Return: None
        """
        BaseFusionPass.__init__(self)

    def match_pattern(self, operation):
        """
        Function: Matches the pattern MatMul + Reshape + add/addv2/bias_add.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type not in ADD_TYPES:
            return False

        if is_tail_layer(operation):
            return False

        reshape_op = operation.inputs[0].op
        if reshape_op.type != 'Reshape':
            return False
        if len(reshape_op.outputs[0].consumers()) != 1:
            return False

        quant_op = None
        if reshape_op.inputs:
            quant_op = reshape_op.inputs[0].op

        if not quant_op or quant_op.type != 'MatMul':
            return False
        if len(quant_op.outputs[0].consumers()) != 1:
            return False

        bias_shape = operation.inputs[1].shape
        if GraphChecker.check_biasadd_shape(bias_shape, quant_op):
            return True

        return False

    def do_pass(self, add_op):
        """
        Function: change pattern from MatMul + Reshape + add/addv2/bias_add to
            MatMul + add/addv2/bias_add + Reshape
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        LOGGER.logd("Adjust position for layer {}".format(add_op.name),
                    'AdjustAddPosition')

        reshape_op = add_op.inputs[0].op
        quant_op = reshape_op.inputs[0].op

        layer_context, _ = split_name_scope(add_op.name)
        context = create_context(layer_context, quant_type='replace_add')
        with tf.compat.v1.variable_scope(None, default_name=context) as scope:
            scope.set_partitioner(None)
            new_add_out = tf.compat.v1.nn.bias_add(
                value=quant_op.outputs[0], bias=add_op.inputs[1])

        relink_tensor(quant_op.outputs[0], new_add_out, reshape_op)
        for consumer in add_op.outputs[0].consumers():
            relink_tensor(add_op.outputs[0], reshape_op.outputs[0], consumer)

        return [], []
