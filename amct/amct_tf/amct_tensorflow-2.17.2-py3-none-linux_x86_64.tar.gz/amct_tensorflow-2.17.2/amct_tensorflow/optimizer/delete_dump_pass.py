#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Remove the dump node from the graph.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.utils.log import LOGGER


__all__ = ['DeleteDumpPass']


class DeleteDumpPass(BaseFusionPass):
    """
    Function: Remove the Dump node from the graph.
    APIs: match_pattern, do_pass,
    """
    def __init__(self):
        """
        Function: init DeleteDumpPass object
        Inputs: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    def match_pattern(self, operation):
        """
        Function: Matches the Dump operation that can be deleted.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type == 'Dump':
            return True
        return False

    def do_pass(self, op):
        """
        Function: Delete Dump node from the graph.
        Inputs:
            op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        object_op_in = op.inputs[0]
        object_op_out = op.outputs[0]
        consumers_object_op_out = object_op_out.consumers()

        replace_inputs_tensor(object_op_in, object_op_out,
                              consumers_object_op_out)
        replace_inputs_tensor(
            tf.compat.v1.placeholder(op.inputs[0].dtype), op.inputs[0], [op])

        LOGGER.logi("doing layer: delete Dump op[%s]!" % op.name, "DeleteDumpPass")
        return [], []
