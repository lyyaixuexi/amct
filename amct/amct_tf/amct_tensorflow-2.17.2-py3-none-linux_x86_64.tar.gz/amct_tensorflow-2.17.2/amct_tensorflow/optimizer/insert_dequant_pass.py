#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert Dequant for quantized layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import numpy as np
import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.utils.quant_ops import create_context
from amct_tensorflow.optimizer.insert_bias_quant_pass import cmp_data_format

from amct_tensorflow.utils.utils_vars import QUANTIZABLE_TYPES
from amct_tensorflow.utils.log import LOGGER

_CUSTOM_OP = load()

DequantParams = collections.namedtuple('DequantParams',
    ['weight_offset_value', 'shift_n_value', 'dqscale_value', 'clip_mode'])

__all__ = ['InsertDeQuantPass', 'insert_dequant']


class InsertDeQuantPass(BaseFusionPass):
    """
    Function: Insert Dequant for quantized layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, records=None, outputs=None):
        """
        Function: init object
        Inputs:
            records: a dictionary containing quant factors
        Return: None
        """
        BaseFusionPass.__init__(self)

        if records is None:
            self.records = dict()
        else:
            self.records = records

        if outputs is None:
            self.outputs = list()
        else:
            self.outputs = outputs
        if not outputs:
            raise RuntimeError("param 'outputs' cannot be empty for dequant "
                               "may change the outputs of graph.")

    def match_pattern(self, operation):
        """
        Function: Match operation after which Dequant can be inserted.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        def pattern_with_bias(operation):
            ''' match pattern "conv+bias" '''
            if operation.type != 'BiasAdd':
                return False

            pre_op = operation.inputs[0].op

            if pre_op.type in QUANTIZABLE_TYPES and \
                len(pre_op.outputs[0].consumers()) == 1 and \
                pre_op.name in self.records and \
                cmp_data_format(pre_op, operation):
                return True
            return False

        def pattern_without_bias(operation):
            ''' match pattern "conv" '''
            if operation.type in QUANTIZABLE_TYPES \
                and operation.name in self.records:
                if len(operation.outputs[0].consumers()) != 1:
                    return True
                next_op = operation.outputs[0].consumers()[0]
                if next_op.type != 'BiasAdd':
                    return True
                if not cmp_data_format(operation, next_op):
                    return True

            return False

        if pattern_without_bias(operation) or pattern_with_bias(operation):
            return True
        return False

    def do_pass(self, object_op):
        """
        Function: Insert Dequant after object_op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        if object_op.type == 'BiasAdd':
            quantized_op = object_op.inputs[0].op
        else:
            quantized_op = object_op
        # inser dequant
        _, dq_shape = QuantOpInfo.get_reduce_dims(quantized_op)
        act_scale_value = self.records.get(quantized_op.name).get('data_scale')
        weight_scale_value = self.records.get(
            quantized_op.name).get('weight_scale')
        weight_offset_value = self.records.get(
            quantized_op.name).get('weight_offset')
        shift_n_value = self.records.get(quantized_op.name).get('shift_n')
        num_bits = self.get_dst_type(quantized_op.name)
        quant_param = collections.OrderedDict()
        quant_param['num_bits'] = num_bits
        quant_param['dq_shape'] = dq_shape
        quant_value = collections.OrderedDict()
        quant_value['act_scale_value'] = act_scale_value
        quant_value['weight_scale_value'] = weight_scale_value
        quant_value['weight_offset_value'] = weight_offset_value
        quant_value['shift_n_value'] = shift_n_value

        deq_quant = insert_dequant(quantized_op, object_op, 0, quant_value,
                                   quant_param)

        # update outputs if object_op in outputs
        if object_op.name in self.outputs:
            index = self.outputs.index(object_op.name)
            self.outputs[index] = deq_quant.op.name

        LOGGER.push_debug_message(
            "finish inserting Dequant for %s" % (quantized_op.name),
            "InsertDeQuantPass")

        return [], []


def insert_dequant(quantized_op, object_op, output_index, quant_value,
                   quant_param):
    """
    Function: insert Dequant for quantized_op
    Inputs:
        quantized_op: an op, the op to be quantized
        object_op: an op, after which to insert Dequant
        output_index: a number, the act's index in quantized_op's inputs
        quant_param: a dictionary containing parameters for quantization
            num_bits: a number means which bit the inputs will be quantized to
            dq_shape: the shape of dqscale
        quant_value: a dictionary containing values for quantization
            act_scale_value : an array or a number containging the value of
                activation's scale.
            weight_scale_value: an array or a number containging the value of
                weight's scale.
            shift_n_value: an array or a number, N
    Returns: None
    """
    # calculate dqscale_value
    dequant_params = _get_dequant_param(quant_value, quant_param)
    fused_param = _fuse_dequant_param(dequant_params.dqscale_value, dequant_params.weight_offset_value,
        dequant_params.shift_n_value, dequant_params.dqscale_value.size)

    data = object_op.outputs[output_index]
    consumers = data.consumers()

    context, _ = split_name_scope(quantized_op.name)
    context = create_context(context, quant_type='dequant')
    with tf.compat.v1.variable_scope(
            None, ''.join([context, '_temp']), [data]):
        if object_op.type == 'AvgPool':
            if QuantOpInfo.get_data_format(object_op) == 'NHWC':
                ksize = object_op.get_attr('ksize')[1:3]
            else:
                ksize = object_op.get_attr('ksize')[2:]
        else:
            ksize = [1, 1]
        deq_quant = _CUSTOM_OP.deq_quant(
            data,
            deqscale=fused_param,
            layer_name=quantized_op.name,
            ksize=ksize)
    replace_inputs_tensor(deq_quant, data, consumers)

    return deq_quant


def _get_dequant_param(quant_value, quant_param):
    """ get essential params for dequant. """
    weight_scale_value = np.reshape(quant_value['weight_scale_value'],
                                    quant_param['dq_shape'])
    weight_offset_value = np.reshape(quant_value['weight_offset_value'],
                                     quant_param['dq_shape'])
    shift_n_value = np.reshape(quant_value['shift_n_value'],
                               quant_param['dq_shape'])
    dqscale_value = quant_value['act_scale_value'] * weight_scale_value
    if np.sum(shift_n_value) == 0:
        clip_mode = 32
    else:
        clip_mode = 16
    dequant_params = DequantParams._make([weight_offset_value, shift_n_value, dqscale_value, clip_mode])
    return dequant_params


def _fuse_dequant_param(deq_scale, offset_w,
                        shift_bits, scale_length):
    """Fused dequant scale, offset_w and shift_bits to uint64 data
    """
    float32_deq_scale = np.array(deq_scale, np.float32)
    uint32_deq_scale = np.frombuffer(float32_deq_scale, np.uint32)
    int8_offset_w = np.array(offset_w, np.int8)
    uint8_offset_w = np.frombuffer(int8_offset_w, np.uint8)

    int8_shift_n = np.array(shift_bits, np.int8)
    uint8_shift_n = np.frombuffer(int8_shift_n, np.uint8)

    # fuse parameter
    # |-----------------|47:40|--------|39:32|--------|31:0|
    #                  offset_w [8]    shift_N [8]    deq_scale [32]
    quant_param = np.zeros(scale_length, dtype=np.uint64)
    for index in range(scale_length):
        quant_param[index] = uint8_offset_w[index]
        quant_param[index] = (quant_param[index] << np.uint32(8))\
                                + uint8_shift_n[index]
        quant_param[index] = (quant_param[index] << np.uint32(32))\
                                + uint32_deq_scale[index]
    return quant_param
