#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2022. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace Relu6 to Relu.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.utils.quant_ops import create_context
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.utils.utils_vars import BASE
from amct_tensorflow.utils.utils_vars import EPSILON

QUANT_BITS = {'INT8': 8, 'INT4': 4}
RELU6_MAX = 6

__all__ = ['ReplaceRelu6Pass']


class ReplaceRelu6Pass(BaseFusionPass):
    """
    Function: Replace relu6 to relu.
    APIs: match_pattern, do_pass,
    """
    def __init__(self):
        """
        Function: init object
        Inputs: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    @staticmethod
    def do_pass(object_op):
        """
        Function: Replace Quant(for act) to 'quant ops'
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        # get params
        context, _ = split_name_scope(object_op.name)
        context = create_context(context, quant_type='replace_relu6')
        data = object_op.inputs[0]
        relu6_out = object_op.outputs[0]
        relu6_consumers = relu6_out.consumers()
        # add new 'relu'
        with tf.compat.v1.variable_scope(None,
                                         default_name=context,
                                         values=[data]):
            new_relu = tf.nn.relu(data)

        replace_inputs_tensor(new_relu, relu6_out, relu6_consumers)
        LOGGER.push_debug_message("Replace %s as %s" %
            (object_op.name, new_relu.op.name), "ReplaceRelu6Pass")

        return [], []

    @staticmethod
    def _check_valid_relu6(ascend_quant_op):
        """check if relu6 + quant == relu + quant """
        dst_type = ascend_quant_op.get_attr('dst_type').decode("utf-8")
        fp_upper_bound = BASE**(QUANT_BITS.get(dst_type) - 1) - 1
        offset = ascend_quant_op.get_attr('offset')
        scale_d = ascend_quant_op.get_attr('scale')
        fp_max = (fp_upper_bound - offset) / scale_d
        if fp_max < RELU6_MAX + EPSILON:
            return True
        return False

    def match_pattern(self, operation):
        """
        Function: Match AscendDequant+Relu6+AscendQuant pattern.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type != 'Relu6':
            return False
        # check producer is AscendDequant
        producer = operation.inputs[0].op
        while producer.type == 'Identity':
            producer = producer.inputs[0].op
        if producer.type != 'AscendDequant':
            return False
        # check consumer is AscendQuant
        consumers = operation.outputs[0].consumers()
        if len(consumers) != 1:
            return False
        while consumers[0].type == 'Identity':
            if len(consumers[0].outputs[0].consumers()) != 1:
                return False
            consumers[0] = consumers[0].outputs[0].consumers()[0]
        if consumers[0].type != 'AscendQuant':
            return False
        return self._check_valid_relu6(consumers[0])
