#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Fuse MatMul and [FusedBatchNorm, FusedBatchNormV2, FusedBatchNormV3].

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from collections import namedtuple
import numpy as np
import tensorflow as tf  # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.optimizer.bn_fusion_utils import is_tail_layer
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.utils.quant_info_generator import QuantInfoGenerator
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.optimizer import bn_fusion_utils as bn_utils
from amct_tensorflow.utils.quant_op_info import QuantOpInfo

from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.utils.utils_vars import FUSE_TYPES
from amct_tensorflow.utils.utils_vars import FUSE_BN_TYPES

MATMUL_BN = 'matmul_bn'
MATMUL_BA_BN = 'matmul_biasadd_bn'

PatternInfo = namedtuple('PatternInfo', ['is_match', 'bn_op', 'reshape_op', 'shape_op_list'])

__all__ = ['MatmulBnFusionPass']


class MatmulBnFusionPass(BaseFusionPass):
    """
    Function: Fuse matmul and bn.
    APIs: match_pattern, do_pass, reset_run_list
    """
    def __init__(self,
                 is_replace=True,
                 outputs=None,
                 records=None,
                 skip_param=None):
        """
        Function: init object
        Inputs:
            is_replace: a bool whether save fused_weight and fused_bias in
                a new variable.
            outputs: a list containing the outputs of graph
            records: a dictionary recording layers' quant factors. if it's
                not None, the quant factors will be changed.
            skip_param: a dict, params for skip including
                do_fusion: a bool, do fusion or not.
                skip_layers: a list containing layers not to be fused.
                skip_layers_fusible: a dict, key is layer not to be fused and
                    value is a bool meaning whether layer is fusible.
        Return: None
        """
        BaseFusionPass.__init__(self)

        if skip_param is None:
            skip_param = dict()
        do_fusion = skip_param.get('do_fusion')
        skip_layers = skip_param.get('skip_layers')
        skip_layers_fusible = skip_param.get('skip_layers_fusible')
        self.do_fusion = True if do_fusion is None else do_fusion
        self.skip_layers = [] if skip_layers is None else skip_layers

        if skip_layers_fusible is None:
            self.skip_layers_fusible = dict.fromkeys(self.skip_layers, False)
        else:
            self.skip_layers_fusible = skip_layers_fusible

        if is_replace and not outputs:
            raise RuntimeError(
                "param 'outputs' cannot be empty when is_replace is True")
        self.is_replace = is_replace
        self.outputs = [] if outputs is None else outputs
        self.records = dict() if records is None else records
        self.structures = dict()

    def match_pattern(self, operation):
        """
        Function: Match pattern of "matmul + biasadd + bn" or "matmul + bn"
        Inputs:
            operation: node to be matched
        Returns:
            True: matched
            False: mismatch
        """
        # check type
        if operation.type not in FUSE_TYPES:
            return False

        def is_skip():
            ''' check whether layer is skiped'''
            if self.do_fusion and operation.name in self.skip_layers \
                or not self.do_fusion:
                self.skip_layers_fusible[operation.name] = True
                return True
            return False

        # match structure and check placeholder
        if match_matmul_bn_pattern(operation, [False]).is_match and not is_skip():
            self.structures[operation.name] = MATMUL_BN
            return True
        if match_matmul_biasadd_bn_pattern(operation, [False]).is_match and \
            not is_skip():
            self.structures[operation.name] = MATMUL_BA_BN
            return True
        return False

    def do_pass(self, object_op): # pylint: disable=R0914
        """
        Function: Do actual matmul layer and bn layer fusion operation
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        if self.structures.get(object_op.name) == MATMUL_BN:
            pattern_info = match_matmul_bn_pattern(object_op)
        elif self.structures.get(object_op.name) == MATMUL_BA_BN:
            pattern_info = match_matmul_biasadd_bn_pattern(
                object_op)
            bias_add_op = object_op.outputs[0].consumers()[0]

        fuse_parameters = bn_utils.get_bn_params(pattern_info.bn_op)
        fuse_parameters["is_replace"] = self.is_replace

        fusion_info = [pattern_info.bn_op.name]
        assign_list = []
        run_list = []
        is_tail = is_tail_layer(pattern_info.reshape_op)

        if self.structures.get(object_op.name) == MATMUL_BN:
            _fuse_matmul_bn_layer(pattern_info.bn_op, fuse_parameters, assign_list,
                                  fusion_info, pattern_info.shape_op_list)
        elif self.structures.get(object_op.name) == MATMUL_BA_BN:
            _fuse_matmul_biasadd_bn_layer(pattern_info.bn_op, fuse_parameters, assign_list,
                                          fusion_info, pattern_info.shape_op_list)

        if pattern_info.reshape_op.name in self.outputs:
            index = self.outputs.index(pattern_info.reshape_op.name)
            bias_add_op = object_op.outputs[0].consumers()[0]
            self.outputs[index] = bias_add_op.name

        if is_tail and not self.outputs:
            new_out_op = object_op.outputs[0].consumers()[0]
            LOGGER.push_warning_message(
                'Fused BN at the end of the network! ' \
                'You need to replace the old output node by the new output ' \
                'node in inference process! \n' \
                '{}The name of the old output node is \'{}\'\n' \
                '{}The name of the new output node is \'{}\''.format(
                    '>'*30, pattern_info.bn_op.outputs[0].name,
                    '<'*30, new_out_op.outputs[0].name),
                module_name='conv_bn_fusion_pass')

        for op_name in fusion_info:
            QuantInfoGenerator().set_fusion_anchor(op_name, fusion_info)

        if self.records and object_op.name in self.records:
            scale_w = self.records.get(object_op.name).get('weight_scale')
            scale_w_new = _fuse_scale_w_online(fuse_parameters, scale_w,
                                               object_op)
            run_list.append(scale_w_new)

        LOGGER.push_info_message("fusing layer: {} and {} success"\
            .format(pattern_info.bn_op.name, object_op.name), "MatmulBnFusionPass")

        return assign_list, run_list

    def reset_run_list(self, object_op, run_list_value):
        """
        Function: save value from tensor in run_list
        Inputs:
            object_op: op to process
            run_list_value: value of tensors in run_list.
        Returns: None
        """
        if self.records and object_op.name in self.records:
            scale_array = self.records.get(object_op.name).get('weight_scale')
            if scale_array.shape:
                self.records.get(object_op.name)['weight_scale'] = \
                    np.abs(run_list_value[0])
            else:
                # modify not channel_wise to channel_wise
                offset_array = self.records.get(object_op.name).get('weight_offset')
                shift_n_array = self.records.get(object_op.name).get('shift_n')
                scale_shape, scale_length = QuantOpInfo.get_scale_shape(
                    object_op.inputs[1], True, object_op.type)
                self.records.get(object_op.name)['weight_scale'] = \
                    np.abs(run_list_value[0]).reshape(scale_shape)
                self.records.get(object_op.name)['weight_offset'] = \
                    offset_array.repeat(scale_length).reshape(scale_shape)
                self.records.get(object_op.name)['shift_n'] = \
                    shift_n_array.repeat(scale_length).reshape(scale_shape)


def verify_match_the_pattern(shape_value_list,
                             channel_cout,
                             uncertain_nodes,
                             output_shape_list,
                             fuse_op_output_shape):
    """ function to verify whether match the pattern"""
    is_match = False
    if len(shape_value_list) == 4 and \
            (shape_value_list[1:] == [1, 1, channel_cout] or \
            shape_value_list[1:] == [channel_cout, 1, 1]):
        is_match = True
    if uncertain_nodes or \
            (output_shape_list and \
             not _verify_shape_match(output_shape_list, fuse_op_output_shape)):
        is_match = False
    return is_match


def _verify_shape_match(output_shape_list, fuse_op_output_shape):
    """ function to verify the reshape output shape and fuse output shape"""
    fuse_op_output_shape_list = fuse_op_output_shape.as_list()
    shape_match = False
    if output_shape_list == fuse_op_output_shape_list:
        shape_match = True
    elif output_shape_list == [fuse_op_output_shape_list[0], -1]:
        shape_match = True
    elif output_shape_list == [-1, fuse_op_output_shape_list[1]]:
        shape_match = True
    else:
        shape_match = False
    return shape_match


def fetch_ops_from_graph(fuse_op):
    """ function to fetch reshape, shape, bn op from sub graph"""
    reshape_op_list = []
    shape_op_list = []
    bn_op = None
    if len(fuse_op.outputs[0].consumers()) == 2:
        reshape_op_list = list(filter(
            lambda next_op: next_op.type == 'Reshape',
            fuse_op.outputs[0].consumers()))
        shape_op_list = list(filter(
            lambda next_op: next_op.type == 'Shape',
            fuse_op.outputs[0].consumers()))
    elif len(fuse_op.outputs[0].consumers()) == 1:
        reshape_op_list = list(filter(
            lambda next_op: next_op.type == 'Reshape',
            fuse_op.outputs[0].consumers()))

    if len(reshape_op_list) == 1 and (
            len(shape_op_list) == 1 or not shape_op_list):
        if len(reshape_op_list[0].outputs[0].consumers()) == 1 and \
            reshape_op_list[0].outputs[0].consumers()[0].type in FUSE_BN_TYPES:
            bn_op = reshape_op_list[0].outputs[0].consumers()[0]
    return reshape_op_list, shape_op_list, bn_op


def match_matmul_bn_pattern(fuse_op, # pylint: disable=R0912, R0914
                            support_is_training=(True, False)):
    """
    Function: Whether the fuse_op can match the fusible pattern without biasadd
        the match pattern is as follows:
         FUSE_TYPES                   matmul(fuse_op)
             |         \\      example:  |         \\
          Reshape       |             Reshape       |
             |       (Shape)             |      (Shape)
        FUSE_BN_TYPES   |               bn          |
             |         /                 |         /
          Reshape                     Reshape
    Inputs:
        fuse_op: the op to be fused, whose type should be in FUSE_TYPES.
    Returns:
        bool: True means the fuse_op match fusible pattern without biasadd and
            False otherwise.
    """

    shape_value_list = []
    output_shape_list = []
    uncertain_nodes = []
    reshape_op = None
    is_match = False

    reshape_op_list, shape_op_list, bn_op = fetch_ops_from_graph(fuse_op)
    if bn_op and len(bn_op.outputs[0].consumers()) == 1 and \
        bn_op.outputs[0].consumers()[0].type == 'Reshape':
        reshape_op = bn_op.outputs[0].consumers()[0]
        input_ops = [reshape_op.inputs[0].op, reshape_op.inputs[1].op]
        if not shape_op_list or shape_op_list[0] in input_ops:
            if fuse_op.type == 'BiasAdd':
                channel_cout = fuse_op.inputs[1].shape[0]
            else:
                channel_cout = fuse_op.inputs[1].shape[1]
            if channel_cout == bn_op.inputs[1].shape:
                shape = reshape_op_list[0].inputs[1]
                with tf.compat.v1.Session(
                        config=tf.compat.v1.ConfigProto(
                            allow_soft_placement=True),
                        graph=fuse_op.graph) as sess:
                    if not GraphChecker.check_placeholder(fuse_op.graph,
                        [shape.op.name]):
                        shape_value = sess.run(shape)
                        shape_value_list = list(shape_value)
                    if not shape_op_list:
                        uncertain_nodes = GraphChecker.check_placeholder(
                            fuse_op.graph, [reshape_op.inputs[1].op.name])
                        if not uncertain_nodes:
                            output_shape = sess.run(reshape_op.inputs[1])
                            output_shape_list = list(output_shape)
                fuse_op_output_shape = fuse_op.outputs[0].shape
                is_match = verify_match_the_pattern(
                    shape_value_list, channel_cout, uncertain_nodes,
                    output_shape_list, fuse_op_output_shape)
        # check bn's attr is_training
        if bn_op.get_attr('is_training') not in support_is_training:
            is_match = False

    # placeholder
    if not bn_utils.check_invalid_fuse(fuse_op):
        is_match = False

    return PatternInfo._make([is_match, bn_op, reshape_op, shape_op_list])


def match_matmul_biasadd_bn_pattern(fuse_op,
                                    support_is_training=(True, False)):
    """
    Function: Whether the fuse_op can match the fusible pattern with biasadd
        the match pattern is as follows:
         FUSE_TYPES                   matmul(fuse_op)
             |                           |
        BiasAdd_TYPES                 biasadd
             |         \\      example:  |         \\
          Reshape       |             Reshape       |
             |       (Shape)             |      (Shape)
        FUSE_BN_TYPES   |               bn          |
             |         /                 |         /
          Reshape                     Reshape
    Inputs:
        fuse_op: the op to be fused, whose type should be in FUSE_TYPES.
    Returns:
        bool: True means the fuse_op match fusible pattern without biasadd and
            False otherwise.
    """
    shape_op_list = []
    bn_op = None
    reshape_op = None
    is_match = False

    if len(fuse_op.outputs[0].consumers()) != 1 \
        or not GraphChecker.check_biasadd(fuse_op.outputs[0].consumers()[0]):
        return PatternInfo._make([is_match, bn_op, reshape_op, shape_op_list])

    bias_add_op = fuse_op.outputs[0].consumers()[0]
    pattern_info = match_matmul_bn_pattern(bias_add_op)
    is_match = pattern_info.is_match

    # check placeholder
    if not bn_utils.check_invalid_fuse(fuse_op) or \
        not bn_utils.check_invalid_fuse(bias_add_op):
        is_match = False

    # check bn's attr is_training
    if pattern_info.bn_op and pattern_info.bn_op.get_attr('is_training') not in support_is_training:
        is_match = False

    matmul_biasadd_bn_pattern = PatternInfo._make(
        [is_match, pattern_info.bn_op, pattern_info.reshape_op, pattern_info.shape_op_list])
    return matmul_biasadd_bn_pattern


def _fuse_matmul_bn_layer(bn_op,
                          fuse_parameters,
                          assign_list,
                          fusion_info,
                          shape_op_list):
    """ fuse matmul-bn structure"""
    # check length
    producer_out = bn_op.inputs[0].op.inputs[0]
    producer_op = producer_out.op
    bn_utils.check_length(
        bn_op.inputs[0], fuse_parameters,
        bn_utils.get_data_format(bn_op.get_attr('data_format')))

    fusion_info.insert(0, producer_op.name)

    context, _ = split_name_scope(producer_op.name)
    # fuse weight
    weight_new, weight_assign = bn_utils.fuse_weight(
        producer_op.type, producer_op.inputs[1], fuse_parameters,
        bn_utils.generate_name_scope(context, 'fused_weight'))

    if weight_assign is not None:
        assign_list.append(weight_assign)
    replace_inputs_tensor(weight_new, producer_op.inputs[1], [producer_op])
    # fuse bias
    bias_new, bias_assign = bn_utils.fuse_bias(
        None, fuse_parameters,
        bn_utils.generate_name_scope(context, 'fused_bias'))
    if bias_assign is not None:
        assign_list.append(bias_assign)

    with tf.compat.v1.name_scope(context):
        compute_out_new = tf.compat.v1.nn.bias_add(
            value=producer_out,
            bias=bias_new,
            name='bias_add')
    QuantInfoGenerator().set_bias_add_anchor(
        compute_out_new.op.name, fusion_info)
    # delete the link of BN
    replace_inputs_tensor(
        compute_out_new, bn_op.outputs[0].consumers()[0].outputs[0],
        bn_op.outputs[0].consumers()[0].outputs[0].consumers())
    replace_inputs_tensor(
        tf.compat.v1.placeholder(bn_op.inputs[0].op.inputs[0].dtype),
        bn_op.inputs[0].op.inputs[0], [bn_op.inputs[0].op])
    if shape_op_list:
        shape_op = shape_op_list[0]
        replace_inputs_tensor(
            tf.compat.v1.placeholder(shape_op.inputs[0].dtype),
            shape_op.inputs[0], [shape_op])


def _fuse_matmul_biasadd_bn_layer(bn_op, fuse_parameters, assign_list,
                                  fusion_info, shape_op_list):
    """ fuse matmul-biasadd-bn structure"""
    bias_op = bn_op.inputs[0].op.inputs[0].op
    conv_op = bias_op.inputs[0].op
    # check length
    bn_utils.check_length(
        bn_op.inputs[0], fuse_parameters,
        bn_utils.get_data_format(bn_op.get_attr('data_format')))

    fusion_info.insert(0, bias_op.name)
    fusion_info.insert(0, conv_op.name)

    context, _ = split_name_scope(conv_op.name)
    # fuse weight
    weight_new, weight_assign = bn_utils.fuse_weight(
        conv_op.type, conv_op.inputs[1], fuse_parameters,
        bn_utils.generate_name_scope(context, 'fused_weight'))
    if weight_assign is not None:
        assign_list.append(weight_assign)
    replace_inputs_tensor(weight_new, conv_op.inputs[1], [conv_op])
    # fuse bias
    bias_new, bias_assign = bn_utils.fuse_bias(
        bias_op.inputs[1], fuse_parameters,
        bn_utils.generate_name_scope(context, 'fused_bias'))
    if bias_assign is not None:
        assign_list.append(bias_assign)
    replace_inputs_tensor(bias_new, bias_op.inputs[1], [bias_op])

    # delete the link of BN
    replace_inputs_tensor(
        bias_op.outputs[0], bn_op.outputs[0].consumers()[0].outputs[0],
        bn_op.outputs[0].consumers()[0].outputs[0].consumers())
    replace_inputs_tensor(
        tf.compat.v1.placeholder(bn_op.inputs[0].op.inputs[0].dtype),
        bn_op.inputs[0].op.inputs[0], [bn_op.inputs[0].op])
    if shape_op_list:
        shape_op = shape_op_list[0]
        replace_inputs_tensor(
            tf.compat.v1.placeholder(shape_op.inputs[0].dtype),
            shape_op.inputs[0], [shape_op])


def _fuse_scale_w_online(fuse_parameters, scale_w_array, matmul_op):
    """ to fuse the scale w online"""
    scale_w = tf.compat.v1.constant(scale_w_array)
    scale_w_new = bn_utils.fuse_scale_w(
        matmul_op.type, scale_w, fuse_parameters)
    return scale_w_new
