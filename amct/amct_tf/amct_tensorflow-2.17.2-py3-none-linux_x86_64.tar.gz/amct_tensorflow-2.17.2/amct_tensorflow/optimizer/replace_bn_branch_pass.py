#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace slim bn branch to single bn.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.optimizer.bn_fusion_utils import is_tail_layer
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.utils.quant_ops import create_context
from amct_tensorflow.pattern.match_pattern import PatternHelper

from amct_tensorflow.utils.utils_vars import PATTERN_CONFIG
from amct_tensorflow.utils.log import LOGGER

_CUSTOM_OP = load()
TARGET_PATTERNS = ["bnv3_branch_train_eval", "bn_branch_train_eval",
                   "bnv2_branch_train_eval"]

__all__ = ['ReplaceBnbranchPass']


class ReplaceBnbranchPass(BaseFusionPass):
    """
    Function: Replace bulk BN to Integrating BN for all layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, outputs=None):
        """
        Function: init object
        Inputs:
            outputs: a list that is names of out ops
        Return: None
        """
        BaseFusionPass.__init__(self)
        if outputs is None:
            outputs = []
        self.outputs = outputs
        self.structure = dict()
        self.training_bn = []

    def match_pattern(self, operation):
        """
        Function: Match replaceable operation to be replaced.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type == "Merge":
            for pattern_name, pattern_config in PATTERN_CONFIG.items():
                if pattern_name not in TARGET_PATTERNS:
                    continue
                flag, op_list = PatternHelper.match_pattern(
                    operation, pattern_config)
                if not flag:
                    LOGGER.push_debug_message(
                        "{} fail for pattern unmatch"\
                        .format(operation.name), "ReplaceBnbranchPass")
                    continue

                # train branch and eval branch is from the same data
                eval_in_op = op_list[pattern_config['OUTPUT']["eval_in"]]
                train_in_op = op_list[pattern_config['OUTPUT']["train_in"]]
                data_in_tensor = eval_in_op.inputs[0]
                if data_in_tensor != train_in_op.inputs[0]:
                    LOGGER.push_debug_message(
                        "{} fail for branches' data differs"\
                        .format(operation.name), "ReplaceBnbranchPass")
                    continue
                # varify inference branch bn's is_training
                eval_bn_op = op_list[pattern_config['OUTPUT']["bn_inference"]]
                is_training = eval_bn_op.get_attr('is_training')
                if is_training:
                    LOGGER.push_debug_message(
                        "{} fail for eval_bn's is_training is not False".
                        format(operation.name), "ReplaceBnbranchPass")
                    continue
                # varify inference branch
                pre_op = op_list[pattern_config['OUTPUT']["phase_train"]]
                pre_value = pre_op.get_attr('value').bool_val
                if pre_value != [False]:
                    LOGGER.push_debug_message(
                        "{} fail for eval_bn's branch cannot be run"\
                        .format(operation.name), "ReplaceBnbranchPass")
                    continue

                self.structure[operation.name] = {
                    'pattern_config': pattern_config,
                    'op_list': op_list
                }
                self.training_bn.append(
                    op_list[pattern_config['OUTPUT']["bn_training"]].name)

                LOGGER.push_debug_message(
                    "{} success for match pattern "\
                    .format(operation.name), "ReplaceBnbranchPass")
                return True

        return False

    def do_pass(self, object_op):
        """
        Function: Replace object_op's pattern to BN(for inference).
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        layer_context, _ = split_name_scope(object_op.name)
        context = create_context(layer_context, quant_type='replace_bn')
        op_list = self.structure.get(object_op.name).get('op_list')
        pattern_out = self.structure.get(object_op.name).get('pattern_config').get('OUTPUT')

        # replace object_op node by replace_object_op node
        with tf.compat.v1.name_scope(context):
            # find in and out for pattern
            eval_in_op = op_list[pattern_out["eval_in"]]
            data_in_tensor = eval_in_op.inputs[0]
            data_out_tensor = object_op.outputs[0]
            # generate new bn for inference
            eval_bn_op = op_list[pattern_out["bn_inference"]]
            with tf.compat.v1.variable_scope(None, default_name=context):
                new_bn_out = tf.compat.v1.layers.batch_normalization(
                    inputs=data_in_tensor,
                    axis=find_bn_axis(eval_bn_op),
                    epsilon=eval_bn_op.get_attr('epsilon'))
                new_bn_op = new_bn_out.op
                replace_inputs_tensor(op_list[pattern_out["scale"]].outputs[0],
                                      new_bn_op.inputs[1], [new_bn_op])
                replace_inputs_tensor(
                    op_list[pattern_out["offset"]].outputs[0],
                    new_bn_op.inputs[2], [new_bn_op])
                replace_inputs_tensor(op_list[pattern_out["mean"]].outputs[0],
                                      new_bn_op.inputs[3], [new_bn_op])
                replace_inputs_tensor(
                    op_list[pattern_out["variance"]].outputs[0],
                    new_bn_op.inputs[4], [new_bn_op])

                if not is_tail_layer(object_op):
                    replace_inputs_tensor(new_bn_out, data_out_tensor,
                                          data_out_tensor.consumers())
                elif not self.outputs:
                    LOGGER.push_warning_message(
                        'Replace BN at the end of the network! You need to ' \
                        'replace the old output node by the new output ' \
                        'node in inference process! \n' + '>'*30 + \
                        'The name of the old output node is \'{}\'\n'.format(
                            object_op.outputs[0].name) + '<'*30 + \
                        'The name of the new output node is \'{}\''.format(
                            new_bn_out.name),
                        module_name='replace_bn_branch_pass')
                if object_op.name in self.outputs:
                    index = self.outputs.index(object_op.name)
                    self.outputs[index] = new_bn_op.name

            replace_inputs_tensor(
                tf.compat.v1.placeholder(data_in_tensor.dtype), data_in_tensor,
                [eval_in_op, op_list[pattern_out["train_in"]]])

        return [], []


def find_bn_axis(bn_op):
    '''find bn's attr(axis) from bn_op '''
    data_format = bn_op.get_attr('data_format')
    if data_format in ['NHWC', b'NHWC']:
        axis = -1
    elif data_format in ['NCHW', b'NCHW']:
        axis = 1
    else:
        raise RuntimeError(" error data_format %s " % (data_format))
    return axis
