#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert retrain op

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.pattern.match_group_conv import pattern_group_conv
from amct_tensorflow.utils import retrain_ops
from amct_tensorflow.utils import quant_ops

from amct_tensorflow.pattern.match_group_conv import GROUP_CONV_SPLIT
from amct_tensorflow.utils.log import LOGGER


class InsertRetrainGroupConvPass(BaseFusionPass):
    """
    Insert retrain pass
    """
    def __init__(self, quant_config, skip_layers):
        BaseFusionPass.__init__(self)
        self.quant_config = quant_config
        self.skip_layers = skip_layers
        self.structure = {}

    def match_pattern(self, operation):
        # Find the split operation
        if operation.type not in GROUP_CONV_SPLIT:
            return False
        # match the group_conv structure
        group_conv = pattern_group_conv(operation)
        if group_conv is None:
            return False

        # check the act quant parameter is same for convs
        def _check_cali(convs, quant_config):
            """ whether convs to do quant as group_conv """
            if not quant_config[convs[0]]['retrain_enable']:
                return False
            for conv in convs[1:]:
                if quant_config[conv] != quant_config[convs[0]]:
                    return False
            return True

        conv_names = group_conv.get_name('conv_names')
        enable_cali = _check_cali(conv_names, self.quant_config)
        if not enable_cali:
            return False

        self.structure[operation.name] = group_conv
        self.skip_layers.extend(conv_names)

        return True

    def do_pass(self, object_op):
        group_conv = self.structure.get(object_op.name)

        LOGGER.push_debug_message('doing group_conv:%s insert retrain quant' %
                                  group_conv.get_name('name'),
                                  'InsertRetrainGroupConvPass')
        # insert act quant
        for conv_name in group_conv.get_name('conv_names'):
            LOGGER.push_info_message('doing layer:%s insert act retrain' %
                                     conv_name, 'InsertRetrainGroupConvPass')

        split_op = group_conv.get_split()
        act_input = split_op.inputs[1]
        context = split_op.name
        convs = group_conv.get_name('conv_names')
        act_kwargs = self.quant_config[convs[0]].get('retrain_data_config')
        act_kwargs['quant_op_names'] = convs

        act_output = retrain_ops.quant_act(act_input, context, act_kwargs)
        del act_kwargs['quant_op_names']
        # relink outputs
        quant_ops.relink_tensor(act_input, act_output, split_op)

        # insert weight quant
        wgt_kwargs = self.quant_config[convs[0]].get('retrain_weight_config')
        for conv in group_conv.get_convs():
            LOGGER.push_info_message('doing layer:%s insert weight retrain' %
                                     conv.name,
                                     'InsertRetrainGroupConvPass')
            wgt_input = conv.inputs[1]
            context = conv.name
            wgt_kwargs['quant_op_names'] = [conv.name]
            wgt_output = retrain_ops.quant_wgt(
                wgt_input,
                context,
                wgt_kwargs,
                conv.type)
            quant_ops.relink_tensor(wgt_input, wgt_output, conv)
            del wgt_kwargs['quant_op_names']

        return [], []
