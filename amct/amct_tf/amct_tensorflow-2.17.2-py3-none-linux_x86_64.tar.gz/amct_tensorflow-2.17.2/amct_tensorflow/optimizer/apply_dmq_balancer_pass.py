#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2023. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert Mul op for dmq_balancer layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.utils import quant_ops

from amct_tensorflow.utils.utils_vars import QUANTIZABLE_TYPES
from amct_tensorflow.utils.utils_vars import NO_WEIGHT_QUANT_TYPES
from amct_tensorflow.utils.utils_vars import DUAL_ACTIVATION_QUANT_TYPES
from amct_tensorflow.utils.log import LOGGER

__all__ = ['ApplyDMQBalancerPass']


class ApplyDMQBalancerPass(BaseFusionPass):
    """
    Function: Insert mul op for dmq_balancer layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, quant_config=None, records=None, skip_layers=None, outputs=None, is_replace=False):
        """
        Function: init object of ApplyDMQBalancerPass
        Inputs:
            quant_config: a dict containing quant config. (quantize_model phase)
            records: a dict containing record.
            skip_layers: a list containing skip quantize layers.
            outputs: a list, graph outputs, needed when is_replace=True and new weights will be assigned.
            is_replace: a bool, True: new weights should be assigned. (save_model phase)
                                False: mul op be inserted to weights, no tensor to be assigned. (quantize_model phase)
        Return: None
        """
        BaseFusionPass.__init__(self, outputs)
        self.quant_config = quant_config
        self.skip_layers = [] if skip_layers is None else skip_layers
        self.records = {} if records is None else records
        self.tensor_balance_factor = []
        if is_replace and not outputs:
            raise RuntimeError(
                "param 'outputs' cannot be empty when is_replace is True")
        self.is_replace = is_replace

    @staticmethod
    def apply_balance_scale_to_weight(object_op, tensor_balance_factor, is_replace):
        '''
        insert mul op to weight tensor, assign new value to weight if is_replace is true
        '''
        _, weight_index = QuantOpInfo.get_quant_index(object_op)
        weight = object_op.inputs[weight_index]
        # broadcast tensor balance factor to weight shape
        balance_scale = tf.compat.v1.constant(tensor_balance_factor, dtype=weight.dtype)
        reshape_dim = [1] * weight.shape.ndims
        _, wgt_cin_idx = QuantOpInfo.get_cin_index(object_op)
        reshape_dim[wgt_cin_idx] = -1
        balance_scale = tf.compat.v1.reshape(balance_scale, reshape_dim)

        # multiply weight and scale
        balanced_weight = tf.compat.v1.multiply(weight, balance_scale)
        if not is_replace:
            quant_ops.relink_tensor(weight, balanced_weight, object_op)
            return [], []

        # assign weight
        layer_context = object_op.name
        with tf.compat.v1.variable_scope(
                None, default_name=layer_context + '/balanced_weight',
                reuse=None) as scope:
            scope.set_partitioner(None)
            wts_var = tf.compat.v1.get_variable(
                'weight',
                shape=weight.shape,
                dtype=weight.dtype,
                trainable=False,
                collections=[
                    tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                    tf.compat.v1.GraphKeys.MODEL_VARIABLES
                ],
                use_resource=False)
            assign_wts = tf.compat.v1.assign(wts_var, balanced_weight)
        quant_ops.relink_tensor(weight, wts_var.read_value(), object_op)
        return [assign_wts], []


    def apply_balance_scale_to_activation(self, object_op):
        '''
        insert mul op to activation tensor
        '''
        quant_op = object_op
        act_index, _ = QuantOpInfo.get_quant_index(quant_op)
        if object_op.inputs[act_index].op.type == 'Pad' \
            and len(object_op.inputs[act_index].op.outputs[0].consumers()) == 1:
            object_op = object_op.inputs[act_index].op
            activation = object_op.inputs[0]
        else:
            activation = object_op.inputs[act_index]
        # broadcast tensor balance factor to activation shape
        balance_scale = tf.compat.v1.constant([1/scale for scale in self.tensor_balance_factor], dtype=activation.dtype)
        reshape_dim = [1] * activation.shape.ndims
        act_cin_idx, _ = QuantOpInfo.get_cin_index(quant_op)
        reshape_dim[act_cin_idx] = -1
        balance_scale = tf.compat.v1.reshape(balance_scale, reshape_dim)

        # multiply activation and scale
        balanced_act = tf.compat.v1.multiply(activation, balance_scale)

        quant_ops.relink_tensor(activation, balanced_act, object_op)


    def match_pattern(self, operation):
        """
        Function: Match quantizable operation to be quantized.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type in QUANTIZABLE_TYPES \
            and operation.type not in NO_WEIGHT_QUANT_TYPES + DUAL_ACTIVATION_QUANT_TYPES \
            and operation.name not in self.skip_layers:
            if self.quant_config is not None:
                if operation.name in self.quant_config.keys() and \
                    self.quant_config.get(operation.name).get('dmq_balancer_param'):
                    return True
            else:
                if operation.name in self.records and self.records[operation.name].get('tensor_balance_factor'):
                    return True
        return False

    def do_pass(self, object_op):
        """
        Function: Insert quant_arq(for weight) before object_op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        if not self.records.get(object_op.name) or \
            not self.records[object_op.name].get('tensor_balance_factor'):
            raise ValueError("config indicates dmq_balancer in layer: %s, " \
                                "but no tensor_balance_factor found in record." \
                                "please check quant_preprocess and calibration is done!" % object_op.name)
        LOGGER.push_info_message('doing layer:%s apply dmq_balancer' %
                                 object_op.name, 'ApplyDMQBalancerPass')
        self.tensor_balance_factor = self.records[object_op.name].get('tensor_balance_factor')
        # insert mul op to activation
        LOGGER.push_debug_message('doing layer:%s apply dmq_balancer to activation' %
                                 object_op.name, 'ApplyDMQBalancerPass')
        self.apply_balance_scale_to_activation(object_op)

        # assign weights
        LOGGER.push_debug_message('doing layer:%s apply dmq_balancer to weight' %
                                 object_op.name, 'ApplyDMQBalancerPass')
        assign_list, run_list = ApplyDMQBalancerPass.apply_balance_scale_to_weight(
            object_op, self.tensor_balance_factor, self.is_replace)

        return assign_list, run_list
