#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Fuse Conv2D, MatMul, DepthwiseConv2dNative, Conv2DBackpropInput and Mul.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.optimizer.bn_fusion_utils import is_tail_layer
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.utils.quant_ops import is_scalar
from amct_tensorflow.optimizer import bn_fusion_utils as bn_utils

from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.utils.utils_vars import FUSE_MUL_TYPES

QUANTOP_MUL = 'quantop_mul'
QUANTOP_BA_MUL = 'quantop_biasadd_mul'

__all__ = ['FuseMulPass']


class FuseMulPass(BaseFusionPass):
    """
    Function: Fuse mul and conv or depthwise_conv or deconv or matmul.
    APIs: match_pattern, do_pass, reset_run_list
    """
    def __init__(self, is_replace=True, outputs=None):
        """
        Function: init object
        Inputs:
            is_replace: a bool whether save fused_weight and fused_bias in
                a new variable.
            outputs: a list containing the outputs of graph
        Return: None
        """
        BaseFusionPass.__init__(self)

        if is_replace and not outputs:
            raise RuntimeError(
                "param 'outputs' cannot be empty when is_replace is True")
        self.is_replace = is_replace

        if outputs is None:
            self.outputs = []
        else:
            self.outputs = outputs

        self.structures = dict()

    def match_pattern(self, operation):
        """
        Function: Match pattern of "quant_op + biasadd + mul" or
            "quant_op + mul"
        Inputs:
            operation: node to be matched
        Returns:
            True: matched
            False: mismatch
        """
        # check type
        if operation.type not in FUSE_MUL_TYPES:
            return False
        # check quant_op's weight
        if GraphChecker.get_dependency_with_placeholder(operation.inputs[1].op):
            return False

        # match structure and check placeholder
        if match_quant_mul_pattern(operation):
            self.structures[operation.name] = QUANTOP_MUL
            return True
        if match_quant_biasadd_mul_pattern(operation):
            self.structures[operation.name] = QUANTOP_BA_MUL
            return True
        return False

    def do_pass(self, object_op):
        """
        Function: Do actual quant layer and mul layer fusion operation
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        if self.structures.get(object_op.name) == QUANTOP_MUL:
            mul_op = object_op.outputs[0].consumers()[0]
        elif self.structures.get(object_op.name) == QUANTOP_BA_MUL:
            bias_add_op = object_op.outputs[0].consumers()[0]
            mul_op = bias_add_op.outputs[0].consumers()[0]

        assign_list = []
        run_list = []
        is_tail = is_tail_layer(mul_op)

        mul_input_index = 0
        mul_value_index = 1
        if is_scalar(mul_op.inputs[0]):
            mul_input_index = 1
            mul_value_index = 0

        new_out_op = None
        if self.structures.get(object_op.name) == QUANTOP_MUL:
            _fuse_quant_mul_layer(mul_op, assign_list, self.is_replace,
                                  mul_input_index, mul_value_index)
            new_out_op = object_op
        elif self.structures.get(object_op.name) == QUANTOP_BA_MUL:
            _fuse_quant_biasadd_mul_layer(mul_op, assign_list, self.is_replace,
                                          mul_input_index, mul_value_index)
            new_out_op = object_op.outputs[0].consumers()[0]

        if mul_op.name in self.outputs:
            index = self.outputs.index(mul_op.name)
            self.outputs[index] = new_out_op.name

        if is_tail and not self.outputs:
            LOGGER.push_warning_message(
                'Fused Mul at the end of the network! ' \
                'You need to replace the old output node by the new output ' \
                'node in inference process! \n' \
                '{}The name of the old output node is \'{}\'\n' \
                '{}The name of the new output node is \'{}\''.format(
                    '>'*30, mul_op.outputs[0].name,
                    '<'*30, new_out_op.outputs[0].name),
                module_name='fuse_mul_pass')

        LOGGER.push_debug_message("fusing layer: {} and {}"\
            .format(mul_op.name, object_op.name), "FuseMulPass")

        return assign_list, run_list


def match_quant_mul_pattern(fuse_op):
    """
    Function: Whether the fuse_op can match the fusible pattern without biasadd
        the match pattern is as follows:
        FUSE_MUL_TYPES           quant(fuse_op)
             |           example:  |
            Mul                   Mul
    Inputs:
        fuse_op: the op to be fused, whose type should be in FUSE_TYPES.
    Returns:
        bool: True means the fuse_op match fusible pattern without biasadd and
            False otherwise.
    """
    if len(fuse_op.outputs[0].consumers()) == 1 \
        and fuse_op.outputs[0].consumers()[0].type == 'Mul':
        mul_op = fuse_op.outputs[0].consumers()[0]
        if is_scalar(mul_op.inputs[1]) or is_scalar(mul_op.inputs[0]):
            return True
    return False


def match_quant_biasadd_mul_pattern(fuse_op):
    """
    Function: Whether the fuse_op can match the fusible pattern with biasadd
        the match pattern is as follows:
        FUSE_MUL_TYPES          quant(fuse_op)
             |                      |
        BiasAdd_TYPES   example:  biasadd
             |                      |
            Mul                    Mul
    Inputs:
        fuse_op: the op to be fused, whose type should be in FUSE_TYPES.
    Returns:
        bool: True means the fuse_op match fusible pattern without biasadd and
            False otherwise.
    """
    if len(fuse_op.outputs[0].consumers()) != 1 \
        or not GraphChecker.check_biasadd(fuse_op.outputs[0].consumers()[0]):
        return False

    bias_add_op = fuse_op.outputs[0].consumers()[0]
    if len(bias_add_op.outputs[0].consumers()) == 1 \
        and bias_add_op.outputs[0].consumers()[0].type == 'Mul':
        mul_op = bias_add_op.outputs[0].consumers()[0]
        if is_scalar(mul_op.inputs[1]) or is_scalar(mul_op.inputs[0]):
            return True

    return False


def fuse_weight_mul(mul_value, weight, is_replace, context):
    """
    Funtion: Fuse weight with Mul layer's parameters.
    Inputs:
        mul_value: a tensor, scalar input value of the mul operator.
        weight: a tensor, the weight to be fused.
        is_replace: a bool, indicates whether to perform offline replacement.
        context: a string, context for created nodes.
    Returns:
        weight_fused: a tensor, the weight fused.
        weight_assign: a tensor which can be run to get new weights.
    """
    # fuse operaions
    weight_new_var = tf.compat.v1.multiply(mul_value, weight)

    # don't store fused weight if is_replace is False
    if not is_replace:
        return weight_new_var, None
    # Construct a new variable to store fused weight if is_replace is True
    with tf.compat.v1.variable_scope(None, default_name=context) as scope:
        scope.set_partitioner(None)
        weight_var = tf.compat.v1.get_variable(
            name='weight_fused',
            shape=weight_new_var.shape,
            initializer=tf.compat.v1.constant_initializer(1.0),
            dtype=weight.dtype,
            trainable=False,
            collections=[
                tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                tf.compat.v1.GraphKeys.MODEL_VARIABLES
            ],
            use_resource=False)
        weight_assign = tf.compat.v1.assign(weight_var, weight_new_var)
        weight_fused = weight_var.read_value()

        return weight_fused, weight_assign


def fuse_bias_mul(mul_value, bias, is_replace, context):
    """
    Funtion: Fuse bias with Mul layer's parameters.
    Inputs:
        mul_value: a tensor, scalar input value of the mul operator.
        bias: a tensor, the bias to be fused.
        is_replace: a bool, indicates whether to perform offline replacement.
        context: a string, context for created nodes.
    Returns:
        bias_fused: a tensor, the bias fused.
        bias_assign: a tensor which can be run to get new bias.
    """
    # fuse operaions
    bias_new_var = tf.compat.v1.multiply(mul_value, bias)

    # don't store fused bias if is_replace is False
    if not is_replace:
        return bias_new_var, None
    # Construct a new variable to store fused bias if is_replace is True
    with tf.compat.v1.variable_scope(None, default_name=context) as scope:
        scope.set_partitioner(None)
        bias_var = tf.compat.v1.get_variable(
            name='bias_fused',
            shape=bias_new_var.shape,
            initializer=tf.compat.v1.constant_initializer(0.0),
            dtype=bias.dtype,
            trainable=False,
            collections=[
                tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                tf.compat.v1.GraphKeys.MODEL_VARIABLES
            ],
            use_resource=False)
        bias_assign = tf.compat.v1.assign(bias_var, bias_new_var)
        bias_fused = bias_var.read_value()

        return bias_fused, bias_assign


def _fuse_quant_mul_layer(mul_op, assign_list, is_replace, mul_input_index,
                          mul_value_index):
    """ fuse quant-mul structure"""
    quant_op = mul_op.inputs[mul_input_index].op

    context, _ = split_name_scope(quant_op.name)
    # fuse weight
    weight_new, weight_assign = fuse_weight_mul(
        mul_op.inputs[mul_value_index], quant_op.inputs[1], is_replace,
        bn_utils.generate_name_scope(context, 'fused_weight'))

    if weight_assign is not None:
        assign_list.append(weight_assign)
    replace_inputs_tensor(weight_new, quant_op.inputs[1], [quant_op])

    # delete the link of Mul
    replace_inputs_tensor(mul_op.inputs[mul_input_index], mul_op.outputs[0],
                          mul_op.outputs[0].consumers())
    replace_inputs_tensor(
        tf.compat.v1.placeholder(mul_op.inputs[mul_input_index].dtype),
        mul_op.inputs[mul_input_index], [mul_op])


def _fuse_quant_biasadd_mul_layer(mul_op, assign_list, is_replace,
                                  mul_input_index, mul_value_index):
    """ fuse quant-biasadd-mul structure"""
    bias_op = mul_op.inputs[mul_input_index].op
    quant_op = bias_op.inputs[0].op

    context, _ = split_name_scope(quant_op.name)
    # fuse weight
    weight_new, weight_assign = fuse_weight_mul(
        mul_op.inputs[mul_value_index], quant_op.inputs[1], is_replace,
        bn_utils.generate_name_scope(context, 'fused_weight'))

    if weight_assign is not None:
        assign_list.append(weight_assign)
    replace_inputs_tensor(weight_new, quant_op.inputs[1], [quant_op])

    # fuse bias
    bias_new, bias_assign = fuse_bias_mul(
        mul_op.inputs[mul_value_index], bias_op.inputs[1], is_replace,
        bn_utils.generate_name_scope(context, 'fused_bias'))

    if bias_assign is not None:
        assign_list.append(bias_assign)
    replace_inputs_tensor(bias_new, bias_op.inputs[1], [bias_op])

    # delete the link of Mul
    replace_inputs_tensor(mul_op.inputs[mul_input_index], mul_op.outputs[0],
                          mul_op.outputs[0].consumers())
    replace_inputs_tensor(
        tf.compat.v1.placeholder(mul_op.inputs[mul_input_index].dtype),
        mul_op.inputs[mul_input_index], [mul_op])
