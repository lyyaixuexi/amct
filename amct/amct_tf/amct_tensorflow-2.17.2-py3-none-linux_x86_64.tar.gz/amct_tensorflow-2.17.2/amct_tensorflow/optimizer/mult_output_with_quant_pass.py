#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Add quant and anti-quant to max_pooling.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.optimizer.quant_fusion_pass import QuantFusionPass
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.utils.quant_ops import create_context

from amct_tensorflow.utils.utils_vars import MULT_OUTPUT_TYPES
from amct_tensorflow.utils.utils_vars import ELTWISE_TYPES
from amct_tensorflow.utils.utils_vars import TRANSPARENT_TYPES
from amct_tensorflow.common.utils import vars_util

_CUSTOM_OP = load()


class MultQuantOptimizerPass(BaseFusionPass):
    """
    Function: Add quant and anti-quant to max_pooling.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, records=None):
        """
        Function: init object
        Inputs:
            records: a dictionary containing quant factors
        Return: None
        """
        BaseFusionPass.__init__(self)
        if records is None:
            records = {}
        self.records = records

    def match_pattern(self, operation):
        """
        Function: Match quantizable operation to be quantized.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        is_matched = False
        if operation.type != 'MaxPool':
            return is_matched
        # match the struct
        input_op = operation.inputs[0].op
        output_ops = input_op.outputs[0].consumers()
        try:
            _remove_maxpool(output_ops)
        except IndexError:
            return is_matched
        else:
            output_ops_types = [output_op.type
                for output_op in output_ops]
            if _check_input_op_valid(input_op) and output_ops_types:
                if all(op_type == 'Quant'
                    for op_type in output_ops_types):
                    num_bits = [op.get_attr('quant_bits') for
                                op in output_ops]
                    fusion_quant_nodes = \
                        QuantFusionPass.find_same_quant_node(
                            self.records, output_ops)
                    if len(fusion_quant_nodes) == 1 and 4 not in num_bits:
                        is_matched = True
        return is_matched

    def do_pass(self, object_op):
        """
        Function: Insert quant and antiquant(for act) before object_op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        layer_context, _ = split_name_scope(object_op.name)
        context = create_context(layer_context, quant_type='activation')
        anti_context = create_context(layer_context, quant_type='anti')
        # insert act_quant and act_antiquant
        object_brother_op, data, act_index = _get_brother_op(object_op)
        scale_value = self.records.get(object_brother_op.name).\
            get('data_scale')
        offset_value = self.records.get(object_brother_op.name).\
            get('data_offset')

        act_anti_quant = MultQuantOptimizerPass.insert_quant_antiquant(
            [context, anti_context], data, [scale_value, offset_value],
            object_brother_op)

        replace_inputs_tensor(act_anti_quant, object_op.inputs[act_index],
                              [object_op])

        return [], []

    @staticmethod
    def insert_quant_antiquant(contexts, data, scale_offset_value,
                               object_brother_op):
        """
        Function: Insert quant and antiquant(for act) before object_op
        Inputs:
            contexts: a list of context and anti_context.
            data: a tensor that is input data.
            scale_offset_value: a list of scale_value and offset_value.
            object_brother_op: a operation that is brother_op of object op.
        Returns:
            act_anti_quant: a tensor that is output of antiquant.
        """
        with tf.compat.v1.variable_scope(None,
                                         default_name=contexts[0],
                                         values=[data]):
            # inser act_quant
            act_quant = _CUSTOM_OP.quant(
                data,
                scale=1.0 / scale_offset_value[0].astype(np.float),
                offset=scale_offset_value[1].astype(np.float),
                layer_name=object_brother_op.name,
                quant_bits=vars_util.INT8_BIT)

        with tf.compat.v1.variable_scope(None,
                                         default_name=contexts[1],
                                         values=[data]):
            # inser act_antiquant
            act_anti_quant = _CUSTOM_OP.anti_quant(
                act_quant,
                scale=scale_offset_value[0].astype(np.float),
                offset=-scale_offset_value[1].astype(np.int32),
                layer_name=object_brother_op.name)
        return act_anti_quant


def _get_brother_op(object_op):
    """Get brother op of the object_op and data."""
    act_index = 0
    input_op = object_op.inputs[act_index].op
    output_ops = input_op.outputs[act_index].consumers()
    _remove_maxpool(output_ops)
    object_brother_op = output_ops[act_index].outputs[act_index].\
        consumers()[act_index]
    if object_brother_op.type == 'Pad':
        object_brother_op = object_brother_op.outputs[act_index].\
            consumers()[act_index]

    data_in_op = object_op.inputs[act_index].op
    data_in_index = object_op.inputs[act_index].value_index
    data = data_in_op.outputs[data_in_index]

    return object_brother_op, data, act_index


def _remove_maxpool(output_ops):
    """Remove the maxpool op from the output_ops."""
    index = 0
    while index < len(output_ops):
        if output_ops[index].type == 'MaxPool':
            output_ops.remove(output_ops[index])
            index -= 1
        if output_ops[index].type == 'Quant':
            if output_ops[index].outputs[0].consumers()[0].type == \
                'AntiQuant':
                output_ops.remove(output_ops[index])
                index -= 1
        index += 1


def _check_input_op_valid(input_op):
    """Check if the input op is valid."""
    while input_op.type in TRANSPARENT_TYPES:
        input_op = input_op.inputs[0].op
    if input_op.type in MULT_OUTPUT_TYPES:
        return True
    if input_op.type in ELTWISE_TYPES:
        if str(input_op.inputs[0].shape) == \
            str(input_op.inputs[1].shape):
            return True
    return False
