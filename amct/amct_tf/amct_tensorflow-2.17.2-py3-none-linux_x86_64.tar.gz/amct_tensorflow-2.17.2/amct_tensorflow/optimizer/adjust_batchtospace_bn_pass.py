#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Change pattern from batchtospace + bn to bn + batchtospace

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.utils.utils_vars import FUSE_BN_TYPES
from amct_tensorflow.optimizer.bn_fusion_utils import is_tail_layer
from amct_tensorflow.optimizer import bn_fusion_utils as bn_utils
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_info_generator import QuantInfoGenerator
from amct_tensorflow.utils.quant_ops import add_context_to_name

from amct_tensorflow.utils.log import LOGGER

__all__ = ['AdjustBatchToSpaceBNPass']


class AdjustBatchToSpaceBNPass(BaseFusionPass):
    """
    Function: Adjust 'conv2d -> batchtospace -> bn' structure to be
        fused in ConvBnFusionPass.
    APIs: match_pattern, do_pass
    """
    def __init__(self, skip_param=None, outputs=None):
        BaseFusionPass.__init__(self)
        if skip_param is None:
            skip_param = dict()
        do_fusion = skip_param.get('do_fusion')
        skip_layers = skip_param.get('skip_layers')
        skip_layers_fusible = skip_param.get('skip_layers_fusible')

        if do_fusion is None:
            self.do_fusion = True
        else:
            self.do_fusion = do_fusion

        if skip_layers is None:
            self.skip_layers = []
        else:
            self.skip_layers = skip_layers

        if skip_layers_fusible is None:
            self.skip_layers_fusible = dict.fromkeys(self.skip_layers, False)
        else:
            self.skip_layers_fusible = skip_layers_fusible

        if outputs is None:
            self.outputs = []
        else:
            self.outputs = outputs

        self.structure = dict()
        self.batchtospace_bn = ['Conv2D', 'BatchToSpaceND', 'BiasAdd']

    def match_pattern(self, operation):
        """
        Function: Matches the pattern "Conv2D + BatchToSpaceND + BN"
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type != self.batchtospace_bn[0]:
            return False

        # check conv2d's filter is placeholder
        if not bn_utils.check_invalid_fuse(operation):
            return False

        def is_skip():
            ''' check whether layer is skiped'''
            if self.do_fusion and operation.name in self.skip_layers \
                    or not self.do_fusion:
                self.skip_layers_fusible[operation.name] = True
                return True
            return False

        # match struct
        is_batchtospace_bn = self._pattern_batchtospace_bn(operation)
        if is_batchtospace_bn and not is_skip():
            return True

        return False

    def do_pass(self, object_op):
        """
        Function: change "batchtospace -> bn" to "bn -> batchtospace"
            for matched pattern
        Inputs:
            object_op: matched operation
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        matched_relation = self.structure.get(object_op.name)
        bts_op = matched_relation[0]
        bns_op = matched_relation[1]
        # next_op can be conv2d or biasadd
        next_op = matched_relation[2]
        # check data_format
        conv_data_format =\
            bn_utils.get_data_format(next_op.get_attr('data_format'))
        bns_data_format =\
            bn_utils.get_data_format(bns_op.get_attr('data_format'))
        if conv_data_format != bns_data_format:
            LOGGER.push_debug_message(
                "layer {} don't match conv2d or biasadd for data_format."
                    .format(bns_op.name), "AdjustBatchToSpaceBNPass")
            return [], []
        # check channel_out length
        fuse_parameters = bn_utils.get_bn_params(bns_op)
        try:
            bn_utils.check_length(
                next_op.outputs[0], fuse_parameters, conv_data_format)
        except RuntimeError:
            LOGGER.push_debug_message(
                "layer {} don't match conv2d or biasadd for channel size."
                    .format(bns_op.name), "AdjustBatchToSpaceBNPass")
            return [], []
        finally:
            pass

        # adjust batchtospace_bn -> bn_batchtospace
        self._adjust_batchtospace_edge(object_op)
        is_tail = is_tail_layer(bns_op)

        # refresh outputs
        if bns_op.name in self.outputs:
            index = self.outputs.index(bns_op.name)
            self.outputs[index] = bts_op.name

        if is_tail and not self.outputs:
            LOGGER.push_warning_message(
                'Fused BN at the end of the network! ' \
                'You need to replace the old output node by the new output ' \
                'node in inference process! \n' \
                '{}The name of the old output node is \'{}\'\n' \
                '{}The name of the new output node is \'{}\''.format(
                    '>' * 30, bns_op.outputs[0].name,
                    '<' * 30, bts_op.outputs[0].name),
                module_name='adjust_batchtospace_bn_pass')

        return [], []

    def _pattern_batchtospace_bn(self,
                                 object_op,
                                 support_is_training=(True, False)):
        """
        match struct batchtospace_bn
        Returns:
                True: matched
                False: mismatch
        """
        # check size of conv2d's outputs
        if len(object_op.outputs[0].consumers()) != 1:
            LOGGER.push_debug_message(
            "layer {} cannot be fused for it doesn't connect to one node only."
                    .format(object_op.name), "AdjustBatchToSpaceBNPass")
            return False
        # match biasadd first
        next_tensor = object_op.outputs[0]
        if next_tensor.consumers()[0].type == self.batchtospace_bn[2]:
            next_tensor = next_tensor.consumers()[0].outputs[0]
            # check bias param is placeholder
            if not bn_utils.check_invalid_fuse(next_tensor.op):
                return False

        next_op = next_tensor.op
        # match batchtospace second
        if len(next_op.outputs[0].consumers()) != 1\
                or next_op.outputs[0].consumers()[0].type !=\
                    self.batchtospace_bn[1]:
            LOGGER.push_debug_message(
            "layer {} cannot be fused for it doesn't connect to one node only."
                    .format(next_op.name), "AdjustBatchToSpaceBNPass")
            return False
        bts_op = next_op.outputs[0].consumers()[0]

        # match bn third
        if len(bts_op.outputs[0].consumers()) != 1 \
                or bts_op.outputs[0].consumers()[0].type not in FUSE_BN_TYPES:
            LOGGER.push_debug_message(
            "layer {} cannot be fused for it doesn't connect to bn layer only."
                    .format(bts_op.name), "AdjustBatchToSpaceBNPass")
            return False
        bns_op = bts_op.outputs[0].consumers()[0]
        # check bn's attr is_training
        if bns_op.get_attr('is_training') not in support_is_training:
            return False

        # save matched pattern relation
        self.structure[object_op.name] = [bts_op, bns_op, next_op]

        return True

    def _adjust_batchtospace_edge(self, object_op):
        """ adjust structure conv2d_batchtospace_bn """
        matched_relation = self.structure.get(object_op.name)
        bts_op = matched_relation[0]
        bns_op = matched_relation[1]
        next_op = matched_relation[2]

        conv_data_format =\
            bn_utils.get_data_format(next_op.get_attr('data_format'))
        fuse_parameters = bn_utils.get_bn_params(bns_op)

        # add new bn
        context, _ = split_name_scope(bns_op.name)
        context = add_context_to_name(context, 'new_bn')
        new_bn_in = next_op.outputs[0]
        axis_dim = _find_axis(conv_data_format)
        with tf.compat.v1.variable_scope(None, default_name=context):
            bn_out = tf.compat.v1.layers.batch_normalization(
                inputs=new_bn_in,
                axis=axis_dim,
                epsilon=fuse_parameters.get("epsilon"))

            new_bn_op = bn_out.op
            replace_inputs_tensor(fuse_parameters.get("scale"),
                                  new_bn_op.inputs[1], [new_bn_op])
            replace_inputs_tensor(fuse_parameters.get("offset"),
                                  new_bn_op.inputs[2], [new_bn_op])
            replace_inputs_tensor(fuse_parameters.get("mean"), new_bn_op.inputs[3],
                                  [new_bn_op])
            replace_inputs_tensor(fuse_parameters.get("variance"),
                                  new_bn_op.inputs[4], [new_bn_op])
        QuantInfoGenerator().set_bias_add_anchor(new_bn_op.name, [bns_op.name])

        # step1: batch2space's outputs -> bn's consumers
        replace_inputs_tensor(bts_op.outputs[0],
                              bns_op.outputs[0], bns_op.outputs[0].consumers())
        # step2: new_bn's outputs -> batch2space's inputs
        replace_inputs_tensor(bn_out, bts_op.inputs[0], [bts_op])


def _find_axis(conv_data_format):
    """ find conv's axis """
    if conv_data_format in (b'NCHW', 'NCHW'):
        axis_dim = 1
    else:
        axis_dim = 3
    return axis_dim