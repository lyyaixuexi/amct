#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace bulk BN to Integrating BN for all layer.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_tensorflow.optimizer_ir.base_ir_fusion_pass import BaseIRFusionPass
from amct_tensorflow.utils.utils_vars import PATTERN_CONFIG
from amct_tensorflow.pattern.match_pattern import PatternHelper
from amct_tensorflow.utils.utils_vars import ADD_TYPES
from amct_tensorflow.utils.quant_ops import create_context
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.optimizer.replace_bn_pass import check_fusable

__all__ = ['ReplaceGraphIRBNPass']


class ReplaceGraphIRBNPass(BaseIRFusionPass):
    """
    Function: replace bulk bn nodes by integrated FakeTrainBN node in the graphIR
    APIs: match_pattern, do_pass,
    """
    def __init__(self):
        BaseIRFusionPass.__init__(self)
        self.pattern_config = None
        self.bulk_nodes = {}

    def match_pattern(self, object_node):
        """
        Function: Matches the bulk bn pattern.
        Inputs:
            object_node: node to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if object_node.type in ADD_TYPES and object_node.type != 'BiasAdd':
            for config_name, pattern_config in PATTERN_CONFIG.items():
                if 'training_' not in config_name or 'bn' not in config_name:# training_True or training_False
                    continue
                flag, bulk_nodes = PatternHelper.match_patternir(object_node,
                                                    pattern_config)
                if flag:
                    self.pattern_config = pattern_config
                    self.bulk_nodes[object_node.name] = bulk_nodes
                    return True
        return False

    def do_pass(self, object_node):
        """
        Function: Replace bulk BN to integrated BN
        """
        graph_ir = self.graph
        bulk_nodes = self.bulk_nodes.get(object_node.name)
        end_nodes = self.pattern_config.get('END')
        mul_node = bulk_nodes[int(list(end_nodes.keys())[0])]
        bn_input, input_ind = mul_node.get_producer(0) # BN's producer
        if check_fusable(bn_input.op):
            bn_outputs, output_inds = object_node.get_consumers(0)# BN's Consumer
            # rename bn node
            context = create_context(split_name_scope(object_node.name)[0], quant_type='replace_bn')
            fakebn = graph_ir.create_fake_node(
                        node_name="".join((context, '/batch_normalization/FusedBatchNormV3')),
                        node_type='FakeFusedBatchNormV3',
                        anchors=[mul_node.input_anchors[0], object_node.output_anchors[0]],
                        node_index=object_node._basic_info.get('node_index'))
            # cut BN'sproducer ---> pool
            graph_ir.remove_edge(bn_input, input_ind, mul_node, 0)
            graph_ir.add_edge(bn_input, input_ind, fakebn, 0)
            # cur AddV2 ---> "BN's consumers"
            for bn_output, output_ind in zip(bn_outputs, output_inds):
                graph_ir.remove_edge(object_node, 0, bn_output, output_ind)
                graph_ir.add_edge(fakebn, 0, bn_output, output_ind)
