#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace bulk BN to Integrating BN for all layer.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_tensorflow.optimizer_ir.base_ir_fusion_pass import BaseIRFusionPass
from amct_tensorflow.utils.utils_vars import PATTERN_CONFIG
from amct_tensorflow.pattern.match_pattern import PatternHelper

__all__ = ['ReplaceDropOutPass']


class ReplaceDropOutPass(BaseIRFusionPass):
    """
    Function: Replace bulk dropout nodes to Integrating dropout node.
    APIs: match_pattern, do_pass,
    """
    def __init__(self):
        BaseIRFusionPass.__init__(self)
        self.pattern_config = {}
        self.bulk_nodes = {}

    def match_pattern(self, object_node):
        """
        Function: Matches the bulk dropout nodes..
        Inputs:
            object_node: node to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if object_node.type == 'Mul':
            for config_name, pattern_config in PATTERN_CONFIG.items():
                flag, bulk_nodes = PatternHelper.match_patternir(object_node,
                                                      pattern_config)
                if flag and 'dropout' in config_name:
                    self.pattern_config = pattern_config
                    self.bulk_nodes[object_node.name] = bulk_nodes
                    return True
        return False

    def do_pass(self, object_node):
        """
        Function: Replace bulk dropout to a fake dropout nodes.
        """
        graph_ir = self.graph
        bulk_nodes = self.bulk_nodes.get(object_node.name)
        target_nodes = self.pattern_config.get('OUTPUT')
        mul_node = bulk_nodes[target_nodes.get('Mul')]
        dropout_input, input_ind = mul_node.get_producer(0)# dropout's producer
        dropout_outputs, output_inds = object_node.get_consumers(0)# dropout's consumers
        # create a fake dropout
        fake_dropout_node = graph_ir.create_fake_node(
                                node_name=object_node.name,
                                node_type='Dropout',
                                anchors=[dropout_input.output_anchors[input_ind], object_node.output_anchors[0]],
                                node_index=object_node._basic_info.get('node_index'))
        # cut "dropout's producer" ---  mul
        graph_ir.remove_edge(dropout_input, input_ind, mul_node, 0)
        graph_ir.add_edge(dropout_input, input_ind, fake_dropout_node, 0)
        # cut mul_1 --- "dropout's consumers"
        for dropout_output, output_ind in zip(dropout_outputs, output_inds):
            graph_ir.remove_edge(object_node, 0, dropout_output, output_ind)
            graph_ir.add_edge(fake_dropout_node, 0, dropout_output, output_ind)
