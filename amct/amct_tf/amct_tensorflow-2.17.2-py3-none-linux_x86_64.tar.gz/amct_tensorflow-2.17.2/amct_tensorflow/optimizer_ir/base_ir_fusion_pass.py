#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Base class for fusion passes
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

__all__ = ['BaseIRFusionPass']


class BaseIRFusionPass():
    """
    Function: Base class of graph optimizer pass
    APIs: set_up, tear_down, match_pattern, do_pass, reset_run_list, run
    """
    def __init__(self, outputs=None):
        """
        Function: init object
        Inputs: None
        Return: None
        """
        self.outputs = outputs
        self.graph = None
        self.records = None

    def set_up(self):
        """
        Function: Do some set up for pass
        Inputs: None
        Return: None
        """

    def tear_down(self):
        """
        Function: Do some tear down for pass
        Inputs: None
        Return: None
        """

    def supplement_pass(self):
        """
        Function: supplement grapg modify after do_pass
        Inputs: None
        Return: None
        """

    def match_pattern(self, object_node):
        """
        Function: Match pattern of specific structure in graph
        Inputs: None
        Return: None
        """
        return False


    def do_pass(self, object_node):
        """
        Function: Do actual fusion operation for a matched pattern
        Inputs: object_op: matched operation
        Return:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """

    def reset_run_list(self, object_op, run_list_value):
        """
        Function: Save the value in run_list
        Inputs:
            object_op: matched operation
            run_list_value: np.arrsy, the value of tensor in run_list
        Return: None
        """

    def run(self, graph):
        """
        Function: Do actual fusion operation for graph
        Inputs: graph: tf.Graph to be fused
        Return: graph: tf.Graph fused
        """
        self.set_up()
        self.graph = graph

        # Step1: match pattern and record first matched operation
        matched_operations = []
        for operation in graph.get_operations():
            if self.match_pattern(operation):
                matched_operations.append(operation)
        # Step2: do each matched node fusion operation
        for _, operation in enumerate(matched_operations):
            self.do_pass(operation)
        # Step3: add global operations
        self.supplement_pass()
        return graph, matched_operations
