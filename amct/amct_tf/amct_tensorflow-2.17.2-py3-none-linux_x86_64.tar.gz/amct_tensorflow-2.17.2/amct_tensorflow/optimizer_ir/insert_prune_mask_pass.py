#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace bulk BN to Integrating BN for all layer.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

from amct_tensorflow.optimizer_ir.base_ir_fusion_pass import BaseIRFusionPass
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.utils import quant_ops
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.capacity import CAPACITY
from amct_tensorflow.common.utils.prune_record_attr_util import AttrProtoHelper
from amct_tensorflow.utils.retrain_alg import _decorate_enter

__all__ = ['InsertPruneMaskPass']

_PRUNE_OP = load()


class InsertPruneMaskPass(BaseIRFusionPass):
    """
    Function:
        Insert Mask Ops in tf.Graph
    """
    def __init__(self):
        BaseIRFusionPass.__init__(self)

    @staticmethod
    def match_pattern(object_node):
        """
        Function: Matches the active-prunable ops
        Inputs:
            object_node: node to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if object_node.type in (CAPACITY.get_value('PRUNABLE_TYPES') + \
            CAPACITY.get_value('SELECTIVE_PRUNABLE_TYPES')):
            return True
        return False

    def do_pass(self, object_node):
        """
        Function: insert mask ops
        Inputs:
            object_node: active-prunable ops to process
        """
        wgt_input = object_node.op.inputs[1]
        context = wgt_input.op.name
        with tf.compat.v1.variable_scope("".join([context, '/prune']),
                                        values=[wgt_input],
                                        reuse=tf.compat.v1.AUTO_REUSE) as scope:
            scope.set_partitioner(None)
            if object_node.has_attr('active_prune_records') and \
                object_node.get_attr('active_prune_records') and not \
                is_tensor(object_node.get_attr('out_channel_tensor')):
                # node is actively prunable and bcp has not been inserted yet
                add_bcp(object_node, self.graph)
            if is_tensor(object_node.get_attr('out_channel_tensor')) \
                or has_tensor(object_node.get_attr('in_channel_tensors')):
                # bcp has been inserted or node needs to be passively pruned
                add_mask(object_node, self.graph)
            if object_node.has_attr('selective_prune_records') and \
                object_node.get_attr('selective_prune_records') and not \
                is_tensor(object_node.get_attr('selective_prune_mask_tensor')):
                # node is selective prunable and selective_mask_gen has not been inserted yet
                add_selective_mask_gen(object_node, wgt_input, self.graph)


def is_tensor(var):
    """Funtion: check if var is a tensor"""
    return isinstance(var, tf.Tensor)


def has_tensor(var_list):
    """Funtion: check if list contains any tensor"""
    for var in var_list:
        if isinstance(var, tf.Tensor):
            return True
    return False


def add_selective_mask_gen(object_node, wgt_input, graph_ir):
    has_passive_prune = has_tensor(object_node.get_attr('in_channel_tensors'))
    if has_passive_prune:
        if len(object_node.get_attr('in_channel_tensors')) > 1:
            remain_channels = check_concat(object_node, graph_ir, wgt_input)
        else:
            remain_channels = object_node.get_attr('in_channel_tensors')[0]
    else:
        num_in_channel = object_node.get_attr('in_channels')
        remain_channels = make_variables('filled', num_in_channel, tf.ones_initializer(), wgt_input.dtype)
        remain_channels = _decorate_enter(wgt_input, object_node.name, [remain_channels])[0]
    mask_container, batch_count = \
        prepare_selective_mask_var(wgt_input, object_node.name)
    prune_axis = object_node.get_attr('selective_prune_axis')
    update_freq = object_node.get_attr('update_freq')
    mask_gen = _PRUNE_OP.selective_mask_gen(
        wgt_input,
        batch_count,
        mask_container,
        remain_channels,
        N=2,
        M=4,
        prune_axis=prune_axis,
        update_freq=update_freq
    )
    object_node.set_attr('selective_prune_mask_tensor', mask_gen)
    masked_wgt = _PRUNE_OP.mask(wgt_input, mask_gen)
    quant_ops.relink_tensor(object_node.op.inputs[1], masked_wgt, object_node.op)


def prepare_selective_mask_var(wgt_tensor, op_name):
    dtype = wgt_tensor.dtype
    batch_count = tf.compat.v1.get_variable(
        name='batch_count',
        shape=[1],
        dtype=dtype,
        initializer=tf.zeros_initializer(),
        trainable=False,
        use_resource=False)
    batch_count = _decorate_enter(wgt_tensor, op_name, [batch_count])[0]
    mask_container = tf.compat.v1.get_variable(
        name='mask_container',
        shape=wgt_tensor.shape,
        dtype=dtype,
        initializer=tf.zeros_initializer(),
        trainable=False,
        use_resource=False)
    mask_container = _decorate_enter(wgt_tensor, op_name, [mask_container])[0]
    return mask_container, batch_count


def add_bcp(object_node, graph_ir):
    '''Function: Insert BalancedL2Norm op for active filter purning'''
    size_splits = []
    # split in consumers
    for active_record in object_node.get_attr('active_prune_records'):
        attr_helper = AttrProtoHelper(active_record.producer[0])
        size_splits.append(attr_helper.get_attr_value('end') - attr_helper.get_attr_value('begin'))
    wgt_inputs = []
    prune_axis = []
    producer_nodes = []
    prune_ratios = []
    all_ascend_optimized = []
    for producer in object_node.get_attr('active_prune_records')[0].producer:
        # elt-wise case
        producer_node = graph_ir.get_node_by_name(producer.name)
        prune_ratios.append(producer_node.get_attr('prune_ratio'))
        producer_nodes.append(producer_node)
        wgt_inputs.append(producer_node.op.inputs[1])
        prune_axis.append(producer_node.get_attr('prune_axis'))
        all_ascend_optimized.append(producer_node.get_attr('ascend_optimized'))

    if len(set(prune_ratios)) > 1:
        LOGGER.push_warning_message("Use min prune ratio for elt-wise group of node: %s" % (object_node.name))
    ascend_optimized = any(all_ascend_optimized)
    prune_ratios = [min(prune_ratios)]*len(object_node.get_attr('active_prune_records'))
    remain_channels_container, batch_count = prepare_bcp_variables(size_splits, wgt_inputs, object_node.name)
    out_channels = _PRUNE_OP.balanced_l2_norm(
        wgt_inputs,
        batch_count,
        remain_channels_container,
        prune_axis=prune_axis,
        size_splits=size_splits,
        prune_ratios=prune_ratios,
        ascend_optimized=ascend_optimized,
        is_group=producer_nodes[0].get_attr('is_group_conv'))
    [node.set_attr('out_channel_tensor', out_channels[-1]) for node in producer_nodes]
    sync_bcp_consumer_c_in(object_node, graph_ir, out_channels)


def sync_bcp_consumer_c_in(object_node, graph_ir, out_channels):
    '''Function: sync consumer ops' c_in channel'''
    consumer_names_no_split = get_consumer_name_set(object_node.get_attr('active_prune_records')[0])
    consumer_names_with_split = set()
    for active_record in object_node.get_attr('active_prune_records'):
        consumer_names = get_consumer_name_set(active_record)
        consumer_names_no_split &= consumer_names
        consumer_names_with_split ^= consumer_names
    if len(object_node.get_attr('active_prune_records')) > 1:
        for consumer_name in consumer_names_with_split:
            # consumer pick c_in from splits
            consumer_node = graph_ir.get_node_by_name(consumer_name)
            split_index = object_node.get_attr('active_prune_records').index(
                consumer_node.get_attr('passive_prune_records')[0])
            consumer_node.get_attr(
                'in_channel_tensors').append(out_channels[split_index])

    for consumer_name in consumer_names_no_split:
        consumer_node = graph_ir.get_node_by_name(consumer_name)
        consumer_node.get_attr(
            'in_channel_tensors').append(out_channels[-1])


def get_consumer_name_set(active_record):
    '''Function: convert consumer names to a set'''
    return {consumer.name for consumer in active_record.consumer}


def prepare_bcp_variables(size_splits, wgt_inputs, op_name):
    '''Function: prepare variables requried for BalancedL2Norm op'''
    dtype = wgt_inputs[0].dtype
    batch_count = make_variables(
        name='batch_count',
        shape=(1),
        initializer=tf.zeros_initializer(),
        dtype=dtype)
    remain_channels_container = []
    for idx, size in enumerate(size_splits):
        remain_channels_container.append(
            make_variables(
                name="".join(('container_', str(idx))),
                shape=size,
                initializer=tf.ones_initializer(),
                dtype=dtype))
    if idx and idx > 0:
        remain_channels_container.append(
            make_variables(
                name="".join(('container_', str(idx+1))),
                shape=sum(size_splits),
                initializer=tf.ones_initializer(),
                dtype=dtype))
    # add enter if object_op is in while loop
    remain_channels_container = _decorate_enter(wgt_inputs[0], op_name, remain_channels_container)
    batch_count = _decorate_enter(wgt_inputs[0], op_name, [batch_count])[0]
    return remain_channels_container, batch_count


def add_mask(object_node, graph_ir):
    '''Function: Insert MaskGen and Mask op'''
    wgt_tensor = object_node.op.inputs[1]
    out_channels = object_node.get_attr('out_channel_tensor')
    if len(object_node.get_attr('in_channel_tensors')) > 1:
        producer_out_channels = check_concat(object_node, graph_ir, wgt_tensor)
    else:
        if not has_tensor(object_node.get_attr('in_channel_tensors')):
            num_in_channel = object_node.get_attr('in_channels')
            producer_out_channels = make_variables('filled', num_in_channel, tf.ones_initializer(), wgt_tensor.dtype)
            producer_out_channels = _decorate_enter(wgt_tensor, object_node.name, [producer_out_channels])[0]
        else:
            producer_out_channels = object_node.get_attr('in_channel_tensors')[0]
    if not is_tensor(object_node.get_attr('out_channel_tensor')):
        num_out_channel = object_node.get_attr('out_channels')
        out_channels = make_variables('filled', num_out_channel, tf.ones_initializer(), wgt_tensor.dtype)
        out_channels = _decorate_enter(wgt_tensor, object_node.name, [out_channels])[0]
    if object_node.type == 'MatMul' and object_node.op.get_attr('transpose_b'):
        # matmul and transpose_b
        mask = _PRUNE_OP.mask_gen(out_channels, producer_out_channels)
    else:
        mask = _PRUNE_OP.mask_gen(producer_out_channels, out_channels)
    masked_wgt = _PRUNE_OP.mask(wgt_tensor, mask)
    quant_ops.relink_tensor(wgt_tensor, masked_wgt, object_node.op)


def check_concat(object_node, graph_ir, wgt_tensor):
    '''Function: concat producers' out_channels if producers are in concat structure'''
    end = 0
    out_channels_to_concat = []
    for passive_record in object_node.get_attr('passive_prune_records'):
        producer_name = passive_record.producer[0].name
        attr_helper = AttrProtoHelper(passive_record.producer[0])
        offset = attr_helper.get_attr_value('begin') - end
        producer_node = graph_ir.get_node_by_name(producer_name)
        if is_tensor(producer_node.get_attr('out_channel_tensor')):
            out_channels_to_concat.append(
                producer_node.get_attr('out_channel_tensor'))
        else: # any input branch of concat is missing
            out_channels_to_concat.append(
                make_variables('filled', offset, tf.ones_initializer(), wgt_tensor.dtype))
        end += attr_helper.get_attr_value('end')
    if end < object_node.get_attr('in_channels'):
        # last branch of concat is missing
        offset = object_node.get_attr('in_channels') - end
        out_channels_to_concat.append(
                make_variables('filled', offset, tf.ones_initializer(), wgt_tensor.dtype))
    return tf.compat.v1.concat(out_channels_to_concat, axis=0)


def make_variables(name, shape, initializer, dtype):
    '''Function: make variables'''
    variable = tf.compat.v1.get_variable(
        name=name,
        initializer=initializer(shape=[shape], dtype=dtype),
        trainable=False,
        use_resource=False)
    read_op = variable.op.outputs[0].consumers()[-1]
    return read_op.outputs[0]
