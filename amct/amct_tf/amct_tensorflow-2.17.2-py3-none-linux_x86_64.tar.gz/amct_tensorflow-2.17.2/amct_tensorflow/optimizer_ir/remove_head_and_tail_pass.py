#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace bulk BN to Integrating BN for all layer.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_tensorflow.optimizer_ir.base_ir_fusion_pass import BaseIRFusionPass
from amct_tensorflow.utils.utils_vars import PRUNABLE_TYPES
from amct_tensorflow.utils.utils_vars import SAFE_OPS

__all__ = ['RemoveHeadAndTailPass']


class RemoveHeadAndTailPass(BaseIRFusionPass):
    """
    Function:
        remove the input-pre-process and output-postprocess sections
        in the graphIR.
    """
    def __init__(self):
        BaseIRFusionPass.__init__(self)

    def run(self, graph_ir):
        '''
        Function:
            remove nodes with no producer or consumer until meets PRUNABLE_TYPES
        '''
        self.graph = graph_ir
        converge = False
        while not converge:
            converge = True
            for node in graph_ir.nodes[:]:
                if node.type in PRUNABLE_TYPES + ['Conv2DBackpropInput']:
                    continue
                # check if no producer
                has_no_producer = node.is_head()
                # check if consumer is fake Output node
                has_no_consumer = node.is_tail()
                if has_no_consumer and has_no_producer:
                    # isolated node, delete straightforwardly
                    self.delete_and_disconnect_output(node)
                    converge = False
                elif has_no_producer:
                    # delete nodes with no producer
                    self.delete_and_disconnect_output(node)
                    converge = False
                elif has_no_consumer:
                    # replace tail nodes by a fake output Node
                    self.replace_node_by_fake_output_node(node)
                    self.delete_and_disconnect_output(node)
                    converge = False

        self.fuse_safe_nodes()
        self.graph._renumber_node_index()
        return self.graph, []

    def replace_node_by_fake_output_node(self, node):
        '''
        Function：
            replace tail node by a fake output Node

            producer       producer                producer           producer
                |     -->     |                       |                  |
            tail_node      fake_output     or      tail_node  -->    fake_output_2
                                                      |
                                                 fake_output_1
        '''
        for in_index in range(len(node.input_anchors)):
            producer_node, output_ind = node.get_producer(in_index)
            if producer_node:
                self.graph.remove_edge(producer_node, output_ind, node, in_index)
                fake_output_node = self.graph.create_fake_node(
                    node_name='output',
                    node_type='Output',
                    anchors=[producer_node.output_anchors[output_ind], []],
                    node_index=len(self.graph.nodes))
                self.graph.add_edge(producer_node, output_ind, fake_output_node, 0)

    def delete_and_disconnect_output(self, node):
        '''
        Function:
            disconnect node from its consumers and then delete the node
        '''
        for output_ind, _ in enumerate(node.output_anchors):
            peer_input_nodes, input_ind = node.get_consumers(output_ind)
            if peer_input_nodes:
                for input_node, input_ind in zip(peer_input_nodes, input_ind):
                    self.graph.remove_edge(node, output_ind, input_node, input_ind)
        self.graph.remove_node(node)

    def fuse_safe_nodes(self):
        '''delete some known nodes not sensitive to dimensions'''
        in_index = 0
        out_index = 0
        for node in self.graph.nodes[:]:
            if node.type in SAFE_OPS and node.name not in self.graph.outputs:
                self._delete_safe_node(node, in_index, out_index)
                self.graph.nodes.remove(node)

    def _delete_safe_node(self, node, in_idx, out_idx):
        '''delete node'''
        producer, producer_out_idx = node.get_producer(in_idx)
        self.graph.remove_edge(producer, producer_out_idx, node, in_idx)
        output_anchor = node.get_output_anchor(out_idx)
        peer_in_anchors = output_anchor.get_peer_input_anchor()
        for anchor in peer_in_anchors[:]:
            consumer = anchor.node
            consumer_in_idx = anchor.index
            self.graph.remove_edge(node, out_idx, consumer, consumer_in_idx)
            self.graph.add_edge(producer, producer_out_idx,
                            consumer, consumer_in_idx)
            anchor.set_name(producer.get_output_anchor(producer_out_idx).name)
