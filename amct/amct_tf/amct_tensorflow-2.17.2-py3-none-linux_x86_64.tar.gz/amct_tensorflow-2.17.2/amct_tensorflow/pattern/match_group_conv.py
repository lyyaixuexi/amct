#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Find group_conv pattern from graph.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import copy
from operator import eq
from collections import namedtuple

from amct_tensorflow.pattern.utils import get_layer_ops_by_type
from amct_tensorflow.utils.utils_vars import FUSE_BN_TYPES
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.configuration.check_graph import GraphChecker

GROUP_CONV_CONCAT = ["ConcatV2", "Concat"]
GROUP_CONV_SPLIT = ["Split"]

GroupConvInfo = namedtuple('GroupConvInfo', ['is_group_conv', 'conv_names', 'bias_names', 'concat_name'])


class GroupConv():
    """
    Function: group conv class
    APIS: get_name, get_attr, get_split, get_convs, get_biases, get_concat,
        get_bn
    """
    def __init__(self, group_conv_names, graph):
        """
        Function: init object
        Inputs:
            group_conv_names:
                split_name: string
                conv_names: a list of string
                bias_names: a list of string
                concat_name:string
                bn_name: string
            graph: the graph which group_conv is in.
        Return: None
        """
        self.names = group_conv_names
        self.graph = graph

        self.group_size = len(self.names['conv_names'])
        if self.group_size < 2:
            raise RuntimeError("Init group_conv fail! There's must be 2 or "
                               "more conv_names for group_conv.")

        if not self.find_data_format():
            LOGGER.push_debug_message(
                "GroupConv.find_data_format() failed "
                "in %s" % (self.names['split_name']), 'match_group_conv')
            raise RuntimeError("data_format in convs differ.")
        self.find_split_dim()

        if not self.check_split_concat():
            LOGGER.push_debug_message(
                "GroupConv.check_split_concat() failed "
                "in %s" % (self.names['split_name']), 'match_group_conv')
            raise RuntimeError("split_dim and concat_dim should be in 'C'.")

        if not self.cmp_convs():
            LOGGER.push_debug_message(
                "GroupConv.cmp_convs() failed "
                "in %s" % (self.names['split_name']), 'match_group_conv')
            raise RuntimeError("convs' attributes should be same.")

        if self.names['bn_name'] is None:
            self.names['name'] = "~".join([
                "groupconv", self.names['split_name'],
                str(self.group_size), self.names['concat_name']
            ])
        else:
            self.names['name'] = "~".join([
                "groupconv", self.names['split_name'],
                str(self.group_size), self.names['bn_name']
            ])

        self.quant_info = dict()
        self.quant_info['enable_group_cali'] = False
        self.quant_info['act_config'] = None
        self.quant_info['enable_group_save'] = False
        self.quant_info['act_factor'] = False

    @staticmethod
    def is_group_conv_structure(split_op):
        """
        Function: Judge the group conv by an op("Split")
        """
        if split_op.type != GROUP_CONV_SPLIT[0]:
            return GroupConvInfo._make([False, None, None, None])

        group_size = len(split_op.outputs)
        if group_size < 2:
            return GroupConvInfo._make([False, None, None, None])
        conv_names = list()
        bias_names = list()
        for output_index in range(group_size):
            conv_name, bias_name, concat_name = find_branch_pattern(
                split_op, output_index)
            # set branch 0 as target branch
            if output_index == 0:
                group_concat_name, has_bias = _set_branch_target_pattern(
                    concat_name, bias_name)
            # compare branch with  params
            is_same = _cmp_branch(group_concat_name, has_bias, conv_name,
                                  bias_name, concat_name)
            if not is_same:
                is_gropu_conv = False
                return GroupConvInfo._make([is_gropu_conv, None, None, None])
            # save when it's a valid branch
            conv_names.append(conv_name)
            if has_bias:
                bias_names.append(bias_name)
        is_gropu_conv = True
        return GroupConvInfo._make([is_gropu_conv, conv_names, bias_names, concat_name])

    @staticmethod
    def group_names(split_name, conv_names, bias_names, concat_name, bn_name):
        '''group name in group_conv's structure '''
        group_conv_names = dict()
        group_conv_names['split_name'] = split_name
        group_conv_names['conv_names'] = conv_names
        group_conv_names['bias_names'] = bias_names
        group_conv_names['concat_name'] = concat_name
        group_conv_names['bn_name'] = bn_name

        return group_conv_names

    def get_name(self, item):
        """ get group_conv's name"""
        return self.names[item]

    def get_attr(self, attr_name):
        """ get group_conv's attrs inclding group_size, split_dim, data_format,
            reshape_dims, concat_dim
        """
        if attr_name == 'group_size':
            return self.group_size
        if attr_name == 'split_dim':
            return self.split_dim
        if attr_name == 'data_format':
            return self.data_format
        if attr_name == 'reshape_dims':
            if self.data_format in (b'NHWC', 'NHWC'):
                reshape_dims = [1, 1, 1, -1]
            elif self.data_format in (b'NCHW', 'NCHW'):
                reshape_dims = [1, -1, 1, 1]
            elif self.data_format in (b'NDHWC', 'NDHWC'):
                reshape_dims = [1, 1, 1, 1, -1]
            else:  # NCDHW
                reshape_dims = [1, -1, 1, 1, 1]
            return reshape_dims
        if attr_name == 'concat_dim':
            concat_dim = -1
            return concat_dim
        raise ValueError('unexcept attr %s for group_conv' % (attr_name))

    def find_split_dim(self):
        """ get group_conv's split_dim"""
        if self.data_format in (b'NCHW', 'NCHW', b'NCDHW', 'NCDHW'):
            self.split_dim = 1
        else:
            self.split_dim = -1

    def find_data_format(self):
        """ get group_conv's data_format"""
        data_formats = list()
        data_formats.extend(
            [conv.get_attr('data_format') for conv in self.get_convs()])

        biases = self.get_biases()
        if biases is not None:
            data_formats.extend(
                [bias.get_attr('data_format') for bias in biases])

        def get_c_dim(data_format):
            if data_format in (b'NCHW', 'NCHW', b'NCDHW', 'NCDHW'):
                return 1
            return -1

        data_c_dim = set(get_c_dim(data_format) for data_format in data_formats)
        if len(data_c_dim) != 1:
            return False

        self.data_format = data_formats[0]
        bn_op = self.get_bn()
        if bn_op and bn_op.get_attr('data_format') != self.data_format:
            self.delete_bn()
        return True

    def cmp_convs(self):
        """ compare convs to ensure conv's attrs are same. """
        convs = self.get_convs()

        def get_conv_attrs(conv):
            """ get conv's attrs """
            dilations = conv.get_attr('dilations')
            data_type = conv.get_attr('T')
            data_format = conv.get_attr('data_format')
            strides = conv.get_attr('strides')
            padding = conv.get_attr('padding')
            if conv.type == "Conv3D":
                explicit_paddings = None
            else:
                explicit_paddings = conv.get_attr('explicit_paddings')
            attrs = [
                dilations, data_type, data_format, strides, padding,
                explicit_paddings
            ]
            return attrs

        global_attrs = None
        for conv in convs:
            if global_attrs is None:
                global_attrs = get_conv_attrs(conv)
            else:
                attrs = get_conv_attrs(conv)
                if global_attrs != attrs:
                    return False

        return True

    def get_split(self):
        """ get group_conv's Split op """
        return self.graph.get_operation_by_name(self.names['split_name'])

    def get_convs(self):
        """ get group_conv's Conv2D ops """
        convs = [
            self.graph.get_operation_by_name(conv_name)
            for conv_name in self.names['conv_names']
        ]
        return convs

    def get_biases(self):
        """ get group_conv's BiasAdd ops """
        if self.names['bias_names']:
            biases = [
                self.graph.get_operation_by_name(bias_name)
                for bias_name in self.names['bias_names']
            ]
            return biases
        return None

    def get_concat(self):
        """ get group_conv's Concat op """
        return self.graph.get_operation_by_name(self.names['concat_name'])

    def get_bn(self):
        """ get group_conv's BN op """
        if self.names['bn_name']:
            return self.graph.get_operation_by_name(self.names['bn_name'])
        return None

    def check_split_concat(self):
        """check whether the split_dim is in C """
        split_op = self.get_split()
        split_in_shape = split_op.inputs[1].shape
        conv_cin_exp = split_in_shape[self.split_dim] // self.group_size
        for index in range(self.group_size):
            conv_cin = split_op.outputs[index].shape[self.split_dim]
            if conv_cin != conv_cin_exp:
                return False

        concat_op = self.get_concat()
        concat_out_shape = concat_op.outputs[0].shape
        concat_cin_exp = concat_out_shape[self.split_dim] // self.group_size
        if concat_op.type == 'ConcatV2':
            cancat_in_indexs = range(self.group_size)
        else:
            cancat_in_indexs = range(1, self.group_size + 1)
        for index in cancat_in_indexs:
            concat_cin = concat_op.inputs[index].shape[self.split_dim]
            if concat_cin != concat_cin_exp:
                return False

        return True

    def get_quant_info(self, item):
        """ get group_conv's act quant info """
        # valid item should be in ('quant_config', 'act_factor')
        return self.quant_info.get(item)

    def check_fuse(self, skip_fuse_layers=None,
                   support_is_training=(True, False)):
        """
        Function: check whether the group_conv can do fuse bn.
        """
        enable_fuse = False
        skip_fuse = False
        # check bn exist
        bn_name = self.get_name('bn_name')
        if bn_name is None:
            return enable_fuse, skip_fuse

        # check conv layer's placeholder
        valid_layers = GraphChecker.check_quantize_placeholder(
            self.graph, self.names['conv_names'])
        if len(valid_layers) != len(self.names['conv_names']):
            return enable_fuse, skip_fuse

        # check bn's attr is_training
        bn_op = self.graph.get_operation_by_name(bn_name)
        if bn_op.get_attr('is_training') not in support_is_training:
            return enable_fuse, skip_fuse

        enable_fuse = True

        if skip_fuse_layers is None:
            skip_fuse_layers = []
        skip_layers = [
            conv_name \
            for conv_name in self.names['conv_names']
            if conv_name in skip_fuse_layers
        ]
        if skip_layers:
            skip_fuse = True

        return enable_fuse, skip_fuse

    def check_cali(self, quant_config):
        """
        Function: check whether the group_conv can do calibration.
        """
        # conv layers' quant_configs exist and are the same
        layer_config = quant_config.get(self.names['conv_names'][0])
        if layer_config is None:
            return False, None

        group_conv_act_config = copy.deepcopy(layer_config.get('activation_quant_params'))

        for conv_name in self.names['conv_names']:
            layer_config = quant_config.get(conv_name)
            if layer_config is None or not eq(
                    group_conv_act_config,
                    layer_config.get('activation_quant_params')):
                return False, None

        enable_group_cali = True
        group_conv_act_config['batch_num'] = quant_config.get('batch_num')
        group_conv_act_config['need_offset'] = quant_config.get('need_offset')

        self.quant_info['enable_group_cali'] = True
        self.quant_info['act_config'] = group_conv_act_config

        return enable_group_cali, group_conv_act_config

    def check_save(self, quant_factors):
        """
        Function: check whether the group_conv can be saved.
        """
        # conv layers' quant_configs exist and are the same
        group_conv_quant_factor = copy.deepcopy(
            quant_factors.get(self.names['conv_names'][0]))
        if group_conv_quant_factor is None:
            return False, None

        def eq_factor(target_quant_factor, quant_factor):
            """
            Function: whether the contents in target_quant_factor
            are included in quant_factor.
            """
            equal_factor = ['data_scale', 'data_offset']
            for key in equal_factor:
                if target_quant_factor.get(key) != quant_factor.get(key):
                    return False

            return True

        del group_conv_quant_factor['weight_offset']
        del group_conv_quant_factor['weight_scale']
        for conv_name in self.names['conv_names']:
            layer_quant_factor = quant_factors.get(conv_name)
            if layer_quant_factor is None or not eq_factor(
                    group_conv_quant_factor, layer_quant_factor):
                return False, None

        self.quant_info['act_factor'] = group_conv_quant_factor
        self.quant_info['enable_group_save'] = True
        return True, group_conv_quant_factor

    def delete_bn(self):
        """ delete bn in range of group conv"""
        self.names['bn_name'] = None
        self.names['name'] = "~".join([
            "groupconv", self.names['split_name'],
            str(self.group_size), self.names['concat_name']
        ])

    def split_data_shape(self, shape):
        """ seperat split_op's input shape to get each conv's input shape.

        Args:
            shape (list): split_op's input shape

        Returns:
            list: conv's input shape
        """
        dims = len(shape)
        group = self.group_size
        # only dim on C is split, other dim is remain same
        new_shape = [(shape[dim] // group) if dim == self.split_dim else shape[dim] for dim in range(dims)]
        return new_shape


def find_branch_pattern(split_op, output_index):
    """
    Function: find the branch's pattern
        1. conv + bias + concat;
        2. conv + concat;
        3. others are invalid
    Return:
        1. conv + bias + concat: conv_name, bias_name, concat_name
        2. conv + concat: conv_name, None, concat_name
    """
    conv_name = None
    bias_name = None
    concat_name = None

    def next_op(tensor):
        """the tensor only has one follower, return the follower"""
        n_consumers = len(tensor.consumers())
        if n_consumers > 1:# check and delete gradient ops
            target_ind = list(range(n_consumers))
            for i in range(n_consumers-1, -1, -1):
                cur_op = tensor.consumers()[i]
                if cur_op.name.split('/')[0] == 'gradients':
                    target_ind.pop(i)
            if len(target_ind) == 1:
                return tensor.consumers()[target_ind[0]]
        elif n_consumers == 1:
            return tensor.consumers()[0]
        return None

    consumer_1 = next_op(split_op.outputs[output_index])
    if consumer_1 and consumer_1.type in ("Conv2D", "Conv3D"):
        conv_name = consumer_1.name
        consumer_2 = next_op(consumer_1.outputs[0])
        if consumer_2 and consumer_2.type in GROUP_CONV_CONCAT:
            concat_name = consumer_2.name
        if consumer_2 and consumer_2.type == "BiasAdd":
            bias_name = consumer_2.name
            consumer_3 = next_op(consumer_2.outputs[0])
            if consumer_3 and consumer_3.type in GROUP_CONV_CONCAT:
                concat_name = consumer_3.name

    return conv_name, bias_name, concat_name


def _set_branch_target_pattern(concat_name, bias_name):
    '''Set branch's target pattern according to concat_name and bias_name'''
    group_concat_name = concat_name
    if bias_name is None:
        has_bias = False
    else:
        has_bias = True
    return group_concat_name, has_bias


def _cmp_branch(group_concat_name, has_bias, conv_name, bias_name,
                concat_name):
    is_same = True
    # conv and concat is essential
    if conv_name is None or concat_name is None:
        is_same = False
    # concat is the same
    if concat_name != group_concat_name:
        is_same = False
    # bias exists or not in all branch
    if (has_bias and (bias_name is None)) or \
       (not has_bias and (bias_name is not None)):
        is_same = False

    return is_same


def find_group_conv(graph):
    """
    Function: find group conv in the graph.
    Returns:
        group_convs: list containing the group_conv in the graph
    """
    split_ops = get_layer_ops_by_type(graph, GROUP_CONV_SPLIT)
    group_convs = list()
    for split_op in split_ops:
        group_conv = pattern_group_conv(split_op)
        if group_conv:
            group_convs.append(group_conv)

    return group_convs


def get_all_group_conv_sub_convs(graph):
    """
    Function: find group conv sub convs in the graph.
    Returns:
        sub_convs: list containing all the op name of group_conv's sub conv in the graph
    """
    group_convs = find_group_conv(graph)
    sub_convs = list()
    for group_conv in group_convs:
        convs = group_conv.get_convs()
        for conv in convs:
            sub_convs.append(conv.name)
    return sub_convs


def pattern_group_conv(split_op):
    ''' find a group_conv's pattern from a split op '''
    graph = split_op.graph
    group_info = GroupConv.is_group_conv_structure(split_op)
    group_conv = None
    if group_info.is_group_conv:
        bn_name = None
        concat_op = graph.get_operation_by_name(group_info.concat_name)
        if len(concat_op.outputs[0].consumers()) == 1:
            concat_consumer = concat_op.outputs[0].consumers()[0]
            if concat_consumer.type in FUSE_BN_TYPES:
                bn_name = concat_consumer.name
        group_conv = construct_group_conv(split_op, group_info.conv_names, group_info.bias_names,
                                          group_info.concat_name, bn_name)
    return group_conv


def construct_group_conv(split_op, conv_names, bias_names, concat_name,
                         bn_name):
    ''' Construct a object of Groupconv. '''
    group_conv_names = GroupConv.group_names(split_op.name, conv_names,
                                             bias_names, concat_name,
                                             bn_name)
    try:
        group_conv = GroupConv(group_conv_names, split_op.graph)
    except RuntimeError:
        LOGGER.push_debug_message(
            "%s cannot construct group_conv." % (split_op.name),
            'match_group_conv')
        group_conv = None
    return group_conv


def find_concat_in(concat_op, index):
    '''find the concat_op's inputs '''
    if concat_op.type == 'Concat':
        return concat_op.inputs[index + 1]
    if concat_op.type == 'ConcatV2':
        return concat_op.inputs[index]
    raise RuntimeError("Unexcepted concat type")
