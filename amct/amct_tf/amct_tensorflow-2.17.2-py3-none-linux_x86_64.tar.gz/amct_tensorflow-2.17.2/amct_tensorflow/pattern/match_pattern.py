#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Match pattern in pattern.json.

"""
from collections import namedtuple

from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.pattern.utils import get_layer_ops_by_type
from amct_tensorflow.utils.utils_vars import PATTERN_CONFIG
from amct_tensorflow.utils.utils_vars import ADD_TYPES

BatchNormPattern = namedtuple('BatchNormPattern', ['flag', 'quantized_op', 'op_list', 'output_dict'])

__all__ = ['PatternHelper']


class PatternHelper():
    """Help cope with pattern from pattern.json """
    @staticmethod
    def match_pattern(operation, pattern_config):
        """Matches bulk BN operators and returns the list of matched operators.
        """
        start_op = operation
        # op list of the op_current's pattern.
        op_list = [start_op]
        # Store op type information in pattern.
        type_list = [start_op.type]
        # Store op connection information in pattern.
        connection_list = []
        count_num = 0
        for op_ele in op_list:
            connection = []
            for index, op_input in enumerate(op_ele.inputs):
                # fp16 bn's param can bypass cast
                if op_input.op.type == 'Cast':
                    op_input = op_input.op.inputs[0]
                # Determines whether the current input op is the end op.
                if pattern_config.get('END').get(str(op_list.index(op_ele))):
                    if index in \
                        pattern_config.get('END')[str(op_list.index(op_ele))]:
                        continue

                if op_input.op not in op_list:
                    op_list.append(op_input.op)
                    type_list.append(op_input.op.type)
                    connection.append(len(op_list)-1)
                else:
                    connection.append(op_list.index(op_input.op))

            connection_list.append(connection)
            is_valid = PatternHelper.check_valid_type(
                connection_list, type_list, pattern_config, count_num)
            if not is_valid:
                return False, op_list
            count_num += 1

        return True, op_list

    @staticmethod
    def check_valid_type(connection_list, type_list, pattern_config,
                         count_num):
        """ Check whether the current matching operator is consistent with the
            template.
        """
        try:
            type_current = type_list[count_num]
            type_template = pattern_config.get('TYPE')[count_num]
            connect_current = connection_list[count_num]
            connect_template = pattern_config.get('CONNECT')[count_num]
        except IndexError:
            return False
        else:
            if connect_current == connect_template:
                if type_current in ('AddV2', 'Add') and \
                    type_template in ('AddV2', 'Add'):
                    return True
                if type_current == type_template:
                    return True
            return False

    @staticmethod
    def match_batch_norm_by_add(object_op):
        """ Match the small operator structure of BN by add op and return the
            related structure information.
        """
        pattern_config = {}
        config_name = None
        flag = False
        for config_name, pattern_config in PATTERN_CONFIG.items():
            flag, op_list = PatternHelper.match_pattern(object_op, pattern_config)
            if flag and 'training_false' in config_name:
                break
        if flag:
            end_dict = pattern_config.get('END')
            key = int(list(end_dict.keys())[0])
            value = list(end_dict.values())[0][0]
            quantized_op = op_list[key].inputs[value].op
            if GraphChecker.check_biasadd(quantized_op):
                quantized_op = quantized_op.inputs[0].op
            output_dict = pattern_config.get('OUTPUT')
            return BatchNormPattern._make([flag, quantized_op, op_list, output_dict])
        return BatchNormPattern._make([flag, None, None, None])

    @staticmethod
    def match_batch_norm_by_main_op(object_op):
        """ Match the small operator structure of BN by object op and return
            the related structure information.
        """
        add_types = ADD_TYPES[:]
        add_types.remove('BiasAdd')
        add_ops = get_layer_ops_by_type(object_op.graph, add_types)
        for add_op in add_ops:
            pattern_config = {}
            config_name = None
            flag = False
            for config_name, pattern_config in PATTERN_CONFIG.items():
                flag, op_list = PatternHelper.match_pattern(add_op, pattern_config)
                if flag and 'training_false' in config_name:
                    break

            if flag:
                end_dict = pattern_config.get('END')
                key = int(list(end_dict.keys())[0])
                value = list(end_dict.values())[0][0]
                quantized_op = op_list[key].inputs[value].op
                if GraphChecker.check_biasadd(quantized_op):
                    quantized_op = quantized_op.inputs[0].op
                if quantized_op == object_op:
                    output_dict = pattern_config.get('OUTPUT')
                    return BatchNormPattern._make([flag, quantized_op, op_list, output_dict])

        return BatchNormPattern._make([False, None, None, None])

    @staticmethod
    def match_patternir(operation, pattern_config):
        """
        Function:
            Matches bulk dropout operators and returns the list of matched operators.
        """
        start_op = operation
        # op list of the op_current's pattern.
        op_list = [start_op]
        # Store op type information in pattern.
        type_list = [start_op.type]
        # Store op connection information in pattern.
        connection_list = []
        count_num = 0
        for op_ele in op_list:
            connection = []
            for index, _ in enumerate(op_ele.input_anchors):
                # Determines whether the current input op is the end op.
                if pattern_config.get('END').get(str(op_list.index(op_ele))) and \
                    index in pattern_config.get('END')[str(op_list.index(op_ele))]:
                    continue
                producer, _ = op_ele.get_producer(index)
                if not producer:
                    continue
                if producer not in op_list:
                    op_list.append(producer)
                    type_list.append(producer.type)
                    connection.append(len(op_list) - 1)
                else:
                    connection.append(op_list.index(producer))

            connection_list.append(connection)

            is_valid = PatternHelper.check_valid_type(connection_list, type_list, pattern_config, count_num)
            if not is_valid:
                return False, op_list
            count_num += 1

        return True, op_list
