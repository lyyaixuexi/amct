#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Get layer ops from graph.

"""


def get_layer_ops_by_type(graph, target_op_type_list):
    """
    Function：find matched ops in tensorflow Graph
    Parameter: graph: tensorflow graph
                target_op_type_list: matched op type list
    Return:layer_ops: matched op list
    """
    layer_ops = []
    ops = graph.get_operations()
    for single_op in ops:
        if single_op.type in target_op_type_list:
            layer_ops.append(single_op)

    return layer_ops
