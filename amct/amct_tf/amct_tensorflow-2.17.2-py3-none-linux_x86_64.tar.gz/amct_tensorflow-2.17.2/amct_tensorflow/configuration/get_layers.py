#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Get layer ops from graph and get quant info from quntizable op.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import functools
from amct_tensorflow.capacity import CAPACITY
from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.pattern.utils import get_layer_ops_by_type
from amct_tensorflow.pattern.match_group_conv import get_all_group_conv_sub_convs
from amct_tensorflow.utils.utils_vars import QUANT_LAYER_SUFFIX

DILATION_ONE_TYPES = ['Conv2DBackpropInput']
SYMMETRIC_LIMIT_TYPES = ['Conv3D']


class OpSelector():
    """
    Function: Based on op type or name, get op description
    API: get_layer_ops_by_type，get_layer_ops_by_name
    """
    @staticmethod
    def get_support_quant_layers(graph):
        """ get support ptq quant layers in graph.

        Args:
            graph (tf.Graph): graph to find quantizable layers.

        Returns:
            list: layer's names
        """
        return list(OpSelector.get_support_ptq_layer2type(graph).keys())

    @staticmethod
    def get_support_ptq_layer2type(graph):
        """ get support ptq quant layers(with type info) in graph.

        Args:
            graph (tf.Graph): graph to find quantizable layers.

        Returns:
            dict: layer's names and type.
        """
        types = CAPACITY.get_value('QUANTIZABLE_TYPES')
        layer_ops = get_layer_ops_by_type(graph, types)
        layer2type = {}
        for layer_op in layer_ops:
            if layer_op.type in DILATION_ONE_TYPES and not check_dilations_equal_one(layer_op):
                continue
            if layer_op.type == 'Conv3D' and not check_conv3d_dilations(layer_op):
                continue
            layer2type[layer_op.name] = layer_op.type
        valid_layer_names = OpSelector.check_quant_layers_valid(graph, list(layer2type.keys()))
        valid_layer2type = {}
        for layer_name in valid_layer_names:
            valid_layer2type[layer_name] = layer2type.get(layer_name)
        return valid_layer2type

    @staticmethod
    def get_support_approximate_layers(graph):
        """ get support post training approximation layers in graph.

        Args:
            graph (tf.Graph): graph to find quantizable layers.

        Returns:
            list: layer's names
        """
        return list(OpSelector.get_support_pta_layer2type(graph).keys())

    @staticmethod
    def get_support_pta_layer2type(graph):
        """ get support pta layers(with type info) in graph.

        Args:
            graph (tf.Graph): graph to find quantizable layers.

        Returns:
            dict: layer's names and type.
        """
        types = CAPACITY.get_value('OP_APPROXIMATION_TYPES')
        layer_ops = get_layer_ops_by_type(graph, types)
        layer2type = {}
        for layer_op in layer_ops:
            layer2type[layer_op.name] = layer_op.type
        return layer2type

    @staticmethod
    def get_support_qat_layers(graph):
        """ get support qat quant layers in graph.

        Args:
            graph (tf.Graph): graph to find quantizable layers.

        Returns:
            list: layer's names
        """
        return list(OpSelector.get_support_qat_layer2type(graph).keys())

    @staticmethod
    def get_support_qat_layer2type(graph):
        """ get support qat quant layers(with type info) in graph.

        Args:
            graph (tf.Graph): graph to find quantizable layers.

        Returns:
            dict: layer's names and type.
        """
        types = CAPACITY.get_value('RETRAIN_TYPES')
        layer2type = {}
        for layer_op in graph.get_operations():
            if layer_op.type not in types:
                continue
            if layer_op.type in DILATION_ONE_TYPES and not check_dilations_equal_one(layer_op):
                continue
            if layer_op.type == 'Conv3D' and not check_conv3d_dilations(layer_op):
                continue
            layer2type[layer_op.name] = layer_op.type
        valid_layer_names = OpSelector.check_quant_layers_valid(graph, list(layer2type.keys()))
        valid_layer2type = {}
        for layer_name in valid_layer_names:
            valid_layer2type[layer_name] = layer2type.get(layer_name)
        return valid_layer2type

    @staticmethod
    def get_support_prune_layer2type(graph):
        '''return supported layer to type map in model'''
        types = CAPACITY.get_value('PRUNABLE_TYPES')
        layers = {}

        for op in graph.get_operations():
            if op.type not in types:
                continue
            if op.type == 'MatMul' and op.get_attr('transpose_a'):
                continue
            # check placeholder
            is_weight_placeholder = GraphChecker.check_weight(
                graph, op, op.name)
            is_bias_placeholder = GraphChecker.check_bias(
                graph, op, op.name)
            if is_weight_placeholder or is_bias_placeholder:
                continue
            layers[op.name] = op.type
        LOGGER.logd("get support filter prune layer2type from graph",
                    module_name="Configuration")
        return layers

    @staticmethod
    def get_support_selective_prune_layer2type(graph):
        '''return supported layer to type map in model'''
        types = CAPACITY.get_value('SELECTIVE_PRUNABLE_TYPES')
        layers = {}

        for op in graph.get_operations():
            if op.type not in types:
                continue
            if op.type == 'MatMul' and op.get_attr('transpose_a'):
                continue
            # check placeholder
            is_weight_placeholder = GraphChecker.check_weight(
                graph, op, op.name)
            is_bias_placeholder = GraphChecker.check_bias(
                graph, op, op.name)
            if is_weight_placeholder or is_bias_placeholder:
                continue
            layers[op.name] = op.type
        LOGGER.logd("get support selective prune layer2type from graph",
                    module_name="Configuration")
        return layers

    @staticmethod
    def get_support_convert_layers(graph):
        ''' get support quant layers in graph'''
        types = CAPACITY.get_value('CONVERT_QAT_QUANTIZABLE_TYPES')
        layer_ops = get_layer_ops_by_type(graph, types)
        quant_layers = []
        for layer_op in layer_ops:
            if layer_op.type in DILATION_ONE_TYPES and not check_dilations_equal_one(layer_op):
                continue
            if layer_op.type == 'Conv3D' and not check_conv3d_dilations(layer_op):
                continue
            quant_layers.append(layer_op.name)

        quant_layers = OpSelector.check_quant_layers_valid(graph, quant_layers)
        return quant_layers

    @staticmethod
    def check_quant_layers_valid(graph, quant_layers):
        """ Check quant layers whether satisfy some special limit for quant.

        Args:
            graph (tf.Graph): graph to find quantizable layers.
            quant_layers (list of string): the layers to check.

        Returns:
            list of string: the layers satisfy special limit to do quant.
        """
        quant_layers = GraphChecker.check_matmul_transpose(graph, quant_layers)
        quant_layers = GraphChecker.check_quantize_placeholder(graph, quant_layers)
        quant_layers = GraphChecker.check_gradient_op(graph, quant_layers)

        return quant_layers

    @staticmethod
    def get_layer_names_by_type(graph, target_op_type_list):
        """
        Function: find matched op name in graph based on op type list
        Parameter: graph: tensorflow graph
                   target_op_type_list: matched op type list
        Return:layer_names: matched op name list
        """
        layer_names = []
        ops = graph.get_operations()

        for single_op in ops:
            if single_op.type in target_op_type_list:
                layer_names.append(single_op.name)

        return layer_names

    @staticmethod
    def get_layers_by_type(graph, target_op_type_list):
        """
        Function: find matched op in graph based on op type list
        Parameter: graph: tensorflow graph
                   target_op_type_list: matched op type list
        Return:layers: matched op list
        """
        layers = []
        ops = graph.get_operations()

        for single_op in ops:
            if single_op.type in target_op_type_list:
                layers.append(single_op)

        return layers

    @staticmethod
    def get_name_type_dict(graph):
        """
        Function: return op name vs type dictionary in tensorflow graph
        Parameter: graph: tensorflow graph
        Return:ops_dict: op name vs type dictionary
        """
        ops = graph.get_operations()
        ops_dict = {}
        for single_op in ops:
            ops_dict[single_op.name] = single_op.type

        return ops_dict

    @staticmethod
    def get_layer_ops_by_name(graph, target_op_name_list):
        """
        Function: find ops in tensorflow graph based name list
        Parameter: graph: tf.compat.v1.Graph to work in
                   target_op_name_list: op_name to match for pattern
        Return:layer_ops: matched op list
        """
        layer_ops = []

        ops = graph.get_operations()
        for single_op in ops:
            if single_op.name in target_op_name_list:
                layer_ops.append(single_op)

        return layer_ops

    @staticmethod
    def get_nuq_quant_layers(graph):
        '''get nuq quant layers'''
        nuq_quantizable_layers = []
        operations = graph.get_operations()
        group_convs = get_all_group_conv_sub_convs(graph)
        for operation in operations:
            if OpSelector.check_nuq_quantize_type(group_convs, operation):
                nuq_quantizable_layers.append(operation.name)
        return nuq_quantizable_layers


    @staticmethod
    def check_nuq_quantize_type(group_convs, check_op):
        """ check if op can be non uniform quantized or not."""
        # check type
        if check_op.type not in CAPACITY.get_value('NUQ_QUANTIZABLE_TYPES'):
            return False
        # check invalid inputs
        if len(check_op.inputs) != 2:
            raise RuntimeError(
                "%s layer(%s) should have 2 input but actually %s inputs."\
                % (check_op.type, check_op.name, len(check_op.inputs)))

        if check_op.type == 'Conv2D':
            # dilation is 1
            dilations = check_op.get_attr('dilations')
            if not set(dilations) == set([1]):
                return False
        # check whether the conv is part of group conv
        if check_op.name in group_convs:
            return False
        return True

    @staticmethod
    def check_nuq_steps(graph, op_name, steps):
        '''check if nuq steps is bigger than weight length'''
        check_op = graph.get_operation_by_name(op_name)
        _, weight_index = QuantOpInfo.get_quant_index(check_op)
        weights = check_op.inputs[weight_index]
        weight_shape = weights.shape
        if str(weight_shape) == '<unknown>':
            return False
        weight_length = functools.reduce(lambda x, y: x * y, weight_shape)
        if weight_length < steps:
            return False
        return True

    @staticmethod
    def check_op_matching(graph, fused_op_list):
        """
        Function: Check whether the ops in json the ops in the original graph
        Inputs:
            graph: tf.compat.v1.Graph, to be quantized
            fused_op_list: list, the ops parsed from the json file
        """
        original_graph_ids = get_all_ops_names(graph)
        for json_op_name in fused_op_list:
            is_quant_op = False
            for quant_suffix in QUANT_LAYER_SUFFIX:
                if quant_suffix in json_op_name:
                    is_quant_op = True
            if is_quant_op:
                continue
            if json_op_name not in original_graph_ids:
                LOGGER.push_debug_message(
                    "Op '{}' in the given mapping_file does not exist in the original graph. "\
                    "The mapping_file may not match the original graph, please check!".format(json_op_name))

    @staticmethod
    def get_act_symmetric_limit_types():
        """get type only support activation symmetric"""
        return SYMMETRIC_LIMIT_TYPES

    @staticmethod
    def get_act_symmetric_limit_layers(graph):
        """get layer only support activation symmetric"""
        layers = OpSelector.get_layers_by_type(graph, SYMMETRIC_LIMIT_TYPES)
        layer_names = [layer.name for layer in layers]
        return layer_names

    @staticmethod
    def get_support_dmq_balancer_types():
        """get type support dmq_balancer"""
        quant_types = CAPACITY.get_value('QUANTIZABLE_TYPES')
        no_weight_quant_types = CAPACITY.get_value('NO_WEIGHT_QUANT_TYPES') + \
            CAPACITY.get_value('DUAL_ACTIVATION_QUANT_TYPES')
        return [type_name for type_name in quant_types if type_name not in no_weight_quant_types]

    @staticmethod
    def get_support_dmq_balancer_layers(graph):
        """get layers support dmq_balancer"""
        dmq_balancer_types = OpSelector.get_support_dmq_balancer_types()
        layer_ops = get_layer_ops_by_type(graph, dmq_balancer_types)
        return [op.name for op in layer_ops]


def get_all_ops_names(graph):
    """
    Function: git all op names in tensorflow graph based name list
    Parameter: graph: tf.compat.v1.Graph to work in
                target_op_name_list: op_name to match for pattern
    Return:layer_ops: all the op names list
    """
    layer_ops = []
    ops = graph.get_operations()
    for single_op in ops:
        layer_ops.append(single_op.name)

    return layer_ops


def check_dilations_equal_one(operation):
    """ Check whether the operation's dilations is one or not.

    Args:
        operation (tf.Operation): the operation to do check

    Returns:
        bool: True, dilations is one and False is others.
    """
    dilations = operation.get_attr('dilations')
    if set(dilations) == {1}:
        return True
    return False


def check_conv3d_dilations(operation):
    """ Check dilations: dilation_d = 1, dilation_h >= 1, dilation_w >= 1

    Args:
        operation (tf.Operation): the operation to do check

    Returns:
        bool: True, dilations is supported and False is others.
    """
    dilations = operation.get_attr('dilations')
    data_format = operation.get_attr('data_format')
    if data_format in (b'NDHWC', 'NDHWC'):
        return dilations[1] == 1 and dilations[2] >= 1 and dilations[3] >= 1
    return dilations[2] == 1 and dilations[3] >= 1 and dilations[4] >= 1
