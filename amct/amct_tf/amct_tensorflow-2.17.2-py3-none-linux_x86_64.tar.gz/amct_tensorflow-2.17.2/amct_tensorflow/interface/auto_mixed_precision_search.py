#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

the auto calibration main AMC calibration API

"""
import os
import copy
import json
import tensorflow as tf
from amct_tensorflow.common.utils.check_params import check_params
from amct_tensorflow.common.auto_calibration import AutoCalibrationEvaluatorBase
from amct_tensorflow.common.utils import vars_util
from amct_tensorflow.common.utils import struct_helper
from amct_tensorflow.common.auto_mixed_precision.auto_mixed_precision_search import AutoSearchMixedPrecisionBase
from amct_tensorflow.common.auto_calibration.sensitivity_base import SensitivityBase
from amct_tensorflow.interface.config_parser import create_quant_config
from amct_tensorflow.interface.quantize_model import _inner_quantize_model
from amct_tensorflow.interface.quantize_model import add_dump_operations
from amct_tensorflow.interface.save_model import save_model
from amct_tensorflow.interface.retrain_conf_parser import create_quant_retrain_config
from amct_tensorflow.utils.net_params import ParamsHelperTf
from amct_tensorflow.utils.graph_utils import GraphUtils
from amct_tensorflow import optimizer as opt
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.utils.analyze_layer_output import LayerOutputAnalyzer
from amct_tensorflow.configuration.configuration import Configuration
from amct_tensorflow.configuration.get_layers import OpSelector
from amct_tensorflow.utils.fuse_bn import fuse_bn_save_model


class GraphInfo(struct_helper.GraphInfoBase):
    """ Graph info to mannage graph's variables. """
    def __init__(self, model, outputs):
        """ Init function

        Args:
            model (string): pb file
            outputs (list of string): model's outputs.
        """
        self.model = os.path.realpath(model)
        self.outputs = outputs
        self.check_params()

        self.origin_graph = GraphUtils.parse_pb_to_graph(self.model, self.outputs)
        self.group_convs = {}

        super().__init__(self.get_graph())

    def check_params(self):
        """ check param, whether it valid or not.

        Raises:
            KeyError: outputs is invalid for graph.
        """
        if not self.outputs:
            raise ValueError("graph's outputs cannot be empty!")
        for output in self.outputs:
            if not isinstance(output, str):
                raise ValueError("graph's output {} should be of type string but is {}".format(output, type(output)))
        GraphUtils.parse_pb_to_graph(self.model, self.outputs)

    def get_graph(self):
        """ Get graph form model.

        Returns:
            tf.Graph: graph from model.
        """
        return GraphUtils.parse_pb_to_graph(self.model, self.outputs)


class AutoSearchMixedPrecision(AutoSearchMixedPrecisionBase):
    """
    the class for quick automatic calibration API
    """
    def __init__(self, model, outputs, config_defination, save_dir, evaluator, sensitivity):
        """ Init function

        Args:
            model (string]): model to do quant, it should be one pb file.
            outputs (list of string): model's outputs.
            config_defination (string): file from AutoMixedPrecisionConfig, indicating how to do search.
            save_dir (string): path to save the results and temp file.
            evaluator (subclass of AutoCalibrationEvaluatorBase): can do evaluation and calibration for a graph.
            sensitivity (SimilaritySensitivityBase): the way to measure the quant sensitivity.
        """
        graph_info = GraphInfo(model, outputs)
        auto_quant_info = struct_helper.AutoSearchMixedPrecisionInfo(config_defination, save_dir, sensitivity)
        cali_config_info = struct_helper.CalibrationConfigInfo(auto_quant_info.cfg_helper.ptq_cfg)

        super().__init__(graph_info, cali_config_info, auto_quant_info)

        self.evaluator = evaluator

    def cal_node_bitops(self):
        """ Calculate bitops of quantizable layers in graph.

        Returns:
            dict: bitops info for layers in each bit.
        """
        bitops_info = {}
        graph = GraphUtils.parse_pb_to_graph(self.temp_info.fused_file)
        for operation in graph.get_operations():
            op_name = operation.name
            if op_name in self.auto_quant_info.quant_layers:
                flops = ParamsHelperTf.get_flops(operation, self.auto_quant_info.shape_info.get(op_name))
                bitops_info[op_name] = {} if op_name not in bitops_info.keys() else bitops_info.get(op_name)
                bitops_info.get(op_name)['FLOPs'] = flops
                for quant_bit in self.auto_quant_info.quant_mix_bits:
                    bitops_info.get(op_name)[str(quant_bit)] = flops * quant_bit * quant_bit
        return bitops_info

    def layer_sensitivity_analysis(self):
        """ Analyze sensitivity by analayzing layer's output difference before and after quant. """
        acc_decay = {}
        self.dump_data()
        fuse_outputs = self.fuse_graph()
        for num_bits in self.auto_quant_info.quant_mix_bits:
            # for 16 bit
            if num_bits == vars_util.FP16_BIT:
                for quant_layer in self.auto_quant_info.quant_layers:
                    acc_decay[quant_layer] = {} if quant_layer not in acc_decay.keys() else acc_decay.get(quant_layer)
                    acc_decay.get(quant_layer)[str(vars_util.FP16_BIT)] = 0
                continue
            # for other quant bit
            ranking_info, shape_info = self.analysis_original_quant(self.temp_info.fused_file, fuse_outputs, num_bits)
            for layer in ranking_info:
                acc_decay[layer] = {} if layer not in acc_decay.keys() else acc_decay.get(layer)
                acc_decay.get(layer)[str(num_bits)] = ranking_info.get(layer)

        self.auto_quant_info.acc_decay = acc_decay
        self.auto_quant_info.shape_info = shape_info

    def dump_data(self):
        """ Dump input data for each quant layers. """
        original_graph = self.graph_info.get_graph()
        dump_config = struct_helper.DumpConfig(dump_dir=self.temp_info.dump_dir,
                                               batch_num=self.auto_quant_info.cfg_helper.test_iteration)
        ori_outputs = copy.deepcopy(self.graph_info.outputs)
        add_dump_operations(original_graph, self.map_file(str(8), 'config_file'), dump_config, ori_outputs)
        self.evaluator.evaluate(original_graph, ori_outputs, self.auto_quant_info.cfg_helper.test_iteration)

    def fuse_graph(self):
        """ Fuse graph before insert quant behavior."""
        original_graph = self.graph_info.get_graph()
        optimizer = opt.GraphOptimizer()
        fuse_outputs = copy.deepcopy(self.graph_info.outputs)
        optimizer.add_pass(opt.ReplaceBnbranchPass(fuse_outputs))
        optimizer.do_optimizer(original_graph)
        GraphChecker.check_amct_operations(original_graph)

        with open(self.temp_info.config_file, 'r') as fid:
            config = json.load(fid)
        original_graph, _ = fuse_bn_save_model(original_graph, fuse_outputs, config['skip_fusion_layers'])

        with original_graph.as_default():
            with tf.compat.v1.Session() as session:
                GraphUtils.savetopb(session, fuse_outputs, self.temp_info.fused_file)

        return fuse_outputs

    def analysis_original_quant(self, fused_origin_pb, fuse_outputs, num_bits):
        """ Analyze sensitivity when quant in num_bits.

        Args:
            fused_origin_pb (string): fused pb model from origin pb.
            fuse_outputs (list of string) : outputs of fused_file
            num_bits (int): bit to do quant.
        """
        original_graph = GraphUtils.parse_pb_to_graph(fused_origin_pb, fuse_outputs)

        # process quantized graph
        quant_outputs = copy.deepcopy(self.graph_info.outputs)
        save_path = os.path.join(self.temp_info.temp_dir, str(num_bits))
        save_model(self.graph_info.model, quant_outputs, self.map_file(num_bits, 'record_file'), save_path)
        quant_model = ''.join([save_path, '_quantized.pb'])
        quant_graph = GraphUtils.parse_pb_to_graph(quant_model, quant_outputs)

        quant_config = Configuration.parse_config_file(self.map_file(num_bits, 'config_file'), original_graph)
        quant_layers, group_convs = LayerOutputAnalyzer.seprate_group_conv(original_graph, quant_config,
                                                                           self.auto_quant_info.quant_layers)
        analyzer = LayerOutputAnalyzer(original_graph, quant_graph, quant_layers, group_convs,
                                       self.temp_info.dump_dir, self.auto_quant_info.sensitivity)
        ranking_info, shape_info = analyzer.get_sensitivity()

        return ranking_info, shape_info

    def prepare_calibration_config(self, config_defination):
        """ prepare calibration config. """
        create_quant_config(self.temp_info.config_file,
                            self.graph_info.origin_graph,
                            config_defination=config_defination)

    def prepare_qat_config(self, config_defination):
        """ prepare quant retrain config. """
        create_quant_retrain_config(self.temp_info.config_file,
                                    self.graph_info.origin_graph,
                                    config_defination=config_defination)

    def do_global_calibration(self, num_bits):
        """ Do calibration to generate record with num_bit for whole graph.

        Args:
            num_bits (int): in which bit to do quant.
        """
        config_file = self.map_file(num_bits, 'config_file')
        record_file = self.map_file(num_bits, 'record_file')

        calib_outputs = copy.deepcopy(self.graph_info.outputs)
        graph = self.graph_info.get_graph()
        try:
            _inner_quantize_model(graph, (config_file, record_file), outputs=calib_outputs, weight_fakequant=False)
        except Exception as e:
            raise RuntimeError("fail to do quantize_model when graph is quant to {0} bit with algo in 'ptq_cfg' in "
                               "AutoMixedPrecisionConfig in post training quantization. Please check the error info "
                               "for more information. Maybe the algo cannot support {0}".format(num_bits)) from e

        # activation calibration process
        with open(config_file) as fid:
            quant_config = json.load(fid)

        try:
            self.evaluator.calibration(graph=graph, outputs=calib_outputs, batch_num=quant_config.get('batch_num'))
        except Exception as e:
            raise RuntimeError("fail to do calibration when graph is quant to {} bit in post training quantization. "
                               "Please check the error info for more information.".format(num_bits)) from e

    def get_support_layer2type(self, mode):
        """ Get support quant layer's name and type info.

        Args:
            mode (string): get in which quant scene. 'ptq' and 'qat' is valid.

        Returns:
            dict: key is layer's name and valid is type info.
        """
        graph = self.graph_info.origin_graph
        if mode == 'qat':
            support_layer2type = OpSelector.get_support_qat_layer2type(graph)
        if mode == 'ptq':
            support_layer2type = OpSelector.get_support_ptq_layer2type(graph)
        return support_layer2type

    def union_search_range(self, bit_search_range):
        """ Union search range, so several layers can has same choice. For group_conv，several conv layers will be
        union, and search_range will has only one representation for it.

        Args:
            bit_search_range (dict): key is layer and value is search_range.

        Returns:
            dict: new search search_range
            dict: key is union_name and value is list of layer to union.
        """
        original_graph = GraphUtils.parse_pb_to_graph(self.temp_info.fused_file)
        with open(self.temp_info.config_file, 'r') as fid:
            cali_config = json.load(fid)
        _, group_convs = LayerOutputAnalyzer.seprate_group_conv(original_graph, cali_config,
                                                                self.auto_quant_info.quant_layers)
        for group_conv in group_convs.values():
            self.graph_info.group_convs[group_conv.get_name('split_name')] = group_conv.get_name('conv_names')

        new_search_range = copy.deepcopy(bit_search_range)
        union_info = {}

        for split_name, conv_names in self.graph_info.group_convs.items():
            search_range = bit_search_range.get(conv_names[0])
            if search_range is None:
                continue
            do_union = True
            for conv_name in conv_names:
                if bit_search_range.get(conv_name) != search_range:
                    do_union = False
                    break
            if not do_union:
                continue
            union_info[split_name] = conv_names
            self._add_info_for_union(split_name, conv_names, new_search_range, self.auto_quant_info.acc_decay,
                                     self.auto_quant_info.computes_ops)

        return new_search_range, union_info


@check_params(model_file=str,
              outputs=list,
              config=str,
              save_dir=str,
              evaluator=AutoCalibrationEvaluatorBase,
              sensitivity=(str, SensitivityBase))
def auto_mixed_precision_search(model_file, outputs, config, save_dir, evaluator,
                                sensitivity='MseSimilarity'):
    """ Auto search quant bit for a model based calibration.

    Args:
        model_file (string]): model to do quant, it should be one pb file.
        outputs (list of string): model's outputs.
        config (string): file from AutoMixedPrecisionConfig, indicating how to do search.
        save_dir (string): path to save the results and temp file.
        evaluator (subclass of AutoCalibrationEvaluatorBase): can do evaluation and calibration for a graph.
        sensitivity (union [str, MseSimilarity]): the way to measure the quant sensitivity.
    """
    amc = AutoSearchMixedPrecision(model_file, outputs, config, save_dir, evaluator, sensitivity)
    amc.run()
