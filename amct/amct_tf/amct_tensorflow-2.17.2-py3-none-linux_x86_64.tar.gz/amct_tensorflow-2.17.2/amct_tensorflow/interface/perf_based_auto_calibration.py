#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Auto quantize model by performance.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import shutil
import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.common.utils.check_params import check_params
from amct_tensorflow.common.utils.files import is_valid_name
from amct_tensorflow.common.utils.files import check_files_exist
from amct_tensorflow.interface.save_model import save_model
from amct_tensorflow.interface.save_model import generate_name
from amct_tensorflow.common.auto_calibration.perf_based_auto_calibration_base import \
    PerfBasedAutoCalibrationBase
from amct_tensorflow.common.performance_utils.performance_policer import BatchRollBackStrategy
from amct_tensorflow.common.performance_utils.performance_policer import PerfStrategyBase
import amct_tensorflow.optimizer as opt
from amct_tensorflow.optimizer.graph_optimizer import GraphOptimizer
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.utils.log import LOGGER


__all__ = ['perf_based_auto_calibration']


class PerfBasedAutoCalibration(PerfBasedAutoCalibrationBase):
    """The subclass of 'PerfBasedAutoCalibrationBase' in Tensorflow.
    """
    def __init__(  # pylint: disable=R0913
            self, original_model_file, quantized_model_file, outputs,
            sampler_config_file, save_dir, strategy):
        PerfBasedAutoCalibrationBase.__init__(
            self, sampler_config_file, save_dir, strategy, 'Tensorflow')

        self.original_model_file = os.path.realpath(original_model_file)
        self.quantized_model_file = os.path.realpath(quantized_model_file)
        self.outputs = outputs

        origin_graph = tf.compat.v1.Graph()
        PerfBasedAutoCalibration.load_graph(self.original_model_file, origin_graph)
        GraphChecker.check_amct_operations(origin_graph)

    @staticmethod
    def load_graph(model_file, graph):
        """Load tensorflow graph from pb file."""
        with tf.compat.v1.io.gfile.GFile(model_file, mode='rb') as model:
            graph_def = tf.compat.v1.GraphDef()
            graph_def.ParseFromString(model.read())

        with graph.as_default():
            tf.compat.v1.import_graph_def(graph_def, name='')

    def update_iteration_recorder(self):
        """Update iteration's recorder."""
        PerfBasedAutoCalibrationBase.update_iteration_recorder(self)
        self.iter_recorder.add_items(self.iter_num, 'pb_file', 'model_path',
                                     '.pb')
        if self.iter_num == 0:
            shutil.copy(self.original_model_file,
                        self.iter_recorder.recorders[self.iter_num]['pb_file'])
            LOGGER.push_info_message(
                'Move the original model name from [{}] to [{}].'.format(
                    self.original_model_file,
                    self.iter_recorder.recorders[self.iter_num]['pb_file']))

    def get_quant_model_info(self):
        """Get quantized model's information."""
        graph = tf.compat.v1.Graph()
        PerfBasedAutoCalibration.load_graph(self.quantized_model_file,
                                            graph)
        optimizer = GraphOptimizer()
        optimizer.add_pass(opt.GetQuantInfoPass(quant_info=self.quant_info))
        optimizer.do_optimizer(graph)
        is_quantized = False
        for key, value in self.quant_info.get_quant_config().items():
            if key in self.quant_info.get_main_layers() and \
                isinstance(value, dict):
                if value['quant_enable']:
                    is_quantized = True
                    break
        if not is_quantized:
            LOGGER.push_error_message(
                'the model[{}] is not quantized!.'.format(
                    self.quantized_model_file))
            raise RuntimeError(
                'the model[{}] is not quantized!.'.format(
                    self.quantized_model_file))

    def roll_back_and_save_model(self):
        """
        Generate the roll-back fake quant model and evaluate the fake quant
        model.
        """
        # turn down the joint quant in auto calibration
        graph = tf.compat.v1.Graph()
        PerfBasedAutoCalibration.load_graph(self.original_model_file,
                                            graph)
        quant_layer_num = self.extract_record_file()
        # Generate quantitative model by the pb_model and record file
        if quant_layer_num > 0:
            save_model(
                pb_model=self.original_model_file,
                outputs=self.outputs[:],
                record_file=self.iter_recorder.recorders.get(self.iter_num).get('record_file'),
                save_path=self.iter_recorder.recorders.get(self.iter_num).get('pb_file'))
            ori_name = '{}_quantized.pb'.format(
                self.iter_recorder.recorders.get(self.iter_num).get('pb_file'))
            new_name = self.iter_recorder.recorders.get(self.iter_num).get('pb_file')
            shutil.move(ori_name, new_name)
            LOGGER.push_info_message(
                'Change the quantized model name from [{}] to [{}].'.format(
                    ori_name, new_name))
        else:
            new_name = self.iter_recorder.recorders.get(self.iter_num).get('pb_file')
            shutil.copy(self.original_model_file, new_name)

    def summary(self):
        """Summarize and output the final result information."""
        PerfBasedAutoCalibrationBase.summary(self)
        best_pb_file = self.iter_recorder.recorders.get(self.best_iter_num).get('pb_file')
        best_config_file = ''.join([best_pb_file[:-2], 'json'])
        best_record_file = ''.join([best_pb_file[:-2], 'txt'])
        best_pb_json_file = ''.join([best_pb_file, '_quant.json'])

        pb_file = generate_name(self.save_dir, self.prefix_name)
        config_file = os.path.join(
            self.save_dir, 'perf_based_auto_calibration_final_config.json')
        record_file = os.path.join(self.save_dir, 'record.txt')
        pb_json_file = ''.join([pb_file[:-7], '.json'])
        check_files_exist([pb_file, config_file, record_file, pb_json_file])
        shutil.copy(best_pb_file, pb_file)
        if os.path.exists(best_pb_json_file):
            shutil.copy(best_config_file, config_file)
            shutil.copy(best_record_file, record_file)
            shutil.copy(best_pb_json_file, pb_json_file)
            LOGGER.push_info_message(
                'The generated model is stored in dir: {}.'.format(pb_file))
            LOGGER.push_info_message(
                'The records file is stored in dir: {}.'.format(record_file))
        else:
            LOGGER.push_info_message(
                'The best performance model is the unquantified model.')
            LOGGER.push_info_message(
                'The generated model is stored in dir: {}.'.format(pb_file))
        fusion_result = os.path.realpath('./fusion_result.json')
        kernel_meta = os.path.realpath('./kernel_meta')
        PerfBasedAutoCalibration.clean_tmp(fusion_result)
        PerfBasedAutoCalibration.clean_tmp(kernel_meta)


@check_params(original_model_file=str,
              quantized_model_file=str,
              outputs=list,
              sampler_config_file=str,
              save_dir=str)
def perf_based_auto_calibration(original_model_file, # pylint: disable=R0913
                                quantized_model_file,
                                outputs,
                                sampler_config_file,
                                save_dir,
                                strategy='BatchRollBack'):
    """
    Function: Based on the model, the performance of the upper plate is
              automatically quantized, and a better mixed precision
              quantization model is obtained.
    Inputs:
        original_model_file: Original unquantified model.
        quantized_model_file: Quantitative model.
        outputs: a list of output nodes of the network.
        sampler_config_file: .
        save_dir: performance sampling profile.
        strategy: performance based quantitative backoff strategy.
    Returns: None.
    """
    # Check input parameters
    is_valid_name(original_model_file, 'model')
    is_valid_name(quantized_model_file, 'model')
    is_valid_name(sampler_config_file, 'sampler_config_file')
    original_model_file = os.path.realpath(original_model_file)
    quantized_model_file = os.path.realpath(quantized_model_file)
    sampler_config_file = os.path.realpath(sampler_config_file)
    save_dir = os.path.realpath(save_dir)

    if strategy == 'BatchRollBack':
        strategy = BatchRollBackStrategy()
    else:
        if not isinstance(strategy, PerfStrategyBase):
            raise RuntimeError(
                "'strategy' is not inherited from base class StrategyBase!")

    # Define auto calibration class
    auto_calibration_controller = PerfBasedAutoCalibration(
        original_model_file, quantized_model_file, outputs, sampler_config_file,
        save_dir, strategy)

    auto_calibration_controller.run()
