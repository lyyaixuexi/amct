#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

create quantize config file and parse config file.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.configuration.get_layers import OpSelector

from amct_tensorflow.common.config.config_base import GraphObjects
from amct_tensorflow.common.retrain_config.retrain_config_base import \
        RetrainConfigBase

from amct_tensorflow.common.utils.check_params import check_params
from amct_tensorflow.common.utils.files import create_empty_file
from amct_tensorflow.common.utils.files import is_valid_name
from amct_tensorflow.capacity import CAPACITY


__all__ = ['create_quant_retrain_config', 'parse_config_file']


def get_configure():
    """get current configure"""
    configure = RetrainConfigBase(
        GraphObjects(graph_querier=OpSelector, graph_checker=GraphChecker),
        CAPACITY)
    return configure


@check_params(config_file=str,
              graph=tf.compat.v1.Graph,
              config_defination=(str, type(None)))
def create_quant_retrain_config(config_file, graph, config_defination=None):
    '''
    create config file to use in quantize_model.
    Inputs:
        config_file: a string, name to save quantized configuration file
            (including path information).
        graph: a tf.compat.v1.Graph.
        config_defination: proto quant config, if this parameter exists,
    Returns: None
    '''
    is_valid_name(config_file, 'config_file')
    config_file = create_empty_file(config_file, check_exist=True)

    GraphChecker.check_amct_operations(graph)

    configure = get_configure()
    if config_defination is None:
        configure.create_default_config(config_file, graph)
    else:
        config_defination = os.path.realpath(config_defination)
        configure.create_config_from_proto(
            config_file,
            graph,
            config_defination)


def parse_config_file(file_name, graph):
    '''
    parse config file, check incorrect value, and fill default value.
    Inputs:
        file_name: a string, name of quantized configuration file (including
                   path information).
        graph: a tf.compat.v1.Graph.
    Returns:
        quant_config: a dict saved quant config.
    '''
    configure = get_configure()
    return configure.parse_config_file(file_name, graph)
