#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quantitative subject control module.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.interface.retrain_conf_parser import parse_config_file
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.common.utils.files import is_valid_name
from amct_tensorflow.common.utils.check_params import check_params
from amct_tensorflow.common.utils import files as files_util

import amct_tensorflow.optimizer as opt
from amct_tensorflow.optimizer.graph_optimizer import GraphOptimizer

__all__ = ['create_quant_retrain_model']


@check_params(graph=tf.compat.v1.Graph, config_file=str, record_file=str)
def create_quant_retrain_model(graph, config_file, record_file):
    """
    Function: Quantization input model: According to the quantization
              configuration file, insert quantization op at the specified
              position of tf.compat.v1.Graph.
    Inputs:
        graph: a tf.compat.v1.Graph.
        config_file: a string, Name of quantized configuration file (including
                   path information).
        record_file: a string, the name of file recording quantization factor.
    Returns:
        quant_add_ops: a list, quantify the list of variables added.
    """
    is_valid_name(config_file, 'config_file')
    is_valid_name(record_file, 'record_file')
    config_file = os.path.realpath(config_file)
    record_file = files_util.create_empty_file(record_file, check_exist=True)

    with graph.as_default():
        if not os.path.exists(config_file):
            raise OSError('file (%s) does not exist!' % config_file)

        #  check ops of amct
        GraphChecker.check_amct_operations(graph)

        # Parsing the quantization profile
        quant_config = parse_config_file(config_file, graph)
        quant_config['record_file'] = record_file

        quant_add_ops = generate_quant_awared_train_graph(graph, quant_config)

        return quant_add_ops


def generate_quant_awared_train_graph(graph, quant_config):
    """
    Function:
    Quantization input model: According to the quantization configuration file,
    insert quantization op at the specified position of tf.compat.v1.Graph.

    Inputs:
    graph: a tf.compat.v1.Graph.
    quant_config: dict, parsed quant configrations

    Returns:
    quant_add_ops: a list, the list of quantization variables added.
    """
    original_ops = tf.compat.v1.global_variables()

    retrained_layers = []
    output_nodes = []
    optimizer = GraphOptimizer()
    optimizer.add_pass(opt.DeleteIdentityPass())
    optimizer.add_pass(opt.InsertRetrainGroupConvPass(
        quant_config,
        skip_layers=retrained_layers))
    optimizer.add_pass(opt.InsertRetrainSearchnGpConv(
        quant_config,
        output_nodes=output_nodes))
    optimizer.add_pass(opt.InsertRetrainPass(
        quant_config,
        skip_layers=retrained_layers))
    optimizer.add_pass(opt.InsertRetrainSearchnBnPass(
        quant_config,
        skip_layers=retrained_layers,
        output_nodes=output_nodes))
    optimizer.add_pass(opt.InsertRetrainSearchNPass(
        quant_config,
        skip_layers=retrained_layers,
        output_nodes=output_nodes))
    graph = optimizer.do_optimizer(graph)

    with tf.compat.v1.control_dependencies(output_nodes):
        output_node = tf.compat.v1.identity(output_nodes[0])

    quant_add_ops = list(
        set(tf.compat.v1.global_variables()) - set(original_ops))
    quant_add_ops.append(output_node)

    return quant_add_ops
