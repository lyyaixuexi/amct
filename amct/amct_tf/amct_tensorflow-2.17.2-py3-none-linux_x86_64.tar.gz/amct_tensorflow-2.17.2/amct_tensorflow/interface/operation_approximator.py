#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

create quantize config file and parse config file.

"""


from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
from datetime import datetime
from datetime import timezone
from datetime import timedelta
import tensorflow as tf

from amct_tensorflow.common.utils import files
from amct_tensorflow.common.utils.check_params import check_params
from amct_tensorflow.utils.log import DEFAULT_LOG_FILE_DIR
from amct_tensorflow.configuration.configuration import Configuration
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.optimizer.graph_optimizer import GraphOptimizer
from amct_tensorflow.optimizer.insert_dump_op_pass import InsertDumpOpPass


def create_approx_calibrator_impl(graph, approx_config):
    '''implementation of create_approximation_calibrator interface'''
    GraphChecker.check_amct_operations(graph)
    save_dir = generate_dump_dir()
    optimizer = GraphOptimizer()
    optimizer.add_pass(InsertDumpOpPass(approx_config, save_dir))
    graph = optimizer.do_optimizer(graph)


def generate_dump_dir():
    '''gereate directory for dumping data'''
    log_dir = os.path.realpath(DEFAULT_LOG_FILE_DIR)
    files.create_path(log_dir)
    time_stamp = datetime.now(tz=timezone(offset=timedelta(hours=8))).strftime('%Y%m%d%H%M%S%f')
    save_dir = os.path.join(log_dir, 'temp{}'.format(time_stamp))
    files.create_path(save_dir)
    return save_dir



@check_params(graph=tf.compat.v1.Graph,
              config_defination=(str, type(None)))
def create_approximation_calibrator(graph,
                                    config_defination=None):
    """
    Function: Interface of op approximation. Insert dump op at the specified
              position in the given tf.graph to dump calibration data.
    Inputs:
        graph: a tf.compat.v1.Graph.
        config_defination: a string, path of configuration file
    Returns:
        graph with dump op inserted
    """
    approx_config = Configuration.create_appoximate_config(graph, config_defination=config_defination)
    create_approx_calibrator_impl(graph, approx_config)
