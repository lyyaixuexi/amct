#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

the Evaluator based on dataset.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

import amct_tensorflow.common.cmd_line_utils.data_handler as data_handler
import amct_tensorflow.common.cmd_line_utils.arguments_handler as args_handler
from amct_tensorflow.common.utils.check_params import check_params
from amct_tensorflow.common.auto_calibration import AutoCalibrationEvaluatorBase
from amct_tensorflow.utils.log import LOGGER


class GraphEvaluator(AutoCalibrationEvaluatorBase):
    '''
    Evaluator: an evaluator based on dataset.
    '''
    @check_params(input_shape=str, data_dir=str, data_types=str)
    def __init__(self, data_dir, input_shape, data_types):
        """ Init func.

        Args:
            data_dir (string): folder to save data, like "data/input1/;data/input2/"
            input_shape (string): input data's shape like "input_name1:n1,c1,h1,w1;input_name2:n2,c2,h2,w2"
            data_types (string): input data's type, like "float32;float64"
        """
        super().__init__()
        self.data_dir = data_dir
        self.input_shape = input_shape
        self.data_types = data_types

        self._process()

    def calibration(self, graph, outputs, batch_num):
        """ Do calibration graph in dataset.

        Args:
            graph (tf.Graph): the graph to do inference.
            outputs (list of string): outputs of graph.
            batch_num (int): the batch number to do inference.
        """
        self.evaluate(graph, outputs, batch_num)
        LOGGER.logw("Finish do calibration", 'GraphEvaluator')

    def evaluate(self, graph, outputs, iterations=None):
        """ Evaluate graph in dataset.

        Args:
            graph (tf.Graph): the graph to do inference.
            outputs (list of string): outputs of graph.
            iterations (int): the batch number to do inference. if None, evaluate on all dataset.
        """
        with graph.as_default():
            outputs_list = []
            with tf.compat.v1.Session(config=tf.compat.v1.ConfigProto(allow_soft_placement=True)) as sess:
                sess.run(tf.compat.v1.global_variables_initializer())
                for data_map in data_handler.load_data(self.input_shape, self.data_dir,
                                                       self.data_types, iterations):
                    outputs_value = sess.run(outputs, feed_dict=data_map)
                    outputs_list.append(outputs_value)
        LOGGER.logw("Finish do evaluate", 'GraphEvaluator')

        return outputs_list

    def _process(self):
        """ process input params including checking, spliting string. """
        input_shape = args_handler.process_data_shape(self.input_shape)
        self.input_shape = {key + ':0': val for key, val in input_shape.items()}
        self.data_types = self.data_types.split(';')
        self.data_dir = args_handler.process_multi_data_path(self.data_dir)
