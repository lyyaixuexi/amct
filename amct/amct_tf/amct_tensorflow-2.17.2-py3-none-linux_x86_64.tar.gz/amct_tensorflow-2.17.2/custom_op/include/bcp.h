/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2021. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief bcp header file
 *
 * @file bcp.h in common_cpp
 *
 * @version 1.0
 */
#ifndef AMCT_BCP_H
#define AMCT_BCP_H

#include <vector>
#include <semaphore.h>

#include "util.h"

namespace AmctCommon {

struct PruneParam {
    // number of channels
    int numChannels;
    // axis to prune
    std::vector<int> pruneAxis;
    // number of splits
    int numSplits;
    std::vector<int> sizeSplits;
    // number of channels to prune for each split
    std::vector<int> dropNums;
};

template <typename Device, typename T>
struct ComputeRemainOut {
    int operator()(
        std::vector<const T*> wgtPtrs,
        std::vector<int> wgtSizes,
        std::vector<int> innerJumps,
        PruneParam pruneParam,
        std::vector<T*> remainChannelsContainerPtrs) const;
};

template <typename T>
int ComputeSumNorm(
    const int innerJump,
    PruneParam pruneParam,
    const int weightSize,
    const T* weight,
    std::vector<T>& norm,
    std::vector<T>& sumNorm,
    std::vector<int> splitGroups);

template <typename T>
std::vector<int> SortNorms(int splitIdx, PruneParam& pruneParam,
    std::vector<int>& splitGroups, std::vector<T>& sumNorm);

template <typename Device, typename T>
struct IdentityOutChannel {
    int operator()(struct PruneParam& pruneParam, std::vector<T*>& remainChannelsContainerPtrs,
        std::vector<T*>& remainChannelsOutPtrs) const;
};

// Define the structure of initializer for sync.
class Initializer {
public:
    static Initializer& GetInstance()
    {
        static Initializer initializer;
        return initializer;
    }

    void Init()
    {
        if (!initFlag) {
            (void)sem_init(&semaphore, 0, 1);
            initFlag = true;
        }
    }

    sem_t semaphore;
    bool initFlag = false;
};

int CalPruneNum(int numChannels, int pruneGroup, float pruneRatio, bool ascendOptimized);
}

#endif
