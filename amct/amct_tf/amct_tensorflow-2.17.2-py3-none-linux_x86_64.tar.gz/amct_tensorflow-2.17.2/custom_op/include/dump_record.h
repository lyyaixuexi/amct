/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this
 * file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief dump to record text
 *
 * @version 1.0
 */
#ifndef DUMP_RECORD_H
#define DUMP_RECORD_H

#include "proto_simulator.h"

namespace amct_tf {
// Write record to file
int WriteToRecordFile(amct_tf::InnerData& data, const std::string& recordFilePath);
}

#endif // DUMP_RECORD_H
