/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Declare AscendWeightQuant Operator Forward Operation
 *
 * @file ascend_weight_quant.h
 *
 * @version 1.0
 */
#ifndef ASCEND_WEIGHT_QUANT_H
#define ASCEND_WEIGHT_QUANT_H

namespace AmctTfOp {
// Define the structure of data quantification
template <typename T>
struct WeightQuantInputParam {
    int size;
    const signed char* weight;
    const signed char* offset;
    int channelInNum;
    int channelOutNum;
    bool channelWise;
    bool transpose;
};

template <typename Device, typename T>
struct AscendWeightQuantFunctor {
    int operator()(struct WeightQuantInputParam<T> inputParam, T* outputData) const;
};
}

#endif // ASCEND_WEIGHT_QUANT_H
