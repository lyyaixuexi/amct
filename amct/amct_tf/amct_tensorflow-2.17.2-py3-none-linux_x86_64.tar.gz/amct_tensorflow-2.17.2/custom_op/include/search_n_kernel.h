/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Declare SEARCH_N Operator Forward Operation
 *
 * @file search_n.h
 *
 * @version 1.0
 */
#ifndef SEARCH_N_KERNEL_H
#define SEARCH_N_KERNEL_H

#include <vector>
#include <string>
#include "common.h"

namespace AmctTfOp {
// Define the structure of data quantification
struct Param {
    std::vector<int> shape;
    bool channelWise;
    std::string dataFormat;
};

// Define the structure of data quantification
template <typename T>
struct SearchnQuantParam {
    bool isBroadcast;
    int* bestN;
    T* searchNData;
    double* quantError;
    float* deqScale;
    float* deqScaleCpu;
    float* out;
    std::string layerName;
    std::string recordFilePath;
};

template <typename T>
struct SearchnInputParam {
    std::vector<std::vector<T>> storeData;
    int size;
    const T* in;
};

template <typename Device, typename T>
struct SearchNFunctor {
    int operator()(struct Param& param, int& batchCounter, int& batchNum,
        struct SearchnInputParam<T>& inputParam, struct SearchnQuantParam<T>& quantParam) const;
};

template <typename Device, typename T>
struct FetchScaleFunctor {
    int operator()(T* scaleHost, const T* scaleInput, int channelNum) const;
};
}

#endif // SEARCH_N_KERNEL_H
