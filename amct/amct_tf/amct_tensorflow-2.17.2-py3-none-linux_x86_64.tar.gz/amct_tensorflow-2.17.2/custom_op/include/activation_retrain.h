/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Declare ActivationRetrain Forward Operation
 *
 * @file activation_retrain.h
 *
 * @version 1.0
 */

#ifndef ACTIVAYION_RETRAIN_H
#define ACTIVAYION_RETRAIN_H

#include "ifmr_kernel.h"

namespace AmctTfOp {
constexpr int INPUT_INDEX = 0;
constexpr int CLIPMAX_INDEX = 1;
constexpr int CLIPMIN_INDEX = 2;
constexpr int OUTPUT_INDEX = 0;
constexpr int SCALE_INDEX = 1;
constexpr int OFFSET_INDEX = 2;
constexpr int BATCH_NUM_INDEX = 3;
constexpr int CLIPMAXOUT_INDEX = 3;
constexpr int CLIPMINOUT_INDEX = 4;

constexpr bool WITH_OFFSET = true;
constexpr float PERCENTILE = 0.999999;
constexpr float IFMR_SEARCH_START = 0.7;
constexpr float IFMR_SEARCH_END = 1.3;
constexpr float SEARCH_STEP = 0.01;

template<typename T>
struct Output {
    T* data;
    float* scale;
    int* offset;
    T* clipMaxOut;
    T* clipMinOut;
};

template<typename T>
struct Input {
    const T* data;
    int length;
    T* clipMax;
    T* clipMin;
};

template<typename Device, typename T>
struct ClipCalculate {
    int operator()(const float* scale, const int* offset, T* clipMax, T* clipMin, const int quantBitNum) const;
};

template<typename Device, typename T>
struct ClipRecord {
    int operator()(T* clipMax, T* clipMin, T& clipMaxPre, T& clipMinPre) const;
};

template<typename Device, typename T>
struct ClipCheckFunctor {
    int operator()(T* clipMax, T* clipMin, T& clipMaxPre, T& clipMinPre, bool fixedMin) const;
};

template<typename Device, typename T>
struct UlqFunctor {
    int operator()(Input<T> input, Output<T> output, int quantBitNum) const;
};

template<typename Device, typename T>
struct GetBatchNum {
    int operator()(const T& batchNum, int& batchNumCpu) const;
};

template<typename Device, typename T>
struct UpdateBatchNum {
    int operator()(T& batchNum) const;
};
}

#endif // ACTIVAYION_RETRAIN_H
