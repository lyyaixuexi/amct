/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this
 * file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief simulate protbuf behavior
 *
 * @version 1.0
 */
#ifndef PROTO_SIMULATOR_H
#define PROTO_SIMULATOR_H

#include <vector>
#include <string>
#include <iostream>
#include <map>

#include <sstream>
#include <fstream>
#include <iterator>
#include <iomanip>

#include "proto_data.h"
#include "proto_proto.h"
#include "error_codes.h"

namespace amct_tf {
class ValueData : public Data {
public:
    ValueData(std::string name, FieldType type, size_t level): Data(name, type, level) {}

    int Init() override
    {
        FloatData* scaleDData = new(std::nothrow) FloatData("scale_d", FieldType::FLOAT32, level_ + 1);
        NULLPTR_CHECK(scaleDData);
        children_.push_back({"scale_d", scaleDData});

        IntData* offsetDData = new(std::nothrow) IntData("offset_d", FieldType::INT32, level_ + 1);
        NULLPTR_CHECK(offsetDData);
        children_.push_back({"offset_d", offsetDData});

        FloatListData* scaleWData = new(std::nothrow) FloatListData("scale_w", FieldType::FLOAT32_LIST, level_ + 1);
        NULLPTR_CHECK(scaleWData);
        children_.push_back({"scale_w", scaleWData});

        IntListData* offsetWData = new(std::nothrow) IntListData("offset_w", FieldType::INT32_LIST, level_ + 1);
        NULLPTR_CHECK(offsetWData);
        children_.push_back({"offset_w", offsetWData});

        UnsignedIntListData* shiftBitData = \
            new(std::nothrow) UnsignedIntListData("shift_bit", FieldType::UINT32_LIST, level_ + 1);
        NULLPTR_CHECK(shiftBitData);
        children_.push_back({"shift_bit", shiftBitData});

        IntListData* clusterData = new(std::nothrow) IntListData("cluster", FieldType::INT32_LIST, level_ + 1);
        NULLPTR_CHECK(clusterData);
        children_.push_back({"cluster", clusterData});

        BoolData* skipFusionData = new(std::nothrow) BoolData("skip_fusion", FieldType::BOOL, level_ + 1);
        NULLPTR_CHECK(skipFusionData);
        children_.push_back({"skip_fusion", skipFusionData});

        StringData* dstTypeData = new(std::nothrow) StringData("dst_type", FieldType::STRING, level_ + 1);
        NULLPTR_CHECK(dstTypeData);
        children_.push_back({"dst_type", dstTypeData});

        FloatListData* tensorBalanceFactorData = \
            new(std::nothrow) FloatListData("tensor_balance_factor", FieldType::FLOAT32_LIST, level_ + 1);
        NULLPTR_CHECK(tensorBalanceFactorData);
        children_.push_back({"tensor_balance_factor", tensorBalanceFactorData});

        return Data::Init();
    }

    ValueData(const ValueData& obj): Data(obj) {}
    ValueData& operator=(const ValueData& obj)
    {
        if (&obj == this) {
            return *this;
        }
        Data::operator=(obj);
        return *this;
    }

    int Copy(Data& value) override
    {
        FloatData* scaleDData = new(std::nothrow) FloatData(*(dynamic_cast<FloatData*>(value.GetChild("scale_d"))));
        NULLPTR_CHECK(scaleDData);
        children_.push_back({"scale_d", scaleDData});

        IntData* offsetDData = new(std::nothrow) IntData(*(dynamic_cast<IntData*>(value.GetChild("offset_d"))));
        NULLPTR_CHECK(offsetDData);
        children_.push_back({"offset_d", offsetDData});

        FloatListData* scaleWData = \
            new(std::nothrow) FloatListData(*(dynamic_cast<FloatListData*>(value.GetChild("scale_w"))));
        NULLPTR_CHECK(scaleWData);
        children_.push_back({"scale_w", scaleWData});

        IntListData* offsetWData = \
            new(std::nothrow) IntListData(*(dynamic_cast<IntListData*>(value.GetChild("offset_w"))));
        NULLPTR_CHECK(offsetWData);
        children_.push_back({"offset_w", offsetWData});

        UnsignedIntListData* shiftBitData = new(std::nothrow) UnsignedIntListData(
            *(dynamic_cast<UnsignedIntListData*>(value.GetChild("shift_bit"))));
        NULLPTR_CHECK(shiftBitData);
        children_.push_back({"shift_bit", shiftBitData});

        IntListData* clusterData = \
            new(std::nothrow) IntListData(*(dynamic_cast<IntListData*>(value.GetChild("cluster"))));
        NULLPTR_CHECK(clusterData);
        children_.push_back({"cluster", clusterData});

        BoolData* skipFusionData = \
            new(std::nothrow) BoolData(*(dynamic_cast<BoolData*>(value.GetChild("skip_fusion"))));
        NULLPTR_CHECK(skipFusionData);
        children_.push_back({"skip_fusion", skipFusionData});

        StringData* dstTypeData = \
            new(std::nothrow) StringData(*(dynamic_cast<StringData*>(value.GetChild("dst_type"))));
        NULLPTR_CHECK(dstTypeData);
        children_.push_back({"dst_type", dstTypeData});

        FloatListData* tensorBalanceFactorData = \
            new(std::nothrow) FloatListData(*(dynamic_cast<FloatListData*>(value.GetChild("tensor_balance_factor"))));
        NULLPTR_CHECK(tensorBalanceFactorData);
        children_.push_back({"tensor_balance_factor", tensorBalanceFactorData});

        valueSetted_ = true;
        return AmctCommon::SUCCESS;
    }

    ~ValueData() override {}

    int AddData(std::string name, Data* value) override
    {
        NULLPTR_CHECK(value);

        auto* child = GetChildPair(name);
        NULLPTR_CHECK(child);
        NULLPTR_CHECK(child->second);
        int ret = (child->second)->AddData(name, value);
        if (ret != AmctCommon::SUCCESS) {
            return ret;
        }

        valueSetted_ = true;
        return AmctCommon::SUCCESS;
    }

    void SetScaleD(float scale) const
    {
        FloatData* scaleD = dynamic_cast<FloatData*>(GetChild("scale_d"));
        scaleD->AddData("scale_d", scale);
    }

    float GetScaleD() const
    {
        FloatData* scaleD = dynamic_cast<FloatData*>(GetChild("scale_d"));
        return scaleD->GetData();
    }

    void SetOffsetD(int offset) const
    {
        IntData* offsetD = dynamic_cast<IntData*>(GetChild("offset_d"));
        offsetD->AddData("offset_d", offset);
    }

    void SetDstType(std::string value) const
    {
        StringData* dstType = dynamic_cast<StringData*>(GetChild("dst_type"));
        dstType->SetData(value);
    }

    void ClearScaleW() const
    {
        FloatListData* scaleW = dynamic_cast<FloatListData*>(GetChild("scale_w"));
        scaleW->ClearData();
    }

    size_t ScaleWSize() const
    {
        FloatListData* scaleW = dynamic_cast<FloatListData*>(GetChild("scale_w"));
        return scaleW->GetSize();
    }

    void AddScaleW(float scale) const
    {
        FloatListData* scaleW = dynamic_cast<FloatListData*>(GetChild("scale_w"));
        scaleW->AddData("scale_w", scale);
    }

    float GetScaleW(size_t index) const
    {
        FloatListData* scaleW = dynamic_cast<FloatListData*>(GetChild("scale_w"));
        return scaleW->GetData(index);
    }

    void ClearOffsetW() const
    {
        IntListData* offsetW = dynamic_cast<IntListData*>(GetChild("offset_w"));
        offsetW->ClearData();
    }

    void AddOffsetW(int offset) const
    {
        IntListData* offsetW = dynamic_cast<IntListData*>(GetChild("offset_w"));
        offsetW->AddData("offset_w", offset);
    }

    void ClearCluster() const
    {
        IntListData* cluster = dynamic_cast<IntListData*>(GetChild("cluster"));
        cluster->ClearData();
    }

    void AddCluster(int value) const
    {
        IntListData* cluster = dynamic_cast<IntListData*>(GetChild("cluster"));
        cluster->AddData("cluster", value);
    }

    void ClearShiftBit() const
    {
        UnsignedIntListData* shiftBit = dynamic_cast<UnsignedIntListData*>(GetChild("shift_bit"));
        shiftBit->ClearData();
    }

    void AddShiftBit(size_t value) const
    {
        UnsignedIntListData* shiftBit = dynamic_cast<UnsignedIntListData*>(GetChild("shift_bit"));
        shiftBit->AddData("shift_bit", value);
    }

    void ClearTensorBalanceFactor() const
    {
        FloatListData* tensorBalanceFactor = dynamic_cast<FloatListData*>(GetChild("tensor_balance_factor"));
        tensorBalanceFactor->ClearData();
    }

    size_t TensorBalanceFactorSize() const
    {
        FloatListData* tensorBalanceFactor = dynamic_cast<FloatListData*>(GetChild("tensor_balance_factor"));
        return tensorBalanceFactor->GetSize();
    }

    void AddTensorBalanceFactor(float factor) const
    {
        FloatListData* tensorBalanceFactor = dynamic_cast<FloatListData*>(GetChild("tensor_balance_factor"));
        tensorBalanceFactor->AddData("tensor_balance_factor", factor);
    }

    float GetTensorBalanceFactor(size_t index) const
    {
        FloatListData* tensorBalanceFactor = dynamic_cast<FloatListData*>(GetChild("tensor_balance_factor"));
        return tensorBalanceFactor->GetData(index);
    }
};

class RecordData : public Data {
public:
    RecordData(std::string name, FieldType type, size_t level): Data(name, type, level) {}

    int Init() override
    {
        StringData* keyData = new(std::nothrow) StringData("key", FieldType::STRING, level_ + 1);
        NULLPTR_CHECK(keyData);
        children_.push_back({"key", keyData});

        ValueData* valueData = new(std::nothrow) ValueData("value", FieldType::MESSAGE, level_ + 1);
        NULLPTR_CHECK(valueData);
        children_.push_back({"value", valueData});
        return Data::Init();
    }

    RecordData(const RecordData& obj): Data(obj) {}
    RecordData& operator=(const RecordData& obj)
    {
        if (this == &obj) {
            return *this;
        }
        Data::operator=(obj);
        return *this;
    }

    int Copy(Data& value) override
    {
        NULLPTR_CHECK((dynamic_cast<StringData*>(value.GetChild("key"))));
        StringData* keyData = new(std::nothrow) StringData(*(dynamic_cast<StringData*>(value.GetChild("key"))));
        NULLPTR_CHECK(keyData);
        children_.push_back({"key", keyData});

        NULLPTR_CHECK((dynamic_cast<ValueData*>(value.GetChild("value"))));
        ValueData* valueData = new(std::nothrow) ValueData(*(dynamic_cast<ValueData*>(value.GetChild("value"))));
        NULLPTR_CHECK(valueData);
        int ret = valueData->Copy(*value.GetChild("value"));
        if (ret != AmctCommon::SUCCESS) {
            delete valueData;
            return ret;
        }
        children_.push_back({"value", valueData});

        valueSetted_ = true;
        return AmctCommon::SUCCESS;
    }

    ~RecordData() override {}

    int AddData(std::string name, Data* value) override
    {
        NULLPTR_CHECK(value);

        auto* child = GetChildPair(name);
        NULLPTR_CHECK(child);
        NULLPTR_CHECK(child->second);

        if (name == "key") {
            NULLPTR_CHECK(dynamic_cast<StringData*>(value));
            StringData* keyData = new(std::nothrow) StringData(*(dynamic_cast<StringData*>(value)));
            NULLPTR_CHECK(keyData);
            delete child->second;
            child->second = keyData;
        } else if (name == "value") {
            NULLPTR_CHECK(dynamic_cast<ValueData*>(value));
            ValueData* valueData = new(std::nothrow) ValueData(*(dynamic_cast<ValueData*>(value)));
            NULLPTR_CHECK(valueData);
            int ret = valueData->Copy(*value);
            if (ret != AmctCommon::SUCCESS) {
                delete valueData;
                return ret;
            }
            delete child->second;
            child->second = valueData;
        }

        valueSetted_ = true;
        return AmctCommon::SUCCESS;
    }

    bool HasKey() const
    {
        StringData* key = dynamic_cast<StringData*>(GetChild("key"));
        return key->HasValue();
    }

    std::string Key() const
    {
        StringData* key = dynamic_cast<StringData*>(GetChild("key"));
        return key->GetData();
    }

    void SetKey(std::string keyValue) const
    {
        StringData* key = dynamic_cast<StringData*>(GetChild("key"));
        key->SetData(keyValue);
    }

    ValueData* Value() const
    {
        return dynamic_cast<ValueData*>(GetChild("value"));
    }
};

class RecordDataPrune : public Data {
public:
    RecordDataPrune(std::string name, FieldType type): Data(name, type, 0) {}

    int Init() override
    {
        data_ = "";
        return Data::Init();
    }

    void AddData(std::string childName, std::string& value) override
    {
        data_ = value;
    }

    std::string Dump() override
    {
        std::string dumpOut = "prune_record {" + data_ + "}\n";
        return dumpOut;
    }

    int Copy(Data& value) override
    {
        RecordDataPrune* recordPruneData = dynamic_cast<RecordDataPrune*>(&value);
        NULLPTR_CHECK(recordPruneData);
        data_ = recordPruneData->data_;
        valueSetted_ = true;
        return AmctCommon::SUCCESS;
    }

    RecordDataPrune(const RecordDataPrune& obj): Data(obj) {}
    RecordDataPrune& operator=(const RecordDataPrune& obj)
    {
        if (this == &obj) {
            return *this;
        }
        Data::operator=(obj);
        this->data_ = obj.data_;
        return *this;
    }
    ~RecordDataPrune() override {}

private:
    std::string data_;
};


class InnerData : public Data {
public:
    InnerData(): Data("InnerScaleOffsetRecord", FieldType::MESSAGE, 0) {}
    ~InnerData() override
    {
        for (auto& ele: record_) {
            if (ele != nullptr) {
                delete ele;
                ele = nullptr;
            }
        }

        for (auto& ele: pruneRecord_) {
            if (ele != nullptr) {
                delete ele;
                ele = nullptr;
            }
        }
    }

    std::string Dump() override
    {
        std::string ret;
        for (auto& ele: record_) {
            ret += ele->Dump();
        }
        for (auto& ele: pruneRecord_) {
            ret += ele->Dump();
        }
        return ret;
    }

    int AddData(std::string name, Data* value) override
    {
        // and name != "prune_record"
        NULLPTR_CHECK(value);
        if (name != "record" and name != "prune_record") {
            std::cout<<"Error raised from proto_simulator.h"<<std::endl;
            return AmctCommon::RECORD_FILE_PARSE_ERROR;
        }

        if (name == "record") {
            NULLPTR_CHECK(dynamic_cast<RecordData*>(value));
            RecordData* ele = new(std::nothrow) RecordData(*(dynamic_cast<RecordData*>(value)));
            NULLPTR_CHECK(ele);
            int ret = ele->Copy(*value);
            if (ret != AmctCommon::SUCCESS) {
                delete ele;
                return ret;
            }
            record_.push_back(ele);
        } else {
            NULLPTR_CHECK(dynamic_cast<RecordDataPrune*>(value));
            RecordDataPrune* ele = new(std::nothrow) RecordDataPrune(*(dynamic_cast<RecordDataPrune*>(value)));
            NULLPTR_CHECK(ele);
            int ret = ele->Copy(*value);
            if (ret != AmctCommon::SUCCESS) {
                delete ele;
                return ret;
            }
            pruneRecord_.push_back(ele);
        }

        valueSetted_ = true;
        return AmctCommon::SUCCESS;
    }

    void ClearData() override
    {
        for (auto& ele: record_) {
            if (ele != nullptr) {
                delete ele;
                ele = nullptr;
            }
        }

        for (auto& ele: pruneRecord_) {
            if (ele != nullptr) {
                delete ele;
                ele = nullptr;
            }
        }
        valueSetted_ = false;
        record_.clear();
        pruneRecord_.clear();
    }

    size_t RecordSize() const
    {
        return record_.size();
    }

    RecordData* GetRecord(size_t index)
    {
        if (index >= record_.size()) {
            return nullptr;
        }
        return record_[index];
    }

    RecordData* AddRecord()
    {
        RecordData* ele = new(std::nothrow) RecordData("record", FieldType::MESSAGE_LIST, 0);
        if (ele == nullptr) {
            return nullptr;
        }

        if (ele->Init() != AmctCommon::SUCCESS) {
            if (ele != nullptr) {
                delete ele;
                ele = nullptr;
            }
            return nullptr;
        }

        record_.push_back(ele);
        valueSetted_ = true;
        return ele;
    }

private:
    std::vector<RecordData*> record_;
    std::vector<RecordDataPrune*> pruneRecord_;
};

#define NULLPTR_CHECK_AND_RELEASE(ptr, toRelease)   \
    do {                                            \
        if (ptr == nullptr) {                       \
            delete toRelease;                       \
            return AmctCommon::NULL_PTR_ERROR;      \
        }                                           \
    } while (0)

class ValueProto : public Proto {
public:
    ValueProto(std::string name, unsigned int level): Proto(name, level) {}
    ~ValueProto() override {}

    int Init() override
    {
        std::string childName = "scale_d";
        FloatProto* scaleDProto = new(std::nothrow) FloatProto(childName, level_ + 1);
        NULLPTR_CHECK(scaleDProto);
        FloatData* scaleDData = new(std::nothrow) FloatData(childName, FieldType::FLOAT32, level_ + 1);
        NULLPTR_CHECK_AND_RELEASE(scaleDData, scaleDProto);
        AddChild(childName, scaleDProto, scaleDData);

        childName = "offset_d";
        IntProto* offsetDProto = new(std::nothrow) IntProto(childName, level_ + 1);
        NULLPTR_CHECK(offsetDProto);
        IntData* offsetDData = new(std::nothrow) IntData(childName, FieldType::INT32, level_ + 1);
        NULLPTR_CHECK_AND_RELEASE(offsetDData, offsetDProto);
        AddChild(childName, offsetDProto, offsetDData);

        childName = "scale_w";
        FloatProto* scaleWProto = new(std::nothrow) FloatProto(childName, level_ + 1);
        NULLPTR_CHECK(scaleWProto);
        FloatListData* scaleWData = new(std::nothrow) FloatListData(childName, FieldType::FLOAT32_LIST, level_ + 1);
        NULLPTR_CHECK_AND_RELEASE(scaleWData, scaleWProto);
        AddChild(childName, scaleWProto, scaleWData);

        childName = "offset_w";
        IntProto* offsetWProto = new(std::nothrow) IntProto(childName, level_ + 1);
        NULLPTR_CHECK(offsetWProto);
        IntListData* offsetWData = new(std::nothrow) IntListData(childName, FieldType::INT32_LIST, level_ + 1);
        NULLPTR_CHECK_AND_RELEASE(offsetWData, offsetWProto);
        AddChild(childName, offsetWProto, offsetWData);

        childName = "shift_bit";
        UnsignedIntProto* shiftBitProto = new(std::nothrow) UnsignedIntProto(childName, level_ + 1);
        NULLPTR_CHECK(shiftBitProto);
        UnsignedIntListData* shiftBitData =
            new(std::nothrow) UnsignedIntListData(childName, FieldType::UINT32_LIST, level_ + 1);
        NULLPTR_CHECK_AND_RELEASE(shiftBitData, shiftBitProto);
        AddChild(childName, shiftBitProto, shiftBitData);

        childName = "cluster";
        IntProto* clusterProto = new(std::nothrow) IntProto(childName, level_ + 1);
        NULLPTR_CHECK(clusterProto);
        IntListData* clusterData = new(std::nothrow) IntListData(childName, FieldType::INT32_LIST, level_ + 1);
        NULLPTR_CHECK_AND_RELEASE(clusterData, clusterProto);
        AddChild(childName, clusterProto, clusterData);

        childName = "skip_fusion";
        BoolProto* skipFusionProto = new(std::nothrow) BoolProto(childName, level_ + 1);
        NULLPTR_CHECK(skipFusionProto);
        BoolData* skipFusionData = new(std::nothrow) BoolData(childName, FieldType::BOOL, level_ + 1);
        NULLPTR_CHECK_AND_RELEASE(skipFusionData, skipFusionProto);
        AddChild(childName, skipFusionProto, skipFusionData);

        childName = "dst_type";
        StringProto* dstTypeProto = new(std::nothrow) StringProto(childName, level_ + 1);
        NULLPTR_CHECK(dstTypeProto);
        StringData* dstTypeData = new(std::nothrow) StringData(childName, FieldType::STRING, level_ + 1);
        NULLPTR_CHECK_AND_RELEASE(dstTypeData, dstTypeProto);
        AddChild(childName, dstTypeProto, dstTypeData);

        childName = "tensor_balance_factor";
        FloatProto* tensorBalanceFactorProto = new(std::nothrow) FloatProto(childName, level_ + 1);
        NULLPTR_CHECK(tensorBalanceFactorProto);
        FloatListData* tensorBalanceFactorData = \
            new(std::nothrow) FloatListData(childName, FieldType::FLOAT32_LIST, level_ + 1);
        NULLPTR_CHECK_AND_RELEASE(tensorBalanceFactorData, tensorBalanceFactorProto);
        AddChild(childName, tensorBalanceFactorProto, tensorBalanceFactorData);

        return Proto::Init();
    }
};

class RecordProto : public Proto {
public:
    explicit RecordProto(std::string name): Proto(name) {}
    ~RecordProto() override {}

    int Init() override
    {
        std::string childName = "key";
        StringProto* keyProto = new(std::nothrow) StringProto(childName, level_ + 1);
        NULLPTR_CHECK(keyProto);
        StringData* keyData = new(std::nothrow) StringData(childName, FieldType::STRING, level_ + 1);
        NULLPTR_CHECK_AND_RELEASE(keyData, keyProto);
        AddChild(childName, keyProto, keyData);

        childName = "value";
        ValueProto* valueProto = new(std::nothrow) ValueProto(childName, level_ + 1);
        NULLPTR_CHECK(valueProto);
        ValueData* valueData = new(std::nothrow) ValueData(childName, FieldType::MESSAGE, level_ + 1);
        NULLPTR_CHECK_AND_RELEASE(valueData, valueProto);
        AddChild(childName, valueProto, valueData);
        return Proto::Init();
    }
};


class PruneRecord : public Proto {
public:
    explicit PruneRecord(std::string name): Proto(name) {}
    ~PruneRecord() override {}

    int Parse(std::string& content, Data& data) override
    {
        data.AddData(name_, content);
        return AmctCommon::SUCCESS;
    }
};


class InnerProto : public Proto {
public:
    InnerProto(): Proto("InnerScaleOffsetRecord") {}
    ~InnerProto() override {}

    int Init() override
    {
        std::string childNameQuant = "record";
        RecordProto* recordProto = new(std::nothrow) RecordProto(childNameQuant);
        NULLPTR_CHECK(recordProto);
        RecordData* recordData = new(std::nothrow) RecordData(childNameQuant, FieldType::MESSAGE_LIST, level_);
        NULLPTR_CHECK_AND_RELEASE(recordData, recordProto);
        AddChild(childNameQuant, recordProto, recordData);

        std::string childNamePrune = "prune_record";
        PruneRecord* recordProtoPrune = new(std::nothrow) PruneRecord(childNamePrune);
        NULLPTR_CHECK(recordProtoPrune);
        RecordDataPrune* recordDataPrune = new(std::nothrow) RecordDataPrune(childNamePrune, FieldType::MESSAGE_LIST);
        NULLPTR_CHECK_AND_RELEASE(recordDataPrune, recordProtoPrune);
        AddChild(childNamePrune, recordProtoPrune, recordDataPrune);

        return Proto::Init();
    }
};

int ParseRecordFile(std::string recordFilePath, InnerData& records);

} // end of namespace amct_tf
#endif
