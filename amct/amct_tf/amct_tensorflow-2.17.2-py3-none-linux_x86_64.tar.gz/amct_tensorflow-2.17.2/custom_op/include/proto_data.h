/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this
 * file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief simulate protbuf behavior
 *
 * @version 1.0
 */
#ifndef PROTO_DATA_H
#define PROTO_DATA_H

#include <vector>
#include <string>

#include <sstream>
#include <iomanip>
#include "error_codes.h"

namespace amct_tf {
enum class FieldType {
    TOP_MESSAGE,
    MESSAGE,
    MESSAGE_LIST,
    STRING,
    FLOAT32,
    FLOAT32_LIST,
    INT32,
    INT32_LIST,
    UINT32_LIST,
    BOOL,
    UNKNOWN_TYPE
};

constexpr size_t FLOAT_PRECISION = 9;

class Data {
public:
    Data(std::string name, FieldType type, size_t level): name_(name), type_(type), level_(level) {}
    virtual ~Data()
    {
        for (auto& ele: children_) {
            delete ele.second;
        }
    }

    virtual int Init()
    {
        for (auto& ele: children_) {
            int ret = (ele.second)->Init();
            if (ret != AmctCommon::SUCCESS) {
                return ret;
            }
        }
        return AmctCommon::SUCCESS;
    }

    virtual int Copy(Data& value)
    {
        (void)value;
        return AmctCommon::SUCCESS;
    }

    virtual void AddData(std::string name, float& value) {}
    virtual void AddData(std::string name, int& value) {}
    virtual void AddData(std::string name, size_t& value) {}
    virtual void AddData(std::string name, std::string& value) {}
    virtual void AddData(std::string name, bool& value) {}
    virtual int AddData(std::string name, Data* value)
    {
        return AmctCommon::SUCCESS;
    }

    virtual void ClearData()
    {
        valueSetted_ = false;
        for (auto& ele: children_) {
            (ele.second)->ClearData();
        }
    }

    bool IsMessage(FieldType type) const
    {
        if (type == FieldType::TOP_MESSAGE || type == FieldType::MESSAGE || type == FieldType::MESSAGE_LIST) {
            return true;
        }
        return false;
    }

    std::string GenSpace() const
    {
        std::string ret;
        for (size_t i = 0; i < level_; i++) {
            ret += "  ";
        }
        return ret;
    }

    virtual std::string Dump()
    {
        std::string ret;
        if (HasValue() && IsMessage(type_)) {
            ret += GenSpace();
            ret += name_;
            ret += " {\n";

            for (auto& ele: children_) {
                ret += (ele.second)->Dump();
            }

            ret += GenSpace();
            ret += "}\n";
        }

        return ret;
    }

    bool HasValue() const
    {
        for (auto& ele: children_) {
            if (ele.second->HasValue()) {
                return true;
            }
        }
        return valueSetted_;
    }

    Data* GetChild(std::string name) const
    {
        for (auto& ele: children_) {
            if (ele.first == name) {
                return ele.second;
            }
        }
        return nullptr;
    }

    std::pair<std::string, Data*>* GetChildPair(std::string name)
    {
        for (auto& ele: children_) {
            if (ele.first == name) {
                return &ele;
            }
        }
        return nullptr;
    }

protected:
    std::string name_;
    FieldType type_;
    size_t level_;
    bool valueSetted_ = false;
    std::vector<std::pair<std::string, Data*>> children_;

    Data(const Data &obj): name_(obj.name_), type_(obj.type_), level_(obj.level_) {}
    Data& operator=(const Data &obj)
    {
        if (&obj == this) {
            return *this;
        }
        name_ = obj.name_;
        type_ = obj.type_;
        level_ = obj.level_;
        valueSetted_ = obj.valueSetted_;
        children_ = obj.children_;
        return *this;
    }
};

class BoolData : public Data {
public:
    BoolData(std::string name, FieldType type, size_t level): Data(name, type, level) {}
    BoolData(const BoolData &obj): Data(obj), data_(obj.data_)
    {
        valueSetted_ = obj.HasValue();
    }
    BoolData& operator=(const BoolData &obj)
    {
        if (&obj == this) {
            return *this;
        }
        Data::operator=(obj);
        data_ = obj.data_;
        valueSetted_ = obj.HasValue();
        return *this;
    }
    ~BoolData() override {}

    int AddData(std::string name, Data* value) override
    {
        NULLPTR_CHECK(value);
        valueSetted_ = true;
        NULLPTR_CHECK(dynamic_cast<BoolData*>(value));
        data_ = dynamic_cast<BoolData*>(value)->data_;
        return AmctCommon::SUCCESS;
    }

    void AddData(std::string name, bool& value) override
    {
        valueSetted_ = true;
        data_ = value;
    }

    std::string Dump() override
    {
        if (!HasValue()) {
            return "";
        }

        std::string value = "false";
        if (data_) {
            value = "true";
        }
        std::string ret = GenSpace() + name_ + ": " + value + "\n";
        return ret;
    }

private:
    bool data_ = false;
};

class FloatData : public Data {
public:
    FloatData(std::string name, FieldType type, size_t level): Data(name, type, level) {}
    FloatData(const FloatData &obj): Data(obj), data_(obj.data_)
    {
        valueSetted_ = obj.HasValue();
    }
    FloatData& operator=(const FloatData &obj)
    {
        if (&obj == this) {
            return *this;
        }
        Data::operator=(obj);
        data_ = obj.data_;
        valueSetted_ = obj.HasValue();
        return *this;
    }
    ~FloatData() override {}

    int AddData(std::string name, Data* value) override
    {
        NULLPTR_CHECK(value);
        valueSetted_ = true;
        NULLPTR_CHECK(dynamic_cast<FloatData*>(value));
        data_ = dynamic_cast<FloatData*>(value)->data_;
        return AmctCommon::SUCCESS;
    }

    void AddData(std::string name, float& value) override
    {
        valueSetted_ = true;
        data_ = value;
    }

    std::string Dump() override
    {
        if (!HasValue()) {
            return "";
        }

        std::stringstream stream;
        stream << std::setprecision(FLOAT_PRECISION) << data_;
        std::string ret = GenSpace() + name_ + ": " + stream.str() + "\n";
        return ret;
    }

    float GetData() const
    {
        return data_;
    }

private:
    float data_ = 0.0;
};

class IntData : public Data {
public:
    IntData(std::string name, FieldType type, size_t level): Data(name, type, level) {}
    IntData(const IntData &obj): Data(obj), data_(obj.data_)
    {
        valueSetted_ = obj.HasValue();
    }
    IntData& operator=(const IntData &obj)
    {
        if (&obj == this) {
            return *this;
        }
        Data::operator=(obj);
        data_ = obj.data_;
        valueSetted_ = obj.HasValue();
        return *this;
    }
    ~IntData() override {}

    int AddData(std::string name, Data* value) override
    {
        NULLPTR_CHECK(value);
        valueSetted_ = true;
        NULLPTR_CHECK(dynamic_cast<IntData*>(value));
        data_ = dynamic_cast<IntData*>(value)->data_;
        return AmctCommon::SUCCESS;
    }

    void AddData(std::string name, int& value) override
    {
        valueSetted_ = true;
        data_ = value;
    }

    std::string Dump() override
    {
        if (!HasValue()) {
            return "";
        }

        std::string ret = GenSpace() + name_ + ": " + std::to_string(data_) + "\n";
        return ret;
    }

private:
    int data_ = 0;
};

class StringData : public Data {
public:
    StringData(std::string name, FieldType type, size_t level): Data(name, type, level) {}
    StringData(const StringData &obj): Data(obj), data_(obj.data_)
    {
        valueSetted_ = obj.HasValue();
    }
    StringData& operator=(const StringData &obj)
    {
        if (&obj == this) {
            return *this;
        }
        Data::operator=(obj);
        data_ = obj.data_;
        valueSetted_ = obj.HasValue();
        return *this;
    }
    ~StringData() override {}

    int AddData(std::string name, Data* value) override
    {
        NULLPTR_CHECK(value);
        valueSetted_ = true;
        NULLPTR_CHECK(dynamic_cast<StringData*>(value));
        data_ = dynamic_cast<StringData*>(value)->data_;
        return AmctCommon::SUCCESS;
    }

    void AddData(std::string childName, std::string& value) override
    {
        valueSetted_ = true;
        data_ = value;
    }

    std::string Dump() override
    {
        if (data_.size() == 0) {
            return "";
        }

        std::string ret = GenSpace() + name_ + ": \"" + data_ + "\"\n";
        return ret;
    }

    std::string GetData()
    {
        return data_;
    }

    void SetData(std::string value)
    {
        AddData(name_, value);
    }

private:
    std::string data_;
};

template<typename T>
class ListData : public Data {
public:
    ListData(std::string name, FieldType type, size_t level): Data(name, type, level) {}
    ~ListData() override {}

    int AddData(std::string name, Data* value) override
    {
        (void)name;
        NULLPTR_CHECK(value);
        valueSetted_ = true;
        std::vector<T>& src = dynamic_cast<ListData*>(value)->data_;
        for (auto& ele: src) {
            data_.push_back(ele);
        }
        return AmctCommon::SUCCESS;
    }

    void AddData(std::string name, T& value) override
    {
        (void)name;
        valueSetted_ = true;
        data_.push_back(value);
    }

    void ClearData() override
    {
        valueSetted_ = false;
        data_.clear();
    }

    virtual size_t GetSize()
    {
        return data_.size();
    }

    virtual T GetData(size_t index)
    {
        const T ret = 0;
        if (index >= data_.size()) {
            return ret;
        }
        return data_[index];
    }

    std::string Dump() override
    {
        if (!HasValue()) {
            return "";
        }

        std::string ret;
        for (auto& ele: data_) {
            ret += GenSpace() + name_ + ": " + std::to_string(ele) + "\n";
        }
        return ret;
    }

protected:
    ListData(const ListData &obj): Data(obj), data_(obj.data_)
    {
        valueSetted_ = obj.HasValue();
    }
    ListData& operator=(const ListData &obj)
    {
        if (&obj == this) {
            return *this;
        }
        Data::operator=(obj);
        data_ = obj.data_;
        valueSetted_ = obj.HasValue();
        return *this;
    }
    std::vector<T> data_;
};

class FloatListData : public ListData<float> {
public:
    FloatListData(std::string name, FieldType type, size_t level): ListData(name, type, level) {}
    FloatListData(const FloatListData &obj): ListData(obj) {}
    FloatListData& operator=(const FloatListData &obj)
    {
        if (&obj == this) {
            return *this;
        }
        ListData::operator=(obj);
        return *this;
    }
    ~FloatListData() override {}

    std::string Dump() override
    {
        if (!HasValue()) {
            return "";
        }

        std::string ret;
        for (auto& ele: data_) {
            std::stringstream stream;
            stream << std::setprecision(FLOAT_PRECISION) << ele;
            ret += GenSpace() + name_ + ": " + stream.str() + "\n";
        }
        return ret;
    }
};

class IntListData : public ListData<int> {
public:
    IntListData(std::string name, FieldType type, size_t level): ListData(name, type, level) {}
    IntListData(const IntListData &obj): ListData(obj) {}
    IntListData& operator=(const IntListData &obj)
    {
        if (&obj == this) {
            return *this;
        }
        ListData::operator=(obj);
        return *this;
    }
    ~IntListData() override {}
};

class UnsignedIntListData : public ListData<size_t> {
public:
    UnsignedIntListData(std::string name, FieldType type, size_t level): ListData(name, type, level) {}
    UnsignedIntListData(const UnsignedIntListData &obj): ListData(obj) {}
    UnsignedIntListData& operator=(const UnsignedIntListData &obj)
    {
        if (&obj == this) {
            return *this;
        }
        ListData::operator=(obj);
        return *this;
    }
    ~UnsignedIntListData() override {}
};
} // end of namespace amct_tf

#endif
