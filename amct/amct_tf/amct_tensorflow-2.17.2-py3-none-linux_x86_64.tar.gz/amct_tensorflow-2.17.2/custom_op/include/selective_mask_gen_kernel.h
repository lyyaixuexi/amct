/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2021. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief selective_mask_gen header file
 *
 * @file selective_mask_gen_kernel.h in common_cpp
 *
 * @version 1.0
 */
#ifndef AMCT_SELECTIVE_MASK_GEN_KERNEL_H
#define AMCT_SELECTIVE_MASK_GEN_KERNEL_H

#include <vector>
#include "util.h"

namespace SelectiveMaskGenKernel {
constexpr int BATCH_COUNT_INDEX = 1;
constexpr int CONTAINER_INDEX = 2;
constexpr int REMAIN_CHANNELS_INDEX = 3;

struct SelectivePruneParam {
    // axis to prune
    unsigned int pruneAxis;
    // n out of m elements to remain
    unsigned int m;
    unsigned int n;
    unsigned int updateFreq;
    std::vector<unsigned int> shape;
};

struct CudaCalcParam {
    unsigned int n;
    unsigned int m;
    unsigned int innerJump;
    unsigned int outerJump;
    unsigned int groupNum;
    unsigned int remainChannelsNum;
    unsigned int remainWgtSize;
    unsigned int oriOuterJump;
};

unsigned int ComputeProduct(std::vector<unsigned int> &vec, unsigned int startIdx, unsigned int endIdx);

template <typename T>
void ProcessSingleGroup(const SelectivePruneParam &pruneParam, unsigned int startIdx, unsigned int jump,
    const T* wgt, std::vector<T> &mask);

template <typename T>
void GetNOutOfM(unsigned int n, std::vector<unsigned int> &flatIdx, const T* wgt);

template <typename Device, typename T>
struct ComputeMask {
    int operator()(const T* wgt, const T* remainChannels, T* remainWgt,
        SelectiveMaskGenKernel::SelectivePruneParam pruneParam, T* mask) const;
};

template <typename Device, typename T>
struct IdentityMask {
    int operator()(unsigned int size, const T* maskContainerPtr, T* maskPtr) const;
};
}

#endif
