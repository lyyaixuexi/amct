/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Declare AscendDequant Operator Forward Operation
 *
 * @file ascend_dequant.h
 *
 * @version 1.0
 */
#ifndef ASCEND_DEQUANT_H
#define ASCEND_DEQUANT_H

#include <string>

namespace AmctTfOp {
// Define the structure of data quantification
template <typename T>
struct DequantInputParam {
    int areaFactor;
    int size;
    const T* input;
    const long long unsigned int* deqscale;
    int channelNum;
    int hwSize;
    bool channelWise;
    bool transpose;
    std::string dataFormat;
};


template <typename Device, typename T>
struct AscendDequantFunctor {
    int operator()(struct DequantInputParam<T> inputParam, T* outputData) const;
};
}

#endif // ASCEND_DEQUANT_H
