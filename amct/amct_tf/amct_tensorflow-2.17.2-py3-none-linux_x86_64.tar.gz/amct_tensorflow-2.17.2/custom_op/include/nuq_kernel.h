/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief nuq head file
 *
 * @file nuq.h
 *
 * @version 1.0
 */

#ifndef NUQ_KERNEL_H
#define NUQ_KERNEL_H

#include <string>
#include "nuq.h"

namespace AmctTfOp {
constexpr int NUQ_WEIGHT_INDEX = 0;
constexpr int NUQ_SCALE_INDEX = 0;
constexpr int NUQ_OFFSET_INDEX = 1;
constexpr int NUQ_OUTPUT_WEIGHT_INDEX = 2;


// Define the structure of data quantification
struct WeightNuqQuantParam {
    float* scale;
    int* offset;
    int* cluster;
    float* scaleCpu;
    int* offsetCpu;
    int* clusterCpu;
    int scaleLength;
    int clusterLength;
    int quantBits;
    int numSteps;
    int numOfIteration;
    bool withOffset;
    std::string layerName;
    std::string recordFilePath;
};


template <typename Device, typename T>
struct Restore {
    void operator()(T* data, std::vector<T> clusterData, float* scale, int* offset, int scaleLength,
        unsigned int perChannelLength) const;
};


template <typename Device, typename T>
struct NuqFunctor {
    void operator()(T* data, const int length, struct WeightNuqQuantParam quantParam,
        struct AmctCommon::ThrustParam<T>& thrustParam) const;
};

template <typename Device, typename T>
struct IdentityScaleOffsetNuq {
    void operator()(struct WeightNuqQuantParam quantParam) const;
};

template <typename Device, typename T>
struct IdentityWeightNuq {
    void operator()(const T* input, T* weight, const int inputSize) const;
};

template <typename Device, typename T>
struct FakeQuantWithNuq {
    void operator()(struct WeightNuqQuantParam quantParam, const T* input, T* output, const int dataLength) const;
};
}

#endif // NUQ_KERNEL_H
