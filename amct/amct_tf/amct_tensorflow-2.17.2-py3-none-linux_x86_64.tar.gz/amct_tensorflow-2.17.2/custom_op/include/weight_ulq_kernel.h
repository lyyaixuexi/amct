/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Declare WeightRetrain Forward Operation
 *
 * @file weight_retrain.h
 *
 * @version 1.0
 */

#ifndef WEIGHT_ULQ_KERNEL_H
#define WEIGHT_ULQ_KERNEL_H

#include "weight_ulq.h"

namespace AmctTfOp {
template <typename Device, typename T>
struct ScaleArqInit {
    int operator()(const int size, const T* in, T* max, T* min, AmctCommon::WeightUlqParam quantParam) const;
};

template<typename Device, typename T>
struct WtsFakeQuantFunctor {
    int operator()(AmctCommon::Input<T> input, T* output, const float* scale, int quantBitNum, bool sRecFlag) const;
};

template<typename Device, typename T>
struct ProcessScale {
    void operator()(const float* scaleIn, float* scaleOut, int* offsetOut, int scaleLength, bool sRecFlag) const;
};
}

#endif // WEIGHT_ULQ_KERNEL_H
