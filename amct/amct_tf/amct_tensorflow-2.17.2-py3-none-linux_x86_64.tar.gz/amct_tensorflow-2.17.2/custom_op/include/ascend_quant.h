/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Declare AscendQuant Operator Forward Operation
 *
 * @file ascend_quant.h
 *
 * @version 1.0
 */
#ifndef ASCEND_QUANT_H
#define ASCEND_QUANT_H

namespace AmctTfOp {
// Define the structure of data quantification
template <typename T>
struct QuantInputParam {
    int size;
    const T* in;
    float scale;
    float offset;
    int quantBits;
};

template <typename Device, typename T>
struct AscendQuantFunctor {
    int operator()(struct QuantInputParam<T> inputParam, T* outputData) const;
};
}

#endif // ASCEND_QUANT_H
