/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define AscendDequant Operator Forward Operation on CPU
 *
 * @file ascend_dequant.cc
 *
 * @version 1.0
 */

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "ascend_dequant.h"
#include "initializer.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "util.h"
#include "cast_util.h"

using namespace tensorflow;
using namespace util;

namespace AmctTfOp {
// OpKernel definition.
// template parameter <T> is the datatype of the tensors.
template <typename Device, typename T>
class AscendDequantOp : public OpKernel {
public:
    explicit AscendDequantOp(OpKernelConstruction* context) : OpKernel(context)
    {
        OP_REQUIRES_OK(context, context->GetAttr("data_format", &(inputParam.dataFormat)));
        OP_REQUIRES_OK(context, context->GetAttr("ksize", &(ksize)));
        inputParam.areaFactor = ksize[0] * ksize[1];
        inputParam.size = 0;
        inputParam.input = nullptr;
        inputParam.deqscale = nullptr;
        inputParam.channelNum = 1;
        inputParam.hwSize = 1;
        inputParam.channelWise = false;
        inputParam.transpose = false;
    }

    ~AscendDequantOp() override {}

    void Compute(OpKernelContext* context) override
    {
        // Grab the input tensor
        const Tensor& inputTensor = context->input(0);
        TensorShape inputTensorShape = inputTensor.shape();
        const Tensor& deqscaleTensor = context->input(1);
        TensorShape deqscaleTensorShape = deqscaleTensor.shape();

        inputParam.size = static_cast<int>(inputTensor.NumElements());
        inputParam.input = inputTensor.flat<float>().data();
        inputParam.deqscale = deqscaleTensor.flat<unsigned long long>().data();

        std::vector<int> inputShape, deqscaleShape;
        inputShape.resize(inputTensorShape.dim_sizes().size());
        deqscaleShape.resize(deqscaleTensorShape.dim_sizes().size());

        for (unsigned int i = 0; i < inputShape.size(); i++) {
            inputShape[i] = inputTensorShape.dim_sizes()[i];
        }
        int deqscaleSize = 1;
        for (unsigned int i = 0; i < deqscaleShape.size(); i++) {
            deqscaleShape[i] = deqscaleTensorShape.dim_sizes()[i];
            deqscaleSize *= deqscaleShape[i];
        }

        if (deqscaleSize <= 1) {
            inputParam.channelWise = false;
        } else {
            inputParam.channelWise = true;
            if (inputParam.dataFormat == "NCHW") {
                inputParam.transpose = true;
                inputParam.channelNum = deqscaleSize;
                inputParam.hwSize = inputShape[NCHW_H_DIM] * inputShape[NCHW_W_DIM];
            } else {
                inputParam.transpose = false;
                inputParam.channelNum = deqscaleSize;
                inputParam.hwSize = inputShape[NHWC_H_DIM] * inputShape[NHWC_W_DIM];
            }
        }

        // Create an output tensor
        Tensor* outputTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(0, inputTensor.shape(), &outputTensor));

        float* outPtr = nullptr;
        Tensor outputSave;
        if (std::is_same<Eigen::half, T>::value) {
            OP_REQUIRES_OK(context, context->allocate_temp(DataTypeToEnum<float>::value,
                TensorShape({inputParam.size}), &outputSave));
            outPtr = outputSave.flat<float>().data();
        } else {
            outPtr = outputTensor->flat<float>().data();
        }

        // Do the computation.
        OP_REQUIRES(context, inputTensor.NumElements() <= tensorflow::kint32max,
                    errors::InvalidArgument("Too many elements in tensor"));

        if (inputParam.size == 0) {
            OP_REQUIRES(context, false, errors::InvalidArgument("AscendDequantOp: inputTensor is empty!"));
        }

        int errorCode = AscendDequantFunctor<Device, float>()(inputParam, outPtr);
        if (std::is_same<Eigen::half, T>::value) {
            DataCastToFloat16Functor<Device, float>()(outPtr,
                reinterpret_cast<uint16_t*>(outputTensor->flat<T>().data()), inputParam.size);
        }
        ERROR_CHECK(errorCode);
    }

private:
    struct DequantInputParam<float> inputParam;
    std::vector<int> ksize;
};
}

// Register the CPU kernels.
REGISTER_KERNEL_BUILDER(Name("AscendDequant").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::AscendDequantOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("AscendDequant").Device(DEVICE_CPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::AscendDequantOp<util::CPUDevice, Eigen::half>);

// Register the GPU kernels.
#ifdef GOOGLE_CUDA
extern template struct AmctTfOp::AscendDequantFunctor<util::GPUDevice, float>;
REGISTER_KERNEL_BUILDER(Name("AscendDequant").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::AscendDequantOp<util::GPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("AscendDequant").Device(DEVICE_GPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::AscendDequantOp<util::GPUDevice, Eigen::half>);
#endif  // GOOGLE_CUDA


REGISTER_OP("AscendDequant")
    .Attr("T: {float16, float32, float64}")
    .Attr("ksize: list(int)")
    .Attr("data_format: string = 'NHWC'")
    .Input("x: float")
    .Input("deq_scale: uint64")
    .Output("y: T")
    .SetShapeFn([](::tensorflow::shape_inference::InferenceContext* c) {
        c->set_output(0, c->input(0));
        return tensorflow::Status::OK();
    });