/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief arq algorithm custom op C++ implement
 *
 * @file arq.cc
 *
 * @version 1.0
 */


#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "arq_kernel.h"
#include "initializer.h"
#include "common.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "cast_util.h"

using namespace tensorflow;
using namespace util;

namespace AmctTfOp {
template <typename Device, typename T>
class QuantArqOp : public OpKernel {
public:
    explicit QuantArqOp(OpKernelConstruction* context) : OpKernel(context)
    {
        Initializer::GetInstance().Init();
        OP_REQUIRES_OK(context, context->GetAttr("scale_length", &scaleLength));
        OP_REQUIRES_OK(context, context->GetAttr("quant_bits", &quantBits));
        OP_REQUIRES_OK(context, context->GetAttr("layer_names", &layerNames));
        OP_REQUIRES_OK(context, context->GetAttr("record_file_path", &recordFilePath));
        scaleCpu.resize(scaleLength);
        offsetCpu.resize(scaleLength);
        quantParam.scale = nullptr;
        quantParam.offset = nullptr;
        quantParam.scaleCpu = nullptr;
        quantParam.offsetCpu = nullptr;
        quantParam.scaleNumber = scaleLength;
        quantParam.quantBits = quantBits;
        quantParam.layerName = "";
        quantParam.recordFilePath = recordFilePath;
    }

    ~QuantArqOp() override {}

    void Compute(OpKernelContext* context) override
    {
        const Tensor& input = context->input(ARQ_WEIGHT_INDEX);
        Tensor* scale = nullptr;
        Tensor* offset = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(ARQ_SCALE_INDEX, TensorShape({scaleLength}), &scale));
        OP_REQUIRES_OK(context, context->allocate_output(ARQ_OFFSET_INDEX, TensorShape({scaleLength}), &offset));

        const int inputSize = static_cast<int>(input.NumElements());
        auto scaleFlat = scale->flat<float>();
        auto offsetFlat = offset->flat<int>();

        quantParam.scale = scaleFlat.data();
        quantParam.offset = offsetFlat.data();
        quantParam.scaleCpu = scaleCpu.data();
        quantParam.offsetCpu = offsetCpu.data();

        Tensor inputSave;
        const float* inputPtr = nullptr;
        if (std::is_same<Eigen::half, T>::value) {
            OP_REQUIRES_OK(context, context->allocate_temp(DataTypeToEnum<float>::value,
                TensorShape({inputSize}), &inputSave));
            DataCastToFloat32Functor<Device, uint16_t>()(reinterpret_cast<const uint16_t*>(input.flat<T>().data()),
                inputSave.flat<float>().data(), inputSize);
            inputPtr = inputSave.flat<float>().data();
        } else {
            inputPtr = input.flat<float>().data();
        }

        batchCounter++;
        if (batchCounter == 1) {
            int errorCode = FindMaxMin<Device, float>()(inputSize, inputPtr, quantParam);
            ERROR_CHECK(errorCode);
            for (unsigned int i = 0; i < layerNames.size(); i++) {
                ERROR_CHECK(WriteWeightToRecordFile(quantParam.scaleCpu, quantParam.offsetCpu, quantParam.scaleNumber,
                    layerNames[i], recordFilePath));
            }
        } else {
            int errorCode = IdentityScaleOffset<Device, float>()(quantParam);
            ERROR_CHECK(errorCode);
        }
    }

private:
    int scaleLength = 1;
    int quantBits = 8;
    struct WeightQuantParam quantParam;
    int batchCounter = 0;
    std::vector<std::string> layerNames;
    std::string recordFilePath = "record_file_path_init";
    std::vector<float> scaleCpu;
    std::vector<int> offsetCpu;
};
}

REGISTER_KERNEL_BUILDER(Name("QuantArq").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::QuantArqOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("QuantArq").Device(DEVICE_CPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::QuantArqOp<util::CPUDevice, Eigen::half>);

#ifdef GOOGLE_CUDA
REGISTER_KERNEL_BUILDER(Name("QuantArq").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::QuantArqOp<util::GPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("QuantArq").Device(DEVICE_GPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::QuantArqOp<util::GPUDevice, Eigen::half>);
#endif


REGISTER_OP("QuantArq")
    .Attr("T: {float16, float32, float64}")
    .Attr("scale_length: int = 1")
    .Attr("quant_bits: int = 8")
    .Attr("layer_names: list(string)")
    .Attr("record_file_path: string")
    .Input("input: T")
    .Input("enable: T")
    .Output("scale: float")
    .Output("offset: int32")
    .SetShapeFn([](shape_inference::InferenceContext* c)
    {
        int scaleLength = 1;
        TF_RETURN_IF_ERROR(c->GetAttr("scale_length", &scaleLength));

        shape_inference::ShapeHandle output;
        output = c->MakeShape({scaleLength});

        c->set_output(0, output);
        c->set_output(1, output);

        return tensorflow::Status::OK();
    })
    .Doc(R"doc(ARQ quant algorithm.)doc");
