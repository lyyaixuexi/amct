/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define QuantIfmr Operator Forward Operation on CPU
 *
 * @file ifmr.cc
 *
 * @version 1.0
 */

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "ifmr_kernel.h"
#include "initializer.h"
#include "common.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "cast_util.h"

using namespace tensorflow;
using namespace util;

namespace AmctTfOp {
// OpKernel definition.
// template parameter <T> is the datatype of the tensors.
template <typename Device, typename T>
class QuantIfmrOp : public OpKernel {
public:
    explicit QuantIfmrOp(OpKernelConstruction* context) : OpKernel(context)
    {
        Initializer::GetInstance().Init();
        isGroup = false;
        OP_REQUIRES_OK(context, context->GetAttr("quant_bit_num", &(quantBitNum)));
        OP_REQUIRES_OK(context, context->GetAttr("with_offset", &(withOffset)));
        OP_REQUIRES_OK(context, context->GetAttr("max_percentile", &(maxPercentile)));
        OP_REQUIRES_OK(context, context->GetAttr("min_percentile", &(minPercentile)));
        OP_REQUIRES_OK(context, context->GetAttr("search_range", &(searchRange)));
        OP_REQUIRES_OK(context, context->GetAttr("search_step", &(searchStep)));
        OP_REQUIRES_OK(context, context->GetAttr("batch_num", &(batchNum)));
        OP_REQUIRES_OK(context, context->GetAttr("layer_names", &layerNames));
        OP_REQUIRES_OK(context, context->GetAttr("record_file_path", &recordFilePath));
        OP_REQUIRES_OK(context, context->GetAttr("input_stamp", &(inputStamp)));
        const int rangeSize = 2;
        std::stringstream printInfo;
        printInfo << "Check failed: searchRange should have size == 2, but got: " << searchRange.size();
        OP_REQUIRES(context, searchRange.size() == rangeSize, errors::InvalidArgument(printInfo.str()));

        ifmrParam.ifmrCommon.calibration = 0;
        ifmrParam.ifmrCommon.numBits = quantBitNum;
        ifmrParam.ifmrCommon.withOffset = withOffset;
        ifmrParam.ifmrCommon.maxPercentile = maxPercentile;
        ifmrParam.ifmrCommon.minPercentile = minPercentile;
        ifmrParam.ifmrCommon.startRatio = searchRange[0];
        ifmrParam.ifmrCommon.endRatio = searchRange[1];
        ifmrParam.ifmrCommon.step = searchStep;
    }

    ~QuantIfmrOp() override {}

    int WriteToFile()
    {
        if (batchCounter == batchNum) {
            inputParam.storeData.clear();
            inputParam.storeData.shrink_to_fit();
            for (unsigned int index = 0; index < layerNames.size(); index++) {
                if (inputStamp == "data") {
                    CHECK_OK(WriteDataToRecordFile(quantParam.scaleCpu, quantParam.offsetCpu,
                        layerNames[index], recordFilePath, "hide"));
                } else {
                    CHECK_OK(WriteWeightToRecordFile(quantParam.scaleCpu, quantParam.offsetCpu,
                        1, layerNames[index], recordFilePath));
                }
            }
        }
        return AmctCommon::SUCCESS;
    }

    void Compute(OpKernelContext* context) override
    {
        // Grab the input tensor
        const Tensor& inTensor = context->input(0);
        // Create an output tensor
        Tensor* scaleTensor = nullptr;
        TensorShape scaleShape({1});
        OP_REQUIRES_OK(context, context->allocate_output(0, scaleShape, &scaleTensor));
        Tensor* offsetTensor = nullptr;
        TensorShape offsetTensorShape({1});
        OP_REQUIRES_OK(context, context->allocate_output(1, offsetTensorShape, &offsetTensor));
        inputParam.size = static_cast<int>(inTensor.NumElements());

        long long elementNum = static_cast<long long>(inputParam.size) * batchNum;
        std::stringstream printInfo;
        printInfo << "Check failed: size <= tensorflow::kint32max (" << elementNum << " vs. 2147483647)";
        OP_REQUIRES(context, elementNum <= static_cast<long long>(tensorflow::kint32max),
                    errors::InvalidArgument(printInfo.str()));
        Tensor ifmrData;
        Tensor quantError;
        if (batchCounter == batchNum - 1) {
            OP_REQUIRES_OK(context, context->allocate_temp(DataTypeToEnum<float>::value,
                TensorShape({static_cast<int>(inputParam.storeData.size()) + inputParam.size}), &ifmrData));
            OP_REQUIRES_OK(context, context->allocate_temp(DataTypeToEnum<float>::value,
                TensorShape({static_cast<int>(inputParam.storeData.size()) + inputParam.size}), &quantError));
        }
        quantParam.scale = scaleTensor->flat<float>().data();
        quantParam.offset = offsetTensor->flat<int>().data();
        quantParam.scaleCpu = &scaleCpu;
        quantParam.offsetCpu = &offsetCpu;
        quantParam.ifmrData = ifmrData.flat<float>().data();
        quantParam.quantError = quantError.flat<float>().data();
        quantParam.layerNames = layerNames;
        quantParam.recordFilePath = recordFilePath;

        Tensor inputSave;
        if (std::is_same<Eigen::half, T>::value) {
            OP_REQUIRES_OK(context, context->allocate_temp(DataTypeToEnum<float>::value, TensorShape({inputParam.size}),
                &inputSave));
            DataCastToFloat32Functor<Device, uint16_t>()(reinterpret_cast<const uint16_t*>(inTensor.flat<T>().data()),
                inputSave.flat<float>().data(), inputParam.size);
            inputParam.in = inputSave.flat<float>().data();
        } else {
            inputParam.in = inTensor.flat<float>().data();
        }
        int errorCode = QuantIfmrFunctor<Device, float>()(
            ifmrParam, batchCounter, batchNum, inputParam, quantParam);
        ERROR_CHECK(errorCode);
        ERROR_CHECK(WriteToFile());
    }

private:
    int quantBitNum;
    bool withOffset;
    bool isGroup;
    float maxPercentile;
    float minPercentile;
    std::vector<float> searchRange;
    float searchStep;
    struct amct_tf::IfmrParam ifmrParam;
    float scaleCpu = 1.0;
    int offsetCpu = 0;
    struct DataQuantParam<float> quantParam;
    struct InputParam<float> inputParam;
    int batchCounter = 0;
    int batchNum;
    std::vector<float> storeData;
    std::vector<std::string> layerNames;
    std::string recordFilePath = "record_file_path_init";
    std::string inputStamp;
};
}

// Register the CPU kernels.
REGISTER_KERNEL_BUILDER(Name("QuantIfmr").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::QuantIfmrOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("QuantIfmr").Device(DEVICE_CPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::QuantIfmrOp<util::CPUDevice, Eigen::half>);

// Register the GPU kernels.
#ifdef GOOGLE_CUDA
extern template struct AmctTfOp::QuantIfmrFunctor<util::GPUDevice, float>;
REGISTER_KERNEL_BUILDER(Name("QuantIfmr").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::QuantIfmrOp<util::GPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("QuantIfmr").Device(DEVICE_GPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::QuantIfmrOp<util::GPUDevice, Eigen::half>);
#endif  // GOOGLE_CUDA


REGISTER_OP("QuantIfmr")
    .Attr("T: {float16, float32, float64}")
    .Attr("quant_bit_num: int")
    .Attr("with_offset: bool")
    .Attr("max_percentile: float")
    .Attr("min_percentile: float")
    .Attr("search_range: list(float)")
    .Attr("search_step: float")
    .Attr("batch_num: int")
    .Attr("layer_names: list(string)")
    .Attr("record_file_path: string")
    .Attr("input_stamp: string = 'data'")
    .Input("in: T")
    .Input("enable: T")
    .Output("scale: float")
    .Output("offset: int32")
    .SetShapeFn([](::tensorflow::shape_inference::InferenceContext* c) {
        shape_inference::ShapeHandle outputShape;
        outputShape = c->MakeShape({1});

        c->set_output(0, outputShape);
        c->set_output(1, outputShape);
        return tensorflow::Status::OK();
    });