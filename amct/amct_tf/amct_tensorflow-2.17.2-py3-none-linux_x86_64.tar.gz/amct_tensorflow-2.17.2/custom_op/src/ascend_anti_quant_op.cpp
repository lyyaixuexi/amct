/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define AscendAntiQuant Operator Forward Operation on CPU
 *
 * @file ascend_anti_quant.cc
 *
 * @version 1.0
 */

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "ascend_anti_quant.h"
#include "initializer.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "util.h"
#include "cast_util.h"

using namespace tensorflow;
using namespace util;

namespace AmctTfOp {
// OpKernel definition.
// template parameter <T> is the datatype of the tensors.
template <typename Device, typename T>
class AscendAntiQuantOp : public OpKernel {
public:
    explicit AscendAntiQuantOp(OpKernelConstruction* context) : OpKernel(context)
    {
        OP_REQUIRES_OK(context, context->GetAttr("scale", &(scale)));
        OP_REQUIRES_OK(context, context->GetAttr("offset", &(offset)));
        inputParam.size = 0;
        inputParam.in = nullptr;
        inputParam.scale = scale;
        inputParam.offset = offset;
    }

    ~AscendAntiQuantOp() override {}

    void Compute(OpKernelContext* context) override
    {
        // Grab the input tensor
        const Tensor& inputTensorAntiQuant = context->input(0);

        inputParam.size = static_cast<int>(inputTensorAntiQuant.NumElements());
        inputParam.in = inputTensorAntiQuant.flat<float>().data();
        // Create an output tensor
        Tensor* outputTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(0, inputTensorAntiQuant.shape(), &outputTensor));

        float* outPtr = nullptr;
        Tensor outputSave;
        if (std::is_same<Eigen::half, T>::value) {
            OP_REQUIRES_OK(context, context->allocate_temp(DataTypeToEnum<float>::value,
                TensorShape({inputParam.size}), &outputSave));
            outPtr = outputSave.flat<float>().data();
        } else {
            outPtr = outputTensor->flat<float>().data();
        }

        // Do the computation.
        OP_REQUIRES(context, inputTensorAntiQuant.NumElements() <= tensorflow::kint32max,
            errors::InvalidArgument("Too many elements in tensor"));

        if (inputParam.size == 0) {
            OP_REQUIRES(context, false, errors::InvalidArgument("AscendAntiQuantOp: inputTensor is empty!"));
        }

        int errorCode = AscendAntiQuantFunctor<Device, float>()(inputParam, outPtr);
        if (std::is_same<Eigen::half, T>::value) {
            DataCastToFloat16Functor<Device, float>()(outPtr,
                reinterpret_cast<uint16_t*>(outputTensor->flat<T>().data()), inputParam.size);
        }
        ERROR_CHECK(errorCode);
    }

private:
    struct AntiQuantInputParam<float> inputParam;
    float scale;
    float offset;
};
}

// Register the CPU kernels.
REGISTER_KERNEL_BUILDER(Name("AscendAntiQuant").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::AscendAntiQuantOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("AscendAntiQuant").Device(DEVICE_CPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::AscendAntiQuantOp<util::CPUDevice, Eigen::half>);

// Register the GPU kernels.
#ifdef GOOGLE_CUDA
extern template struct AmctTfOp::AscendAntiQuantFunctor<util::GPUDevice, float>;
REGISTER_KERNEL_BUILDER(Name("AscendAntiQuant").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::AscendAntiQuantOp<util::GPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("AscendAntiQuant").Device(DEVICE_GPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::AscendAntiQuantOp<util::GPUDevice, Eigen::half>);
#endif  // GOOGLE_CUDA


REGISTER_OP("AscendAntiQuant")
    .Attr("T: {float16, float32, float64}")
    .Attr("scale: float")
    .Attr("offset: float")
    .Input("x: float")
    .Output("y: T")
    .SetShapeFn([](::tensorflow::shape_inference::InferenceContext* c) {
        c->set_output(0, c->input(0));
        return tensorflow::Status::OK();
    });