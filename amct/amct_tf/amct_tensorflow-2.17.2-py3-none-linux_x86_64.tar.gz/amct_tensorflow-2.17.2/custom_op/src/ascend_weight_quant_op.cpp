/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define AscendWeightQuant Operator Forward Operation on CPU
 *
 * @file ascend_weight_quant.cc
 *
 * @version 1.0
 */

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "ascend_weight_quant.h"
#include "initializer.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "util.h"

using namespace tensorflow;
using namespace util;

namespace AmctTfOp {
// OpKernel definition.
// template parameter <T> is the datatype of the tensors.
template <typename Device, typename T>
class AscendWeightQuantOp : public OpKernel {
public:
    explicit AscendWeightQuantOp(OpKernelConstruction* context) : OpKernel(context)
    {
        OP_REQUIRES_OK(context, context->GetAttr("dst_type", &(dstType)));
        inputParam.size = 0;
        inputParam.weight = nullptr;
        inputParam.offset = nullptr;
        inputParam.channelInNum = 1;
        inputParam.channelOutNum = 1;
        inputParam.channelWise = false;
        inputParam.transpose = false;
    }

    ~AscendWeightQuantOp() override {}

    void Compute(OpKernelContext* context) override
    {
        // Grab the input tensor
        const Tensor& inputTensor = context->input(0);
        TensorShape inputTensorShape = inputTensor.shape();
        const Tensor& offsetTensor = context->input(1);
        TensorShape offsetTensorShape = offsetTensor.shape();

        inputParam.size = static_cast<int>(inputTensor.NumElements());
        inputParam.weight = inputTensor.flat<int8>().data();
        inputParam.offset = offsetTensor.flat<int8>().data();

        std::vector<int> weightShape, offsetShape;
        weightShape.resize(inputTensorShape.dim_sizes().size());
        offsetShape.resize(offsetTensorShape.dim_sizes().size());

        for (unsigned int i = 0; i < weightShape.size(); i++) {
            weightShape[i] = inputTensorShape.dim_sizes()[i];
        }
        for (unsigned int i = 0; i < offsetShape.size(); i++) {
            offsetShape[i] = offsetTensorShape.dim_sizes()[i];
        }

        int offsetSize = 1;
        for (unsigned int i = 0; i < offsetShape.size(); i++) {
            offsetShape[i] = offsetTensorShape.dim_sizes()[i];
            offsetSize *= offsetShape[i];
        }
        if (offsetSize <= 1) {
            inputParam.channelWise = false;
        } else {
            inputParam.channelWise = true;
            if (offsetShape[offsetShape.size() - WEIGHT_SHAPE_CIN_OFFSET] > 1) {
                inputParam.transpose = true;
                inputParam.channelInNum = weightShape.back();
                inputParam.channelOutNum = weightShape[weightShape.size() - WEIGHT_SHAPE_CIN_OFFSET];
            } else {
                inputParam.transpose = false;
                inputParam.channelInNum = weightShape[weightShape.size() - WEIGHT_SHAPE_CIN_OFFSET];
                inputParam.channelOutNum = weightShape.back();
            }
        }

        // Create an output tensor
        Tensor* outputTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(0, inputTensor.shape(), &outputTensor));

        // Do the computation.
        OP_REQUIRES(context, inputTensor.NumElements() <= tensorflow::kint32max,
                    errors::InvalidArgument("Too many elements in tensor"));

        if (inputParam.size == 0) {
            OP_REQUIRES(context, false, errors::InvalidArgument("AscendWeightQuantOp: inputTensor is empty!"));
        }

        int errorCode = AscendWeightQuantFunctor<Device, T>()(inputParam, outputTensor->flat<T>().data());
        ERROR_CHECK(errorCode);
    }

private:
    struct WeightQuantInputParam<float> inputParam;
    std::string dstType;
};
}

// Register the CPU kernels.
REGISTER_KERNEL_BUILDER(Name("AscendWeightQuant").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::AscendWeightQuantOp<util::CPUDevice, float>);

// Register the GPU kernels.
#ifdef GOOGLE_CUDA
extern template struct AmctTfOp::AscendWeightQuantFunctor<util::GPUDevice, float>;
REGISTER_KERNEL_BUILDER(Name("AscendWeightQuant").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::AscendWeightQuantOp<util::GPUDevice, float>);
#endif  // GOOGLE_CUDA


REGISTER_OP("AscendWeightQuant")
    .Attr("T: {float16, float32, float64}")
    .Attr("dst_type: {'INT4', 'INT8'} = 'INT8'")
    .Input("x: int8")
    .Input("offset_w: int8")
    .Output("y: T")
    .SetShapeFn([](::tensorflow::shape_inference::InferenceContext* c) {
        c->set_output(0, c->input(0));
        return tensorflow::Status::OK();
    });