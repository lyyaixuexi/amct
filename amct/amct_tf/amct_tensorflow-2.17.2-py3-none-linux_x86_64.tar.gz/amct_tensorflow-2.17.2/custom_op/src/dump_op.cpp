/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief arq algorithm custom op C++ implement
 *
 * @file arq.cc
 *
 * @version 1.0
 */


#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "dump_kernel.h"
#include "initializer.h"
#include "common.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "util.h"

using namespace tensorflow;

namespace AmctTfOp {
template <typename Device, typename T>
class DumpOp : public OpKernel {
public:
    explicit DumpOp(OpKernelConstruction* context) : OpKernel(context)
    {
        Initializer::GetInstance().Init();
        OP_REQUIRES_OK(context, context->GetAttr("dump_dir", &dumpParam.dumpDir));
        OP_REQUIRES_OK(context, context->GetAttr("name_prefix", &dumpParam.namePrefix));
        OP_REQUIRES_OK(context, context->GetAttr("batch_num", &batchNum));
    }

    ~DumpOp() override {}

    void Compute(OpKernelContext* context) override
    {
        const Tensor& inputTensor = context->input(0);
        Tensor* outTensorPtr = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(0, inputTensor.shape(), &outTensorPtr));
        auto inputFlat = inputTensor.flat<T>();
        auto outFlat = outTensorPtr->flat<T>();
        if (std::is_same<Eigen::half, T>::value) {
            amct_tf::CopyDataFunctor<Device, uint16_t>()(reinterpret_cast<const uint16_t*>(inputFlat.data()),
                inputFlat.size(), reinterpret_cast<uint16_t*>(outFlat.data()));
        } else {
            amct_tf::CopyDataFunctor<Device, T>()(inputFlat.data(), inputFlat.size(), outFlat.data());
        }

        batchCounter++;
        if (batchNum == -1 || batchCounter <= batchNum) {
            dumpParam.batchCounter = batchCounter;
            dumpParam.inputShapeLength = inputTensor.dims() + 1;
            dumpParam.inputShape.push_back(static_cast<float>(inputTensor.shape().dims()));
            for (int dimIndex = 0; dimIndex < inputTensor.shape().dims(); dimIndex++) {
                dumpParam.inputShape.push_back(static_cast<float>(inputTensor.shape().dim_size(dimIndex)));
            }
            if (std::is_same<Eigen::half, T>::value) {
                amct_tf::DumpFunctor<Device, uint16_t>()(reinterpret_cast<const uint16_t*>(inputFlat.data()),
                    inputFlat.size(), dumpParam);
            } else {
                amct_tf::DumpFunctor<Device, T>()(inputFlat.data(), inputFlat.size(), dumpParam);
            }
        }
    }

private:
    struct amct_tf::DumpParam dumpParam;
    int batchNum = -1;
    int batchCounter = 0;
    bool writeAdd = false;
};
}

REGISTER_KERNEL_BUILDER(Name("Dump").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::DumpOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("Dump").Device(DEVICE_CPU).TypeConstraint<double>("T"),
    AmctTfOp::DumpOp<util::CPUDevice, double>);
REGISTER_KERNEL_BUILDER(Name("Dump").Device(DEVICE_CPU).TypeConstraint<int>("T"),
    AmctTfOp::DumpOp<util::CPUDevice, int>);
REGISTER_KERNEL_BUILDER(Name("Dump").Device(DEVICE_CPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::DumpOp<util::CPUDevice, Eigen::half>);

#ifdef GOOGLE_CUDA
REGISTER_KERNEL_BUILDER(Name("Dump").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::DumpOp<util::GPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("Dump").Device(DEVICE_GPU).TypeConstraint<double>("T"),
    AmctTfOp::DumpOp<util::GPUDevice, double>);
REGISTER_KERNEL_BUILDER(Name("Dump").Device(DEVICE_GPU).TypeConstraint<int>("T"),
    AmctTfOp::DumpOp<util::GPUDevice, int>);
REGISTER_KERNEL_BUILDER(Name("Dump").Device(DEVICE_GPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::DumpOp<util::GPUDevice, Eigen::half>);
#endif

REGISTER_OP("Dump")
    .Attr("T: {float16, float32, float64, int32}")
    .Attr("dump_dir: string")
    .Attr("name_prefix: string")
    .Attr("batch_num: int")
    .Input("in: T")
    .Output("out: T")
    .SetShapeFn([](shape_inference::InferenceContext* c)
    {
        c->set_output(0, c->input(0));
        return tensorflow::Status::OK();
    })
    .Doc(R"doc(Dump quant algorithm.)doc");
