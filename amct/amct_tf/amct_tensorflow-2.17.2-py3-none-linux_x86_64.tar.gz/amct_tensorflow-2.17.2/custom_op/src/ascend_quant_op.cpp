/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define AscendQuant Operator Forward Operation on CPU
 *
 * @file ascend_quant.cc
 *
 * @version 1.0
 */

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "ascend_quant.h"
#include "initializer.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "util.h"
#include "cast_util.h"

using namespace tensorflow;
using namespace util;

namespace AmctTfOp {
// OpKernel definition.
// template parameter <T> is the datatype of the tensors.
template <typename Device, typename T>
class AscendQuantOp : public OpKernel {
public:
    explicit AscendQuantOp(OpKernelConstruction* context) : OpKernel(context)
    {
        OP_REQUIRES_OK(context, context->GetAttr("dst_type", &(dstType)));
        OP_REQUIRES_OK(context, context->GetAttr("scale", &(scale)));
        OP_REQUIRES_OK(context, context->GetAttr("offset", &(offset)));
        inputParam.size = 0;
        inputParam.in = nullptr;
        inputParam.scale = scale;
        inputParam.offset = offset;
        if (dstType == "INT4") {
            inputParam.quantBits = FOUR;
        } else if (dstType == "INT8") {
            inputParam.quantBits = EIGHT;
        }
    }

    ~AscendQuantOp() override {}

    void Compute(OpKernelContext* context) override
    {
        // Grab the input tensor
        const Tensor& inputTensorQuant = context->input(0);
        inputParam.size = static_cast<int>(inputTensorQuant.NumElements());
        // Create an output tensor
        Tensor* outputTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(0, inputTensorQuant.shape(), &outputTensor));

        Tensor inputSave;
        if (std::is_same<Eigen::half, T>::value) {
            OP_REQUIRES_OK(context, context->allocate_temp(DataTypeToEnum<float>::value,
                TensorShape({inputParam.size}), &inputSave));
            DataCastToFloat32Functor<Device, uint16_t>()(
                reinterpret_cast<const uint16_t*>(inputTensorQuant.flat<T>().data()),
                inputSave.flat<float>().data(),
                inputParam.size);
            inputParam.in = inputSave.flat<float>().data();
        } else {
            inputParam.in = inputTensorQuant.flat<float>().data();
        }

        // Do the computation.
        OP_REQUIRES(context, inputTensorQuant.NumElements() <= tensorflow::kint32max,
                    errors::InvalidArgument("Too many elements in tensor"));

        if (inputParam.size == 0) {
            OP_REQUIRES(context, false, errors::InvalidArgument("AscendQuantOp: inputTensor is empty!"));
        }

        int errorCode = AscendQuantFunctor<Device, float>()(inputParam, outputTensor->flat<float>().data());
        ERROR_CHECK(errorCode);
    }

private:
    struct QuantInputParam<float> inputParam;
    std::string dstType;
    float scale;
    float offset;
};
}

// Register the CPU kernels.
REGISTER_KERNEL_BUILDER(Name("AscendQuant").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::AscendQuantOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("AscendQuant").Device(DEVICE_CPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::AscendQuantOp<util::CPUDevice, Eigen::half>);

// Register the GPU kernels.
#ifdef GOOGLE_CUDA
extern template struct AmctTfOp::AscendQuantFunctor<util::GPUDevice, float>;
REGISTER_KERNEL_BUILDER(Name("AscendQuant").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::AscendQuantOp<util::GPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("AscendQuant").Device(DEVICE_GPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::AscendQuantOp<util::GPUDevice, Eigen::half>);
#endif  // GOOGLE_CUDA


REGISTER_OP("AscendQuant")
    .Attr("T: {float16, float32, float64}")
    .Attr("dst_type: {'INT4', 'INT8'} = 'INT8'")
    .Attr("quant_bits: int = 8")
    .Attr("scale: float")
    .Attr("offset: float")
    .Input("x: T")
    .Output("y: float")
    .SetShapeFn([](::tensorflow::shape_inference::InferenceContext* c) {
        c->set_output(0, c->input(0));
        return tensorflow::Status::OK();
    });