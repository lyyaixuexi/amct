/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define WeightRetrain Operator Forward Operation on CPU
 *
 * @file weight_ulq.cc
 *
 * @version 1.0
 */

#include <cmath>
#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/op_kernel.h"
#include "tensorflow/core/framework/shape_inference.h"

#include "weight_ulq_kernel.h"
#include "initializer.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "util.h"

using namespace tensorflow;

namespace AmctTfOp {
template<typename Device, typename T>
class WeightUlqOp : public OpKernel {
public:
    explicit WeightUlqOp(OpKernelConstruction* context) : OpKernel(context)
    {
        Initializer::GetInstance().Init();
        OP_REQUIRES_OK(context, context->GetAttr("s_rec_flag", &sRecFlag_));
        OP_REQUIRES_OK(context, context->GetAttr("quant_bit_num", &quantBitNum_));
        OP_REQUIRES_OK(context, context->GetAttr("scale_length", &scaleLength_));
    }

    ~WeightUlqOp() override {}

    void Compute(OpKernelContext* context) override
    {
        const Tensor& inputTensor = context->input(AmctCommon::DATA_IN_INDEX);
        auto inputFlat = inputTensor.flat<T>();

        Tensor scaleTensor = context->input(AmctCommon::SCALE_INDEX);
        auto scaleFlat = scaleTensor.flat<float>();

        Tensor* outputTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(AmctCommon::WEIGHT_ULQ_OUT_INDEX,
            inputTensor.shape(), &outputTensor));
        auto outputFlat = outputTensor->template flat<float>();

        Tensor* scaleOutTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(AmctCommon::WEIGHT_ULQ_SCALE_INDEX,
            TensorShape({scaleLength_}), &scaleOutTensor));
        auto scaleOutputFlat = scaleOutTensor->template flat<float>();

        Tensor* offsetOutTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(AmctCommon::WEIGHT_ULQ_OFFSET_INDEX,
            TensorShape({scaleLength_}), &offsetOutTensor));
        auto offsetOutFlat = offsetOutTensor->template flat<int>();

        AmctCommon::Input<T> wtsUlqInput;
        wtsUlqInput.data = inputFlat.data();
        wtsUlqInput.length = static_cast<int>(inputTensor.NumElements());
        wtsUlqInput.scaleLength = scaleLength_;

        WtsFakeQuantFunctor<Device, T>()(wtsUlqInput, outputFlat.data(), scaleFlat.data(), quantBitNum_, sRecFlag_);
        ProcessScale<Device, T>()(scaleFlat.data(), scaleOutputFlat.data(),
            offsetOutFlat.data(), scaleLength_, sRecFlag_);
    }

private:
    bool sRecFlag_ = false;
    int quantBitNum_ = 8;
    int scaleLength_ = 1;
};
}

REGISTER_KERNEL_BUILDER(Name("WeightUlq").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::WeightUlqOp<util::CPUDevice, float>);

#ifdef GOOGLE_CUDA
extern template struct AmctTfOp::WtsFakeQuantFunctor<util::GPUDevice, float>;
REGISTER_KERNEL_BUILDER(Name("WeightUlq").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::WeightUlqOp<util::GPUDevice, float>);
#endif

REGISTER_OP("WeightUlq")
    .Attr("T: {float16, float32, float64}")
    .Attr("quant_bit_num: int = 8")
    .Attr("s_rec_flag: bool")
    .Attr("scale_length: int = 1")
    .Attr("layer_names: list(string)")
    .Input("input: T")
    .Input("scale: float")
    .Output("output: T")
    .Output("scale_w: float")
    .Output("offset_w: int32")
    .SetIsStateful()
    .SetShapeFn([](::tensorflow::shape_inference::InferenceContext* c) {
        int scaleLength = 1;
        TF_RETURN_IF_ERROR(c->GetAttr("scale_length", &scaleLength));

        shape_inference::ShapeHandle output;
        output = c->MakeShape({scaleLength});

        c->set_output(0, c->input(0));
        c->set_output(1, output);
        c->set_output(2, output);
        return tensorflow::Status::OK();
    });


namespace AmctTfOp {
template<typename Device, typename T>
class WeightUlqInitOp : public OpKernel {
public:
    explicit WeightUlqInitOp(OpKernelConstruction* context) : OpKernel(context)
    {
        Initializer::GetInstance().Init();
        OP_REQUIRES_OK(context, context->GetAttr("s_rec_flag", &sRecFlag_));
        OP_REQUIRES_OK(context, context->GetAttr("quant_bit_num", &quantBitNum_));
        OP_REQUIRES_OK(context, context->GetAttr("scale_length", &scaleLength_));
        quantParam_.scale = nullptr;
        quantParam_.scaleLength = scaleLength_;
        quantParam_.quantBits = quantBitNum_;
        quantParam_.sRecFlag = sRecFlag_;
    }

    ~WeightUlqInitOp() override {}

    void Compute(OpKernelContext* context) override
    {
        const Tensor& inputTensor = context->input(AmctCommon::DATA_IN_INDEX);
        auto inputFlat = inputTensor.flat<T>();
        const int inputSize = inputFlat.size();

        const Tensor& scaleTensor = context->input(AmctCommon::SCALE_INDEX);

        Tensor* scaleOutTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(AmctCommon::DATA_IN_INDEX,
            scaleTensor.shape(), &scaleOutTensor));
        auto scaleOutputFlat = scaleOutTensor->template flat<float>();
        quantParam_.scale = scaleOutputFlat.data();

        Tensor max;
        Tensor min;
        OP_REQUIRES_OK(context, context->allocate_temp(DataTypeToEnum<T>::value,
            TensorShape({scaleLength_}), &max));
        OP_REQUIRES_OK(context, context->allocate_temp(DataTypeToEnum<T>::value,
            TensorShape({scaleLength_}), &min));
        auto maxFlat = max.flat<T>();
        auto minFlat = min.flat<T>();

        ScaleArqInit<Device, T>()(inputSize, inputFlat.data(), maxFlat.data(), minFlat.data(), quantParam_);
    }

private:
    AmctCommon::WeightUlqParam quantParam_;
    bool sRecFlag_ = false;
    int quantBitNum_ = 8;
    int scaleLength_ = 1;
};
}

REGISTER_KERNEL_BUILDER(Name("WeightUlqInit").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::WeightUlqInitOp<util::CPUDevice, float>);

#ifdef GOOGLE_CUDA
REGISTER_KERNEL_BUILDER(Name("WeightUlqInit").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::WeightUlqInitOp<util::GPUDevice, float>);
#endif

REGISTER_OP("WeightUlqInit")
    .Attr("T: {float16, float32, float64}")
    .Attr("quant_bit_num: int = 8")
    .Attr("s_rec_flag: bool")
    .Attr("scale_length: int = 1")
    .Input("input: T")
    .Input("scale: float")
    .Output("scale_w: float")
    .SetIsStateful()
    .SetShapeFn([](::tensorflow::shape_inference::InferenceContext* c) {
        c->set_output(0, c->input(1));
        return tensorflow::Status::OK();
    });