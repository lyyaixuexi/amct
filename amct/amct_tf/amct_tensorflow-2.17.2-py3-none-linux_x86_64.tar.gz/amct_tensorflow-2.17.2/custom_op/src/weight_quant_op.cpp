/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief weight_quant custom op C++ implement. now it has no real quant behaviours.
 *
 * @file weight_quant.cc
 *
 * @version 1.0
 */


#include <algorithm>
#include <cmath>

#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"
#include "tensorflow/core/framework/op.h"

#include "weight_quant.h"
#include "initializer.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "util.h"

using namespace tensorflow;
using namespace util;

namespace AmctTfOp {
template <typename Device, typename T>
class WeightQuantOp : public OpKernel {
public:
    explicit WeightQuantOp(OpKernelConstruction* context) : OpKernel(context)
    {
        OP_REQUIRES_OK(context, context->GetAttr("layer_name", &layerName));
        OP_REQUIRES_OK(context, context->GetAttr("quant_bits", &quantBits));
    }

    ~WeightQuantOp() override {}

    void Compute(OpKernelContext* context) override
    {
        const Tensor& weight = context->input(WEIGHT_IN_INDEX);
        auto weightFlat = weight.flat<T>();
        const int weightSize = weightFlat.size();

        Tensor* output = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(WEIGHT_OUT_INDEX, weight.shape(), &output));
        auto outputFlat = output->flat<T>();

        for (int i = 0; i < weightSize; i++) {
            outputFlat(i) = weightFlat(i);
        }
    }

private:
    std::string layerName = "layer_name_init";
    int quantBits = EIGHT;
};
}

REGISTER_KERNEL_BUILDER(Name("WeightQuant").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::WeightQuantOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("WeightQuant").Device(DEVICE_CPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::WeightQuantOp<util::CPUDevice, Eigen::half>);

REGISTER_OP("WeightQuant")
    .Attr("T: {float16, float32, float64}")
    .Attr("layer_name: string")
    .Attr("quant_bits: int = 8")
    .Input("weight: T")
    .Input("scale: float32")
    .Input("offset: int8")
    .Output("output: T")
    .SetShapeFn([](shape_inference::InferenceContext* c)
    {
        c->set_output(0, c->input(0));
        return tensorflow::Status::OK();
    })
    .Doc(R"doc(Weight quant algorithm.)doc");
