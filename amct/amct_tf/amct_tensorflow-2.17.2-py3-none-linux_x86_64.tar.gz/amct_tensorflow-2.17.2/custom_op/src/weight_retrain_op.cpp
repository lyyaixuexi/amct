/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define WeightRetrain Operator Forward Operation on CPU
 *
 * @file weight_retrain.cc
 *
 * @version 1.0
 */

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/op_kernel.h"
#include "tensorflow/core/framework/shape_inference.h"

#include "weight_retrain.h"
#include "initializer.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "util.h"

using namespace tensorflow;

namespace AmctTfOp {
template<typename Device, typename T>
class WeightRetrainOp : public OpKernel {
public:
    explicit WeightRetrainOp(OpKernelConstruction* context) : OpKernel(context)
    {
        Initializer::GetInstance().Init();
        OP_REQUIRES_OK(context, context->GetAttr("quant_bit_num", &quantBitNum_));
        OP_REQUIRES_OK(context, context->GetAttr("scale_length", &scaleLength_));
    }

    ~WeightRetrainOp() override {}

    void Compute(OpKernelContext* context) override
    {
        const Tensor& inputTensor = context->input(WEIGHT_RETRAIN_IN_INDEX);
        auto input = inputTensor.flat<T>();

        Tensor* outputTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(WEIGHT_RETRAIN_OUT_INDEX, inputTensor.shape(),
                                                         &outputTensor));
        auto output = outputTensor->template flat<float>();

        Tensor* scaleTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(WEIGHT_RETRAIN_SCALE_INDEX, TensorShape({scaleLength_}),
                                                         &scaleTensor));
        auto scale = scaleTensor->template flat<float>();

        Tensor* offsetTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(WEIGHT_RETRAIN_OFFSET_INDEX, TensorShape({scaleLength_}),
                                                         &offsetTensor));
        auto offset = offsetTensor->template flat<int>();

        AmctCommon::Input<T> arqInput;
        arqInput.data = input.data();
        arqInput.length = static_cast<int>(inputTensor.NumElements());
        arqInput.scaleLength = scaleLength_;

        AmctCommon::Output<T> arqOutput;
        arqOutput.data = output.data();
        arqOutput.scale = scale.data();
        arqOutput.offset = offset.data();

        ArqQuantFunctor<Device, T>()(arqInput, arqOutput, quantBitNum_);
    }

private:
    int quantBitNum_;
    int scaleLength_;
};
}

REGISTER_KERNEL_BUILDER(Name("WeightRetrain").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::WeightRetrainOp<util::CPUDevice, float>);

#ifdef GOOGLE_CUDA
extern template struct AmctTfOp::ArqQuantFunctor<util::GPUDevice, float>;
REGISTER_KERNEL_BUILDER(Name("WeightRetrain").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::WeightRetrainOp<util::GPUDevice, float>);
#endif

REGISTER_OP("WeightRetrain")
    .Attr("T: {float}")
    .Attr("quant_bit_num: int = 8")
    .Attr("scale_length: int = 1")
    .Attr("layer_names: list(string)")
    .Input("input: T")
    .Output("output: float")
    .Output("scale: float")
    .Output("offset: int32")
    .SetShapeFn([](::tensorflow::shape_inference::InferenceContext* c) {
        int scaleLength = 1;
        TF_RETURN_IF_ERROR(c->GetAttr("scale_length", &scaleLength));

        shape_inference::ShapeHandle output;
        output = c->MakeShape({scaleLength});

        c->set_output(0, c->input(0));
        c->set_output(1, output);
        c->set_output(2, output);
        return tensorflow::Status::OK();
    });
