/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief weight_quant custom op C++ implement. now it has no real quant behaviours.
 *
 * @file weight_quant.cc
 *
 * @version 1.0
 */


#include <algorithm>
#include <cmath>
#include <cfloat>
#include <climits>

#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"
#include "tensorflow/core/framework/op.h"

#include "weight_quant_nuq.h"
#include "initializer.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "util.h"
#include "cast_util.h"

using namespace tensorflow;
using namespace util;

namespace AmctTfOp {
template <typename T>
struct RealQuantWithNuq<util::CPUDevice, T> {
    int operator()(const T* input, T* output, const float* scale, const int* cluster, const int clusterLength,
        const int scaleLength, const int dataLength)
    {
        // first find the scale and offset using ARQ;
        std::vector<T> data(input, input + dataLength);

        size_t indexCout = 0;
        if (scaleLength == 0) {
            return AmctCommon::ZERO_DIVISION_ERROR;
        }
        for (size_t index = 0; index < data.size(); index++) {
            indexCout = index % scaleLength;
            float scaleCpu = scale[indexCout];
            if (scaleCpu < DBL_EPSILON) {
                scaleCpu = 1.0;
            }
            data[index] = data[index] / scaleCpu;
        }
        // cluster the weight
        for (int index = 0; index < dataLength; index++) {
            int minDistance = INT_MAX;
            for (int snCluster = 0; snCluster < clusterLength; snCluster++) {
                // set the weight to the nearest clusterCenter;
                if (abs(data[index] - cluster[snCluster]) < minDistance) {
                    minDistance = abs(data[index] - cluster[snCluster]);
                    output[index] = cluster[snCluster];
                }
            }
        }
        return AmctCommon::SUCCESS;
    }
};


template <typename Device, typename T>
class WeightQuantNuqOp : public OpKernel {
public:
    explicit WeightQuantNuqOp(OpKernelConstruction* context) : OpKernel(context)
    {
        OP_REQUIRES_OK(context, context->GetAttr("layer_name", &layerName));
        OP_REQUIRES_OK(context, context->GetAttr("quant_bits", &quantBits));
    }

    ~WeightQuantNuqOp() override {}

    void Compute(OpKernelContext* context) override
    {
        Tensor weight = context->input(WEIGHT_IN_INDEX);
        const Tensor& scale = context->input(SCALE_IN_INDEX);
        const Tensor& cluster = context->input(CLUSTER_IN_INDEX);

        auto clusterFlat = cluster.flat<int>();
        auto scaleFlat = scale.flat<float>();

        const int clusterSize = clusterFlat.size();
        const int scaleSize = scaleFlat.size();
        const int weightSize = weight.flat<T>().size();

        OP_REQUIRES(context, (scaleSize != 0), errors::InvalidArgument("WeightQuantNuqOp: ScaleLength is zero!"));

        Tensor* output = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(WEIGHT_OUT_INDEX, weight.shape(), &output));

        const float* inPtr = nullptr;
        float* outPtr = nullptr;
        Tensor inputSave;
        Tensor outputSave;
        if (std::is_same<Eigen::half, T>::value) {
            OP_REQUIRES_OK(context, context->allocate_temp(DataTypeToEnum<float>::value,
                TensorShape({weightSize}), &inputSave));
            DataCastToFloat32Functor<Device, uint16_t>()(reinterpret_cast<const uint16_t*>(weight.flat<T>().data()),
                inputSave.flat<float>().data(), weightSize);
            inPtr = inputSave.flat<float>().data();

            OP_REQUIRES_OK(context, context->allocate_temp(DataTypeToEnum<float>::value,
                TensorShape({weightSize}), &outputSave));

            outPtr = outputSave.flat<float>().data();
        } else {
            inPtr = weight.flat<float>().data();
            outPtr = output->flat<float>().data();
        }
        // quant the weight to INT8 and clustering the INT8 weight;
        int status = RealQuantWithNuq<Device, float>()(inPtr,
            outPtr, scaleFlat.data(), clusterFlat.data(), clusterSize, scaleSize, weightSize);
        if (std::is_same<Eigen::half, T>::value) {
            DataCastToFloat16Functor<Device, float>()(outPtr,
                reinterpret_cast<uint16_t*>(output->flat<T>().data()), weightSize);
        }
        ERROR_CHECK(status);
    }

private:
    std::string layerName = "layer_name_init";
    int quantBits = EIGHT;
};
}

REGISTER_KERNEL_BUILDER(Name("WeightQuantNuq").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::WeightQuantNuqOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("WeightQuantNuq").Device(DEVICE_CPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::WeightQuantNuqOp<util::CPUDevice, Eigen::half>);

REGISTER_OP("WeightQuantNuq")
    .Attr("T: {float16, float32, float64}")
    .Attr("layer_name: string")
    .Attr("quant_bits: int = 8")
    .Input("weight: T")
    .Input("scale: float32")
    .Input("offset: int8")
    .Input("cluster: int32")
    .Output("output: T")
    .SetShapeFn([](shape_inference::InferenceContext* c)
    {
        c->set_output(0, c->input(0));
        return tensorflow::Status::OK();
    })
    .Doc(R"doc(Weight quant nuq algorithm.)doc");
