/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief quant custom op C++ implement. now it has no real quant behaviours.
 *
 * @file quant.cc
 *
 * @version 1.0
 */


#include <cmath>
#include <algorithm>

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "record_quant_factors.h"
#include "ifmr_kernel.h"
#include "arq_kernel.h"
#include "initializer.h"
#include "common.h"
#include "tf_error_check.h"
#include "error_codes.h"

using namespace tensorflow;

namespace AmctTfOp {
template <typename Device, typename T>
class RecordQuantFactorsOp : public OpKernel {
public:
    explicit RecordQuantFactorsOp(OpKernelConstruction* context) : OpKernel(context)
    {
        Initializer::GetInstance().Init();
        OP_REQUIRES_OK(context, context->GetAttr("record_file_path", &recordFilePath));
        OP_REQUIRES_OK(context, context->GetAttr("N", &Number));
        OP_REQUIRES_OK(context, context->GetAttr("input_stamp", &(inputStamp)));

        scaleDCpu.resize(1);
        offsetDCpu.resize(1);
    }

    ~RecordQuantFactorsOp() override {}

    void Compute(OpKernelContext* context) override
    {
        OpInputList scaleDs;
        OP_REQUIRES_OK(context, context->input_list("scale_ds", &scaleDs));
        OpInputList offsetDs;
        OP_REQUIRES_OK(context, context->input_list("offset_ds", &offsetDs));
        OpInputList inputlayerNames;
        OP_REQUIRES_OK(context, context->input_list("layer_names", &inputlayerNames));

        // Create an output tensor
        Tensor* output = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(RECORD_OUT_INDEX, scaleDs[0].shape(), &output));

        for (int idx = 0; idx < scaleDs.size(); idx++) {
            Tensor scaleD = scaleDs[idx];
            Tensor offsetD = offsetDs[idx];
            dataQuantParam.scaleCpu = scaleDCpu.data();
            dataQuantParam.offsetCpu = offsetDCpu.data();
            dataQuantParam.scale = scaleD.flat<float>().data();
            dataQuantParam.offset = offsetD.flat<int>().data();

            // copy to CPU and write
            int errorCode = CopyDataToHost<Device, T>()(dataQuantParam);
            ERROR_CHECK(errorCode);
            Tensor layerName = inputlayerNames[idx];
            for (unsigned int i = 0; i < layerName.shape().dim_sizes()[0]; i++) {
                if (inputStamp == "data") {
                    ERROR_CHECK(WriteDataToRecordFile(dataQuantParam.scaleCpu, dataQuantParam.offsetCpu,
                        layerName.flat<tstring>().data()[i], recordFilePath.c_str()));
                } else {
                    ERROR_CHECK(WriteWeightToRecordFile(dataQuantParam.scaleCpu, dataQuantParam.offsetCpu, 1,
                        layerName.flat<tstring>().data()[i], recordFilePath.c_str()));
                }
            }
        }
    }

private:
    struct DataQuantFactors dataQuantParam = {nullptr, nullptr, nullptr, nullptr};
    std::vector<std::string> layerNames{};
    std::string recordFilePath = "record_file_path_init";
    std::vector<float> scalesDCpu{};
    std::vector<int> offsetsDCpu{};
    std::vector<float> scaleDCpu{};
    std::vector<int> offsetDCpu{};
    int Number = 0;
    std::string inputStamp;
};
}

// Register the CPU kernels.
REGISTER_KERNEL_BUILDER(Name("RecordQuantFactors").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::RecordQuantFactorsOp<util::CPUDevice, float>);

// Register the GPU kernels.
#ifdef GOOGLE_CUDA
extern template struct AmctTfOp::CopyDataToHost<util::GPUDevice, float>;
REGISTER_KERNEL_BUILDER(Name("RecordQuantFactors").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::RecordQuantFactorsOp<util::GPUDevice, float>);
#endif  // GOOGLE_CUDA


REGISTER_OP("RecordQuantFactors")
    .Attr("T: {float16, float32, float64}")
    .Attr("N: int")
    .Attr("record_file_path: string")
    .Attr("input_stamp: string = 'data'")
    .Input("scale_ds: N * float32")
    .Input("offset_ds: N * int32")
    .Input("layer_names: N * string")
    .Output("output: T")
    .SetIsStateful()
    .SetShapeFn([](shape_inference::InferenceContext* c)
    {
        c->set_output(0, c->input(0));
        return tensorflow::Status::OK();
    })
    .Doc(R"doc(RecordQuantFactors algorithm.)doc");
