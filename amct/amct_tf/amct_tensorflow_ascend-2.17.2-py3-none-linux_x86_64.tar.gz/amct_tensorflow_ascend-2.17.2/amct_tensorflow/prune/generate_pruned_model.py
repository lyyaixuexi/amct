#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Data structure of graph which contains graph topologic info

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
import numpy as np
from tensorflow.python.framework import tensor_util

from amct_tensorflow.graph.graph import Graph
from amct_tensorflow.optimizer.graph_optimizer import GraphOptimizer
from amct_tensorflow.optimizer.delete_prune_mask_pass import DeletePruneMaskPass
from amct_tensorflow.optimizer.fold_prune_weight_pass import FoldPruneWeightPass
from amct_tensorflow.optimizer_ir.copy_shared_weight_prune_pass import CopySharedWeightPrunePass
from amct_tensorflow.utils.utils_vars import PASSIVE_PRUNABLE_TYPES
from amct_tensorflow.utils.utils_vars import PRUNABLE_TYPES
from amct_tensorflow.common.utils.prune_record_attr_util import AttrProtoHelper

__all__ = ['delete_mask', 'create_reshaped_model']


def delete_mask(graph, prune_records, outputs, prune_idx=None):
    """
    Function:
    disconnect mask ops and collect remain channels stored in bcp op
    """
    optimizer = GraphOptimizer()
    optimizer.add_pass(FoldPruneWeightPass(outputs))
    optimizer.add_pass(DeletePruneMaskPass(prune_records, prune_idx))
    graph = optimizer.do_optimizer(graph)
    return graph


def create_reshaped_model(graph, prune_records, outputs):
    '''
    Function:
    prune redundant channels and generate output pruned model

    Input:
    graph: tf.graph with mask ops disconnected
    prune_records: a dict storing remain channels of each layer to be pruned
    outputs: list of output names of the model

    Return:
    None
    '''
    graph_ir = Graph(graph, prune_config={}, outputs=outputs)
    optimizer = GraphOptimizer()
    optimizer.add_pass(CopySharedWeightPrunePass(prune_records))
    graph_ir = optimizer.do_optimizer(graph_ir)
    filter_prune_record_list = []
    for node in graph_ir.nodes[:]:
        prune_record = prune_records.get(node.name)
        if not prune_record:
            continue
        if prune_record.get('selective_prune_record'):
            selective_record = prune_record.get('selective_prune_record')
            node = graph_ir.get_node_by_name(selective_record.selective_prune.name)
            replace_weight_for_selective_prune(node, graph_ir, selective_record.selective_prune)
        else:
            filter_prune_record_list.append(prune_record.get('active_prune_record'))

    for active_records in filter_prune_record_list:
        active_records.sort(key=lambda x: (
            AttrProtoHelper(x.producer[0]).get_attr_value('begin')))
        for active_record in active_records[::-1]:
            for producer in active_record.producer:
                producer_node = graph_ir.get_node_by_name(producer.name)
                replace_weight(producer_node, graph_ir, producer, 'out')
            for consumer in active_record.consumer:
                consumer_node = graph_ir.get_node_by_name(consumer.name)
                reshape_consumer_node(consumer_node, active_records, consumer, graph_ir)

    pruned_graph = get_pruned_graph(graph_ir)
    return pruned_graph


def replace_weight_for_selective_prune(node, graph_ir, record):
    '''
    Function:
        prune weight node
    Input:
        node: weight node to be pruned
        graph_ir: inner reprensentation of tf.graph
        records: a proto object storing mask
    Return:
        None
    '''
    attr_helper = AttrProtoHelper(record)
    mask_shape = attr_helper.get_attr_value('mask_shape')
    size = 1
    for shape in mask_shape:
        size *= shape
    pack = np.asarray(attr_helper.get_attr_value('selective_mask'))
    pack = np.frombuffer(pack.tobytes(), dtype=np.uint8)
    mask = np.unpackbits(pack)[:size].reshape(mask_shape)
    for wgt_name in node.get_attr('wgt_names'):
        wgt_node = graph_ir.get_node_by_name(wgt_name)
        weight_old = tensor_util.MakeNdarray(wgt_node.node_def.attr.get('value').tensor)
        weight_pruned = weight_old * mask
        update_value_def(weight_pruned, wgt_node)


def replace_weight(node, graph_ir, record, in_or_out):
    '''
    Function:
        prune redundant channels in weight node
    Input:
        node: weight node to be pruned
        graph_ir: inner reprensentation of tf.graph
        records: a proto object storing remain channels
        in_or_out: list of strings ['out', 'in'],
            to indicate whether to prune output channels or input channels
    Return:
        None
    '''
    attr_helper = AttrProtoHelper(record)
    remain_channels = attr_helper.get_attr_value('remain_channels')
    begin = attr_helper.get_attr_value('begin')
    end = attr_helper.get_attr_value('end')
    if in_or_out == 'out':
        num_channels = node.get_attr('out_channels')
    elif in_or_out == 'in':
        pruned_offset = node.get_attr('passive_prune_split')
        pruned_offset[end] = end - begin - len(remain_channels) if remain_channels else 0
        num_channels = node.get_attr('in_channels')
        for prev_end, offset in pruned_offset.items():
            if prev_end <= attr_helper.get_attr_value('begin'):
                begin -= offset
                end -= offset
    full_remain_channels = np.concatenate((np.arange(begin),
            begin+np.asarray(remain_channels), np.arange(end, num_channels)))
    _replace_weight(node, graph_ir, in_or_out, full_remain_channels)


def _replace_weight(node, graph_ir, in_or_out, full_remain_channels):
    '''Function: inner function for replacing weight node'''
    for wgt_name in node.get_attr('wgt_names'):
        wgt_node = graph_ir.get_node_by_name(wgt_name)

        # check if weight is shared and has been already processed
        if _has_pruned(wgt_node, in_or_out):
            continue

        if not wgt_node.node_def.attr.get('value'):
            if node.type == 'FusedBatchNormV3' and wgt_node.type == 'VariableV2':
                continue
        else:
            weight_old = tensor_util.MakeNdarray(wgt_node.node_def.attr.get('value').tensor)
        if in_or_out == 'out':
            weight_pruned = prune_cout_weight(node, full_remain_channels, weight_old)
            node.set_attr('out_channels', full_remain_channels.size)
        elif in_or_out == 'in':
            weight_pruned = prune_cin_weight(node, full_remain_channels, weight_old)
            node.set_attr('in_channels', full_remain_channels.size)
        update_value_def(weight_pruned, wgt_node)


def _has_pruned(wgt_node, in_or_out):
    '''Function: check if weight is shared and has been already processed'''
    if not wgt_node.has_attr('shared_weight_processed'):
        # weight is not shared
        return False
    if in_or_out not in wgt_node.get_attr('shared_weight_processed'):
        # weight not pruned yet
        wgt_node.get_attr('shared_weight_processed').append(in_or_out)
        return False
    return True


def update_value_def(new_value, node):
    """Function：update value in node_def"""
    tensor_proto = tf.make_tensor_proto(new_value)
    node.node_def.attr.get('value').CopyFrom(tf.compat.v1.AttrValue(tensor=tensor_proto))


def reshape_consumer_node(consumer_node, active_records, consumer_record, graph_ir):
    '''
    Function:
        reshape consumers' C-in channel according to node type
    Inputs:
        consumer_node: node to be pruned
        active_records: producer's record storing remain channel index
        consumer_record,: record of consumer_node
        graph_ir: abstraction of tf.graph
    '''
    if consumer_node.type in PASSIVE_PRUNABLE_TYPES + PRUNABLE_TYPES:
        if consumer_node.type == 'BiasAdd' and consumer_node.op.inputs[1].op.type == 'BroadcastTo':
            broadcast_node = consumer_node.get_producer(1)[0]
            if not broadcast_node.has_attr('is_pruned'):
                reshape_broadcast(broadcast_node, active_records)
        replace_weight(consumer_node, graph_ir, consumer_record, 'in')
    elif consumer_node.type in ['SplitV'] and not consumer_node.has_attr('is_pruned'):
        reshape_split_size(consumer_node, active_records)
    elif consumer_node.type in ['Reshape'] and not consumer_node.has_attr('is_pruned'):
        reshape_shape(consumer_node, active_records)


def extract_new_shapes(active_records):
    """Function：update shape attr after pruning"""
    new_shapes = []
    for active_record in active_records:
        producer_record = active_record.producer[0]
        attr_helper = AttrProtoHelper(producer_record)
        new_shapes.append(len(attr_helper.get_attr_value('remain_channels')))
    return new_shapes


def reshape_split_size(node, active_records):
    '''Function: update size_split input to splitV op'''
    new_size_splits = extract_new_shapes(active_records)
    size_split_node = node.get_producer(1)[0]
    update_value_def(new_size_splits, size_split_node)
    node.set_attr('is_pruned', True)


def reshape_shape(node, active_records):
    '''Function: update shape input to reshape op'''
    new_shapes = extract_new_shapes(active_records)
    shape_node = node.get_producer(1)[0]
    update_value_def([-1, sum(new_shapes)], shape_node)
    node.set_attr('is_pruned', True)


def reshape_broadcast(node, active_records):
    '''Function: update shape input to BroadcastTo op'''
    new_shapes = extract_new_shapes(active_records)
    shape_node = node.get_producer(1)[0]
    update_value_def([sum(new_shapes)], shape_node)
    node.set_attr('is_pruned', True)


def prune_cin_weight(node, remain_in_channels, weight):
    '''Function: prune weight matrix's C-in axis'''
    node_type = node.type
    if node_type == 'Conv2DBackpropInput':
        weight = weight[:, :, :, remain_in_channels]
    elif node_type in ['Conv2D', 'DepthwiseConv2dNative']:
        weight = weight[:, :, remain_in_channels, :]
    elif node_type == 'MatMul':
        if node.op.get_attr('transpose_b'):
            weight = weight[:, remain_in_channels]
        else:
            weight = weight[remain_in_channels, :]
    elif node_type in ['FusedBatchNorm', 'FusedBatchNormV3', 'FusedBatchNormV2', 'BiasAdd']:
        weight = weight[remain_in_channels]
    return weight


def prune_cout_weight(node, remain_out_channels, weight):
    '''Function：prune weight matrix's C-out axis'''
    node_type = node.type
    if node_type == 'Conv2DBackpropInput':
        weight = weight[:, :, remain_out_channels, :]
    elif node_type == 'Conv2D':
        weight = weight[:, :, :, remain_out_channels]
    elif node_type == 'MatMul':
        if node.op.get_attr('transpose_b'):
            weight = weight[remain_out_channels, :]
        else:
            weight = weight[:, remain_out_channels]
    return weight


def get_pruned_graph(graph_ir):
    '''
    Function: export pruned model
    '''
    graph_def = tf.compat.v1.GraphDef()
    for node in graph_ir.nodes:
        graph_def.node.append(node.node_def)
    graph = check_prune_success(graph_def)
    return graph


def check_prune_success(graph_def):
    """Function: Check if purne is success by importing graph_def to tf.graph"""
    graph = tf.compat.v1.Graph()
    with graph.as_default():
        try:
            tf.import_graph_def(graph_def, name='')
        except (TypeError, ValueError) as error:
            raise RuntimeError('Failed to import pruned graph_def: %s' % error) from error
    return graph
