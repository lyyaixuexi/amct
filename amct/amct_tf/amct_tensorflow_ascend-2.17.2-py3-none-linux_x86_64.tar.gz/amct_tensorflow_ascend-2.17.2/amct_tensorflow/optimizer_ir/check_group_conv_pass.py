#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace bulk BN to Integrating BN for all layer.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_tensorflow.optimizer_ir.base_ir_fusion_pass import BaseIRFusionPass
from amct_tensorflow.pattern.match_group_conv import pattern_group_conv
from amct_tensorflow.pattern.match_group_conv import GROUP_CONV_SPLIT
from amct_tensorflow.utils.utils_vars import PRUNABLE_TYPES
from amct_tensorflow.utils.utils_vars import PRUNE_KNOWN_OPS

__all__ = ['CheckGroupConvPass']


class CheckGroupConvPass(BaseIRFusionPass):
    """
    Function: check if braches in group conv share the same prune ratio
    APIs: match_pattern, do_pass,
    """
    def __init__(self):
        """
        Function: init CheckGroupConvPass object
        """
        BaseIRFusionPass.__init__(self)
        self.group_conv = None

    def match_pattern(self, object_node):
        """
        Function: Match fusible pattern of "group_conv + bn".
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if object_node.type not in GROUP_CONV_SPLIT:
            return False
        # match struct
        self.group_conv = pattern_group_conv(object_node.op)
        if self.group_conv is None:
            return False
        return True

    def do_pass(self, object_node):
        """
        Function: check if convs in group conv share the same prune ratio
        Inputs:
            object_node: split node
        """
        prune_ratios = []
        prune_enables = []
        for conv_name in self.group_conv.names.get('conv_names'):
            conv_node = self.graph.get_node_by_name(conv_name)
            prune_ratios.append(conv_node.get_attr('prune_ratio'))
            prune_enables.append(conv_node.get_attr('filter_prune_enable'))
        if len(set(prune_ratios)) > 1:
            raise RuntimeError(
                'Purne ratios of group conv must be consistant. Please check configs in config_defination.')
        if len(set(prune_enables)) > 1:
            raise RuntimeError(
                'Purne enables of group conv must be consistant. Please check configs in config_defination.')
        producers = set()
        prunable_producers = find_prunable_producer(object_node, producers)
        for node in prunable_producers:
            node.set_attr('is_group_conv', True)


def find_prunable_producer(node, producers):
    '''
    Function:
        trace back form current node until find its upstream PRUNABLE_TYPES
    '''
    if node.type in PRUNABLE_TYPES or node.type not in PRUNE_KNOWN_OPS:
        return {node}
    for input_ind, _ in enumerate(node.input_anchors):
        producer, _ = node.get_producer(input_ind)
        if producer:
            brothers = find_prunable_producer(producer, set())
            producers.update(brothers)
    return producers
