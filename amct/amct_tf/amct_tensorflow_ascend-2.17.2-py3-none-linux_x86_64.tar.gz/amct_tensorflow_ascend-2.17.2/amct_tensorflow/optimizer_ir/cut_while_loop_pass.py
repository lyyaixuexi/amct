#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace bulk BN to Integrating BN for all layer.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_tensorflow.optimizer_ir.base_ir_fusion_pass import BaseIRFusionPass
from amct_tensorflow.optimizer_ir.check_group_conv_pass import find_prunable_producer
from amct_tensorflow.utils.utils_vars import PATTERN_CONFIG
from amct_tensorflow.pattern.match_pattern import PatternHelper

__all__ = ['CutWhileLoopPass']


class CutWhileLoopPass(BaseIRFusionPass):
    """
    Function: extract the body part from the loop structure
    APIs: match_pattern, do_pass,
    """
    def __init__(self):
        BaseIRFusionPass.__init__(self)
        self.pattern_config = PATTERN_CONFIG.get('while')
        self.bulk_nodes = {}

    def match_pattern(self, object_node):
        """
        Function: Matches loop strcture.
        Inputs:
            object_node: node to be matched
        Returns:
            True: matched
            False: mismatch
        """
        is_while, bulk_nodes = PatternHelper.match_patternir(object_node, self.pattern_config)
        if is_while:
            self.bulk_nodes[object_node.name] = bulk_nodes
        return is_while

    def do_pass(self, object_node):
        """
        Function:
            extract the body part from the loop structure
        e.g.
            reshape(begin_node)                         reshape(disabled)
              |                                            |
            enter                           --->      matmul_while_1
              |                                            |
            merge <-------------------------              ...
              |                            |               |
            switch (0) --> exit-> end_node |      matmul_while_end(disabled)
              |(1)                         |               |
        matmul_while_1(loop_head)          |            end_node
              |                            |
             ...                           |
              |                            |
        matmul_while_end(loop_tail)        |
              |                            |
         next_iteration --------------------
              |
        """
        target_nodes = self.pattern_config.get('OUTPUT')
        bulk_nodes = self.bulk_nodes.get(object_node.name)
        switch_node = object_node
        switch_consumers, _ = switch_node.get_consumers(0)
        if not switch_consumers:
            # condition branch has no exit node
            switch_consumers, switch_consumer_in_inds = switch_node.get_consumers(1)
            for consumer, consumer_ind in zip(switch_consumers, switch_consumer_in_inds):
                self.graph.remove_edge(object_node, 1, consumer, consumer_ind)
        else:
            # body branch to be processed
            exit_node =  switch_consumers[0]
            enter_node = bulk_nodes[target_nodes.get('Enter')]
            begin_node, begin_node_ind = enter_node.get_producer(0) # node before while loop
            end_nodes, end_anchor_ind = exit_node.get_consumers(0) # node after while loop
            loop_head, loop_head_ind = switch_node.get_consumers(1)
            nextiteration_node = bulk_nodes[target_nodes.get('Next_itr')]
            loop_tail, loop_tail_ind = nextiteration_node.get_producer(0)
            self.graph.remove_edge(begin_node, begin_node_ind, enter_node, 0)
            for start_node, start_ahchor_ind in zip(loop_head, loop_head_ind):
                self.graph.remove_edge(switch_node, 1, start_node, start_ahchor_ind)
                start_node.replace_input_anchor(start_ahchor_ind, enter_node.input_anchors[0].name)
                self.graph.add_edge(begin_node, begin_node_ind, start_node, start_ahchor_ind)
            self.graph.remove_edge(loop_tail, loop_tail_ind, nextiteration_node, 0)

            producers_tail = find_prunable_producer(loop_tail, set())
            producers_head = find_prunable_producer(begin_node, set())
            for disable_node in producers_head | producers_tail:
                disable_node.set_attr('filter_prune_enable', False)
                disable_node.set_attr('selective_prune_enable', False)

            if end_nodes:
                for end_node, end_anchor_index in zip(end_nodes, end_anchor_ind):
                    self.graph.remove_edge(exit_node, 0, end_node, end_anchor_index)
                    end_node.replace_input_anchor(end_anchor_index, loop_tail.name)
                    self.graph.add_edge(loop_tail, loop_tail_ind, end_node, end_anchor_index)
