#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace bulk BN to Integrating BN for all layer.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

from amct_tensorflow.optimizer_ir.base_ir_fusion_pass import BaseIRFusionPass
from amct_tensorflow.common.prune.prune_recorder_helper import PruneRecordHelper
from amct_tensorflow.utils.utils_vars import PASSIVE_PRUNABLE_TYPES
from amct_tensorflow.utils.utils_vars import PRUNABLE_TYPES
from amct_tensorflow.graph.node import Node


__all__ = ['CopySharedWeightPrunePass']


class CopySharedWeightPrunePass(BaseIRFusionPass):
    """
    Function: Duplicate weights shared by multiple nodes in graphIR.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, prune_records):
        BaseIRFusionPass.__init__(self)
        self.prune_records = prune_records

    def run(self, graph_ir):
        """
        Function:
            check weight_shared case in graphIR. If weight-shared but remain_channels
            are different, duplicate the weight to avoid purning conflict.
        """
        self.graph = graph_ir
        # find shared_weight_layers
        shared_weight_layers = self.find_shared_weight_layers()
        # read active and passive remain channels from record proto
        prune_record_list = []
        for records in self.prune_records.values():
            if records.get('active_prune_record'):
                prune_record_list += records.get('active_prune_record')

        active_remain_channels, passive_remain_channels = \
            PruneRecordHelper.parse_record_proto_to_dict(prune_record_list)

        # process weight shared nodes
        for weight_name, nodes in shared_weight_layers.items():
            # group nodes that share the same weight and have the same remain_channels
            groups = _group_shared_weight_nodes(
                nodes, active_remain_channels, passive_remain_channels)

            all_shared_nodes = find_shared_nodes(nodes)
            for idx, group in enumerate(groups):
                if len(group) == 1:
                    shared_nodes = all_shared_nodes
                else:
                    shared_nodes = find_shared_nodes(group)
                weight_node = graph_ir.get_node_by_name(weight_name)
                new_weight_node = weight_node
                if idx > 0:
                    new_weight_node = self.duplicate_weight_node(weight_node, idx, group, shared_nodes)
                # register the new_weight_node to make sure it is only pruned once
                new_weight_node.set_attr('shared_weight_processed', [])
        return graph_ir, []

    def find_shared_weight_layers(self):
        '''Function: find all shared_weight_layers in the graph'''
        wgt_nodes_dict = {}
        shared_weight_layers = {}
        for node in self.graph.nodes:
            if node.type not in PRUNABLE_TYPES + PASSIVE_PRUNABLE_TYPES:
                continue
            for wgt_name in node.get_attr('wgt_names'):
                if wgt_nodes_dict.get(wgt_name) is None:
                    wgt_nodes_dict[wgt_name] = [node]
                else:
                    # the weight node is shared
                    wgt_nodes_dict.get(wgt_name).append(node)
                    shared_weight_layers[wgt_name] = wgt_nodes_dict.get(wgt_name)
        return shared_weight_layers

    def duplicate_weight_node(self, weight_node, idx, group, shared_nodes):
        '''
        Function:
            duplicate the weight node for the group of nodes
        Input:
            weight_node: the target weight node to be copied
            idx: index to name the copied weight node
            group: the group of nodes that share the same remain channels
            shared_nodes: shared nodes between the prunable nodes and their shared weight
        Output:
            new_weight_node: duplicate of the weight node

        for instance:
                         weight                           weight
                           |                                |
                          read                             read               fold_weight
                        /      \                 --->       |            +        |
            WeightRetrain_1   WeightRetrain_2         WeightRetrain_1        WeightRetrain_2
                     /            \                         |                     |
                conv2d_1        conv2d_2                 conv2d_1              conv2d_2
        '''
        # fold the shared nodes by session run
        sess = tf.compat.v1.Session(graph=self.graph.graph)
        fold_weight = sess.run(''.join([shared_nodes[-1], ":0"]))
        sess.close()
        # duplicate the weight node and update its value by the folded weight
        new_weight_node = copy_node(idx, weight_node, self.graph)
        new_weight_node.node_def.attr.get('value').CopyFrom(
            tf.compat.v1.AttrValue(tensor=tf.make_tensor_proto(fold_weight)))
        # link new_weight_node to shared nodes' consumer
        for prunable in group:
            shared_weight_idx = prunable.get_attr('path_to_wgt').index(shared_nodes[-1])
            shared_weight_consumer = self.graph.get_node_by_name(
                prunable.get_attr('path_to_wgt')[shared_weight_idx-1])
            for index, input_anchor in enumerate(shared_weight_consumer.input_anchors):
                peer_anchor = input_anchor.get_peer_output_anchor()
                if peer_anchor is None:
                    continue
                if peer_anchor.node.name == shared_nodes[-1]:
                    in_index = index
                    break
            relink_node_and_def(new_weight_node, 0, shared_weight_consumer, in_index, self.graph)
            prunable.set_attr('wgt_names', [new_weight_node.name])
        return new_weight_node


def find_shared_nodes(nodes):
    '''
    Function:
    find intermediate shared nodes between the given prunable nodes and their shared weight

    for instance:
                    weight(shared node)
                            |
                    read(shared node)
                        /       \
                  conv2d_1    conv2d_2
    '''
    common_nodes_set = set(nodes[0].get_attr('path_to_wgt'))
    for prunable in nodes[1:]:
        common_nodes_set &= set(prunable.get_attr('path_to_wgt'))
    common_nodes_sorted = []
    for node_name in common_nodes_set:
        common_nodes_sorted.append((node_name, nodes[0].get_attr('path_to_wgt').index(node_name)))
    common_nodes_sorted.sort(key=lambda x: x[1], reverse=True)
    return [node[0] for node in common_nodes_sorted]


def _group_shared_weight_nodes(nodes, active_remain_channels, passive_remain_channels):
    """
    Function:
        group the shared weight nodes according to their remain_channels
    """
    groups = []
    grouped = [] # nodes already been grouped
    # two pointers to go through nodes in the group
    for node_1 in nodes:
        if node_1 in grouped:
            continue
        group = [node_1]
        for node_2 in nodes[::-1]:
            if node_2 in grouped or node_2 == node_1:
                continue
            # group node together if their remain channels are the same
            if active_remain_channels.get(node_1.name) == active_remain_channels.get(node_2.name) and \
                passive_remain_channels.get(node_1.name) == passive_remain_channels.get(node_2.name):
                group.append(node_2)
                grouped.append(node_2)
        grouped.append(node_1)
        groups.append(group)
    # Sort the groups by their length in descending order
    groups.sort(key=lambda x: len(x), reverse=True)
    return groups


def copy_node(idx, node, graph_ir):
    """
    Function: duplicate the weight node to avoid purning conflict.
    """
    new_node = Node(len(graph_ir.nodes), node.op)
    new_node_name = "%s_copy_%d" % (new_node.name, idx)
    new_node._basic_info['name'] = new_node_name
    new_node.node_def.name = new_node_name
    graph_ir.nodes.append(new_node)
    return new_node


def relink_node_and_def(src_node, src_index, dst_node, dst_index, graph_ir):
    """Function: relink node_def"""
    if dst_node.get_producer(dst_index)[0]:
        graph_ir.remove_edge(dst_node.get_producer(dst_index)[0], 0, dst_node, dst_index)
    graph_ir.add_edge(src_node, src_index, dst_node, dst_index)
    dst_node.node_def.input.pop(dst_index)
    dst_node.node_def.input.append(src_node.name)
