#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace bulk BN to Integrating BN for all layer.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_tensorflow.optimizer_ir.base_ir_fusion_pass import BaseIRFusionPass
from amct_tensorflow.utils.utils_vars import PATTERN_CONFIG
from amct_tensorflow.pattern.match_pattern import PatternHelper

__all__ = ['ReplacePoolReshapePass']


class ReplacePoolReshapePass(BaseIRFusionPass):
    """
    Function:
        Replace pool+reshape pattern to enable upstream node to be pruned
    """
    def __init__(self):
        """
        Function: init ReplacePoolReshapePass object
        """
        BaseIRFusionPass.__init__(self)
        self.pattern_config = None
        self.bulk_nodes = {}

    def match_pattern(self, object_node):
        """
        Function: Matches the pool+reshape pattern.
        Inputs:
            object_node: node to be matched
        Returns:
            True: matched
            False: mismatch
        """
        maxpool_reshape_config = PATTERN_CONFIG.get('maxpool_reshape', None)
        is_maxpool_reshape, bulk_nodes = PatternHelper.match_patternir(object_node, maxpool_reshape_config)
        if is_maxpool_reshape:
            self.pattern_config = maxpool_reshape_config
            self.bulk_nodes[object_node.name] = bulk_nodes
        avgpool_reshape_config = PATTERN_CONFIG.get('avgpool_reshape', None)
        is_avgpool_reshape, bulk_nodes = PatternHelper.match_patternir(object_node, avgpool_reshape_config)
        if is_avgpool_reshape:
            self.pattern_config = avgpool_reshape_config
            self.bulk_nodes[object_node.name] = bulk_nodes
        return is_avgpool_reshape or is_maxpool_reshape

    def do_pass(self, object_node):
        """
        Function: Replace pool+reshape to custom node
        Inputs:
            object_node: reshape op
        """
        graph_ir = self.graph
        bulk_nodes = self.bulk_nodes.get(object_node.name)
        target_nodes = self.pattern_config.get('OUTPUT')
        pool_node = bulk_nodes[target_nodes.get('pool')]
        pool_input, input_ind = pool_node.get_producer(0)# pooling node's producer
        reshape_outputs, output_inds = object_node.get_consumers(0)# reshape's consumers
        if check_pool(pool_node.op, object_node.op):
            poolreshape_node = graph_ir.create_fake_node(
                                node_name=object_node.name,
                                node_type='PoolReshape',
                                anchors=[pool_input.output_anchors[input_ind], object_node.output_anchors[0]],
                                node_index=object_node._basic_info.get('node_index'))
            # cut pool'sproducer --- pool
            graph_ir.remove_edge(pool_input, input_ind, pool_node, 0)
            graph_ir.add_edge(pool_input, input_ind, poolreshape_node, 0)
            # cur reshape --- "reshape's consumers"
            for reshape_output, output_ind in zip(reshape_outputs, output_inds):
                graph_ir.remove_edge(object_node, 0, reshape_output, output_ind)
                graph_ir.add_edge(poolreshape_node, 0, reshape_output, output_ind)


def check_pool(pool_op, reshape_op):
    '''
    Function:
        check if pooling output shape is "N*1*1*C" and reshape axis is "C"
    '''
    data_format = pool_op.get_attr('data_format').decode('utf-8')
    h_axis = data_format.find('H')
    w_axis = data_format.find('W')
    c_axis = data_format.find('C')
    pool_output_shape = pool_op.outputs[0].shape.as_list()
    if pool_output_shape[h_axis] == 1 and pool_output_shape[w_axis] == 1:
        reshape_out_shape = reshape_op.outputs[0].shape.as_list()
        if reshape_out_shape[0] == pool_output_shape[0] and \
            reshape_out_shape[1] == pool_output_shape[c_axis]:
            return True
    return False
