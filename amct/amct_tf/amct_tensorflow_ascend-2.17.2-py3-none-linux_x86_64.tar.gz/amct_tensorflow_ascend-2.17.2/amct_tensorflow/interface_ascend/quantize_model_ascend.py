#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quantitative subject control module.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import copy
import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.capacity import CAPACITY
from amct_tensorflow.common.capacity.query_capacity import switch_capacity
from amct_tensorflow.common.capacity.query_capacity import ASCEND_CAPACITY_TYPE
from amct_tensorflow.interface.quantize_model import preprocess_quantize_model
from amct_tensorflow.common.utils.files import is_valid_name
from amct_tensorflow.common.utils.check_params import check_params

from amct_tensorflow.common.utils import files as files_util
from amct_tensorflow.utils import fuse_bn
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.utils.graph_utils import GraphUtils
from amct_tensorflow.utils.utils_vars import ACT_CALI
from amct_tensorflow.utils.utils_vars import WTS_CALI
import amct_tensorflow.optimizer as opt
from amct_tensorflow.optimizer.graph_optimizer import GraphOptimizer
from amct_tensorflow.optimizer.base_fusion_pass \
    import extract_graph_def_from_sess

__all__ = ['quantize_model_ascend']


@switch_capacity(CAPACITY, ASCEND_CAPACITY_TYPE)
@check_params(graph=tf.compat.v1.Graph,
              outputs=list,
              config_file=str,
              record_file=str)
def quantize_model_ascend(graph, outputs, config_file, record_file):
    """
    Function: Quantization input model: According to the quantization
              configuration file, insert quantization op at the specified
              position of tf.compat.v1.Graph.
    Inputs:
        graph: a tf.compat.v1.Graph.
        outputs: a list containing the names of outputs in pb_model.
        config_file: a string, Name of quantized configuration file (including
                   path information).
        record_file: a string, the name of file recording quantization factor.
    Returns:
        quant_add_ops: a list, quantify the list of variables added.
    """
    is_valid_name(config_file, 'config_file')
    is_valid_name(record_file, 'record_file')
    config_file = os.path.realpath(config_file)
    if not os.path.exists(config_file):
        raise OSError('file (%s) does not exist!' % config_file)
    record_file = files_util.create_empty_file(record_file, check_exist=True)

    cali_graph, cali_outputs = copy_graph(graph, outputs)

    with cali_graph.as_default():
        # preprocess the before quantize
        cali_graph, quant_config = preprocess_quantize_model(
            cali_graph, cali_outputs, config_file)

        # BN fusion.
        cali_graph, _ = fuse_bn.fuse_bn_quantize_model(
            cali_graph, quant_config.get('do_fusion'),
            quant_config.get('skip_fusion_layers'), record_file, cali_outputs)

        quantized_layers_flag = {ACT_CALI: [], WTS_CALI: []}
        quant_config['record_file'] = record_file

        optimizer = GraphOptimizer()
        optimizer.add_pass(
            opt.GroupConvInsertCaliPass(quant_config=quant_config,
                                        skip_layers=quantized_layers_flag,
                                        on_ascend=True,
                                        outputs=cali_outputs))
        optimizer.add_pass(
            opt.InsertARQPass(quant_config=quant_config,
                              skip_layers=quantized_layers_flag.get(WTS_CALI),
                              on_ascend=True,
                              outputs=cali_outputs))
        optimizer.add_pass(
            opt.InsertActCaliPass(quant_config=quant_config,
                               skip_layers=quantized_layers_flag.get(ACT_CALI),
                               on_ascend=True,
                               outputs=cali_outputs))

        cali_graph = optimizer.do_optimizer(cali_graph)

    cali_graph, cali_outputs = copy_graph(cali_graph, cali_outputs)

    return cali_graph, cali_outputs


def copy_graph(graph, outputs):
    """ Copy a graph to a new graph. """
    # extract graph_def from graph
    try:
        with tf.compat.v1.Session(
                config=tf.compat.v1.ConfigProto(allow_soft_placement=True),
                graph=graph) as sess:
            graph_def = extract_graph_def_from_sess(sess, outputs)
    except Exception as exce:
        LOGGER.push_debug_message("Copy graph fail for {}".format(exce),
                                  "quantize_model_ascend")
        raise RuntimeError("The graph cannot be quantized for extract " \
            "graph_def from its session fail. Please ensure graph can be used "
            "to do inference for oneself.") from exce

    # copy a new graph and outputs
    new_outputs = copy.deepcopy(outputs)
    new_graph = tf.compat.v1.Graph()
    with new_graph.as_default():
        GraphUtils.handle_graph_def(graph_def)
        tf.compat.v1.import_graph_def(graph_def, name='')

    return new_graph, new_outputs
