#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Modify graph to 'deploy' mode and save it to PB. The
'fake_quant' graph can be used to inference in tensorflow with quantization.
The 'deploy' graph can be transfered to be deployed on the core by OMG Tools.
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_tensorflow.capacity import CAPACITY
from amct_tensorflow.common.capacity.query_capacity import switch_capacity
from amct_tensorflow.common.capacity.query_capacity import ASCEND_CAPACITY_TYPE
from amct_tensorflow.interface.save_model import save_model_inner
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.common.utils.check_params import check_params

_CUSTOM_OP = load()

DATA_OFFSET_RANGE = [-128, 127]
WEIGHT_OFFSET_RANGE = [0, 0]

__all__ = ["save_model_ascend"]


@switch_capacity(CAPACITY, ASCEND_CAPACITY_TYPE)
@check_params(pb_model=str, outputs=list, record_file=str, save_path=str)
def save_model_ascend(pb_model, outputs, record_file, save_path):
    """
    Function: Convert a model to models with compression including fakequant
        model and deploy model.
    Inputs:
        pb_model: original model to be converted.
        outputs: a list containing the names of outputs in pb_model.
        record_file: a string, path of file containing the scale and offset.
        save_path: a string, the path where to store model and model's name.
    Returns: None
    """
    save_model_inner(pb_model, outputs, record_file, save_path, on_ascend=True)
