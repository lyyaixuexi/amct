#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quant op fusion optimization.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.lib.load_custom_op import load

_CUSTOM_OP = load()

__all__ = ['QuantFusionPass']


class QuantFusionPass(BaseFusionPass):
    """
    Function: Quant op fusion optimization.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, records=None):
        """
        Function: init object
        Inputs:
            records: a dictionary containing quant factors
        Return: None
        """
        BaseFusionPass.__init__(self)
        if records is None:
            records = {}
        self.records = records

    @staticmethod
    def encode_scale_offset(scale_value, offset, quant_bits):
        """encode scale and offset to unique key"""
        float_scale = np.float32(scale_value)
        uint32_scale = np.frombuffer(float_scale, np.uint32)

        int32_offset = np.int32(offset)
        uint32_offset = np.frombuffer(int32_offset, np.uint32)

        encode_result = np.uint64(0)
        encode_result = np.uint64(uint32_scale) << np.uint32(32) | np.uint64(
            uint32_offset)

        return str(encode_result) + quant_bits

    @staticmethod
    def find_same_quant_node(records, quant_nodes_list):
        """find quant node with same scale and offset"""
        fusion_quant_nodes = {}
        for quant_node in quant_nodes_list:
            quant_bits = str(quant_node.get_attr('quant_bits'))
            layer_name = str(quant_node.get_attr('layer_name'), 'utf-8')
            scale_d = records.get(layer_name).get('data_scale')
            offset_d = records.get(layer_name).get('data_offset')
            encode_id = QuantFusionPass.encode_scale_offset(scale_d, offset_d, quant_bits)
            if encode_id not in fusion_quant_nodes:
                fusion_quant_nodes[encode_id] = [quant_node]
            else:
                fusion_quant_nodes.get(encode_id).append(quant_node)
        return fusion_quant_nodes

    def match_pattern(self, operation):
        """
        Function: Match quantizable operation to be quantized.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        for output_tensor in operation.outputs:
            quant_layer_count = 0
            for output_op in output_tensor.consumers():
                if output_op.type == 'Quant':
                    quant_layer_count += 1
            if quant_layer_count > 1:
                return True
        return False

    def do_pass(self, object_op):
        """
        Function: Optimized fusion quant op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        for output_tensor in object_op.outputs:
            quant_node_list = []
            for output_op in output_tensor.consumers():
                if output_op.type == 'Quant':
                    quant_node_list.append(output_op)

            # record quant layer with same scale and offset
            fusion_quant_nodes = self.find_same_quant_node(
                self.records, quant_node_list)
            # do quant fusion
            for _, nodes in fusion_quant_nodes.items():
                if len(nodes) < 2:
                    continue
                for node in nodes[1:]:
                    for index, _ in enumerate(node.outputs):
                        replace_inputs_tensor(
                            nodes[0].outputs[index],
                            node.outputs[index],
                            node.outputs[index].consumers())

        return [], []
