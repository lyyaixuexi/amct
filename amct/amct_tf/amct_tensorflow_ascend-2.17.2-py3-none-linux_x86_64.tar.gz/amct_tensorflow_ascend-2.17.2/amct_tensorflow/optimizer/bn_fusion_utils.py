#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Utils for Fuse FusedBatchNororm.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.configuration.check_graph import GraphChecker

__all__ = [
    'check_invalid_fuse', 'check_length', 'get_bn_params', 'split_bn_params',
    'get_data_format', 'fuse_weight', 'fuse_bias', 'fuse_scale_w',
    'generate_name_scope', 'is_tail_layer'
]


def check_invalid_fuse(operation):
    """
    Funtion: check whether the node can be fuse or not.
    Inputs:
        operation, the FUSE_TYPES or "BiasAdd".
    Returns:
        True or False
    """
    # there's no placeholder in weights or bias.
    param_node = operation.inputs[1].op
    uncertain_nodes = GraphChecker.check_placeholder(operation.graph,
                                                     [param_node.name])
    if uncertain_nodes:
        LOGGER.push_debug_message("layer {} cannot be fused for placeholder."\
            .format(operation.name), "fuse_bn")
        return False

    return True


def check_length(inputs, bn_params, data_format):
    """
    Function: Check whether the length of bn_params is match with its inputs.
        The length of scale/offset/mean/variance should be same as 'C' of
        inputs.
    Inputs:
        inputs: a tensor, bn's inputs.
        bn_params: a list, the parameters to be checked.
        data_format: a string, indicating how the inputs is saved.
    Returns: None
    """
    if data_format in ('NCHW', 'NCDHW'):
        channel = inputs.shape[1]
    elif data_format in ('NHWC', 'NDHWC'):
        channel = inputs.shape[-1]
    else:
        raise TypeError(" %s isn't supported." % (data_format))
    # get parameter
    params_name_list = ["scale", "offset", "mean", "variance"]

    for name in params_name_list:
        param = bn_params.get(name)
        length = sum(param.shape)
        # mean and variance can not be None
        if length == 0 and name in ("mean", "variance"):
            raise RuntimeError("layer %s's %s is [], pleasure ensure bn layer "
                               "is for inference" % (inputs.op.name, name))
        # lenght should be equal to channel
        if length != channel:
            raise RuntimeError("layer %s %s's length sholud be same as "\
                               "'C' of inputs." % (inputs.op.name, name))


def is_tail_layer(operation):
    '''Determine whether the current op is a tail node.'''
    consumers = 0
    if operation.outputs:
        for output in operation.outputs:
            consumers += len(output.consumers())
    if consumers > 0:
        return False
    return True


def get_data_format(data_format):
    '''get data_format '''
    if data_format in (b'NCHW', 'NCHW'):
        return 'NCHW'
    if data_format in (b'NHWC', 'NHWC'):
        return 'NHWC'
    if data_format in (b'NDHWC', 'NDHWC'):
        return 'NDHWC'
    if data_format in (b'NCDHW', 'NCDHW'):
        return 'NCDHW'

    raise ValueError("data_format must be a bytes and valid data_format.")


def generate_name_scope(name_scope, op_name):
    ''' generate name scope '''
    if name_scope != '':
        return '/'.join([name_scope, op_name])
    return op_name


def get_bn_params(bn_op):
    ''' get bn's params '''
    fuse_parameters = {}
    fuse_parameters["scale"] = tf.compat.v1.cast(bn_op.inputs[1], tf.float32)
    fuse_parameters["offset"] = tf.compat.v1.cast(bn_op.inputs[2], tf.float32)
    fuse_parameters["mean"] = tf.compat.v1.cast(bn_op.inputs[3], tf.float32)
    fuse_parameters["variance"] = tf.compat.v1.cast(bn_op.inputs[4], tf.float32)
    fuse_parameters["epsilon"] = bn_op.get_attr("epsilon")

    return fuse_parameters


def split_bn_params(bn_op, group_size):
    '''split bn's params for group_conv'''
    bn_params = get_bn_params(bn_op)
    fuse_parameters = {}
    split_scales = tf.compat.v1.split(value=bn_params.get("scale"),
                                      num_or_size_splits=group_size,
                                      axis=0)
    split_offsets = tf.compat.v1.split(value=bn_params.get("offset"),
                                       num_or_size_splits=group_size,
                                       axis=0)
    split_means = tf.compat.v1.split(value=bn_params.get("mean"),
                                     num_or_size_splits=group_size,
                                     axis=0)
    split_variances = tf.compat.v1.split(value=bn_params.get("variance"),
                                         num_or_size_splits=group_size,
                                         axis=0)

    epsilon = bn_params.get("epsilon")
    split_fuse_parameters = list()
    for index in range(group_size):
        fuse_parameters = {}
        fuse_parameters["scale"] = split_scales[index]
        fuse_parameters["offset"] = split_offsets[index]
        fuse_parameters["mean"] = split_means[index]
        fuse_parameters["variance"] = split_variances[index]
        fuse_parameters["epsilon"] = epsilon
        split_fuse_parameters.append(fuse_parameters)

    return split_fuse_parameters


def _reshape_bn_param(compute_type, bn_params, weight_and_scale):
    """
    Function: Reshape parameters of BN layer before fusing.
        The bn_params is with size matching the 'Channel' dimension.
    Inputs:
        compute_type: a string, the type of operation to be fused with BN
            layer. Only "Conv2D" "Conv3D" "DepthwiseConv2dNative" "MatMul"
            are supported.
        bn_params: a list, the parameters to be reshaped.
        weight_and_scale: weight or scale to be fused
    Returns: None
    """
    if compute_type == "Conv2D":
        shape = [1, 1, 1, -1]
    elif compute_type == "Conv3D":
        shape = [1, 1, 1, 1, -1]
    elif compute_type == "DepthwiseConv2dNative":
        if weight_and_scale.get_shape().as_list():
            shape = [1, 1, -1, weight_and_scale.get_shape()[-1]]
        else:
            shape = [-1]
    elif compute_type == "MatMul":
        shape = [1, -1]
    else:
        raise TypeError(" %s isn't supported." % (compute_type))

    bn_params = [tf.compat.v1.reshape(param, shape) for param in bn_params]

    return bn_params


def fuse_scale_w(compute_type, scale_w, fuse_parameters):
    """
    Funtion: Fuse scale_w with BN layer's parameters.
    """
    # get parameter
    scale = fuse_parameters.get("scale")
    variance = fuse_parameters.get("variance")
    epsilon = fuse_parameters.get("epsilon")

    # fuse operaions
    ori_type = scale.dtype
    scale, variance = _reshape_bn_param(
        compute_type, [scale, variance], scale_w)
    scale_w_new = tf.compat.v1.multiply(tf.compat.v1.cast(scale, tf.float32), scale_w)
    variance = tf.compat.v1.add(variance, epsilon)
    stdev = tf.compat.v1.sqrt(variance)
    scale_w_new = tf.compat.v1.divide(scale_w_new, tf.compat.v1.cast(stdev, tf.float32))
    LOGGER.push_debug_message(
        "fuse_scale_w information:\nscale:{}\nvariance:{}\nscale_w_new:{}".
        format(scale, variance, scale_w_new), "fuse_bn")

    return tf.compat.v1.cast(scale_w_new, ori_type)


def fuse_weight(compute_type, weight, fuse_parameters, context):
    """
    Funtion: Fuse weight with BN layer's parameters.
    Inputs:
        compute_type: a string, the type of operation to be fused with
            BN layer. Only "Conv2D" and "DepthwiseConv2dNative" are supported.
        weight: a tensor, the weight to be fused.
        fuse_parameters: a dictionary containing necessary parameters
            scale: a tensor, the scale of BN layer.
            variance: a tensor, the variance of BN layer.
            epsilon: a tensor, the epsilon of BN layer.
        context: a string, context for created nodes.
    Returns:
        weight_fused: a tensor, the weight fused.
        weight_assign: a tensor which can be run to get new weights.
    """
    # get parameter
    scale = fuse_parameters.get("scale")
    variance = fuse_parameters.get("variance")
    epsilon = fuse_parameters.get("epsilon")

    # fuse operaions
    scale, variance = _reshape_bn_param(
        compute_type, [scale, variance], weight)
    weight_new = tf.compat.v1.multiply(scale, tf.compat.v1.cast(weight, tf.float32))
    variance = tf.compat.v1.add(variance, epsilon)
    stdev = tf.compat.v1.sqrt(variance)
    weight_new = tf.compat.v1.divide(weight_new, stdev)
    weight_new = tf.compat.v1.cast(weight_new, weight.dtype)
    LOGGER.push_debug_message(
        "fuse_weight information:\nscale:{}\nvariance:{}\nweight_new:{}".
        format(scale, variance, weight_new), "fuse_bn")

    # don't store fused weight if is_replace is False
    if not fuse_parameters.get("is_replace"):
        return weight_new, None
    # Construct a new variable to store fused weight if is_replace is True
    with tf.compat.v1.variable_scope(None, default_name=context) as scope:
        scope.set_partitioner(None)
        weight_var = tf.compat.v1.get_variable(
            name='weight_fused',
            shape=weight_new.shape,
            initializer=tf.compat.v1.constant_initializer(1.0),
            dtype=weight.dtype,
            trainable=False,
            collections=[
                tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                tf.compat.v1.GraphKeys.MODEL_VARIABLES
            ],
            use_resource=False)
        weight_assign = tf.compat.v1.assign(weight_var, weight_new)
        weight_fused = weight_var.read_value()

        return weight_fused, weight_assign


def fuse_bias(bias, fuse_parameters, context):
    """
    Funtion: Fuse bias with BN layer's parameters.
    Inputs:
        bias: a tensor, the bias to be fused.
        fuse_parameters: a dictionary containing necessary parameters
            mean: a tensor, the mean of BN layer.
            variance: a tensor, the variance of BN layer.
            scale: a tensor, the scale of BN layer.
            offset: a tensor, the offset of BN layer.
        context: a string, context for created nodes.
    Returns:
        bias_fused: a tensor, the bias fused.
    """
    # get parameter
    scale = fuse_parameters.get("scale")
    offset = fuse_parameters.get("offset")
    mean = fuse_parameters.get("mean")
    variance = fuse_parameters.get("variance") + fuse_parameters.get("epsilon")

    # fuse
    if bias is None:
        bias = tf.compat.v1.constant([0.0])
    bias_new = tf.compat.v1.cast(bias, tf.float32) - mean
    bias_new = tf.compat.v1.multiply(scale, bias_new)
    stdev = tf.compat.v1.sqrt(variance)
    bias_new = tf.compat.v1.divide(bias_new, stdev)
    bias_new = tf.compat.v1.add(bias_new, offset)
    LOGGER.push_debug_message(
        "fuse_bias information:\nscale:{}\nvariance:{}\noffset:{}\nbias_new:{}"
        .format(scale, variance, offset, bias_new), "fuse_bn")
    bias_new = tf.compat.v1.cast(bias_new, bias.dtype)

    # don't store fused bias if is_replace is False
    if not fuse_parameters.get("is_replace"):
        return bias_new, None
    # Construct a new variable to store fused bias if is_replace is True
    with tf.compat.v1.variable_scope(None, default_name=context) as scope:
        scope.set_partitioner(None)
        bias_var = tf.compat.v1.get_variable(
            name='bias_fused',
            shape=bias_new.shape,
            initializer=tf.compat.v1.constant_initializer(0.0),
            dtype=bias.dtype,
            trainable=False,
            collections=[
                tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                tf.compat.v1.GraphKeys.MODEL_VARIABLES
            ],
            use_resource=False)
        bias_assign = tf.compat.v1.assign(bias_var, bias_new)
        bias_fused = bias_var.read_value()

        return bias_fused, bias_assign
