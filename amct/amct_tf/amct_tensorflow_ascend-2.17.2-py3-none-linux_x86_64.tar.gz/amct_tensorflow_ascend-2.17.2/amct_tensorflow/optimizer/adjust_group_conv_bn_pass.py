#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Adjust group_conv's bn layer. New bn will be added in each conv and original
bn after concat will be deleted.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.optimizer.bn_fusion_utils import is_tail_layer
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_info_generator import QuantInfoGenerator
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.utils.quant_ops import add_context_to_name
from amct_tensorflow.pattern.match_group_conv import pattern_group_conv
from amct_tensorflow.pattern.match_group_conv import find_concat_in
from amct_tensorflow.pattern.match_group_conv import GROUP_CONV_SPLIT
from amct_tensorflow.optimizer.bn_fusion_utils import split_bn_params

from amct_tensorflow.utils.log import LOGGER

__all__ = ['AdjustGroupConvBNPass']


class AdjustGroupConvBNPass(BaseFusionPass):
    """
    Function: Adjust group_conv's bn layer to be fused in ConvBnFusionPass.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, skip_param=None, outputs=None):
        """
        Function: init object
        Inputs:
            skip_layers: a list containing the layers not to be fusded.
        Return: None
        """
        BaseFusionPass.__init__(self)
        if skip_param is None:
            skip_param = dict()
        do_fusion = skip_param.get('do_fusion')
        skip_layers = skip_param.get('skip_layers')
        skip_layers_fusible = skip_param.get('skip_layers_fusible')

        if do_fusion is None:
            self.do_fusion = True
        else:
            self.do_fusion = do_fusion

        if skip_layers is None:
            self.skip_layers = []
        else:
            self.skip_layers = skip_layers

        if skip_layers_fusible is None:
            self.skip_layers_fusible = dict.fromkeys(self.skip_layers, False)
        else:
            self.skip_layers_fusible = skip_layers_fusible

        if outputs is None:
            self.outputs = []
        else:
            self.outputs = outputs

        self.structure = dict()

    def match_pattern(self, operation):
        """
        Function: Match fusible pattern of "group_conv + bn".
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type not in GROUP_CONV_SPLIT:
            return False
        # match struct
        group_conv = pattern_group_conv(operation)
        if group_conv is None:
            return False

        enable_fuse, skip_fuse = group_conv.check_fuse(
            self.skip_layers, support_is_training=[False])
        if not enable_fuse:
            return False

        # ensure do fusion in config
        if not self.do_fusion or skip_fuse:
            self.skip_layers_fusible[group_conv.get_name("conv_names")[0]] = \
                True
            return False

        self.structure[operation.name] = {'group_conv': group_conv}
        return True

    def do_pass(self, object_op):
        """
        Function: Adjust group_conv's bn layer actually
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        group_conv = self.structure.get(object_op.name).get('group_conv')
        bn_op = group_conv.get_bn()
        is_tail = is_tail_layer(bn_op)
        concat_op = group_conv.get_concat()
        _split_group_conv_bn(group_conv)
        if bn_op.name in self.outputs:
            index = self.outputs.index(bn_op.name)
            self.outputs[index] = concat_op.name

        if is_tail and not self.outputs:
            LOGGER.push_warning_message(
                'Fused Group BN at the end of the network! ' \
                'You need to replace the old output node by the new output ' \
                'node in inference process! \n' \
                '{}The name of the old output node is \'{}\'\n' \
                '{}The name of the new output node is \'{}\''.format(
                    '>'*30, bn_op.outputs[0].name,
                    '<'*30, concat_op.outputs[0].name),
                module_name='adjust_group_conv_bn_pass')

        return [], []


def _split_group_conv_bn(group_conv):
    """
    Function: Split group_conv's bn into several bns and add bn for each conv.
        case1:
                split                          split
                /   \\                         /   \
             conv   conv                    conv   conv
              |       |                      |       |
          biasadd   biasadd              biasadd   biasadd
               \\     /                       |       |
                concat                       bn      bn
                  |                           \\    /
                  bn                           concat
        case2:
                split                          split
                /   \\                         /   \
             conv   conv                    conv   conv
               \\     /                      |       |
                concat                       bn      bn
                  |                            \\    /
                  bn                           concat
    Inputs:
        group_conv: an object of GroupConv
    Returns:
        None
    """
    # split parameters of bn
    bn_op = group_conv.get_bn()
    split_fuse_parameters = split_bn_params(
        bn_op, group_conv.get_attr('group_size'))

    # add bn for conv in each branch
    concat_op = group_conv.get_concat()
    for index, conv in enumerate(group_conv.get_convs()):
        context, _ = split_name_scope(conv.name)
        context = add_context_to_name(context, 'group_conv_bn')
        fuse_parameters = split_fuse_parameters[index]
        concat_in = find_concat_in(concat_op, index)
        with tf.compat.v1.variable_scope(None, default_name=context):
            bn_out = tf.compat.v1.layers.batch_normalization(
                inputs=concat_in,
                axis=group_conv.split_dim,
                epsilon=fuse_parameters["epsilon"])
            new_bn_op = bn_out.op
            replace_inputs_tensor(fuse_parameters["scale"],
                                  new_bn_op.inputs[1], [new_bn_op])
            replace_inputs_tensor(fuse_parameters["offset"],
                                  new_bn_op.inputs[2], [new_bn_op])
            replace_inputs_tensor(fuse_parameters["mean"], new_bn_op.inputs[3],
                                  [new_bn_op])
            replace_inputs_tensor(fuse_parameters["variance"],
                                  new_bn_op.inputs[4], [new_bn_op])
        QuantInfoGenerator().set_bias_add_anchor(new_bn_op.name, [bn_op.name])
        replace_inputs_tensor(bn_out, concat_in, [concat_op])

    LOGGER.push_debug_message(
        "Add bn layers for convs in group_conv{%s}" %
        (group_conv.get_name('name')), 'AdjustGroupConvBNPass')

    # delete the link of BN
    bn_op = group_conv.get_bn()
    replace_inputs_tensor(bn_op.inputs[0], bn_op.outputs[0],
                          bn_op.outputs[0].consumers())
    replace_inputs_tensor(tf.compat.v1.placeholder(bn_op.inputs[0].dtype),
                          bn_op.inputs[0], [bn_op])
    group_conv.delete_bn()
