#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

WeightQuant op fusion optimization.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np

from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor

_CUSTOM_OP = load()

__all__ = ['WeightQuantFusionPass']


class WeightQuantFusionPass(BaseFusionPass):
    """
    Function: WeightQuant op fusion optimization.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, records=None):
        """
        Function: init object
        Inputs:
            records: a dictionary containing quant factors
        Return: None
        """
        BaseFusionPass.__init__(self)
        if records is None:
            records = {}

        self.records = records

    @staticmethod
    def find_same_weight_quant_node(records, weight_quant_node_list):
        """find quant node with same scale and offset"""
        fusion_weight_quant_nodes = {}
        for weight_quant_node in weight_quant_node_list:
            layer_name = str(weight_quant_node.get_attr('layer_name'),
                             'utf-8')
            scale_w = records.get(layer_name).get('weight_scale')
            if np.size(scale_w) > 1:
                encode_id = tuple(list(np.reshape(scale_w, -1)))
            else:
                encode_id = tuple([float(scale_w)])
            if encode_id not in fusion_weight_quant_nodes:
                fusion_weight_quant_nodes[encode_id] = [weight_quant_node]
            else:
                fusion_weight_quant_nodes.get(encode_id).append(weight_quant_node)
        return fusion_weight_quant_nodes

    def match_pattern(self, operation):
        """
        Function: Match quantizable operation to be quantized.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """

        for output_tensor in operation.outputs:
            candidate_ops = []
            weight_quant_layer_count = 0
            candidate_ops += output_tensor.consumers()
            for output_op in output_tensor.consumers():
                if output_op.type == "Identity":
                    candidate_ops += output_op.outputs[0].consumers()
            for ops in candidate_ops:
                if ops.type == 'WeightQuant':
                    weight_quant_layer_count += 1
            if weight_quant_layer_count > 1:
                return True
        return False

    def do_pass(self, object_op):
        """
        Function: Optimized fusion weight quant op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        for output_tensor in object_op.outputs:
            weight_quant_node_list = []
            candidate_ops = []
            candidate_ops += output_tensor.consumers()
            for output_op in output_tensor.consumers():
                if output_op.type == "Identity":
                    candidate_ops += output_op.outputs[0].consumers()
            for candidate_op in candidate_ops:
                if candidate_op.type == 'WeightQuant':
                    weight_quant_node_list.append(candidate_op)

            # record quant layer with same scale and offset
            fusion_weight_quant_nodes = self.find_same_weight_quant_node(
                self.records, weight_quant_node_list)

            # do weight quant fusion
            for _, nodes in fusion_weight_quant_nodes.items():
                if len(nodes) < 2:
                    continue
                for node in nodes[1:]:
                    for index, _ in enumerate(node.outputs):
                        replace_inputs_tensor(
                            nodes[0].outputs[index],
                            node.outputs[index],
                            node.outputs[index].consumers())

        return [], []
