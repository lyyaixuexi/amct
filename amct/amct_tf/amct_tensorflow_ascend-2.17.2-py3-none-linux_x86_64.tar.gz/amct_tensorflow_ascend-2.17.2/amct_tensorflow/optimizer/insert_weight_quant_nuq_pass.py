#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert WeightQuantNuq for quantized layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.utils.quant_ops import create_context
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.utils.utils_vars import DUAL_ACTIVATION_QUANT_TYPES
from amct_tensorflow.utils.utils_vars import NUQ_QUANTIZABLE_TYPES
from amct_tensorflow.utils.utils_vars import CLUSTER_CENTER
from amct_tensorflow.utils.log import LOGGER

_CUSTOM_OP = load()
SKIP_TYPES = ['AvgPool']


class InsertWeightQuantNuqPass(BaseFusionPass):
    """
    Function: Insert WeightQuantNuq for quantized layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, records=None):
        """
        Function: init object
        Inputs:
            records: a dictionary containing quant factors
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records

    def match_pattern(self, operation):
        """
        Function: Match quantizable operation to be quantized.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        # this pass only for nuq, records has key cluster center
        if operation.type in NUQ_QUANTIZABLE_TYPES \
            and operation.type not in SKIP_TYPES + DUAL_ACTIVATION_QUANT_TYPES \
            and operation.name in self.records \
            and CLUSTER_CENTER in self.records.get(operation.name).keys():
            return True

        return False


    def do_pass(self, object_op): # pylint: disable=R0914
        """
        Function: Insert WeightQuantNuq before object_op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        layer_context, _ = split_name_scope(object_op.name)
        context = create_context(layer_context, quant_type='weight')

        scale_value = self.records.get(object_op.name).get('weight_scale')
        offset_value = self.records.get(object_op.name).get('weight_offset')
        num_bits = self.get_dst_type(object_op.name)
        cluster_center_value = self.records.get(
            object_op.name).get('cluster_center')

        _, weight_index = QuantOpInfo.get_quant_index(object_op)
        weight_in_op = object_op.inputs[weight_index].op
        weight_in_index = object_op.inputs[weight_index].value_index

        weight = weight_in_op.outputs[weight_in_index]

        with tf.compat.v1.variable_scope(None,
                                         default_name=context + '_temp',
                                         values=[weight]):
            scale = tf.compat.v1.constant(scale_value,
                                          dtype=tf.compat.v1.float32,
                                          name='scale_weight')
            offset = tf.compat.v1.constant(offset_value,
                                           dtype=tf.compat.v1.int8,
                                           name='offset_weight')
            cluster_center = tf.compat.v1.constant(cluster_center_value,
                                                   dtype=tf.compat.v1.int32,
                                                   name='cluster_center')
            weight_quant = _CUSTOM_OP.weight_quant_nuq(weight,
                                                       scale=scale,
                                                       offset=offset,
                                                       cluster=cluster_center,
                                                       layer_name=object_op.name,
                                                       quant_bits=num_bits)

        replace_inputs_tensor(weight_quant, object_op.inputs[weight_index],
                                [object_op])
        LOGGER.push_debug_message(
            "finish inserting WeightQuantNuq for %s" % (object_op.name),
            "InsertWeightQuantNuqPass")

        return [], []
