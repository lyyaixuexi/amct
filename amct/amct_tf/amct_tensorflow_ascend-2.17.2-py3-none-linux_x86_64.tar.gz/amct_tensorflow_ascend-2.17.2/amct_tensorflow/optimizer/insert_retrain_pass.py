#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert retrain op

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.utils import quant_ops
from amct_tensorflow.utils import retrain_ops

from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.utils.utils_vars import NO_WEIGHT_QUANT_TYPES


class InsertRetrainPass(BaseFusionPass):
    """
    Insert retrain pass
    """
    def __init__(self, quant_config=None, skip_layers=None):
        '''inner method'''
        BaseFusionPass.__init__(self)
        self.quant_config = quant_config
        self.skip_layers = skip_layers
        self.op_group_map = {}
        self.group_num = 0
        self.group_info = {}
        self.context_num = 0

    @staticmethod
    def _is_fixed_min(op): # pylint: disable=C0103
        if op.type.startswith('Relu'):
            return True

        if len(op.inputs) > 0 and op.inputs[0].op.type.startswith('Relu'):
            if op.type in ['Reshape', 'Identity', 'Transpose', 'Pad', 'MirrorPad']:
                return True

            if op.type == 'PadV2':
                with tf.compat.v1.Session(
                        config=tf.compat.v1.ConfigProto(allow_soft_placement=True),
                        graph=op.graph) as sess:
                    value = sess.run(op.inputs[2])
                    if value >= 0:
                        return True
        return False

    def need_retrain(self, operation):
        '''inner method'''
        if operation.type in self.quant_config['support_types'] and \
            operation.name in self.quant_config.keys() and \
                operation.name not in self.skip_layers and \
                self.quant_config[operation.name]['retrain_enable']:
            return True
        return False

    def match_co_retrain_pattern(self, operator):
        '''inner method'''
        act_index, _ = QuantOpInfo.get_quant_index(operator)
        act_input = operator.inputs[act_index]
        # already record in co-retrain group, no need to store
        if operator.name in self.op_group_map.keys():
            return True

        lgroups = []
        for consumer in act_input.consumers():
            if self.need_retrain(consumer):
                for l_g in lgroups:
                    name = self.group_info.get(l_g).get('members')[0]
                    # if already has group
                    if self.quant_config[consumer.name][
                            'retrain_data_config'] == \
                            self.quant_config[name]['retrain_data_config']:
                        self.op_group_map[consumer.name] = l_g
                        group_content = self.group_info.get(l_g)
                        group_content['members'].append(consumer.name)
                        LOGGER.push_info_message(
                            'Add %s to %d co-retrain group'
                            % (consumer.name, l_g),
                            module_name='retrain layer')
                        break
                if consumer.name not in self.op_group_map.keys():
                    # build new group
                    self.group_num += 1
                    self.group_info[self.group_num] = {}
                    group_content = self.group_info.get(self.group_num)
                    group_content['done'] = False
                    group_content['members'] = []
                    self.op_group_map[consumer.name] = self.group_num
                    group_content['members'].append(consumer.name)
                    lgroups.append(self.group_num)
                    LOGGER.push_info_message(
                        'Add %s new co-retraining group: %d' %
                        (consumer.name, self.group_num),
                        module_name='retrain layer')

        return True

    def match_pattern(self, operation):
        '''inner method'''
        if self.need_retrain(operation):
            if self.match_co_retrain_pattern(operation):
                return True
        return False

    def do_pass(self, object_op):
        """
        Function: Do actual "Convolution" layer and "BatchNorm" layer
                  fusion operation
        Parameters:
            object_node: node to process
        """
        LOGGER.push_info_message('doing layer:%s insert retrain layer' %
                                 object_op.name,
                                 module_name='retrain layer')
        if object_op.name in self.op_group_map.keys():
            group_num = self.op_group_map.get(object_op.name)
            if not self.group_info.get(group_num).get('done'):
                self._do_act_retrain_pass(object_op)
                self.group_info.get(group_num)['done'] = True
        else:
            self._do_act_retrain_pass(object_op)
        if object_op.type in NO_WEIGHT_QUANT_TYPES:
            return [], []

        _, wgt_index = QuantOpInfo.get_quant_index(object_op)
        object_conf = self.quant_config[object_op.name]
        wgt_input = object_op.inputs[wgt_index]
        wgt_kwargs = object_conf.get('retrain_weight_config')
        wgt_kwargs['quant_op_names'] = [object_op.name]
        context = wgt_input.op.name
        with tf.compat.v1.device(object_op.device):
            wgt_output = retrain_ops.quant_wgt(
                wgt_input,
                context,
                wgt_kwargs,
                object_op.type)

        quant_ops.relink_tensor(wgt_input, wgt_output, object_op)

        return [], []

    def _do_act_retrain_pass(self, object_op):
        '''inner method'''
        LOGGER.push_info_message('doing layer:%s insert act retrain layer' %
                                 object_op.name,
                                 module_name='retrain layer')
        if len(object_op.inputs) > 1:
            context = object_op.inputs[1].op.name
        else:
            context = '%d_' % self.context_num
            self.context_num += 1
        # inser act_quant
        act_index, _ = QuantOpInfo.get_quant_index(object_op)
        act_input = object_op.inputs[act_index]

        object_conf = self.quant_config[object_op.name]
        act_kwargs = object_conf.get('retrain_data_config')
        name_list = []
        if object_op.name in self.op_group_map.keys():
            group_id = self.op_group_map.get(object_op.name)
            name_list = self.group_info.get(group_id).get('members')
        else:
            name_list = [object_op.name]
        act_kwargs['quant_op_names'] = name_list

        if InsertRetrainPass._is_fixed_min(act_input.op):
            act_kwargs['fixed_min'] = True

        with tf.compat.v1.device(object_op.device):
            act_output = retrain_ops.quant_act(
                act_input,
                context,
                act_kwargs)

        for name in name_list:
            act_op = tf.compat.v1.get_default_graph().get_operation_by_name(
                name)
            quant_ops.relink_tensor(act_input, act_output, act_op)
