#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

GraphOptimizer is manager and executor of graph passes.

"""

from amct_tensorflow.utils.log import LOGGER

__all__ = ['GraphOptimizer']


class GraphOptimizer():
    """
    Function: GraphOptimizer is manager and executor of graph passes.
    APIs: add_pass, clear_pass, do_optimizer
    """
    def __init__(self):
        """
        Function: init function
        Inputs: None
        Return: None
        """
        self.__passes = []
        self.__matched_layers = dict()

    def get_matched_layers(self, pass_type):
        """
        Function: get matched ops for pass
        Inputs: pass_type: the pass type str
        Return: a list containing matched ops' name for passes
        """
        return self.__matched_layers.get(pass_type)

    def add_pass(self, graph_pass):
        """
        Function: add pass
        Inputs: graph_pass: a pass to modify graph
        Return: None
        """
        self.__passes.append(graph_pass)

    def clear_pass(self):
        """
        Function: clear pass
        Inputs: None
        Return:None
        """
        self.__passes.clear()

    def get_pass(self, pass_index):
        """
        Function: get pass
        Inputs: pass_index: pass' index in __passes
        Return: a pass
        """
        return self.__passes[pass_index]

    def do_optimizer(self, graph):
        """
        Function: optimize the graph according the passes
        Inputs: graph: tf.compat.v1.Graph, to be optimized
        Return: graph: tf.compat.v1.Graph after optimized
        """
        for graph_pass in self.__passes:
            LOGGER.push_info_message('Do {}'.format(type(graph_pass)),
                                     'GraphOptimizer')
            graph, matched_operations = graph_pass.run(graph)
            self.__matched_layers[str(type(graph_pass))] = [op.name for op in matched_operations]

        return graph
