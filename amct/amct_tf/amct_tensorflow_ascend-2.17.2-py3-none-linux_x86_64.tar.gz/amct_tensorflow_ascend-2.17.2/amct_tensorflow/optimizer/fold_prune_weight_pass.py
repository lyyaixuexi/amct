#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert retrain op

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.retrain_alg import _decorate_enter


class FoldPruneWeightPass(BaseFusionPass):
    """
    Function: Fold maskmul's inputs as new weight tensor
    """
    def __init__(self, outputs=None):
        BaseFusionPass.__init__(self)
        self.outputs = outputs

    @staticmethod
    def match_pattern(operation):
        """Function: match mask_mul ops"""
        if operation.type in ['Mask']:
            return True
        return False

    @staticmethod
    def do_pass(object_op):
        '''
        Function fold weight tensor for all peer mask_mul ops
        e.g.
                weight
                   |               weight_folded
                reshape     --->         |
                   |                 enter_new
                 enter                /      \
                 /   \          mask_mul_1  mask_mul_2
        mask_mul_1  mask_mul_2      |           |
            |           |         conv1       conv2
          conv1       conv2
        '''
        mask_mul_op = object_op
        wgt_tensor = mask_mul_op.inputs[0]
        if wgt_tensor.op.type in ['Identity', 'Const']:
            # no need to fold
            return [], []
        context, _ = split_name_scope(wgt_tensor.op.name)
        if context == "":
            context = "prune"
        # check if weight is in a while loop
        info_length = GraphChecker.get_dependency_enter_info(wgt_tensor.op)[0]
        if info_length: # skip enter op
            wgt_tensor = wgt_tensor.op.inputs[0]
        with tf.compat.v1.variable_scope(None, default_name=context, values=[wgt_tensor]):
            wgt_fold_variable = tf.compat.v1.get_variable(
                'weight_folded',
                shape=wgt_tensor.shape,
                dtype=wgt_tensor.dtype,
                trainable=False,
                collections=[
                    tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                    tf.compat.v1.GraphKeys.MODEL_VARIABLES],
                use_resource=False)
            assign_weight = tf.compat.v1.assign(wgt_fold_variable, wgt_tensor)
            wgt_read_op = wgt_fold_variable.op.outputs[0].consumers()[1]
            wgt_fold_tensor = wgt_read_op.outputs[0]
            wgt_fold_tensor = _decorate_enter(wgt_tensor, mask_mul_op.name, [wgt_fold_tensor])[0]
        # disconnect maskmul_op's consumers
        replace_inputs_tensor(wgt_fold_tensor, mask_mul_op.inputs[0], \
            mask_mul_op.inputs[0].consumers())
        return [assign_weight], []
