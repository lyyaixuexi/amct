#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Base class for fusion passes
"""


from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.utils.graph_utils import GraphUtils


__all__ = ['BaseFusionPass']


class BaseFusionPass():  # pylint: disable=unused-argument, no-self-use
    """
    Function: Base class of graph optimizer pass
    APIs: set_up, tear_down, match_pattern, do_pass, reset_run_list, run
    """
    def __init__(self, outputs=None):
        """
        Function: init object
        Inputs: None
        Return: None
        """
        self.outputs = outputs
        self.graph = None
        self.records = None

    def set_up(self):
        """
        Function: Do some set up for pass
        Inputs: None
        Return: None
        """

    def tear_down(self):
        """
        Function: Do some tear down for pass
        Inputs: None
        Return: None
        """

    def supplement_pass(self):
        """
        Function: supplement grapg modify after do_pass
        Inputs: None
        Return: None
        """

    def match_pattern(self, operation):
        """
        Function: Match pattern of specific structure in graph
        Inputs: None
        Return: None
        """
        return False

    def do_pass(self, object_op):
        """
        Function: Do actual fusion operation for a matched pattern
        Inputs: object_op: matched operation
        Return:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        assign_list = []
        run_list = []
        return assign_list, run_list

    def reset_run_list(self, object_op, run_list_value):
        """
        Function: Save the value in run_list
        Inputs:
            object_op: matched operation
            run_list_value: np.arrsy, the value of tensor in run_list
        Return: None
        """

    def get_dst_type(self, op_name):
        """
        Function: check and return dst_type
        Inputs:
            op_name: name of operation
        Return: int num_bit
        """
        if 'dst_type' in self.records.get(op_name):
            dst_type = self.records.get(op_name).get('dst_type')
            num_bit = 8 if dst_type == "INT8" else 4
        else:
            num_bit = 8
        return num_bit

    def run(self, graph):
        """
        Function: Do actual fusion operation for graph
        Inputs: graph: tf.compat.v1.Graph to be fused
        Return: graph: tf.compat.v1.Graph fused
        """
        self.set_up()
        self.graph = graph

        # Step1: match pattern and record first matched operation
        matched_operations = []
        for operation in graph.get_operations():
            if self.match_pattern(operation):
                matched_operations.append(operation)

        # Step2: do each matched node fusion operation
        with graph.as_default():
            assign_lists = list()
            run_lists = list()
            run_lists_index = [0] * (len(matched_operations) + 1)
            for index, operation in enumerate(matched_operations):
                assign_list, run_list = self.do_pass(operation)
                assign_lists.extend(assign_list)
                run_lists.extend(run_list)
                run_lists_index[index +
                                1] = run_lists_index[index] + len(run_list)
        # Step3: add global operations
        self.supplement_pass()

        # Step4: update necesary variables
        if assign_lists or run_lists:
            if self.outputs is None:
                raise RuntimeError(
                    "the model's outputs is needed to update new variables",
                    "BaseFusionPass")
            with tf.compat.v1.Session(
                    config=tf.compat.v1.ConfigProto(allow_soft_placement=True),
                    graph=graph) as sess:
                sess.run(tf.compat.v1.global_variables_initializer())
                if run_lists:
                    run_lists_value = sess.run(run_lists)
                if assign_lists:
                    sess.run(assign_lists)
                # extract graph_def for inference
                graph_def = extract_graph_def_from_sess(sess, self.outputs)

            # update new_graph
            graph = tf.compat.v1.Graph()
            with graph.as_default():
                GraphUtils.handle_graph_def(graph_def)
                tf.compat.v1.import_graph_def(graph_def, name='')

            # update run_lists value
            if run_lists:
                for index, operation in enumerate(matched_operations):
                    run_list_value = run_lists_value[
                        run_lists_index[index]:run_lists_index[index + 1]]
                    self.reset_run_list(operation, run_list_value)
        self.tear_down()
        return graph, matched_operations


def extract_graph_def_from_sess(sess, outputs):
    '''extract graph_def from a session  '''
    graph_def = tf.compat.v1.graph_util.convert_variables_to_constants(
        sess, sess.graph_def, outputs)
    return graph_def
