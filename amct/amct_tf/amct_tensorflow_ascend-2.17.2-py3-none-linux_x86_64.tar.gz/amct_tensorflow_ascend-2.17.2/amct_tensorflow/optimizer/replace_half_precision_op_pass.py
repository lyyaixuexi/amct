#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2023. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace half-precision to full-precision for quantized layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.utils.quant_op_info import QuantOpInfo

from amct_tensorflow.utils.log import LOGGER

__all__ = ['ReplaceHalfPrecisionOpPass']


class ReplaceHalfPrecisionOpPass(BaseFusionPass):
    """
    Function: Replace float16 op to float32 op.
    APIs: match_pattern, do_pass,
    """
    def __init__(self):
        """
        Function: init object
        Inputs: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    def match_pattern(self, operation):
        """
        Function: Match fakequant op.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type == "Quant" and operation.node_def.attr['T'].type == tf.float16.as_datatype_enum:
            return True
        return False

    def do_pass(self, object_op):
        """
        Function: Replace half to float
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        graph = tf.compat.v1.get_default_graph()
        quant_out = object_op.outputs[0]
        quant_consumers = quant_out.consumers()
        cast_quant_out = tf.cast(quant_out, tf.float32)
        for member in quant_consumers:
            if member.type == 'Cast':
                continue
            if member.type == 'AntiQuant':
                relink_tensor = tf.cast(cast_quant_out, tf.float16)
                replace_inputs_tensor(relink_tensor, member.inputs[0], [member])
                continue
            oriout_tensor, output_tensor = self.copy_node(graph, member, cast_quant_out)
            oriout_tensor, output_tensor = self.copy_node_after_pad_and_split(member, oriout_tensor, output_tensor)
            oriout_tensor, output_tensor = self.copy_biasadd(oriout_tensor, output_tensor)

            output_tensor = tf.cast(output_tensor, tf.float16)
            dequant_producer = oriout_tensor.consumers()
            replace_inputs_tensor(output_tensor, oriout_tensor, dequant_producer)
            LOGGER.push_debug_message(
                "finish replacing HalfPrecisionOperation for %s" %
                (object_op.get_attr('layer_name')), "ReplaceHalfPrecisionOpPass")
        return [], []

    def get_new_node_inputs(self, member, act_new_input):
        """
        Function: Get new float32 node inputs.
        Inputs:
            member: op to get inputs
            act_new_input: new input for activation
        Returns:
            node_inputs: member's copy node's inputs
        """
        node_inputs = [None] * len(member.inputs)
        act_index, weight_index = 0, 1
        if member.type in ['AntiQuant', 'Pad']:
            act_index, weight_index = 0, 0
        elif member.type in ['Split']:
            act_index, weight_index = 1, 1
        else:
            act_index, weight_index = QuantOpInfo.get_quant_index(member)
        for input_idx, input_tensor in enumerate(member.inputs):
            if input_idx == act_index:
                node_inputs[input_idx] = act_new_input
            elif input_idx == weight_index:
                node_inputs[input_idx] = tf.cast(input_tensor, tf.float32)
            else:
                node_inputs[input_idx] = input_tensor
            replace_inputs_tensor(
                tf.compat.v1.placeholder(input_tensor.dtype), input_tensor, [member])
        return node_inputs

    def copy_biasadd(self, oriout_tensor, output_tensor):
        ''' copy biasadd after op '''
        if oriout_tensor.consumers()[0].type == 'BiasAdd':
            bias_node = oriout_tensor.consumers()[0]
            new_bias_def = bias_node.node_def
            new_bias_def.name = new_bias_def.name + '_full_precision_for_amct'
            bias_node_inputs = [output_tensor, tf.cast(bias_node.inputs[1], tf.float32)]
            replace_inputs_tensor(
                tf.compat.v1.placeholder(bias_node.inputs[1].dtype), bias_node.inputs[1], [bias_node])
            new_bias_def.attr['T'].CopyFrom(tf.compat.v1.AttrValue(type=tf.float32.as_datatype_enum))
            new_bias_node = tf.Operation(new_bias_def, self.graph, inputs=bias_node_inputs)
            oriout_tensor = bias_node.outputs[0]
            output_tensor = new_bias_node.outputs[0]
        return oriout_tensor, output_tensor

    def copy_node(self, graph, object_op, new_act_input):
        ''' copy a fp32 op from fp16 '''
        new_node_def = object_op.node_def
        new_node_def.name = object_op.name + '_full_precision_for_amct'
        quant_node_inputs = self.get_new_node_inputs(object_op, new_act_input)
        new_node_def.attr['T'].CopyFrom(tf.compat.v1.AttrValue(type=tf.float32.as_datatype_enum))
        new_quant_op = tf.Operation(new_node_def, graph, inputs=quant_node_inputs)
        output_tensor = new_quant_op.outputs[0]
        oriout_tensor = object_op.outputs[0]
        return oriout_tensor, output_tensor

    def copy_node_after_pad_and_split(self, member, oriout_tensor, output_tensor):
        ''' copy node after pad and split '''
        if member.type not in ['Pad', 'Split']:
            return oriout_tensor, output_tensor
        oriout_tensors = []
        member_consumers = []
        for member_out in member.outputs:
            member_consumers.extend(member_out.consumers())
        # quantize ops after pad or split
        for idx, quant_op in enumerate(member_consumers):
            _, output_tensor_tmp = self.copy_node(self.graph, quant_op, output_tensor.op.outputs[idx])
            oriout_tensor_tmp, output_tensor_tmp = self.copy_biasadd(quant_op.outputs[0], output_tensor_tmp)
            oriout_tensors.append(output_tensor_tmp)
        oriout_tensor = oriout_tensor_tmp
        output_tensor = output_tensor_tmp
        if oriout_tensor.consumers()[0].type in ['Concat', 'ConcatV2']:
            axis_idx = -1 if oriout_tensor.consumers()[0].type == 'ConcatV2' else 0
            axis_tensor = oriout_tensor.consumers()[0].inputs[axis_idx]
            new_concat_out = tf.concat(oriout_tensors, axis=axis_tensor)
            replace_inputs_tensor(tf.compat.v1.placeholder(axis_tensor.dtype),
                axis_tensor, oriout_tensor.consumers())
            oriout_tensor = oriout_tensor.consumers()[0].outputs[0]
            output_tensor = new_concat_out
        return oriout_tensor, output_tensor