#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert Quant for quantizable layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils import quant_ops
from amct_tensorflow.utils.quantize_alg import insert_dump
from amct_tensorflow.utils.utils_vars import OP_APPROXIMATION_TYPES


__all__ = ['InsertDumpOpPass']


class InsertDumpOpPass(BaseFusionPass):
    """
    Function: Insert Dump op for op approximation.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, approx_config, save_dir):
        """
        Function: init object
        Inputs:
            approx_config: a dictionary containing
                approximation config
            save_dir: directory of dumped data
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.approx_config = approx_config
        self.dump_config = {'dump_dir': save_dir}

    def match_pattern(self, operation):
        """
        Function: Match operation to be approximated.
        Inputs:
            operation: op to be approximated
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type not in OP_APPROXIMATION_TYPES:
            return False
        if operation.name not in self.approx_config.keys():
            return False
        approx_kwagrs = self.approx_config.get(operation.name)
        if not approx_kwagrs['approximate_enable'] or \
            approx_kwagrs['approximate_algo'] != 'FastSoftmax':
            return False
        return True

    def do_pass(self, object_op):
        """
        Function: Insert dump op before object_op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        if object_op.type == 'Softmax':
            act_index = 0
        self.dump_config['name_prefix'] = "{}_in{}".format(
            object_op.name.replace('/', '_'), act_index)
        self.dump_config['batch_num'] = self.approx_config['batch_num']
        input_tensor = object_op.inputs[act_index]
        layer_context, _ = split_name_scope(object_op.name)
        context = quant_ops.create_context(layer_context, 'dump')
        output_tensor = insert_dump(input_tensor, context, self.dump_config)
        quant_ops.relink_tensor(input_tensor, output_tensor, object_op)
        return [], []
