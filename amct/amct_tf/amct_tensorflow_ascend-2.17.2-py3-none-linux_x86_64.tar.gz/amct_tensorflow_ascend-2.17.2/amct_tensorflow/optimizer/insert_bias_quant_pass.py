#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert BiasQuant for quantized layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.utils.quant_ops import create_context

from amct_tensorflow.utils.utils_vars import QUANTIZABLE_TYPES
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.utils.utils_vars import QUANT_BIAS_BITS

_CUSTOM_OP = load()

__all__ = ['InsertBiasQuantPass', 'cmp_data_format']


class InsertBiasQuantPass(BaseFusionPass):
    """
    Function: Insert BiasQuant for quantized layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, records=None, num_bits=QUANT_BIAS_BITS):
        """
        Function: init object
        Parameter:
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records
        self.num_bits = num_bits

    def match_pattern(self, operation):
        """
        Function: Match operation before which BiasQuant can be inserted.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type != 'BiasAdd':
            return False

        pre_op = operation.inputs[0].op
        if pre_op.type in QUANTIZABLE_TYPES and pre_op.name in self.records \
            and cmp_data_format(pre_op, operation):
            return True

        return False

    def do_pass(self, object_op):
        """
        Function: Insert BiasQuant before object_op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        pre_op = object_op.inputs[0].op
        layer_context, _ = split_name_scope(object_op.name)
        context = create_context(layer_context, quant_type='bias')
        # inser bias_quant
        act_scale_value = self.records.get(pre_op.name).get('data_scale')
        weight_scale_value = self.records.get(pre_op.name).get('weight_scale')
        dqscale_value = act_scale_value * weight_scale_value
        dqscale_value = np.reshape(dqscale_value, -1)

        bias = object_op.inputs[1]

        with tf.compat.v1.variable_scope(
                None, ''.join([context, '_temp']), [bias]):
            deq_scale = tf.compat.v1.constant(dqscale_value,
                                              dtype=tf.compat.v1.float32,
                                              name='dqscale')
            bias_quant = _CUSTOM_OP.bias_quant(bias,
                                               deqscale=deq_scale,
                                               layer_name=pre_op.name,
                                               quant_bits=self.num_bits)

        replace_inputs_tensor(bias_quant, bias, [object_op])

        LOGGER.push_debug_message(
            "finish inserting BiasQuant for %s" % (pre_op.name),
            "InsertDeQuantPass")

        return [], []


def cmp_data_format(quantized_op, bias_add_op):
    '''
    Function: compare quantized_op's data_format and bias_add_op's data_format
        if they have data_foramt.
    Inputs:
        quantized_op: opeartion to be quantized
        bias_add_op: opeartion BiasAdd
    Returns:
        True: quantized_op's data_format is equal to bias_add_op's data_format,
            or quantized_op has no data_format.
        False: quantized_op's data_format is unequal to bias_add_op's
            data_format.
    '''
    nchw_foramt = ('NCHW', 'NCDHW', b'NCHW', b'NCDHW')
    nhwc_foramt = ('NHWC', 'NDHWC', b'NDHWC', b'NHWC')
    try:
        data_format1 = quantized_op.get_attr('data_format')
        data_format2 = bias_add_op.get_attr('data_format')
    except ValueError:
        # quantizable op has no data_format, MatMul for example.
        return True
    else:
        if data_format1 in nchw_foramt and data_format2 in nchw_foramt:
            return True
        if data_format1 in nhwc_foramt and data_format2 in nhwc_foramt:
            return True
        return False
