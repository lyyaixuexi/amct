#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Replace Quant to 'quant ops' for quantized layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.utils.log import LOGGER

_CUSTOM_OP = load()

__all__ = ['DeleteRetrainPass']


class DeleteRetrainPass(BaseFusionPass):
    """
    Function: Replace Quant to 'quant ops' for quantized layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self):
        """
        Function: init object
        Inputs: None
        Return: None
        """
        BaseFusionPass.__init__(self)

    def match_pattern(self, operation):
        """
        Function: Match Quant op.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type in ["ActivationRetrain", "WeightRetrain", "WeightUlq"]:
            return True
        return False


    def do_pass(self, object_op):
        """
        Function: Replace Quant(for act) to 'quant ops'
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        # get params
        quant_out = object_op.outputs[0]
        target_quant_nodes = quant_out.consumers()
        if target_quant_nodes[0].type == 'Transpose':
            quant_out = target_quant_nodes[0].outputs[0]
            target_quant_nodes = target_quant_nodes[0].outputs[0].consumers()

        check_numeric_op = object_op.inputs[0].op
        if check_numeric_op.type == 'Transpose':
            check_numeric_op = check_numeric_op.inputs[0].op
        orig_input = check_numeric_op.inputs[0]

        replace_inputs_tensor(orig_input, quant_out, target_quant_nodes)
        replace_inputs_tensor(tf.compat.v1.placeholder(check_numeric_op.inputs[0].dtype),
            check_numeric_op.inputs[0], [check_numeric_op])

        LOGGER.push_debug_message(
            "doing layer: delete retrain op[%s]!" % object_op.name,
            "DeleteRetrainPass")

        return [], []
