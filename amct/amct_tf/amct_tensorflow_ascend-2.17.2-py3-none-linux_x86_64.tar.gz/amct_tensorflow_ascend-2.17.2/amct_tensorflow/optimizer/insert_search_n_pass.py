#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert search_n op for quantizable layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.optimizer.bn_fusion_utils import is_tail_layer
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.pattern.utils import get_layer_ops_by_type
from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.utils.quant_ops import create_context
from amct_tensorflow.utils.quant_ops import get_next_single_op
from amct_tensorflow.utils import quant_ops

from amct_tensorflow.utils.utils_vars import SHIFT_N_TYPES
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.utils.utils_vars import DUAL_ACTIVATION_QUANT_TYPES

_CUSTOM_OP = load()

__all__ = ['InsertSearchNQuantPass']


class InsertSearchNQuantPass(BaseFusionPass):
    """
    Function: Insert search_n op for quantized layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, quant_config=None, skip_layers=None, outputs=None):
        """
        Function: init object
        Inputs:
            quant_config: a dictionary containing quant config
            skip_layers: a list containing skip quantize layers
        Return: None
        """
        BaseFusionPass.__init__(self)
        if quant_config is None:
            quant_config = {}
        if skip_layers is None:
            skip_layers = []
        self.quant_config = quant_config
        self.skip_layers = skip_layers

        if outputs is None:
            self.outputs = []
        else:
            self.outputs = outputs

    @staticmethod
    def gen_searchn_param(object_op, cali_scales, quant_config):
        '''gen searchn param for  object_op'''
        quant_kwargs = quant_config.get(object_op.name).\
            get('activation_quant_params')
        # ifmr with searchN, hfmg with searchN v2
        if quant_kwargs.get('act_algo') is None or \
                quant_kwargs.get('act_algo') == 'ifmr':
            quant_kwargs['searchn_version'] = 'V1'
        else:
            quant_kwargs['searchn_version'] = 'V2'
        quant_kwargs['batch_num'] = quant_config.get('batch_num')
        quant_kwargs['quant_op_names'] = [object_op.name]
        quant_kwargs['quant_op_types'] = [object_op.type]
        quant_kwargs['record_file_name'] = quant_config.\
            get('record_file')
        if object_op.type == 'AvgPool':
            channel_wise = False
            shift_n_length = 1
        else:
            weights = object_op.inputs[1]
            if object_op.inputs[1].op.type == 'Enter':
                weights = object_op.inputs[1].op.inputs[0]
            if quant_config.get(object_op.name).get(
                    'weight_quant_params').get('wts_algo') == 'nuq_quantize':
                channel_wise = True if object_op.type == 'Conv2D' else False # pylint:disable=R1719
            else:
                channel_wise = quant_config.get(object_op.name).\
                    get('weight_quant_params').get('channel_wise')
            _, shift_n_length = QuantOpInfo.get_scale_shape(
                weights, channel_wise, object_op.type)
        quant_kwargs['shift_n_length'] = shift_n_length
        quant_kwargs['channel_wise'] = channel_wise
        try:
            quant_kwargs['data_format'] = object_op.get_attr('data_format')
        except ValueError:
            quant_kwargs['data_format'] = 'NHWC'
        quant_kwargs['act_cali_output'] = cali_scales[0]
        quant_kwargs['wgt_cali_output'] = cali_scales[1]
        return quant_kwargs

    @staticmethod
    def insert_search_n(object_op, compute_op, context, quant_kwargs):
        """
        Function: Do insert search_n after compute_op
        Inputs:
            object_op: op to process
            compute_op: insert searchn after this op
            context: op context
            quant_kwargs: dictionary of quantization parameter
        Returns:
            None
        """
        tail_layer = is_tail_layer(compute_op)
        outputs = compute_op.outputs[0]
        if not tail_layer:
            relink_ops = outputs.consumers()
        search_n_outputs, _ = quant_ops.quant_calibration(
            [outputs, [outputs]],
            context,
            'search_n',
            quant_kwargs,
            object_op.type)

        if tail_layer:
            LOGGER.push_warning_message(
                'Insert searchN operator at the end of the network! ' \
                'You need to replace the old output node by the new output ' \
                'node in inference process! \n' \
                '{}The name of the old output node is \'{}\'\n' \
                '{}The name of the new output node is \'{}\''.format(
                    '>'*30, outputs.name,
                    '<'*30, search_n_outputs[0].name),
                module_name='quantize_model')
        else:
            quant_ops.replace_inputs_tensor(search_n_outputs[0], outputs,
                                            relink_ops)
        return search_n_outputs[0].op.name

    @staticmethod
    def get_calibration_scales(operation):
        """
        Function: Get the output tensor of the ifmr/hfmg/arq/nuq.
        Inputs:
            operation: op to be matched
        Returns:
            cali_output[0]: the output tensor of the act_calibration_op
            cali_output[1]: the output tensor of the wgt_calibration_op
        """
        act_cali_types = ['QuantIfmr', 'QuantHfmg']
        wgt_cali_types = ['QuantArq', 'QuantNuq']

        def _get_cali_output(operation, cali_op_type, input_stamp=None):
            cali_output = None
            cali_ops = get_layer_ops_by_type(
                operation.graph, cali_op_type)
            op_name = bytes(operation.name, encoding="utf8")
            if input_stamp is None:
                for cali_op in cali_ops:
                    if op_name in cali_op.get_attr('layer_names'):
                        cali_output = cali_op.outputs[0]
                        return cali_output
            else:
                input_stamp = bytes(input_stamp, encoding="utf8")
                for cali_op in cali_ops:
                    if op_name in cali_op.get_attr('layer_names') and \
                            cali_op.get_attr('input_stamp') == input_stamp:
                        cali_output = cali_op.outputs[0]
                        return cali_output
            return cali_output

        if operation.type in DUAL_ACTIVATION_QUANT_TYPES:
            return _get_cali_output(operation, act_cali_types, 'data'), \
                   _get_cali_output(operation, act_cali_types, 'weight')

        if operation.type == 'AvgPool':
            op_shape = InsertSearchNQuantPass._get_weight_shape(operation)
            area_factor = 1 / (op_shape[0] * op_shape[1])
            return _get_cali_output(operation, act_cali_types), area_factor

        return _get_cali_output(operation, act_cali_types), \
               _get_cali_output(operation, wgt_cali_types)

    @staticmethod
    def _get_weight_shape(object_op):
        data_sequence = bytes('NHWC', encoding="utf8")
        if object_op.get_attr('data_format') == data_sequence:
            return object_op.get_attr('ksize')[1:3]
        return object_op.get_attr('ksize')[2:]

    def match_pattern(self, operation):
        """
        Function: Match quantizable operation to be quantized.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        is_matched = False
        if operation.type in SHIFT_N_TYPES \
            and operation.name in self.quant_config.keys() \
            and operation.name not in self.skip_layers:
            is_matched = True
        return is_matched

    def do_pass(self, object_op):
        """
        Function: Insert search_n(for output) after object_op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing tensor need to be run to get value
        """
        LOGGER.push_info_message('doing layer:%s insert search_n_quant' %
                                 object_op.name,
                                 module_name='quantize_model')
        layer_context, _ = split_name_scope(object_op.name)
        context = create_context(layer_context, quant_type='search_n')
        # insert search_n
        compute_op = object_op
        compute_out = object_op.outputs[0]
        next_op = get_next_single_op(compute_out.consumers())
        if next_op is not None:
            if GraphChecker.check_biasadd(next_op):
                compute_op = next_op
        cali_scales = InsertSearchNQuantPass.get_calibration_scales(object_op)
        if cali_scales[0] is None:
            raise RuntimeError(
                "Not found %s's QuantIfmr or QuantHfmg" % (object_op.name))
        if cali_scales[1] is None:
            raise RuntimeError(
                "Not found %s's QuantArq or QuantNuq" % (object_op.name))
        quant_kwargs = InsertSearchNQuantPass.gen_searchn_param(
            object_op, cali_scales, self.quant_config)

        search_n_name = InsertSearchNQuantPass.insert_search_n(
            object_op, compute_op, context, quant_kwargs)

        if compute_op.name in self.outputs:
            index = self.outputs.index(compute_op.name)
            self.outputs[index] = search_n_name
        return [], []
