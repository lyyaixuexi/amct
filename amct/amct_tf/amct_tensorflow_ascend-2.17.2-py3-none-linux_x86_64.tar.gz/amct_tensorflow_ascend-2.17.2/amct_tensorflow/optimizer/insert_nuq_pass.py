#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert quant_nuq op for quantizable layer.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import functools
from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.utils import quant_ops
from amct_tensorflow.utils.quant_ops import create_context

from amct_tensorflow.utils.utils_vars import QUANTIZABLE_TYPES
from amct_tensorflow.utils.utils_vars import NO_WEIGHT_QUANT_TYPES
from amct_tensorflow.utils.utils_vars import DUAL_ACTIVATION_QUANT_TYPES
from amct_tensorflow.common.utils import vars_util
from amct_tensorflow.utils.log import LOGGER

_CUSTOM_OP = load()

__all__ = ['InsertNUQPass']


class InsertNUQPass(BaseFusionPass):
    """
    Function: Insert quant_nuq op for quantized layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, quant_config=None, skip_layers=None):
        """
        Function: init object of InsertNUQPass
        Inputs:
            quant_config: a dictionary containing quant config
            skip_layers: a list containing skip quantize layers
        Return: None
        """
        BaseFusionPass.__init__(self)
        if skip_layers is None:
            skip_layers = []
        if quant_config is None:
            quant_config = {}
        self.quant_config = quant_config
        self.skip_layers = skip_layers

    @staticmethod
    def insert_nuq_single_op(object_op, quant_config):
        ''' insert nuq for single op '''
        quant_kwargs = quant_config.get(object_op.name).get('weight_quant_params')
        layer_context, _ = split_name_scope(object_op.name)
        context = create_context(layer_context, quant_type='weight_nuq')
        # insert wts_quant
        _, weight_index = QuantOpInfo.get_quant_index(object_op)
        inputs = object_op.inputs[weight_index]
        weight_shape = inputs.shape
        weight_length = functools.reduce(lambda x, y: x * y, weight_shape)
        if weight_length < quant_kwargs['num_steps']:
            raise RuntimeError(
                "Op {}, nuq do not support weight size less than {}, "
                "but weight shape is {}".format(
                    object_op.name, quant_kwargs['num_steps'], weight_shape))
        quant_kwargs['quant_op_names'] = [object_op.name]
        quant_kwargs['record_file_name'] = quant_config.get('record_file')
        quant_kwargs['num_bits'] = quant_kwargs.get('num_bits', vars_util.INT8_BIT)
        quant_kwargs['with_offset'] = False

        outputs, _ = quant_ops.quant_calibration(
            [inputs, [inputs]], context, 'weight_nuq', quant_kwargs,
            object_op.type)
        quant_ops.relink_tensor(inputs, outputs, object_op)
        LOGGER.push_info_message('doing layer:%s insert weight_quant' %
                                 object_op.name, module_name='InsertNUQPass')

    def match_pattern(self, operation):
        """
        Function: Match quantizable operation to be quantized.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type not in QUANTIZABLE_TYPES \
            or operation.type in NO_WEIGHT_QUANT_TYPES + DUAL_ACTIVATION_QUANT_TYPES:
            return False
        if operation.name not in self.quant_config.keys() or operation.name in self.skip_layers:
            return False
        quant_kwargs = self.quant_config.get(operation.name).get('weight_quant_params')
        # to ensure compatibility, without wts_algo means arq_quantize
        if "wts_algo" not in quant_kwargs.keys():
            return False
        if quant_kwargs['wts_algo'] != 'nuq_quantize':
            return False
        return True

    def do_pass(self, object_op):
        """
        Function: Insert quant_nuq(for weight) before object_op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing tensor need to be run to get value
        """

        InsertNUQPass.insert_nuq_single_op(object_op, self.quant_config)

        return [], []
