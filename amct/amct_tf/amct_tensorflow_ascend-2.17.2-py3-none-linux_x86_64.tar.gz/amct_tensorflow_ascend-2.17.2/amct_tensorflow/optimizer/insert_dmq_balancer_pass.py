#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2023. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert dmq_balancer op for quantizable layer.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.utils import quant_ops
from amct_tensorflow.utils.quant_info_generator import split_name_scope
from amct_tensorflow.utils.quantize_alg import _decorate_enter

from amct_tensorflow.utils.utils_vars import QUANTIZABLE_TYPES
from amct_tensorflow.utils.utils_vars import NO_WEIGHT_QUANT_TYPES
from amct_tensorflow.utils.utils_vars import DUAL_ACTIVATION_QUANT_TYPES
from amct_tensorflow.utils.log import LOGGER

_CUSTOM_OP = load()

__all__ = ['InsertDMQBalancerPass']


class InsertDMQBalancerPass(BaseFusionPass):
    """
    Function: Insert dmq_balancer op for quantized layer.
    APIs: match_pattern, do_pass,
    """
    def __init__(self, quant_config=None):
        """
        Function: init object of InsertDMQBalancerPass
        Inputs:
            quant_config: a dictionary containing quant config
        Return: None
        """
        BaseFusionPass.__init__(self)
        if quant_config is None:
            quant_config = {}
        self.quant_config = quant_config
        self.dmq_balancer_param = 0.5

    def match_pattern(self, operation):
        """
        Function: Match quantizable operation to do dmq_balancer.
        Inputs:
            operation: op to be matched
        Returns:
            True: matched
            False: mismatch
        """
        if operation.type in QUANTIZABLE_TYPES \
            and operation.type not in NO_WEIGHT_QUANT_TYPES + DUAL_ACTIVATION_QUANT_TYPES \
            and operation.name in self.quant_config.keys() \
            and self.quant_config.get(operation.name).get('dmq_balancer_param'):
            self.dmq_balancer_param = self.quant_config.get(operation.name).get('dmq_balancer_param')
            return True
        return False

    def do_pass(self, object_op):
        """
        Function: Insert quant_arq(for weight) before object_op
        Inputs:
            object_op: op to process
        Returns:
            assign_list: a list containing the tensor need to be run to update
                variables.
            run_list: a list containing trensor need to be run to get value
        """
        ''' insert arq for single op '''
        LOGGER.push_info_message('doing layer:%s insert dmq_balancer' %
                                 object_op.name, 'InsertDMQBalancerPass')

        act_index, weight_index = QuantOpInfo.get_quant_index(object_op)
        weight_tensor = object_op.inputs[weight_index]
        if object_op.inputs[act_index].op.type == 'Pad' \
            and len(object_op.inputs[act_index].op.outputs[0].consumers()) == 1:
            act_tensor = object_op.inputs[act_index].op.inputs[0]
        else:
            act_tensor = object_op.inputs[act_index]
        self._insert_dmq_balancer_op(act_tensor, weight_tensor, object_op)

        return [], []


    def _transpose_for_dmq_balancer(self, act_tensor, weight_tensor, object_op):
        """ transpose activation and weight to c-first format """
        act_cin_idx, wgt_cin_idx = QuantOpInfo.get_cin_index(object_op)

        act_perm = list(range(act_tensor.shape.ndims))
        cin_axis = act_perm.pop(act_cin_idx)
        act_perm.insert(0, cin_axis)
        act_trans = tf.compat.v1.transpose(act_tensor, perm=act_perm)

        wgt_perm = list(range(weight_tensor.shape.ndims))
        cin_axis = wgt_perm.pop(wgt_cin_idx)
        wgt_perm.insert(0, cin_axis)
        weight_trans = tf.compat.v1.transpose(weight_tensor, perm=wgt_perm)

        return act_trans, weight_trans


    def _insert_dmq_balancer_op(self, act_tensor, weight_tensor, object_op):
        ''' transpose and insert dmq_balancer op '''
        context = object_op.name
        with tf.compat.v1.variable_scope(None,
                                         default_name="".join([context, '/DMQBalancer']),
                                         values=[weight_tensor],
                                         reuse=None) as scope:
            scope.set_partitioner(None)
            # 1. transpose activation and weight to c-first format
            act_trans, weight_trans = self._transpose_for_dmq_balancer(act_tensor, weight_tensor, object_op)

            # 2. insert dmq_balancer op
            tensor_balance_factor = _CUSTOM_OP.dmq_balancer(
                act_trans,
                weight_trans,
                migration_strength=self.dmq_balancer_param,
                layer_name=object_op.name,
                record_file_path=self.quant_config.get('record_file')
            )
            balance_factor_var = tf.compat.v1.get_variable(
                'tensor_balance_factor',
                shape=[QuantOpInfo.get_cin_length(object_op)],
                dtype=tf.compat.v1.float32,
                trainable=False,
                collections=[
                    tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                    tf.compat.v1.GraphKeys.MODEL_VARIABLES
                ],
                use_resource=False)
            decorated_tensors = _decorate_enter(weight_tensor, balance_factor_var, object_op.name)
            assign_factor = tf.compat.v1.assign(decorated_tensors.quant_var, tensor_balance_factor)

            # 3. add control_dependencies to enable tensor_balance_factor be calculated in calibration phase
            with tf.compat.v1.control_dependencies([assign_factor]):
                wgt_identity = tf.compat.v1.identity(weight_tensor)
            quant_ops.relink_tensor(weight_tensor, wgt_identity, object_op)