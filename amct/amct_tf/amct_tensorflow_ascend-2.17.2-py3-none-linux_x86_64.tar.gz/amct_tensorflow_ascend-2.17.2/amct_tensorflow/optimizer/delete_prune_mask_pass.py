#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert retrain op

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
import tensorflow as tf
from tensorflow.python.framework import tensor_util

from amct_tensorflow.optimizer.base_fusion_pass import BaseFusionPass
from amct_tensorflow.utils.quant_ops import replace_inputs_tensor
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.capacity import CAPACITY
from amct_tensorflow.common.utils.prune_record_attr_util import AttrProtoHelper


class DeletePruneMaskPass(BaseFusionPass):
    """
    Function:
    disconnect Mask ops
    """
    def __init__(self, prune_records, prune_idx=None):
        BaseFusionPass.__init__(self)
        self.prune_records = prune_records
        self.prune_idx = prune_idx

    @staticmethod
    def match_pattern(operation):
        """Function: match prunable ops"""
        if operation.type in (CAPACITY.get_value('PRUNABLE_TYPES') + \
                              CAPACITY.get_value('SELECTIVE_PRUNABLE_TYPES')):
            return True
        return False

    def do_pass(self, object_op):
        """
        Function:
        Reconnect wgt_tensor to prunable op to bypass mask op. Meanwhile,
        collect remain channels stored in bcp op.
        """
        mask_gen_op = find_mask_gen_op(object_op.inputs[1].op)
        selective_mask_gen_op = find_selective_mask_gen_op(object_op.inputs[1].op)
        if not mask_gen_op and not selective_mask_gen_op:
            return [], []
        if mask_gen_op:
            mask_mul_op = mask_gen_op.outputs[0].consumers()[0]
        else:
            mask_mul_op = selective_mask_gen_op.outputs[0].consumers()[0]
        wgt_tensor = mask_mul_op.inputs[0]
        replace_inputs_tensor(wgt_tensor, mask_mul_op.outputs[0], \
            mask_mul_op.outputs[0].consumers())
        LOGGER.push_debug_message(
            "doing layer: delete pruning mask[%s]!" % object_op.name,
            "DeletePruneMaskPass")
        prune_records = self.prune_records.get(object_op.name)
        if prune_records:
            if mask_gen_op:
                collect_filter_prune_info(object_op, mask_gen_op, prune_records, self.prune_idx)
            else:
                collect_selective_prune_info(object_op, selective_mask_gen_op, prune_records)
        return [], []


def collect_filter_prune_info(object_op, mask_gen_op, prune_records, prune_idx):
    """
    Function:
    collect remain channels stored in bcp op
    """
    active_prune_records = prune_records.get('active_prune_record')
    remain_out_channels = find_remain_channels(mask_gen_op, object_op)
    for active_prune_record in active_prune_records:
        for producer in active_prune_record.producer:
            remain_in_channels = register_producer_remain_channels(
                producer, remain_out_channels)
            op_prune_type = AttrProtoHelper(producer).get_attr_value('type')
            if op_prune_type in CAPACITY.get_value('PASSIVE_PRUNABLE_TYPES'):
                continue
            if prune_idx is not None:
                prune_idx[producer.name] = remain_out_channels.astype(np.int).tolist()

        for consumer in active_prune_record.consumer:
            register_consumer_remain_channels(
                consumer, remain_in_channels)
            op_prune_type = AttrProtoHelper(consumer).get_attr_value('type')
            if op_prune_type in CAPACITY.get_value('PASSIVE_PRUNABLE_TYPES') and prune_idx is not None:
                prune_idx[consumer.name] = remain_in_channels.astype(np.int).tolist()


def collect_selective_prune_info(object_op, selective_mask_gen, prune_records):
    """
    Function:
    collect selective prune mask stored in selective_mask_gen op
    """
    selective_prune_records = prune_records.get('selective_prune_record')
    mask = find_selective_mask(selective_mask_gen, object_op)
    register_selective_prune_mask(selective_prune_records.selective_prune, mask)


def register_producer_remain_channels(record, remain_out_channels):
    """
    Function:
    register remain out channels for producers
    """
    attr_helper = AttrProtoHelper(record)
    begin = attr_helper.get_attr_value('begin')
    end = attr_helper.get_attr_value('end')
    remain_out_index = np.where(remain_out_channels[begin:end] == 1)[0]
    attr_helper.set_attr_value(
        'remain_channels', 'INTS', remain_out_index)
    return remain_out_channels[begin:end]


def register_consumer_remain_channels(record, remain_in_channels):
    """
    Function:
    register remain in channels for consumers
    """
    attr_helper = AttrProtoHelper(record)
    remain_in_index = np.where(remain_in_channels == 1)[0]
    attr_helper.set_attr_value(
        'remain_channels', 'INTS', remain_in_index)


def register_selective_prune_mask(record, mask):
    attr_helper = AttrProtoHelper(record)
    pack_uint8 = np.packbits(mask != 0)
    if len(pack_uint8) % 8 != 0:
        pack_uint8 = np.append(pack_uint8, np.zeros(8 - len(pack_uint8) % 8, dtype=np.uint8))
    pack = np.frombuffer(pack_uint8.tobytes(), dtype=np.int64)
    attr_helper.set_attr_value('selective_mask', 'INTS', pack)


def find_remain_channels(mask_gen_op, object_op):
    """
    Function:
    locate bcp op and collect remain in/out channels
    """
    if object_op.type == 'MatMul' and object_op.get_attr('transpose_b'):
        input_tensor = mask_gen_op.inputs[0]
    else:
        input_tensor = mask_gen_op.inputs[1]
    input_tensor = skip_enter(input_tensor)
    if input_tensor.op.type == "Identity":
        const_node_def = input_tensor.op.inputs[0].op.node_def
        binary_array = tensor_util.MakeNdarray(const_node_def.attr['value'].tensor)
    elif input_tensor.op.type == 'BalancedL2Norm':
        output_index = input_tensor.op.outputs.index(input_tensor)
        total_outputs = len(input_tensor.op.outputs)
        input_ind = -(total_outputs-output_index)
        identity_op = skip_enter(input_tensor.op.inputs[input_ind]).op
        const_node_def = identity_op.inputs[0].op.node_def
        binary_array = tensor_util.MakeNdarray(const_node_def.attr['value'].tensor)
    if sum(binary_array) == 0:
        raise RuntimeError("BCP node %s generats 0 remain channels." % (input_tensor.op.name))
    return binary_array


def find_selective_mask(mask_gen_op, object_op):
    """
    Function:
    collect selective prune mask
    """
    input_tensor = mask_gen_op.inputs[2]
    input_tensor = skip_enter(input_tensor)
    const_node_def = input_tensor.op.inputs[0].op.node_def
    binary_array = tensor_util.MakeNdarray(const_node_def.attr['value'].tensor)
    if np.sum(binary_array) == 0:
        raise RuntimeError("SelectiveMaskGen node %s generates no mask." % (mask_gen_op.name))
    return binary_array


def find_mask_gen_op(op):
    """Function: find MaskGen op from prunable op"""
    if op.type == 'MaskGen':
        return op
    mask_gen_op = None
    for input_tensor in op.inputs:
        if not isinstance(mask_gen_op, tf.Operation):
            mask_gen_op = find_mask_gen_op(input_tensor.op)
    return mask_gen_op


def find_selective_mask_gen_op(op):
    """Function: find SelectiveMaskGen op from prunable op"""
    if op.type == 'SelectiveMaskGen':
        return op
    selective_mask_gen_op = None
    for input_tensor in op.inputs:
        if not isinstance(selective_mask_gen_op, tf.Operation):
            selective_mask_gen_op = find_selective_mask_gen_op(input_tensor.op)
    return selective_mask_gen_op


def skip_enter(tensor):
    '''Function: grab tensor out of enter op'''
    weight_in_op = tensor.op
    if weight_in_op.type in ['Enter', 'RefEnter']:
        tensor = weight_in_op.inputs[0]
    return tensor
