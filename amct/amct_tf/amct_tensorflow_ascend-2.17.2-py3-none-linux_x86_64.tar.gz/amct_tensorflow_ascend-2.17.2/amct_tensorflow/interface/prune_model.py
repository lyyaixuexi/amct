#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

the automatic calibration for Tensorflow.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import tensorflow as tf

from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.utils.parse_record_file import RecordFileParser
from amct_tensorflow.common.utils.check_params import check_params
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.optimizer.graph_optimizer import GraphOptimizer
from amct_tensorflow.common.config.config_base import GraphObjects
from amct_tensorflow.configuration.get_layers import OpSelector
from amct_tensorflow.common.retrain_config.retrain_config_base import \
        RetrainConfigBase
from amct_tensorflow.common.utils.files import is_valid_name
from amct_tensorflow.common.utils import files as files_util
from amct_tensorflow.capacity import CAPACITY
from amct_tensorflow.optimizer.replace_add_pass import ReplaceAddPass
from amct_tensorflow.optimizer.replace_bn_pass import ReplaceBNPass
from amct_tensorflow.prune.generate_masked_model import generate_masked_model
from amct_tensorflow.prune.generate_pruned_model import create_reshaped_model
from amct_tensorflow.prune.generate_pruned_model import delete_mask
from amct_tensorflow.utils.graph_utils import GraphUtils
from amct_tensorflow.interface.save_model import cope_inputs
from amct_tensorflow.interface.save_model import save_graph_to_pb

__all__ = ['create_prune_retrain_model', 'save_prune_retrain_model']


def get_configure():
    """
    Function:   Initialise a config object to read pruning configs.
    """
    configure = RetrainConfigBase(
        GraphObjects(graph_querier=OpSelector, graph_checker=GraphChecker),
        CAPACITY)
    return configure


@check_params(graph=tf.compat.v1.Graph,
              outputs=list,
              record_file=str,
              config_defination=(str, type(None)))
def create_prune_retrain_model(graph, outputs, record_file, config_defination):
    """
    Function: Interface of filter prune: According to the pruning
              configuration file, insert mask ops at the specified
              position in the given tf.graph, to achieve unstructured
              filter pruning.
    Inputs:
        graph: a tf.compat.v1.Graph.
        outputs: a list containing the names of outputs of the model.
        record_file: a string, the path of txt file recording relationships
            between the prunable ops.
        config_defination: a string, path of configuration file
    Returns:
        masks are added in the original graph, so no return is needed.
    """
    is_valid_name(record_file, 'record_file')
    record_file = files_util.create_empty_file(record_file, check_exist=True)
    GraphChecker.check_amct_operations(graph)
    configure = get_configure()
    configure.set_ability(enable_retrain=False, enable_prune=True)
    prune_config = {}
    if config_defination is None:
        raise RuntimeError('''Filter Prune has no default config. Please make sure config_defination is provided.''')
    config_defination = os.path.realpath(config_defination)
    configure.create_config_from_proto(
        prune_config,
        graph,
        config_defination)
    disable_outputs(graph, outputs, prune_config)
    optimizer = GraphOptimizer()
    optimizer.add_pass(ReplaceAddPass(outputs=outputs))
    graph = optimizer.do_optimizer(graph)
    generate_masked_model(graph, prune_config, record_file, outputs)


def disable_outputs(graph, outputs, prune_config):
    """
    Function:   check if the given output ops exist in the graph. Meanwhile,
                disable them during pruning.
    """
    for output in outputs:
        try:
            graph.get_operation_by_name(output)
        except KeyError as error:
            raise RuntimeError("%s. Please check output list" % error) from error
        else:
            if prune_config.get(output):
                prune_config[output]['regular_prune_enable'] = False


def preprocess(graph):
    """
    Function:
    prepross the given graph, by replacing addv2 to BiassAdd and
    replacing bulk BN ops to integrated BN op.
    """
    optimizer = GraphOptimizer()
    optimizer.add_pass(ReplaceAddPass())
    optimizer.add_pass(ReplaceBNPass(outputs=None))
    graph = optimizer.do_optimizer(graph)
    return graph


@check_params(pb_model=str, outputs=list, record_file=str, save_path=str)
def save_prune_retrain_model(pb_model, outputs, record_file, save_path):
    """
    Function:   Interface of filter prune: Remove the masks ops added in the graph
                and drop the prunable channels in the graph to achieve structured
                pruning.

    Inputs:
        pb_model: pb model in eval mode with mask ops inserted
        outputs: a list containing the names of outputs of the model.
        record_file: a string, the path of txt file recording relationships
            between the prunable ops.
        save_path: a string, the path of pb model generated by structued pruning.
    Returns:
        output model is saved at the given "save_path", so no return is needed.
    """
    pb_model, record_file, split_save_path = cope_inputs(
        pb_model,
        outputs,
        record_file,
        save_path)
    save_dir, save_prefix = split_save_path
    new_graph = GraphUtils.parse_pb_to_graph(pb_model, outputs)
    record_file = os.path.realpath(record_file)
    preprocessed_graph = preprocess(new_graph)
    pruned_graph = generate_pruned_model(preprocessed_graph, outputs, record_file)

    save_graph_to_pb(pruned_graph, outputs, [save_dir, save_prefix])
    LOGGER.push_info_message("{:*^100s}".format('PRUNE COMPLETE'))


def generate_pruned_model(graph, outputs, record_path, prune_idx=None):
    """
    Function:
    remove mask ops in the given tf.graph. Meanwhile, reshape
    the weight ops to achieve structured filter pruning.

    Inputs:
    graph: graph loaded from masked pb model (eval mode).
    outputs: a list containing the names of outputs of the model.
    record_file: a string, the path of txt file recording relationships between the prunable ops.
    """
    prune_records = parse_record_file(record_path, graph)
    graph = delete_mask(graph, prune_records, outputs, prune_idx)
    pruned_graph = create_reshaped_model(graph, prune_records, outputs)
    return pruned_graph


def parse_record_file(record_path, graph):
    """
    Function:
        parse record proto
    Input:
        record_path: path of record file
        graph: tf.graph
    Return:
        prune_record_dict: a dict containing record info
    """
    record_parser = RecordFileParser(record_path, graph, '', enable_quant=False, enable_prune=True)
    if record_parser.is_records_empty():
        raise RuntimeError(
            "record_file is empty, no layers to be pruned. "
            "Please ensure that the model structure is prunable!"
        )

    prune_record, _ = record_parser.parse()
    prune_record_dict = {}
    for record in prune_record:
        if record.producer:
            if prune_record_dict.get(record.producer[0].name):
                prune_record_dict.get(record.producer[0].name).get(
                    'active_prune_record').append(record)
            else:
                prune_record_dict[record.producer[0].name] = {
                    'active_prune_record':[record]}
        elif record.HasField('selective_prune'):
            prune_record_dict[record.selective_prune.name] = {'selective_prune_record': record}
    return prune_record_dict
