#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Modify graph to 'fake_quant' mode or 'deploy' mode and save it to PB. The
'fake_quant' graph can be used to inference in tensorflow with quantization.
The 'deploy' graph can be transfered to be deployed on the core by OMG Tools.
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.common.utils.check_params import check_params
from amct_tensorflow.utils.quant_info_generator import QuantInfoGenerator
from amct_tensorflow.utils.parse_record_file import RecordFileParser
from amct_tensorflow.utils.fuse_bn import fuse_bn_save_model
from amct_tensorflow.utils.generate_deploy_model import generate_deploy_model
from amct_tensorflow.utils.graph_utils import GraphUtils
from amct_tensorflow.interface.save_model import cope_inputs
from amct_tensorflow.optimizer.graph_optimizer import GraphOptimizer
from amct_tensorflow.interface.save_model import save_graph_to_pb
from amct_tensorflow.optimizer.delete_retrain_pass import DeleteRetrainPass
from amct_tensorflow.optimizer.replace_bn_branch_pass import \
    ReplaceBnbranchPass
from amct_tensorflow.utils.log import LOGGER


_CUSTOM_OP = load()


__all__ = ["save_quant_retrain_model"]


def load_graph(model_name):
    '''inner method'''
    tf.compat.v1.reset_default_graph()
    with tf.compat.v1.io.gfile.GFile(model_name, 'rb') as g_file:
        graph_defination = tf.compat.v1.GraphDef()
        graph_defination.ParseFromString(g_file.read())
        GraphUtils.handle_graph_def(graph_defination)
        tf.compat.v1.import_graph_def(graph_defination, name='')
    graph = tf.compat.v1.get_default_graph()

    return graph


@check_params(pb_model=str, outputs=list, record_file=str, save_path=str)
def save_quant_retrain_model(pb_model, outputs, record_file, save_path):
    """
    Function: Convert a model to models with compression including fakequant
        model and deploy model.
    Inputs:
        pb_model: original model to be converted.
        outputs: a list containing the names of outputs in pb_model.
        record_file: a string, path of file containing the scale and offset.
        save_path: a string, the path where to store model and model's name.
    Returns: None
    """
    LOGGER.push_debug_message('convert_model doing', 'convert_model')
    # check inputs
    pb_model, record_file, split_save_path = cope_inputs(
        pb_model,
        outputs,
        record_file,
        save_path)
    save_dir, save_prefix = split_save_path
    # parse pb_model
    graph = load_graph(pb_model)
    # modify graph and save model to a file in format of pb
    graph = generate_quant_deploy_graph(graph, pb_model, outputs, record_file)
    save_graph_to_pb(graph, outputs, [save_dir, save_prefix])

    QuantInfoGenerator().uninit()


def generate_quant_deploy_graph(graph, pb_model, outputs, record_file, prune_idx=None):
    """
    Function:
    process the graph to deploy model format.

    Inputs:
    graph: tf.graph with amct quantization operations.
    pb_model: str, path to the model with amct quantization operations.
    outputs: a list containing the names of outputs in pb_model.
    record_file: a string, path of file containing the scale and offset.
    prune_idx: dict, {"layer_name"(str): [remained channel after prune](list of 0 or 1)}

    Returns:
    graph: processed graph
    """
    optimizer = GraphOptimizer()

    delete_retrain_pass = DeleteRetrainPass()
    optimizer.add_pass(delete_retrain_pass)
    optimizer.add_pass(ReplaceBnbranchPass(outputs))
    origin_graph = optimizer.do_optimizer(graph)

    # parse record_file
    record_parser = RecordFileParser(record_file, origin_graph, pb_model,
        enable_quant=True, enable_prune=False, prune_idx=prune_idx)
    if record_parser.is_records_empty():
        raise RuntimeError(
            "record_file is empty, no layers to be quantized. "
            "please ensure calibration is finished by checking information!"
        )
    layers_params, _ = record_parser.parse()

    # BN fusion.
    bn_fused_graph, _ = fuse_bn_save_model(origin_graph, outputs, [], True)

    graph = generate_deploy_model(bn_fused_graph, outputs, layers_params)
    return graph
