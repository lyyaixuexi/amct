#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Modify graph to 'deploy' mode and save it to PB. The
'fake_quant' graph can be used to inference in tensorflow with quantization.
The 'deploy' graph can be transfered to be deployed on the core by OMG Tools.
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import functools

import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.common.utils.check_params import check_params
from amct_tensorflow.utils.quant_info_generator import QuantInfoGenerator
from amct_tensorflow.utils.parse_record_file import RecordFileParser
from amct_tensorflow.utils.fuse_bn import fuse_bn_save_model
from amct_tensorflow.utils.generate_deploy_model import generate_deploy_model
from amct_tensorflow.optimizer.replace_bn_branch_pass import \
    ReplaceBnbranchPass
from amct_tensorflow.optimizer.graph_optimizer import GraphOptimizer

from amct_tensorflow.common.utils import files as files_util
from amct_tensorflow.utils.graph_utils import GraphUtils
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.utils.utils_vars import CLUSTER_CENTER
from amct_tensorflow.utils.utils_vars import SHIFT_N_ENABLE

_CUSTOM_OP = load()

DATA_OFFSET_RANGE = [-128, 127]
WEIGHT_OFFSET_RANGE = [0, 0]

__all__ = ["save_model", "cope_inputs", "generate_name",
           "save_graph_to_pb", 'save_model_inner']


@check_params(pb_model=str, outputs=list, record_file=str, save_path=str)
def save_model(pb_model, outputs, record_file, save_path):
    """
    Function: Convert a model to models with compression including fakequant
        model and deploy model.
    Inputs:
        pb_model: original model to be converted.
        outputs: a list containing the names of outputs in pb_model.
        record_file: a string, path of file containing the scale and offset.
        save_path: a string, the path where to store model and model's name.
    Returns: None
    """

    save_model_inner(pb_model, outputs, record_file, save_path)


def save_model_inner(pb_model, outputs, record_file, save_path, on_ascend=False):
    """
    Function: Convert a model to models with compression including fakequant
        model and deploy model.
    Inputs:
        pb_model: original model to be converted.
        outputs: a list containing the names of outputs in pb_model.
        record_file: a string, path of file containing the scale and offset.
        save_path: a string, the path where to store model and model's name.
    Returns: None
    """
    LOGGER.push_debug_message('save_model doing', 'save_model')
    # check inputs
    pb_model, record_file, split_save_path = cope_inputs(
        pb_model, outputs, record_file, save_path)
    save_dir, save_prefix = split_save_path
    # parse pb_model
    origin_graph = GraphUtils.parse_pb_to_graph(pb_model, outputs)
    # preprocess the graph
    optimizer = GraphOptimizer()
    optimizer.add_pass(ReplaceBnbranchPass(outputs))
    optimizer.do_optimizer(origin_graph)

    # check graph
    GraphChecker.check_amct_operations(origin_graph)

    QuantInfoGenerator().init(origin_graph)

    # parse record_file
    record_parser = RecordFileParser(record_file, origin_graph, pb_model)
    if record_parser.is_records_empty():
        raise RuntimeError(
            "record_file is empty, no layers to be quantized. "
            "please ensure calibration is finished by checking information!"
        )

    layers_params, skip_fusion_layers = record_parser.parse(SHIFT_N_ENABLE)
    # save the nuq layers to record file
    record_nuq_layers(layers_params, save_dir)

    # BN fusion.
    bn_fused_graph, _ = fuse_bn_save_model(origin_graph, outputs,
                                           skip_fusion_layers)

    # modify graph and save model to a file in format of pb
    graph = generate_deploy_model(bn_fused_graph, outputs, layers_params, True, on_ascend)

    deploy_model_file = save_graph_to_pb(graph, outputs, [save_dir, save_prefix])
    deploy_graph = GraphUtils.parse_pb_to_graph(deploy_model_file, outputs)
    QuantInfoGenerator().update_graph(deploy_graph)
    QuantInfoGenerator().dump_info_to_json(save_dir, save_prefix)

    QuantInfoGenerator().uninit()


def cope_inputs(pb_model, outputs, record_file, save_path):
    ''' Cope inputs by checking and transforming.'''
    files_util.is_valid_name(pb_model, 'pb_model')
    files_util.is_valid_name(record_file, 'record_file')

    if not outputs:
        raise ValueError("param 'outputs' cannot be empty!")
    for output in outputs:
        if not isinstance(output, str):
            raise ValueError("output should be of type string")

    pb_model = os.path.realpath(pb_model)
    record_file = os.path.realpath(record_file)

    # cope with save_path
    save_dir, save_prefix = files_util.split_save_path(save_path)
    files_util.create_path(save_dir)
    split_save_path = (save_dir, save_prefix)

    return pb_model, record_file, split_save_path


def generate_name(save_path, prefix):
    ''' Generate model's name. '''
    tail = 'quantized.pb'
    name = files_util.concat_name(save_path, prefix, tail)

    return name


def save_graph_to_pb(graph, outputs, save_path):
    """
    Function: Save graph to a model.pb
    Inputs:
        graph: tf.compat.v1.Graph to be converted
        outputs: a list containing the names of outputs in graph.
        save_path: a list containing the path to store model and model's name.
    Return: None
    """
    save_model_file = generate_name(save_path[0], save_path[1])
    with graph.as_default():
        with tf.compat.v1.Session() as session:
            GraphUtils.savetopb(session, outputs, save_model_file)
    return save_model_file


def record_nuq_layers(records, save_dir):
    """ record the nuq layers to file"""
    nuq_layers = []
    for key, value in records.items():
        if CLUSTER_CENTER in value.keys():
            nuq_layers.append(key)
    if len(nuq_layers) == 0:
        LOGGER.push_debug_message('No non uniform quant layer exist in quant config.')
        return
    file_name = os.path.join(save_dir, 'amct_tensorflow_nuq_record.txt')
    line = functools.reduce(lambda x, y: x + ';' + y, nuq_layers)
    files_util.check_files_exist([file_name])
    with open(file_name, 'w') as nuq_record_file:
        nuq_record_file.write(line)
    LOGGER.push_info_message('Create {} non uniform layer record.'.format(file_name))
