#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

the automatic calibration for Tensorflow.

"""


import os
import copy
import json
import shutil
import inspect
from collections import OrderedDict
import tensorflow as tf # pylint: disable=E0401

import amct_tensorflow as amct
from amct_tensorflow.common.auto_calibration.accuracy_based_auto_calibration_base import \
    AccuracyBasedAutoCalibrationBase
from amct_tensorflow.interface.quantize_model import _inner_quantize_model
from amct_tensorflow.common.utils.check_params import check_params
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.optimizer.graph_optimizer import GraphOptimizer
from amct_tensorflow.optimizer.replace_bn_branch_pass import ReplaceBnbranchPass
from amct_tensorflow.utils.quant_info_generator import QuantInfoGenerator
from amct_tensorflow.utils.analyze_layer_output import LayerOutputAnalyzer
from amct_tensorflow.configuration.configuration import Configuration
from amct_tensorflow.utils.fuse_bn import fuse_bn_save_model

from amct_tensorflow.common.auto_calibration.auto_calibration_strategy_base import AutoCalibrationStrategyBase
from amct_tensorflow.common.auto_calibration.binary_search_strategy import BinarySearchStrategy
from amct_tensorflow.common.auto_calibration.cosine_similarity_sensitivity import CosineSimilaritySensitivity
from amct_tensorflow.common.auto_calibration.sensitivity_base import SensitivityBase
from amct_tensorflow.common.auto_calibration.auto_calibration_evaluator_base import AutoCalibrationEvaluatorBase
from amct_tensorflow.common.utils.files import check_files_exist
from amct_tensorflow.common.utils.struct_helper import DumpConfig

__all__ = ['accuracy_based_auto_calibration']


class AccuracyBasedAutoCalibration(AccuracyBasedAutoCalibrationBase): # pylint: disable=R0902
    """The subclass of 'AccuracyBasedAutoCalibrationBase' in Tensorflow.
    """
    def __init__(self, # pylint: disable=R0913,R0902
                 model_file,
                 outputs,
                 record_file,
                 config_file,
                 save_dir,
                 evaluator,
                 strategy,
                 sensitivity):
        AccuracyBasedAutoCalibrationBase.__init__(
            self, record_file, config_file, save_dir, evaluator, strategy, sensitivity)
        self.model_file = os.path.realpath(model_file)
        self.outputs = outputs
        self.original_outputs = copy.deepcopy(outputs)
        self.original_graph = tf.compat.v1.Graph()
        self.quantized_graph = tf.compat.v1.Graph()
        self.group_convs = {}
        with open(self.config_file, 'r') as config_content:
            config = json.load(config_content)
            config['joint_quant'] = False
        self.quantized_layers = self.get_quant_enable_layers(config)

        self.config_file = os.path.join(self.temp_dir, 'accuracy_based_auto_calibration_final_config.json')
        with open(self.config_file, 'w') as config_info:
            config_info.write(json.dumps(config, sort_keys=False, indent=4, separators=(',', ':'), ensure_ascii=False))

    @staticmethod
    def load_graph(model_file, graph):
        """Load tensorflow graph from pb file."""
        with tf.compat.v1.io.gfile.GFile(model_file, mode='rb') as model:
            graph_def = tf.compat.v1.GraphDef()
            graph_def.ParseFromString(model.read())

        with graph.as_default():
            tf.compat.v1.import_graph_def(graph_def, name='')

    def calibration(self):
        """Do calibration"""
        graph = tf.compat.v1.Graph()
        self.load_graph(self.model_file, graph)
        # do calibration and dump at the same time.
        dump_config = DumpConfig(dump_dir=self.temp_dir, batch_num=None)
        _inner_quantize_model(graph, (self.config_file, self.record_file), dump_config, self.outputs)
        if 'batch_num' in inspect.signature(self.evaluator.calibration).parameters:
            with open(self.config_file) as fid:
                quant_config = json.load(fid)
            self.evaluator.calibration(graph=graph, outputs=self.outputs, batch_num=quant_config.get('batch_num'))
        else:
            self.evaluator.calibration(graph, self.outputs)

        self.outputs = copy.deepcopy(self.original_outputs)
        amct.save_model(self.model_file, self.outputs, self.record_file, self.save_dir)
        model_file = ''.join([self.save_dir, '_quantized.pb'])
        return model_file

    def get_original_accuracy(self):
        self.load_graph(self.model_file, self.original_graph)
        original_accuracy = self.evaluator.evaluate(self.original_graph, self.original_outputs)
        return original_accuracy

    def get_global_quant_accuracy(self):
        model_file = self.calibration()
        self.load_graph(model_file, self.quantized_graph)
        global_quant_accuracy = self.evaluator.evaluate(self.quantized_graph, self.outputs)

        roll_back_config = OrderedDict()
        for layer in self.quantized_layers:
            roll_back_config[layer] = True
        record = {
            'roll_back_config': roll_back_config,
            'metric_eval': self.evaluator.metric_eval(self.original_accuracy, global_quant_accuracy)
        }
        self.history_records.append(record)
        return global_quant_accuracy

    def get_ranking_info(self):
        optimizer = GraphOptimizer()
        self.outputs = copy.deepcopy(self.original_outputs)
        optimizer.add_pass(ReplaceBnbranchPass(self.outputs))
        optimizer.do_optimizer(self.original_graph)

        GraphChecker.check_amct_operations(self.original_graph)

        QuantInfoGenerator().init(self.original_graph)

        with open(self.config_file, 'r') as config_file:
            config = json.load(config_file)

        self.original_graph, _ = fuse_bn_save_model(
            self.original_graph, self.outputs, config['skip_fusion_layers'])

        quant_config = Configuration.parse_config_file(self.config_file, self.original_graph)
        self.quantized_layers, self.group_convs = LayerOutputAnalyzer.seprate_group_conv(
            self.original_graph, quant_config, self.quantized_layers)

        analyzer = LayerOutputAnalyzer(
            self.original_graph, self.quantized_graph, self.quantized_layers, self.group_convs, self.temp_dir,
            self.sensitivity)
        ranking_info, _ = analyzer.get_sensitivity()

        return ranking_info

    def roll_back_and_evaluate_model(self, roll_back_config):
        with open(self.config_file, 'r') as config_file:
            config = json.load(config_file)
            for key, value in roll_back_config.items():
                # is group conv, all quant or all not quant
                if key in self.group_convs.keys():
                    group_conv = self.group_convs[key]
                    conv_names = group_conv.get_name("conv_names")
                    for layer_name in conv_names:
                        config[layer_name]['quant_enable'] = value
                else:
                    config[key]['quant_enable'] = value

        with open(self.config_file, 'w') as config_file:
            config_file.write(json.dumps(config, sort_keys=False, indent=4, separators=(',', ':'), ensure_ascii=False))

        model_file = self.calibration()

        graph = tf.compat.v1.Graph()
        self.load_graph(model_file, graph)
        quant_accuracy = self.evaluator.evaluate(graph, self.outputs)
        return quant_accuracy

    def save_final_config(self):
        final_config_file_path = os.path.join(os.path.split(self.save_dir)[0],
            os.path.split(self.config_file)[-1])
        check_files_exist([final_config_file_path])
        shutil.copy(self.config_file, os.path.split(self.save_dir)[0])


@check_params(model_file=str, outputs=list, record_file=str, config_file=str, save_dir=str)
def accuracy_based_auto_calibration(model_file, # pylint: disable=R0913
                                    outputs,
                                    record_file,
                                    config_file,
                                    save_dir,
                                    evaluator,
                                    strategy='BinarySearch',
                                    sensitivity='CosineSimilarity'):
    """
    Function: calibration the input model automatically, decide which
    layers need to roll back and save the final quantized model (fake
    quant and deploy models)

    Parameters:
        model_file (str): The model file with '.pb' suffix.
        outputs (list): A list of strings representing output nodes.
        record_file (str): The scale and offset record file path.
        config_file (str): The quant config json file path.
        save_dir (str): The path where model is saved with prefix.
        evaluator (AutoCalibrationEvaluatorBase): The user implemented
        evaluator instance.
        strategy (union [str, BinarySearchStrategy]): The instance of
        strategy to control the search process, set 'BinarySearch' to
        use default value.
        sensitivity (union [str, CosineSimilaritySensitivity]): The
        instance of sensitivity to measure the quant sensitivity of
        quantable layers, set 'CosineSimilarity' to use default value.
    """
    if strategy == 'BinarySearch':
        strategy = BinarySearchStrategy()
    else:
        if not isinstance(strategy, AutoCalibrationStrategyBase):
            raise RuntimeError("'strategy' is not inherited from base class AutoCalibrationStrategyBase!")

    if sensitivity == 'CosineSimilarity':
        sensitivity = CosineSimilaritySensitivity()
    else:
        if not isinstance(sensitivity, SensitivityBase):
            raise RuntimeError("'sensitivity' is not inherited from base class SensitivityBase!")

    if not isinstance(evaluator, AutoCalibrationEvaluatorBase):
        raise RuntimeError("The model evaluator is not inherited from base class AutoCalibrationEvaluatorBase!")

    auto_calibration_controller = AccuracyBasedAutoCalibration(
        model_file, outputs, record_file, config_file, save_dir, evaluator, strategy, sensitivity)
    auto_calibration_controller.run()
