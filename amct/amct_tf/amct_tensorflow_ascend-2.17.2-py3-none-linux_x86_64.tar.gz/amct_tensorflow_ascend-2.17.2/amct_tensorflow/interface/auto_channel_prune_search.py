#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2022. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

the auto channel prune search for Tensorflow.

"""


import tensorflow as tf
import numpy as np
from tensorflow.python.ops.gradients_impl import gradients
from tensorflow.python.framework import tensor_util

from amct_tensorflow.configuration.get_layers import OpSelector
from amct_tensorflow.capacity import CAPACITY
from amct_tensorflow.graph.graph import Graph
from amct_tensorflow.prune.simplify_graphir import simplify_graph
from amct_tensorflow.prune.generate_masked_model import find_prune_consumers
from amct_tensorflow.utils.quant_op_info import QuantOpInfo

from amct_tensorflow.common.utils.check_params import check_params
from amct_tensorflow.common.auto_channel_prune.auto_channel_prune_config_helper import AutoChannelPruneConfigHelper
from amct_tensorflow.common.auto_channel_prune.auto_channel_prune_search_base import AutoChannelPruneSearchBase
from amct_tensorflow.common.auto_channel_prune.search_channel_base import SearchChannelBase
from amct_tensorflow.common.auto_channel_prune.search_channel_base import GreedySearch
from amct_tensorflow.common.auto_channel_prune.sensitivity_base import SensitivityBase
from amct_tensorflow.common.utils.net_params import ParamsHelper
from amct_tensorflow.utils.net_params import ParamsHelperTf
from amct_tensorflow.graph.node import find_weight_tensor
from amct_tensorflow.common.utils.prune_record_attr_util import AttrProtoHelper

OPT_TYPE = {
    'ApplyAdadelta' : -1,
    'ApplyAdagrad' : -1,
    'ApplyAdagradDA' : -5,
    'ApplyAdam' : -1,
    'ApplyAddSign' : -1,
    'ApplyCenteredRMSProp' : -1,
    'ApplyFtrl' : -5,
    'ApplyFtrlV2' : -5,
    'ApplyGradientDescent' : -1,
    'ApplyMomentum' : -2,
    'ApplyPowerSign' : -1,
    'ApplyProximalAdagrad' : -1,
    'ApplyProximalGradientDescent': -1,
    'ApplyRMSProp' : -1,
    'ResourceApplyAdadelta' : -1,
    'ResourceApplyAdagrad' : -1,
    'ResourceApplyAdagradDA' : -5,
    'ResourceApplyAdam' : -1,
    'ResourceApplyAdamWithAmsgrad' : -1,
    'ResourceApplyAddSign' : -1,
    'ResourceApplyCenteredRMSProp' : -1,
    'ResourceApplyFtr' : -5,
    'ResourceApplyFtrlV2' : -5,
    'ResourceApplyGradientDescent' : -1,
    'ResourceApplyKerasMomentum' : -2,
    'ResourceApplyMomentum' : -2,
    'ResourceApplyPowerSign' : -1,
    'ResourceApplyProximalAdagrad' : -1,
    'ResourceApplyProximalGradientDescent' : -1,
    'ResourceApplyRMSProp' : -1,
    'ResourceSparseApplyAdadelta' : -2,
    'ResourceSparseApplyAdagrad' : -2,
    'ResourceSparseApplyAdagradDA' : -6,
    'ResourceSparseApplyCenteredRMSProp' : -2,
    'ResourceSparseApplyFtrl' : -6,
    'ResourceSparseApplyFtrlV2' : -6,
    'ResourceSparseApplyKerasMomentum' : -3,
    'ResourceSparseApplyMomentum' : -3,
    'ResourceSparseApplyProximalAdagrad' : -2,
    'ResourceSparseApplyProximalGradientDescent' : -2,
    'ResourceSparseApplyRMSProp' : -2,
    'SparseApplyAdadelta' : -2,
    'SparseApplyAdagrad' : -2,
    'SparseApplyAdagradDA' : -6,
    'SparseApplyCenteredRMSProp' : -2,
    'SparseApplyFtrl' : -6,
    'SparseApplyFtrlV2' : -6,
    'SparseApplyMomentum' : -3,
    'SparseApplyProximalAdagrad' : -2,
    'SparseApplyProximalGradientDescent' : -2,
    'SparseApplyRMSProp' : -2,
}


class AutoChannelPruneSearch(AutoChannelPruneSearchBase):
    """ """
    def __init__(self, graph, outputs, input_data, config_helper, sensitivity, output_cfg, search_alg):
        if not input_data:
            raise ValueError("input_data is empty.")
        for feed_dict in input_data:
            if not isinstance(feed_dict, dict):
                raise ValueError("input_data data type error. please make sure input_data contains dict.")
        self.graph = graph
        self.outputs = outputs
        super().__init__(graph, input_data, config_helper, sensitivity, search_alg, output_cfg)

    def get_search_ops(self, graph, prune_config):
        graph_ir = Graph(graph, prune_config, self.outputs)
        simplify_graph(graph_ir)
        record = find_prune_consumers(graph_ir)
        return record.prune_record

    def get_graph_bitops(self, graph, input_data):
        graph_info = {}
        for op in graph.get_operations():
            if op.type == 'Conv2D':
                in_channel, out_channel, bitops = self._cal_conv2d_info(op, graph, input_data)
            elif op.type == 'MatMul':
                in_channel, out_channel, bitops = self._cal_matmul_flops(op, graph, input_data)
            else:
                continue
            graph_info[op.name] = {}
            graph_info.get(op.name)['cin'] = in_channel
            graph_info.get(op.name)['cout'] = out_channel
            graph_info.get(op.name)['ori_cout'] = out_channel
            graph_info.get(op.name)['bitops'] = bitops
        return graph_info

    def _cal_conv2d_info(self, op, graph, input_data):
        output_tensor = self._run_layer(graph, input_data, op.outputs[0])
        output_shape = output_tensor.shape
        if QuantOpInfo.get_data_format(op) == 'NCHW':
            out_channel, out_h, out_w = output_shape[1], output_shape[2], output_shape[3]
        else:
            out_h, out_w, out_channel = output_shape[1], output_shape[2], output_shape[3]
        weight_shape = op.inputs[1].shape.as_list()
        k_h, k_w, in_channel = weight_shape[0], weight_shape[1], weight_shape[2]
        flops = ParamsHelper.calc_conv_flops(in_channel=in_channel,
                                            out_channel=out_channel,
                                            k_h=k_h,
                                            k_w=k_w,
                                            out_h=out_h,
                                            out_w=out_w,
                                            group=1,
                                            has_bias=ParamsHelperTf.has_bias(op))
        flops *= output_shape[0]
        bitops = flops * (op.inputs[0].dtype.size * 8) * (op.inputs[1].dtype.size * 8)
        return in_channel, out_channel, bitops

    def _cal_matmul_flops(self, op, graph, input_data):
        output_shape = self._run_layer(graph, input_data, op.outputs[0]).shape
        input_shape = list(self._run_layer(graph, input_data, op.inputs[0]).shape)
        # modify shape to satisfy [N, C1, C2, ..., M, K] * [N, C1, C2, ..., K, L] = [N, C1, C2, ..., M, L]
        if op.get_attr('transpose_a'):
            input_shape[-2], input_shape[-1] = input_shape[-1], input_shape[-2]
        flops = ParamsHelper.calc_matmul_flops(input_shape, output_shape, has_bias=False)
        flops *= output_shape[0]
        bitops = flops * (op.inputs[0].dtype.size * 8) * (op.inputs[1].dtype.size * 8)
        return input_shape[-1], output_shape[-1], bitops

    def _run_layer(self, graph, input_data, output_tensor):
        with tf.compat.v1.Session(graph=graph) as sess:
            sess.run(tf.compat.v1.global_variables_initializer())
            data_numpy = sess.run(output_tensor, feed_dict=input_data[0])
        return data_numpy


class TaylorLossSensitivity(SensitivityBase):
    """ TaylorLossSensitivity """
    def __init__(self):
        super(TaylorLossSensitivity, self).__init__()
        self.grads = None
        self.weights = None
        self.graph_info = None
        self.graph = None

    def setup_initialization(self, graph_tuple, input_data, test_iteration, output_nodes):
        """
        Function: setup initialization
        Param: graph_tuple (graph, graph_info)
        Return: None
        """
        self.graph, self.graph_info = graph_tuple
        self.grads, self.weights = self.get_backward_grad(input_data, test_iteration, output_nodes)

    def get_sensitivity(self, search_records):
        """
        Function: get sensitivity
        Param: search_records
        Return: None, revise record
        """
        for prune_record in search_records:
            producer_list = []
            ch_info = {}
            for producer in prune_record.producer:
                attr_helper = AttrProtoHelper(producer)
                node_type = attr_helper.get_attr_value('type')
                if node_type not in CAPACITY.get_value('PRUNABLE_TYPES'):
                    continue
                ch_info['begin'] = attr_helper.get_attr_value('begin')
                ch_info['end'] = attr_helper.get_attr_value('end')
                producer_list.append(producer.name)

            consumer_list = []
            for consumer in prune_record.consumer:
                attr_helper = AttrProtoHelper(consumer)
                node_type = attr_helper.get_attr_value('type')
                if node_type not in CAPACITY.get_value('PRUNABLE_TYPES'):
                    continue

                consumer_list.append(consumer.name)

            sensitivity = \
                sum(self.compute_taylor_by_channel(x, ch_info) for x in producer_list) + \
                sum(self.compute_taylor_by_channel(x, ch_info, is_consumer=True) for x in consumer_list)

            attr_helper = AttrProtoHelper(prune_record.producer[0])
            attr_helper.set_attr_value('sensitivity', 'FLOATS', sensitivity.tolist())

    def compute_taylor_by_channel(self, layer_name, ch_info, is_consumer=False):
        """
        Function: compute, taylor
        Param: layer_name, ch_info, is_consumer
        Return: np.array, taylor score by channel
        """
        op = self.graph.get_operation_by_name(layer_name)
        taylor = self.weights.get(layer_name) * self.grads.get(layer_name)
        cin_axis, cout_axis = self._get_channel_idx(op)
        taylor_cut = np.split(taylor, taylor.shape[cout_axis], axis=cout_axis)
        taylor = np.concatenate(taylor_cut[:self.graph_info.get(layer_name).get('cout')], axis=cout_axis)
        taylor_cut = np.split(taylor, taylor.shape[cin_axis], axis=cin_axis)
        taylor = np.concatenate(taylor_cut[:self.graph_info.get(layer_name).get('cin')], axis=cin_axis)

        sum_axis = len(self.weights.get(layer_name).shape)
        ch_axis = sum_axis + cin_axis if is_consumer else sum_axis + cout_axis
        dims = [axis for axis in range(sum_axis) if axis != ch_axis]
        norm_dims = [0 if dim < ch_axis else -1 for dim in dims]
        for norm_dim in norm_dims:
            taylor = np.linalg.norm(taylor, axis=norm_dim)
        taylor_arr = taylor if is_consumer else taylor[ch_info.get('begin') : ch_info.get('end')]
        return taylor_arr

    def get_backward_grad(self, input_data, test_iteration, output_nodes):
        """
        Function: feed data, foward and backward, get backward grad
        Param: input_data, test_iteration, output_nodes
        Return: grads, weights
        """
        if len(input_data) < test_iteration:
            raise RuntimeError('insufficient input data for testing : ' + str(test_iteration))

        with tf.compat.v1.Session(graph=self.graph) as sess:
            init = tf.compat.v1.global_variables_initializer()
            sess.run(init)
            for i in range(test_iteration):
                sess.run(output_nodes, feed_dict=input_data[i])

        grads_collection = {}
        wts_collection = {}
        with tf.compat.v1.Session(graph=self.graph) as sess:
            init = tf.compat.v1.global_variables_initializer()
            sess.run(init)
            for op_name in self.graph_info.keys():
                op = self.graph.get_operation_by_name(op_name)
                weight_in_tensor = op.inputs[1]
                weight_tensor, _ = find_weight_tensor(
                    weight_in_tensor,
                    [op.name, weight_in_tensor.op.name])

                readable_wts = self._get_readable_wts_tensor(weight_tensor)
                optimize_type = weight_tensor.op.outputs[0].consumers()[-1].type
                optimize_idx = OPT_TYPE.get(optimize_type, -1)
                grad_tensor = weight_tensor.op.outputs[0].consumers()[-1].inputs[optimize_idx]
                wts_collection[op_name], grads_collection[op_name] = \
                    sess.run([readable_wts, grad_tensor], feed_dict=input_data[0])

        return grads_collection, wts_collection

    def _get_readable_wts_tensor(self, weight_tensor):
        if weight_tensor.dtype == tf.resource:
            for consumer in weight_tensor.consumers():
                if consumer.type == 'ReadVariableOp':
                    return consumer.outputs[0]

        return weight_tensor

    def _get_channel_idx(self, op):
        if op.type == 'MatMul':
            if op.get_attr('transpose_b'):
                cin = -1
                cout = -2
            else:
                cin = -2
                cout = -1
        elif op.type == 'Conv2D':
            cin = -2
            cout = -1
        return cin, cout


@check_params(graph=tf.compat.v1.Graph,
              output_nodes=list,
              config=str,
              input_data=list,
              output_cfg=str,
              sensitivity=(str, SensitivityBase),
              search_alg=(str, SearchChannelBase))
def auto_channel_prune_search(graph, output_nodes, config, input_data, output_cfg,
                              sensitivity='TaylorLossSensitivity', search_alg='GreedySearch'):
    """ Auto search quant bit for a model based calibration.

    Args:
        graph (tf.compat.v1.Graph): model to be processed, should be a training graph containing backprop ops.
        output_nodes (list of string): model's outputs.
        config (string): file from AutoChannelPruneConfig, indicating how to do search.
        input_data (list of dict of data): feed dict for calibration.
        output_cfg (string): path of output channel prune config file.
        sensitivity (union [str, SensitivityBase]): the way to measure the quant sensitivity.
        search_alg (union [str, SearchChannelBase]): algorithm to do search.
    """
    config_helper = AutoChannelPruneConfigHelper(graph, config, OpSelector, CAPACITY)
    if not output_nodes:
        raise ValueError("output_nodes is empty.")
    if isinstance(search_alg, str):
        if search_alg == 'GreedySearch':
            search_alg = GreedySearch()
        else:
            raise ValueError("search_alg not support.")
    if isinstance(sensitivity, str):
        if sensitivity == 'TaylorLossSensitivity':
            sensitivity = TaylorLossSensitivity()
        else:
            raise ValueError("sensitivity not support.")
    amc = AutoChannelPruneSearch(graph, output_nodes, input_data, config_helper, sensitivity, output_cfg, search_alg)
    amc.run(input_data, output_nodes)