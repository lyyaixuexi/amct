#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Modify graph to 'fake_quant' mode or 'deploy' mode and save it to PB.
The 'fake_quant' graph can be used to inference in tensorflow with
quantization. The 'deploy' graph can be transfered to be deployed on the
core by OMG Tools.
"""


from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os

import amct_tensorflow
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.common.utils.check_params import check_params
from amct_tensorflow.common.utils.log_base import LOG_FILE_DIR
from amct_tensorflow.utils.quant_info_generator import QuantInfoGenerator
from amct_tensorflow.utils.parse_record_file import ConvertModelRecordFileParser
from amct_tensorflow.utils.fuse_bn import fuse_bn_convert_model
from amct_tensorflow.utils.generate_deploy_model import generate_deploy_model
from amct_tensorflow.interface.save_model import cope_inputs
from amct_tensorflow.interface.save_model import save_graph_to_pb
from amct_tensorflow.utils.graph_utils import GraphUtils
from amct_tensorflow.optimizer.delete_identity_pass import DeleteIdentityPass
from amct_tensorflow.optimizer.graph_optimizer import GraphOptimizer
from amct_tensorflow.optimizer.replace_add_pass import ReplaceAddPass
from amct_tensorflow.optimizer.adjust_add_position import AdjustAddPosition
from amct_tensorflow.optimizer.replace_bn_branch_pass import ReplaceBnbranchPass
from amct_tensorflow.common.utils.record_file_operator import ScaleOffsetRecordHelper
from amct_tensorflow.optimizer.delete_fake_quant_pass import DeleteFakeQuantPass
from amct_tensorflow.proto import scale_offset_record_pb2

from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.common.utils import vars_util


DATA_OFFSET_RANGE = [-128, 127]
WEIGHT_OFFSET_RANGE = [0, 0]

__all__ = ["convert_model", "convert_qat_model"]


@check_params(pb_model=str, outputs=list, record_file=str, save_path=str)
def convert_model(pb_model, outputs, record_file, save_path):
    """
    Convert a model to models with compression including fakequant model
    and deploy model.

    Args:
        pb_model (str): original model to be converted.
        outputs (list): a list containing the names of outputs in
        pb_model.
        record_file (str): a string, path of file containing the scale
        and offset.
        save_path (str): a string, the path where to store model and
        model's name.
    """
    LOGGER.push_debug_message('convert_model doing', 'convert_model')
    # check inputs
    pb_model, record_file, split_save_path = cope_inputs(
        pb_model, outputs, record_file, save_path)
    save_dir, save_prefix = split_save_path

    # parse pb_model
    origin_graph = GraphUtils.parse_pb_to_graph(pb_model, outputs)
    # preprocess the graph
    optimizer = GraphOptimizer()
    optimizer.add_pass(ReplaceBnbranchPass(outputs))
    optimizer.do_optimizer(origin_graph)
    # check graph
    GraphChecker.check_amct_operations(origin_graph)

    QuantInfoGenerator().init(origin_graph)

    # parse record_file
    record_parser = ConvertModelRecordFileParser(
        record_file, origin_graph, pb_model)
    if record_parser.is_records_empty():
        raise RuntimeError("record_file is empty, no layers to be quantized.")
    layers_params, skip_fusion_layers = record_parser.parse(False)

    # BN fusion.
    bn_fused_graph, _ = fuse_bn_convert_model(origin_graph, outputs,
                                              layers_params,
                                              skip_fusion_layers)
    # modify graph and save model to a file in format of pb
    graph = generate_deploy_model(bn_fused_graph, outputs, layers_params)

    deploy_model_file = save_graph_to_pb(graph, outputs, [save_dir, save_prefix])
    graph = GraphUtils.parse_pb_to_graph(deploy_model_file, outputs)
    QuantInfoGenerator().update_graph(graph)
    QuantInfoGenerator().dump_info_to_json(save_dir, save_prefix)

    QuantInfoGenerator().uninit()


@check_params(pb_model=str, outputs=list, save_path=str, record_file=(type(None), str))
def convert_qat_model(pb_model, outputs, save_path, record_file=None):
    """
    Convert TensorFlow QAT model to Ascend model.

    Args:
        pb_model (str): a string of model file path.
        outputs (list): a list of output nodes name.
        save_path (str): a string of save path.
        record_file (str): a string of record file path.

    Returns:
        list: a list of output nodes name.
    """
    if record_file is None:
        record_file = os.path.join(LOG_FILE_DIR, 'scale_offset_record.txt')
    os.makedirs(os.path.split(record_file)[0], exist_ok=True)

    LOGGER.push_debug_message('convert_qat_model doing')
    pb_model, record_file, split_save_path = cope_inputs(pb_model, outputs, record_file, save_path)
    save_dir, save_prefix = split_save_path

    origin_graph = GraphUtils.parse_pb_to_graph(pb_model, outputs)
    record_helper = ScaleOffsetRecordHelper(scale_offset_record_pb2.ScaleOffsetRecord)

    GraphChecker.check_amct_operations(origin_graph)

    optimizer = GraphOptimizer()
    optimizer.add_pass(ReplaceBnbranchPass(outputs))
    optimizer.add_pass(DeleteFakeQuantPass(record_helper, outputs))
    optimizer.add_pass(DeleteIdentityPass(outputs=outputs))
    optimizer.add_pass(AdjustAddPosition())
    optimizer.add_pass(ReplaceAddPass(is_replace=True, outputs=outputs))
    graph = optimizer.do_optimizer(origin_graph)

    record_helper.dump(record_file)

    QuantInfoGenerator().init(graph)

    record_parser = ConvertModelRecordFileParser(record_file, graph, pb_model)
    if record_parser.is_records_empty():
        save_graph_to_pb(graph, outputs, [save_dir, save_prefix])
        return outputs

    layers_params, _ = record_parser.parse(False)

    graph = amct_tensorflow.utils.generate_deploy_model.generate_deploy_model(
        graph, outputs, layers_params, vars_util.INT8_BIT)

    QuantInfoGenerator().update_graph(graph)
    QuantInfoGenerator().dump_info_to_json(save_dir, save_prefix)

    save_graph_to_pb(graph, outputs, [save_dir, save_prefix])

    QuantInfoGenerator().uninit()

    return outputs
