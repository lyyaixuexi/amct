#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

generate approximate tf graph.

"""


from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

from amct_tensorflow.common.utils.check_params import check_params
from amct_tensorflow.configuration.configuration import Configuration
from amct_tensorflow.optimizer.graph_optimizer import GraphOptimizer
from amct_tensorflow.optimizer.delete_dump_pass import DeleteDumpPass
from amct_tensorflow.optimizer.replace_softmax_pass import ReplaceSoftmaxPass
from amct_tensorflow.common.utils import files as files_util
from amct_tensorflow.utils.graph_utils import GraphUtils


def remove_side_effect_of_approx_cali(graph):
    """
    Function: Remove side effect of API: create_approximation_calibrator.
              Include: delete dump op
    Inputs:
        graph: a tf.compat.v1.Graph.
    Returns:
        graph: a tf.compat.v1.Graph.
    """
    optimizer = GraphOptimizer()
    optimizer.add_pass(DeleteDumpPass())
    graph = optimizer.do_optimizer(graph)
    return graph


def replace_approximate_op(graph, config, outputs):
    """
    Function: Replace op with approximate implementation.
    Inputs:
        graph: a tf.compat.v1.Graph.
        config: a dict, approximate config.
        outputs: a list containing the names of outputs in pb_model.
    Returns:
        graph: a tf.compat.v1.Graph.
    """
    optimizer = GraphOptimizer()
    optimizer.add_pass(ReplaceSoftmaxPass(config, outputs))
    graph = optimizer.do_optimizer(graph)
    return graph


def save_appro_graph_impl(graph,
                          outputs,
                          save_path,
                          approx_config):
    """
    Function: Interface of op approximation. Delete dump op, calibrate on dump
              data, replace op with approximate implementation.
    Inputs:
        graph: a tf.compat.v1.Graph.
        outputs: a list containing the names of outputs in pb_model.
        save_path: a string, the path where to store model and model's name.
        approx_config: a dict, approximate config
    Returns:
        None
    """
    # cope with outputs
    if not outputs:
        raise ValueError("param 'outputs' cannot be empty!")
    for output in outputs:
        if not isinstance(output, str):
            raise ValueError("output should be of type string")

    graph = replace_approximate_op(graph, approx_config, outputs)
    graph = remove_side_effect_of_approx_cali(graph)

    # save approximation pb
    save_dir, save_prefix = files_util.split_save_path(save_path)
    files_util.create_path(save_dir)
    save_model_file = files_util.concat_name(save_dir, save_prefix, 'approximation.pb')
    with graph.as_default():
        with tf.compat.v1.Session() as session:
            GraphUtils.savetopb(session, outputs, save_model_file)
    return save_model_file


@check_params(graph=tf.compat.v1.Graph,
              outputs=list,
              save_path=str,
              config_defination=(str, type(None)))
def save_approximation_graph(graph,
                             outputs,
                             save_path,
                             config_defination=None):
    """
    Function: Interface of op approximation. Delete dump op, calibrate on dump
              data, replace op with approximate implementation.
    Inputs:
        graph: a tf.compat.v1.Graph.
        outputs: a list containing the names of outputs in pb_model.
        save_path: a string, the path where to store model and model's name.
        config_defination: a string, path of configuration file
    Returns:
        None
    """
    approx_config = Configuration.create_appoximate_config(graph, config_defination=config_defination)
    save_appro_graph_impl(graph, outputs, save_path, approx_config)
