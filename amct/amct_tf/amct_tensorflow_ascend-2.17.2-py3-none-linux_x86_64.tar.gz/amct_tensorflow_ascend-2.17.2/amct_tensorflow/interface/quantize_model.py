#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quantitative subject control module.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.utils import fuse_bn
from amct_tensorflow.configuration.configuration import Configuration
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.common.utils.files import is_valid_name
from amct_tensorflow.common.utils.check_params import check_params
from amct_tensorflow.common.config.config_base import check_config_dmq_balancer
from amct_tensorflow.utils.parse_record_file import RecordFileParser

from amct_tensorflow.common.utils import files as files_util
from amct_tensorflow.utils.utils_vars import ACT_CALI
from amct_tensorflow.utils.utils_vars import WTS_CALI
from amct_tensorflow.utils.utils_vars import SEARCH_N

import amct_tensorflow.optimizer as opt
from amct_tensorflow.optimizer.graph_optimizer import GraphOptimizer


__all__ = ['quantize_model', 'preprocess_quantize_model']


@check_params(graph=tf.compat.v1.Graph, config_file=str, record_file=str, calib_outputs=(list, type(None)))
def quantize_model(graph, config_file, record_file, calib_outputs=None):
    """
    Function: Quantization input model: According to the quantization
              configuration file, insert quantization op at the specified
              position of tf.compat.v1.Graph.
    Inputs:
        graph: a tf.compat.v1.Graph.
        config_file: a string, Name of quantized configuration file (including
                   path information).
        record_file: a string, the name of file recording quantization factor.
        calib_outputs: a list containing the names of outputs in pb_model.
    Returns:
        quant_add_ops: a list, quantify the list of variables added.
    """
    if calib_outputs is not None:
        for calib_output in calib_outputs:
            try:
                graph.get_operation_by_name(calib_output)
            except (TypeError, KeyError) as e:
                raise KeyError(
                    'The output node[{}] is not in the graph, please check whether ' \
                    'the node name is correct (without :0)'.format(calib_output)) from e
    quant_add_ops = _inner_quantize_model(graph, (config_file, record_file), outputs=calib_outputs)

    return quant_add_ops


def _inner_quantize_model(graph, # pylint: disable=R0913
                          files,
                          dump_config=None,
                          outputs=None,
                          weight_fakequant=True):
    """
    Function: Quantization input model: According to the quantization
              configuration file, insert quantization op at the specified
              position of tf.compat.v1.Graph.
    param:dump_config, DumpConfig
    """
    config_file, record_file = files
    is_valid_name(config_file, 'config_file')
    is_valid_name(record_file, 'record_file')
    config_file = os.path.realpath(config_file)
    if not os.path.exists(config_file):
        raise OSError('file (%s) does not exist!' % config_file)

    with graph.as_default():
        original_ops = tf.compat.v1.global_variables()

        # preprocess the before quantize
        graph, quant_config = preprocess_quantize_model(
            graph, outputs, config_file)
        # get records if config indicates dmq_balancer
        records = get_balance_factor_records(graph, quant_config, record_file)

        # BN fusion.
        graph, _ = fuse_bn.fuse_bn_quantize_model(
            graph, quant_config.get('do_fusion'),
            quant_config.get('skip_fusion_layers'), record_file, outputs)

        dmq_balancer_layers_flag = []
        quantized_layers_flag = {
            ACT_CALI: [],
            WTS_CALI: [],
            SEARCH_N: [],
        }

        # quantify models through high-performance or high-accuracy models.
        quant_config['record_file'] = record_file
        mode = 'cali' if dump_config is None else 'cali_dump'
        optimizer = GraphOptimizer()
        optimizer.add_pass(opt.GroupConvApplyDMQBalancerPass(quant_config=quant_config,
                                                          records=records,
                                                          skip_layers=dmq_balancer_layers_flag))
        optimizer.add_pass(opt.ApplyDMQBalancerPass(quant_config=quant_config,
                                                    records=records,
                                                    skip_layers=dmq_balancer_layers_flag))
        optimizer.add_pass(opt.GroupConvInsertCaliPass(quant_config=quant_config, skip_layers=quantized_layers_flag,
                                                       dump_config=dump_config, mode=mode,
                                                       weight_fakequant=weight_fakequant))
        if quant_config.get('joint_quant'):
            optimizer.add_pass(opt.EltwiseInsertCaliPass(quant_config=quant_config,
                                                         skip_layers=quantized_layers_flag,
                                                         weight_fakequant=weight_fakequant))
        optimizer.add_pass(opt.InsertActCaliPass(quant_config=quant_config,
                                                 skip_layers=quantized_layers_flag.get(ACT_CALI),
                                                 dump_config=dump_config, mode=mode))
        optimizer.add_pass(opt.InsertARQPass(quant_config=quant_config,
                                             skip_layers=quantized_layers_flag.get(WTS_CALI),
                                             weight_fakequant=weight_fakequant))
        optimizer.add_pass(opt.InsertNUQPass(quant_config=quant_config, 
                                             skip_layers=quantized_layers_flag.get(WTS_CALI)))
        optimizer.add_pass(opt.InsertSearchNQuantPass(quant_config=quant_config,
                                                      skip_layers=quantized_layers_flag.get(SEARCH_N),
                                                      outputs=outputs))

        graph = optimizer.do_optimizer(graph)

        optimizer = GraphOptimizer()
        optimizer.add_pass(opt.ReplaceSearchnPass())
        graph = optimizer.do_optimizer(graph)

        quant_add_ops = list(
            set(tf.compat.v1.global_variables()) - set(original_ops))

        return quant_add_ops


def get_balance_factor_records(graph, quant_config, record_file):
    """
    Function: get records if config indicates dmq_balancer
    Inputs:
        graph: a tf.compat.v1.Graph.
        quant_config: a dict, quant config parsed from config_file.
        record_file: a string, the name of file recording quantization factor.
    Returns:
        records: a dict
    """
    tensor_balance_enable = False
    for key, _ in quant_config.items():
        if not isinstance(quant_config[key], dict):
            continue
        if quant_config[key].get("dmq_balancer_param"):
            tensor_balance_enable = True
            break
    if tensor_balance_enable:
        if os.path.exists(record_file):
            record_parser = RecordFileParser(record_file, graph, 'quantize_graph')
        if not os.path.exists(record_file) or record_parser.is_records_empty():
            raise RuntimeError(
                "config_file indicates dmq_balancer, but record_file is empty. "
                "please check quant_preprocess and calibration is done!"
            )
        return record_parser.parse().layers_params
    else:
        record_file = files_util.create_empty_file(record_file, check_exist=True)
        return {}


def preprocess_quantize_model(graph, outputs, config_file):
    """
    Function: Preprocess the graph for quantize_model
    Inputs:
        graph: a tf.compat.v1.Graph.
        layers_name: a list, layers to be quantized.
    Returns:
        quant_config: a dict, quant config
    """
    # preprocess the graph
    optimizer = GraphOptimizer()
    optimizer.add_pass(opt.ReplaceBnbranchPass(outputs))
    graph = optimizer.do_optimizer(graph)

    # check ops of amct
    GraphChecker.check_amct_operations(graph)

    # parsing the quantization profile
    quant_config = Configuration.parse_config_file(config_file, graph)
    layers_name = Configuration.get_layers_name(quant_config)

    GraphChecker.check_quantize_placeholder(graph, layers_name)

    return graph, quant_config


def add_dump_operations(graph, config_file, dump_config, outputs):
    """ Add dump for quant layers in graph. After runind the model, the quant layers' input featuremap is dump to bin.

    Args:
        graph (tf.Graph): the graph to add dump operations.
        config_file (string): the quant config json file, indicating which layers to add dump.
        dump_config (DumpConfig): the config for dump data
        outputs (list of string): graph's outputs.
    """
    with graph.as_default():
        # parse the quant_config
        graph, quant_config = preprocess_quantize_model(
            graph, outputs, config_file)
        # add dump operation by data calibration process.
        quantized_layers_flag = {
            ACT_CALI: [],
            WTS_CALI: [],
            SEARCH_N: [],
        }

        optimizer = GraphOptimizer()
        optimizer.add_pass(
            opt.GroupConvInsertCaliPass(quant_config=quant_config,
                                        skip_layers=quantized_layers_flag,
                                        dump_config=dump_config,
                                        mode='dump'))
        optimizer.add_pass(opt.InsertActCaliPass(
            quant_config=quant_config, skip_layers=quantized_layers_flag.get(ACT_CALI),
            dump_config=dump_config, mode='dump'))
        graph = optimizer.do_optimizer(graph)


def disable_dmq_balancer_for_shared_wts(graph, quant_config):
    """ Function:
        remove dmq_balancer_param from quant_config if layer's weight is shared weight.
    """
    layers_name = Configuration.get_layers_name(quant_config)
    shared_weight = GraphChecker.get_shared_weights(graph, quant_config, layers_name)
    for shared_weight_layers in shared_weight.values():
        if len(shared_weight_layers) == 1:
            continue
        for layer in shared_weight_layers:
            quant_config.get(layer).pop('dmq_balancer_param')


@check_params(graph=tf.compat.v1.Graph, config_file=str, record_file=str, outputs=(list, type(None)))
def quantize_preprocess(graph, config_file, record_file, outputs=None):
    """
    Function: Quantization input model: According to the quantization
              configuration file, insert dmq_balancer op at the specified
              position of tf.compat.v1.Graph.
    Inputs:
        graph: a tf.compat.v1.Graph.
        config_file: a string, Name of quantized configuration file (including
                   path information).
        record_file: a string, the name of file recording quantization factor.
        outputs: a list containing the names of outputs in pb_model.
    Returns:
        None
    """
    if outputs is not None:
        for calib_output in outputs:
            try:
                graph.get_operation_by_name(calib_output)
            except (TypeError, KeyError) as e:
                raise KeyError(
                    'The output node[{}] is not in the graph, please check whether ' \
                    'the node name is correct (without :0)'.format(calib_output)) from e
    is_valid_name(config_file, 'config_file')
    is_valid_name(record_file, 'record_file')
    config_file = os.path.realpath(config_file)
    if not os.path.exists(config_file):
        raise OSError('file (%s) does not exist!' % config_file)
    record_file = files_util.create_empty_file(record_file, check_exist=True)

    with graph.as_default():
        # preprocess the graph before quantize
        graph, quant_config = preprocess_quantize_model(
            graph, outputs, config_file)

        # check dmq_balancer config
        check_config_dmq_balancer(quant_config)
        disable_dmq_balancer_for_shared_wts(graph, quant_config)
        quant_config['record_file'] = record_file

        # BN fusion.
        graph, _ = fuse_bn.fuse_bn_quantize_model(
            graph, quant_config.get('do_fusion'),
            quant_config.get('skip_fusion_layers'), record_file, outputs)

        # insert dmq_balancer op
        optimizer = GraphOptimizer()
        optimizer.add_pass(opt.InsertDMQBalancerPass(quant_config))
        graph = optimizer.do_optimizer(graph)
