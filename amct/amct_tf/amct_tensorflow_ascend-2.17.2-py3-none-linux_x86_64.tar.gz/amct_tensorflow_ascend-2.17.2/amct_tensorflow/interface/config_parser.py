#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

create quantize config file and parse config file.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.configuration.configuration import Configuration
from amct_tensorflow.common.utils.check_params import check_params
from amct_tensorflow.common.utils.files import is_valid_name

__all__ = ['create_quant_config']


@check_params(config_file=str,
              graph=tf.compat.v1.Graph,
              skip_layers=(list, type(None)),
              batch_num=int,
              activation_offset=bool,
              config_defination=(str, type(None)))
def create_quant_config(config_file, # pylint: disable=too-many-arguments
                        graph,
                        skip_layers=None,
                        batch_num=1,
                        activation_offset=True,
                        config_defination=None):
    '''
    create config file to use in quantize_model.
    Inputs:
        config_file: a string, name to save quantized configuration file
            (including path information).
        graph: a tf.compat.v1.Graph.
        skip_layer_types: a list, type of layers would not apply quantize, the
            type should be in ['Conv2D', 'MatMul', 'DepthwiseConv2dNative'].
        skip_layers: a list, layer names which would not apply quantize, the
            skip layer type should be in ['Conv2D', 'MatMul',
            'DepthwiseConv2dNative'].
        batch_num: an integer, indicate how many batch of data are used
            for calibration.
        activation_offset: whether activation quantize with offset
        config_defination: proto quant config, if this parameter exists,
            [skip_layers, batch_num, activation_offset] will be ignored.
    Returns: None
    '''
    is_valid_name(config_file, 'config_file')
    config_file = os.path.realpath(config_file)
    GraphChecker.check_amct_operations(graph)

    config_param = (batch_num, activation_offset)
    Configuration.create_quant_config(config_file, graph, skip_layers,
                                      config_param, config_defination)
