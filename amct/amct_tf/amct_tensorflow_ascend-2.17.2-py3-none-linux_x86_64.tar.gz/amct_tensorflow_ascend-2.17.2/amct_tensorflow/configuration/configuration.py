#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Create quantize config file and parse config file.

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.configuration.get_layers import OpSelector
from amct_tensorflow.pattern.match_group_conv import get_all_group_conv_sub_convs

from amct_tensorflow.common.config.config_base import GraphObjects
from amct_tensorflow.common.config.config_base import ConfigBase
from amct_tensorflow.common.config.config_base import check_config_quant_enable
from amct_tensorflow.common.utils.check_params import check_params
from amct_tensorflow.capacity import CAPACITY


def get_configurer():
    '''Get Configure from the latest CAPACITY  '''
    graph_tools = GraphObjects(graph_querier=OpSelector, graph_checker=GraphChecker)
    return ConfigBase(graph_tools, CAPACITY)


def get_approximate_configurer():
    '''Get Configure from the latest CAPACITY '''
    graph_tools = GraphObjects(graph_querier=OpSelector, graph_checker=GraphChecker)
    return ConfigBase(graph_tools, CAPACITY, enable_quant=False, enable_approximate=True)


class Configuration: # pylint: disable=attribute-defined-outside-init
    """
    Function: manage configuration of project including quant_config
              and record_file.
    APIs: get_quant_config, get_layer_config, get_record_file_path;
        create_quant_config, parse_quant_config
    """
    @staticmethod
    @check_params(config_file=str,
                  graph=tf.compat.v1.Graph,
                  skip_layers=(list, type(None)),
                  config_param=tuple,
                  config_defination=(str, type(None)))
    def create_quant_config(  # pylint: disable=too-many-arguments
            config_file,
            graph,
            skip_layers=None,
            config_param=(1, True),
            config_defination=None):
        '''
        Function: Create quant config.
        Inputs:
            config_file: a string, name to save quantized configuration file
                (including path information).
            graph: a tf.compat.v1.Graph.
            skip_layer_types: a list, type of layers would not apply quantize, the
                type should be in ['Conv2D', 'MatMul', 'DepthwiseConv2dNative'].
            skip_layers: a list, layer names which would not apply quantize, the
                skip layer type should be in ['Conv2D', 'MatMul',
                'DepthwiseConv2dNative'].
            config_param: a tuple, consists of
                - batch_num: an integer, indicate how many batch of data are used
                for calibration.
                - activation_offset: whether activation quantize with offset
            config_defination: proto quant config, if this parameter exists,
                [skip_layers, batch_num, activation_offset] will be ignored.
        Returns: None
        '''
        if skip_layers is None:
            skip_layers = []

        batch_num, activation_offset = config_param
        configure = get_configurer()
        if config_defination is None:
            configure.create_quant_config(
                config_file, graph, skip_layers, batch_num, activation_offset)
        else:
            config_defination = os.path.realpath(config_defination)
            configure.create_config_from_proto(
                config_file, graph, config_defination)

    @staticmethod
    @check_params(config_file=str, graph=tf.compat.v1.Graph)
    def parse_config_file(config_file, graph):
        '''
        parse config file, check incorrect value, and fill default value.
        Inputs:
            config_file: a string, name of quantized configuration file (including
                       path information).
            graph: a tf.compat.v1.Graph.
        Returns:
            quant_config: a dict saved quant config.
        '''
        if not os.path.exists(config_file):
            raise OSError('file (%s) does not exist!' % config_file)
        configure = get_configurer()
        quant_config = configure.parse_config_file(config_file, graph)
        check_config_quant_enable(quant_config)

        group_convs = get_all_group_conv_sub_convs(graph)
        for item in quant_config:
            if not isinstance(quant_config[item], dict):
                continue
            quant_kwargs = quant_config[item]['weight_quant_params']
            check_op = graph.get_operation_by_name(item)
            if 'wts_algo' in quant_kwargs and quant_kwargs['wts_algo'] == 'nuq_quantize':
                if check_op.type == 'Conv2D':
                    if check_op.name in group_convs:
                        raise ValueError(
                            "operation {} is group conv, now nuq do not support group conv".format(check_op.name))
                    # dilation is 1
                    dilations = check_op.get_attr('dilations')
                    if not set(dilations) == set([1]):
                        raise ValueError(
                            "operation {} dilation != 1 , now only support dilation == 1".format(check_op.name))
                    # nuq conv2d channel_wise is fixed to True, matmul is false
                    quant_config[item]['weight_quant_params']['channel_wise'] = True
                else:
                    quant_config[item]['weight_quant_params']['channel_wise'] = False
        return quant_config

    @staticmethod
    def get_layers_name(quant_config):
        """Get all layers' name from quant_config """
        configure = get_configurer()
        layers_name = list(quant_config.keys())
        for item in configure.root.get_keys():
            if item in layers_name:
                layers_name.remove(item)
        return layers_name

    @staticmethod
    def create_appoximate_config(graph, batch_num=1, config_defination=None):
        '''Create config for op approximation'''
        configurer = get_approximate_configurer()
        if config_defination is None:
            approx_config = configurer.create_quant_config(None, graph, skip_layers=[], batch_num=batch_num)
        else:
            config_defination = os.path.realpath(config_defination)
            approx_config = configurer.create_config_from_proto(None, graph, config_defination)
        return approx_config
