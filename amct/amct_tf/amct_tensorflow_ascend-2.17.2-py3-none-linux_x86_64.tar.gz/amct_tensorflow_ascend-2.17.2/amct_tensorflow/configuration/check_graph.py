#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quantization map matching module.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import copy
from collections import namedtuple
import tensorflow as tf # pylint: disable=E0401

from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.utils.utils_vars import AMCT_OPERATIONS
from amct_tensorflow.utils.utils_vars import AMCT_QAT_OPS
from amct_tensorflow.utils.utils_vars import AMCT_PRUNE_OPS
from amct_tensorflow.utils.utils_vars import QUANTIZABLE_TYPES
from amct_tensorflow.utils.utils_vars import NO_WEIGHT_QUANT_TYPES
from amct_tensorflow.utils.utils_vars import DUAL_ACTIVATION_QUANT_TYPES
from amct_tensorflow.utils.utils_vars import ADD_TYPES
from amct_tensorflow.utils.utils_vars import ELTWISE_TYPES
from amct_tensorflow.utils.utils_vars import TENSOR_QUANTIZABLE_TYPES

AddIndex = namedtuple('AddIndex', ['data_index', 'bias_add_index', 'quant_op', 'bias_op'])

__all__ = ['GraphChecker']


class GraphChecker():
    """
    Fuction: Check the graph.
    APIS: check_amct_operations, check_quantize_placeholder, check_placeholder,
        check_biasadd
    """
    @staticmethod
    def check_amct_operations(graph):
        ''' Check whether there's operations from amct. '''
        ops = graph.get_operations()
        for single_op in ops:
            if single_op.type in AMCT_OPERATIONS:
                raise RuntimeError(
                    "the graph is unsupported for layer %s's type is %s. "
                    "please ensure the graph isn't quantized by "
                    "amct_tensorflow." % (single_op.name, single_op.type))

    @staticmethod
    def check_enable_amct_op_types(graph):
        '''
        Function: Check whether there's amct QAT or CP ops in the graph.
        '''
        ops = graph.get_operations()
        enable_quant = False
        enable_prune = False
        for single_op in ops:
            if single_op.type in AMCT_QAT_OPS:
                enable_quant = True
            if single_op.type in AMCT_PRUNE_OPS:
                enable_prune = True
        return enable_quant, enable_prune

    @staticmethod
    def check_matmul_transpose(graph, layers_name):
        """
        Function: Checks whether the matmul is transposed.
        Inputs:
            graph: tf.compat.v1.Graph
            layers_name: a list, name of layers to be quantized.
        Outputs:
            valid_layers: the layer there's no transposition.
        """
        valid_layers = copy.deepcopy(layers_name)
        matmul_attr = ['transpose_a', 'transpose_b']
        batchmatmul_attr = ['adj_x', 'adj_y']
        for layer_name in layers_name:
            is_tranpose = False
            match_transpose = False
            quant_op = graph.get_operation_by_name(layer_name)
            if quant_op.type == 'MatMul':
                is_tranpose = GraphChecker.check_matmul_sub_transpose(
                    quant_op, matmul_attr, match_transpose)

            if quant_op.type in ['BatchMatMul', 'BatchMatMulV2']:
                match_transpose = True
                is_tranpose = GraphChecker.check_matmul_sub_transpose(quant_op,
                        batchmatmul_attr, match_transpose)

            if is_tranpose:
                LOGGER.push_debug_message(
                    "layer %s cannot be quantized for the matmul has "
                    "transpose operation." % (layer_name),
                    module_name='check_graph')
                valid_layers.remove(layer_name)

        return valid_layers

    @staticmethod
    def check_matmul_sub_transpose(operation, attr_list, support_transpose):
        """
        Function: Checks whether the matmul is transpose under support_transpose.
        Inputs:
            operation: matmul op.
            attr_list: matmul transpose attr list.
            support_transpose: whether the matmul is support_transpose.
        Outputs:
            istrans: the result whether the matmul is transposed.
        """
        istrans_a = operation.get_attr(attr_list[0])
        istrans_b = operation.get_attr(attr_list[1])
        # support sub_transpose
        if support_transpose:
            return istrans_a
        else:
            return istrans_a or istrans_b

    @staticmethod
    def check_gradient_op(graph, layers_name):
        """
        Function: Check whether the current quantization op is the op
            generated in reverse convolution.
        Inputs:
            graph: tf.compat.v1.Graph
            layers_name: a list, name of layers to be quantized.
        Outputs:
            valid_layers: the layer there's no gradient operator.
        """
        valid_layers = copy.deepcopy(layers_name)
        for layer_name in layers_name:
            quant_op = graph.get_operation_by_name(layer_name)
            if quant_op.type not in QUANTIZABLE_TYPES:
                raise TypeError(
                    "layer %s is not supported type for quantization." %
                    (layer_name))
            if 'gradients' in quant_op.name:
                LOGGER.push_debug_message(
                    "layer %s cannot be quantized for it is gradient "
                    "operator." % (layer_name),
                    module_name='check_graph')
                valid_layers.remove(layer_name)

        return valid_layers

    @staticmethod
    def check_quantize_placeholder(graph, layers_name):
        """
        Function: Check whether there's Placeholder in weight and bias of
            layers to be quantized.
        Inputs:
            graph: tf.compat.v1.Graph
            layers_name: a list, name of layers to be quantized.
        Outputs:
            valid_layers: the layer there's no Placeholder in weight and bias.
        """
        valid_layers = copy.deepcopy(layers_name)
        for layer_name in layers_name:
            quant_op = graph.get_operation_by_name(layer_name)
            if quant_op.type not in QUANTIZABLE_TYPES:
                raise TypeError(
                    "layer %s is not supported type for quantization." %
                    (layer_name))
            if quant_op.type in NO_WEIGHT_QUANT_TYPES + DUAL_ACTIVATION_QUANT_TYPES:
                continue

            is_weight_placeholder = GraphChecker.check_weight(
                graph, quant_op, layer_name)
            is_bias_placeholder = GraphChecker.check_bias(
                graph, quant_op, layer_name)
            if is_weight_placeholder or is_bias_placeholder:
                valid_layers.remove(layer_name)

        return valid_layers

    @staticmethod
    def check_tensor_quant(graph, quant_tensors):
        """
        Function: Check whether tensor exists in the graph and if
        tensor.op's type is quantizable
        Inputs:
        graph: tf.compat.v1.Graph
        quant_tensors: a list of quant-tensors.
        Raise:
        TypeError: tensor.op's type in quantizable types
        RuntimeError: tensor not found in graph
        """
        for tensor_dict in quant_tensors:
            op_name = tensor_dict.get('layer_name')
            tensor_idx = tensor_dict.get('input_index')
            try:
                op = graph.get_operation_by_name(op_name)
            except (ValueError, SyntaxError, KeyError) as e:
                raise RuntimeError(
                    "Operation %s is not found in the given Graph." %
                    (op_name)) from e
            if op.type not in TENSOR_QUANTIZABLE_TYPES:
                raise TypeError(
                    "Operation %s is not supported for tensor quantization." % (op_name))
            if tensor_idx < 0:
                raise IndexError(
                    "Input index %d cannot be negative for the operation %s" % (tensor_idx, op_name))
            if tensor_idx + 1 > len(op.inputs):
                raise IndexError(
                    "Input index %d is out of range for the operation %s" % (tensor_idx, op_name))

    @staticmethod
    def check_weight(graph, quant_op, layer_name):
        """
        Function: check weight.
        Inputs:
            graph: a graph, input user graph structure.
            quant_op: a operation to be quantized.
            layer_name: a string, the name of the op to be quantified.
        Returns:
            is_placeholder: a bool, indicating whether the current data
                supports quantization..
        """
        is_placeholder = False
        _, weight_index = QuantOpInfo.get_quant_index(quant_op)
        weights = quant_op.inputs[weight_index]
        weight_node = weights.op
        if not GraphChecker.check_valid_shape(weights) \
            or not GraphChecker.check_valid_enter(weights) \
            or GraphChecker.check_placeholder(graph, [weight_node.name]):
            is_placeholder = True
            LOGGER.push_debug_message(
                "layer %s cannot be quantized for its weight is "
                "not quantifiable." % (layer_name),
                module_name='check_graph')
        return is_placeholder

    @staticmethod
    def check_bias(graph, quant_op, layer_name):
        """
        Function: check bias.
        Inputs:
            graph: a graph, input user graph structure.
            quant_op: a operation to be quantized.
            layer_name: a string, the name of the op to be quantified.
        Returns:
            is_placeholder: a bool, indicating whether the current data
                supports quantization..
        """
        is_placeholder = False
        consumers = quant_op.outputs[0].consumers()
        if len(consumers) == 1:
            next_op = quant_op.outputs[0].consumers()[0]
            if next_op.type == "BiasAdd":
                bias = next_op.inputs[1]
                bias_node = bias.op
                if not GraphChecker.check_valid_shape(bias) \
                    or not GraphChecker.check_valid_enter(bias) or \
                    GraphChecker.check_placeholder(graph, [bias_node.name]):
                    is_placeholder = True
                    LOGGER.push_debug_message(
                        "layer %s cannot be quantized for its bias is "
                        "not quantifiable." % (layer_name),
                        module_name='check_graph')
        return is_placeholder

    @staticmethod
    def check_valid_shape(input_tensor):
        """
        Function: check whether the shape of the tensor is quantifiable.
        Inputs:
            input_tensor: a tensor, bias or weight tensor.
        Returns:
            a bool, indicates the current data shape whether is valid.
        """
        shape = input_tensor.shape
        if str(shape) == '<unknown>':
            return False
        return True

    @staticmethod
    def check_valid_enter(input_tensor):
        """
        Function: check whether the weight that depends on enter_op can be
            quantized.
        Inputs:
            input_tensor: a tensor, bias or weight tensor.
        Returns:
            a bool, indicates the current tensor shape can be quantized.
        """
        info_length, _, _, _ = \
            GraphChecker.get_dependency_enter_info(input_tensor.op)
        if info_length > 1:
            return False
        return True

    @staticmethod
    def check_placeholder(graph, dest_nodes):
        """
        Function: check whether there's placeholder in the subgraph extracted
            from graph by nodes in dest_nodes.
        Inputs:
            graph: tf.compat.v1.Graph
            dest_nodes: A list of strings specifying the destination node
                names.
        Returns:
            uncertain_nodes: a list of string, name of the nodes whose
                subgraph there's placeholder.
        """
        uncertain_nodes = []
        for dest_node in dest_nodes:
            dest_op = graph.get_operation_by_name(dest_node)
            if GraphChecker.get_dependency_with_placeholder(dest_op):
                uncertain_nodes.append(dest_node)

        return uncertain_nodes

    @staticmethod
    def get_dependency_with_placeholder(dest_op):
        """
        Function: Determine whether the dest_op is dependent on 'Placeholder'.
        Inputs:
            dest_op: an operation.
        Returns:
            dependency_flag: a bool,
                True: the dest_op is dependent on 'Placeholder'.
                False: the dest_op isn't dependent on 'Placeholder'.
        """
        input_ops = []
        not_ergodic_op_list = [dest_op]

        ergodic_op_list = []
        while not_ergodic_op_list:
            dependency_and_inputs = []
            dependency_and_inputs.extend(not_ergodic_op_list[0].inputs)
            dependency_and_inputs.extend(
                not_ergodic_op_list[0].control_inputs)
            if not dependency_and_inputs:
                input_ops.append(not_ergodic_op_list[0])
                not_ergodic_op_list.pop(0)
            else:
                for op_input in dependency_and_inputs:
                    operation = None
                    if isinstance(op_input, tf.compat.v1.Operation):
                        operation = op_input
                    else:
                        operation = op_input.op
                    if operation not in ergodic_op_list:
                        not_ergodic_op_list.append(operation)
                        ergodic_op_list.append(operation)
                not_ergodic_op_list.pop(0)

        input_ops_type = [item.type for item in input_ops]

        if 'Placeholder' in input_ops_type or \
            'PlaceholderWithDefault' in input_ops_type:
            return True

        return False

    @staticmethod
    def get_dependency_enter_info(dest_op):
        """
        Function: Determines whether the dest_op depends on the enter op and
            whether the dest_op can be quantized, and returns the attribute
            information of the enter.
        Inputs:
            dest_op: an operation.
        Returns:
            enter_info: a list:
                info_length: 0(no enter); 1(has valid enter can be quantized);
                             2(has unvalid enter cannot be quantized).
                frame_name: attributes of the fram_name field of enter_op.
                is_constant: attributes of the is_constant field of enter_op.
                parallel_iterations: attributes of the parallel_iterations
                                     field of enter_op.
        """
        enter_ops = []
        not_ergodic_op_list = [dest_op]

        ergodic_op_list = []
        while not_ergodic_op_list:
            process_op = not_ergodic_op_list.pop(0)
            if process_op.type == 'Exit':
                continue
            if process_op.type == 'Enter':
                enter_ops.append(process_op)
            for op_input in process_op.inputs:
                if op_input.op not in ergodic_op_list:
                    not_ergodic_op_list.append(op_input.op)
                    ergodic_op_list.append(op_input.op)


        frame_name = [enter_op.get_attr('frame_name') for enter_op in enter_ops]
        is_constant = [enter_op.get_attr('is_constant') for enter_op in enter_ops]
        enter_info = [0, None, None, None]
        enter_info[0] = len(frame_name)
        enter_info[1] = frame_name[0] if frame_name else None
        enter_info[2] = is_constant[0] if is_constant else None
        enter_info[3] = 1 # parallel_iterations set to 1

        if len(frame_name) == 1:
            if dest_op.type == 'Enter':
                enter_info[0] = 1
            else:
                enter_info[0] = 2
        return enter_info

    @staticmethod
    def get_add_index(check_op):
        """
        Function: get data index and bias index of the add operation.
        Inputs:
            check_op: tf.compat.v1.Operation
        Returns:
            data_index: the data index
            bias_add_index: the bias add index
            quant_op: tf.compat.v1.Operation, it's type should be in QUANTIZABLE_TYPES.
            bias_op: tf.compat.v1.Operation
        """
        data_index = -1
        bias_add_index = -1
        quant_op = None
        bias_op = None
        if check_op.type in ADD_TYPES:
            first_input_op = check_op.inputs[0].op
            second_input_op = check_op.inputs[1].op
            if first_input_op.type in QUANTIZABLE_TYPES and \
                second_input_op.type not in QUANTIZABLE_TYPES:
                data_index = 0
                bias_add_index = 1
                quant_op = first_input_op
                bias_op = second_input_op
            elif first_input_op.type not in QUANTIZABLE_TYPES and \
                second_input_op.type in QUANTIZABLE_TYPES:
                data_index = 1
                bias_add_index = 0
                quant_op = second_input_op
                bias_op = first_input_op

        return AddIndex._make([data_index, bias_add_index, quant_op, bias_op])

    @staticmethod
    def get_cout_channel(operation):
        """
        Function: Get the cout channel of the operation.
        Inputs:
            operation: tf.compat.v1.Operation.
        Returns:
            cout_channel: a number, the cout channel.
        """
        cout_channel = -1
        if len(operation.inputs) > 1:
            input_shape = operation.inputs[1].get_shape()
        op_type = operation.type
        if op_type == "Conv2D":
            # filter_shape arranged as [h, w, cin, cout]
            cout_channel = input_shape[-1]
        elif op_type == "Conv3D":
            # filter_shape arranged as [d, h, w, cin, cout]
            cout_channel = input_shape[-1]
        elif op_type == "DepthwiseConv2dNative":
            # filter_shape arranged as [h, w, cin, channel_multiplier]
            cout_channel = input_shape[-2] * input_shape[-1]
        elif op_type == 'Conv2DBackpropInput':
            # filter_shape arranged as [h, w, cout, cin]
            cout_channel = input_shape[-2]
        elif op_type == 'MatMul':
            # filter_shape arranged as [cin, cout]
            cout_channel = input_shape[1]
            if operation.get_attr('transpose_b'):
                cout_channel = input_shape[0]
        return cout_channel

    @staticmethod
    def get_add_length(quant_op, add_shape):
        """
        Function: get bias_add's valid length.
        Inputs:
            quant_op: tf.compat.v1.Operation, it's type should be in QUANTIZABLE_TYPES.
            add_shape: the bias_add's shape
        Returns:
            real_length: the bias_add's valid length.
        """
        real_length = -1
        if add_shape == []:
            real_length = 0
        elif len(add_shape) == 1:
            real_length = add_shape[0]
        elif len(add_shape) == 2:
            if add_shape[0] == 1 and quant_op.type == 'MatMul':
                real_length = add_shape[1]
        elif len(add_shape) == 4:
            if quant_op.type != 'MatMul':
                if quant_op.get_attr('data_format') == b'NHWC':
                    if add_shape[0] * add_shape[1] * add_shape[2] == 1:
                        real_length = add_shape[3]
                elif quant_op.get_attr('data_format') == b'NCHW':
                    if add_shape[0] * add_shape[2] * add_shape[3] == 1:
                        real_length = add_shape[1]
        return real_length

    @staticmethod
    def check_biasadd_shape(bias_shape, quant_op):
        """
        Function: check whether bias op has the same C-out shape as quant_op
        Inputs:
            bias_shape: the bias_add's shape
            quant_op: matmul op
        Returns:
            a bool, whether shape equals
        """
        real_length = GraphChecker.get_add_length(quant_op, bias_shape)
        expect_length = GraphChecker.get_cout_channel(quant_op)
        if real_length < 0 or expect_length < 0:
            return False
        if real_length > 0 and real_length != expect_length:
            return False
        return True

    @staticmethod
    def check_biasadd(check_op):
        """
        Function: check whether check_op plays the role of biasadd.
        Inputs:
            check_op: tf.compat.v1.Operation
        Returns:
            is_biasadd: a bool, whether check_op plays the role of biasadd.
        """
        add_index = GraphChecker.get_add_index(check_op)
        if add_index.data_index < 0 or add_index.bias_add_index < 0:
            return False
        if GraphChecker.get_dependency_with_placeholder(add_index.bias_op):
            return False
        bias_shape = check_op.inputs[add_index.bias_add_index].shape
        return GraphChecker.check_biasadd_shape(bias_shape, add_index.quant_op)

    @staticmethod
    def check_eltwise(check_op):
        """
        Function: check whether check_op plays the role of elementwise add/mul.
        Inputs:
            check_op: tf.compat.v1.Operation
        Returns:
            is_eltwise: a bool, whether check_op plays the role of elementwise
                add/mul.
        """
        is_eltwise = False
        if check_op.type in ELTWISE_TYPES:
            try:
                shape_1 = str(check_op.inputs[0].shape)
                shape_2 = str(check_op.inputs[1].shape)
                shape_3 = str(check_op.outputs[0].shape)
            except IndexError:
                is_eltwise = False
            else:
                if shape_1 == shape_2 and shape_3 == shape_2:
                    is_eltwise = True
        return is_eltwise

    @staticmethod
    def get_shared_weights(graph, quant_config, quantizable_layers):
        """
        Function: get all weights and corresponding quant layers in graph
        Inputs:
            graph: tf.compat.v1.Graph, to be quantized
            quant_config: a dict, quant config
            quantizable_layers: a list, containing name of layers in
                quant_config
        Returns:
            shared_weight_layers: a dict, key: weight_tensor_name, value: list of layer_name
        """
        shared_weight_layers = dict()
        for layer_name in list(quant_config.keys()):
            if layer_name not in quantizable_layers:
                continue
            quant_op = graph.get_operation_by_name(layer_name)
            if quant_op.type in NO_WEIGHT_QUANT_TYPES + DUAL_ACTIVATION_QUANT_TYPES:
                continue
            _, weight_index = QuantOpInfo.get_quant_index(quant_op)
            weight_tensor_name = quant_op.inputs[weight_index].name
            if shared_weight_layers.get(weight_tensor_name) is None:
                shared_weight_layers[weight_tensor_name] = [layer_name]
            else:
                shared_weight_layers.get(weight_tensor_name).append(layer_name)

        return shared_weight_layers

    @staticmethod
    def check_weights_shared(graph, quant_config, quantizable_layers):
        """
        Function: Check whether the quant layers with same weight have
            same weight quant config
        Inputs:
            graph: tf.compat.v1.Graph, to be quantized
            quant_config: a dict, quant config
            quantizable_layers: a list, containing name of layers in
                quant_config
        """
        # Step1: find layers with same weights in quant_config
        shared_weight_layers = GraphChecker.get_shared_weights(graph, quant_config, quantizable_layers)

        # Step2: check whether the config is same for layers with same weights
        def get_wts_config(quant_config, layer_name):
            '''get wts config for layer_name in quant_config '''
            return quant_config[layer_name]['retrain_weight_config']

        for _, layers_name in shared_weight_layers.items():
            if len(layers_name) == 1:
                continue
            wts_config = None
            do_quant_layer = list()
            for layer_name in layers_name:
                if not quant_config[layer_name].get('retrain_enable', None):
                    continue
                do_quant_layer.append(layer_name)
                if wts_config is None:
                    wts_config = get_wts_config(quant_config, layer_name)
                if wts_config != get_wts_config(quant_config, layer_name):
                    raise RuntimeError(
                        "layers with same weight should have same " \
                        "retrain_weight_config, but %s is not satisfied."
                        % (do_quant_layer))
