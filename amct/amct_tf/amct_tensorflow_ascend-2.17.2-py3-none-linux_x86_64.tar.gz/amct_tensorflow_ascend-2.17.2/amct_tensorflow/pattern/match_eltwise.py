#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Find eltwise pattern from graph.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from amct_tensorflow.optimizer.insert_bias_quant_pass import cmp_data_format
from amct_tensorflow.configuration.check_graph import GraphChecker

from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.utils.utils_vars import QUANTIZABLE_TYPES

ELTWISE_ADD_TYPES = ['Add', 'AddV2']
UNION_QUANT_TYPES = ['Conv2D']
BY_PASS_TYPES = ['Relu']
FOLLOW_TYPES = ['MaxPool', 'Add', 'AddV2', 'Conv2D']

__all__ = ['EltwiseAddUnion']


class EltwiseAddUnion():
    '''
    Function: s16 eltwise add pattern
    APIS: get_union_ops, get_layer_config, find_eltwise_union_pattern,
        check_eltwise_add
    '''
    def __init__(self, eltwise_op, quant_config):
        self.quant_config = quant_config
        self.head = eltwise_op
        self.union_ops = []
        self.tail_ops = []

        self.searched_eltwise_ops = []
        self.candidate_eltwise = []

        if eltwise_op.type not in ELTWISE_ADD_TYPES:
            raise RuntimeError(
                "%s is valid for eltwise_op's type, %s is unsupported" %
                (ELTWISE_ADD_TYPES, eltwise_op.type))

        if not self.find_eltwise_union_pattern():
            raise RuntimeError(
                "cannot find eltwise_add_union pattern from %s" %
                (eltwise_op.name))

    @staticmethod
    def check_eltwise_add(operation):
        ''' check an operation is eltwise_add '''
        if operation.type in ELTWISE_ADD_TYPES and \
            GraphChecker.check_eltwise(operation):
            return True
        return False

    def get_union_ops(self):
        ''' get unino_ops '''
        return self.union_ops

    def get_union_op_names(self):
        ''' get unino_ops '''
        union_op_names = [union_op.name for union_op in self.union_ops]
        return union_op_names

    def get_tail_ops(self):
        ''' get tail_ops '''
        return self.tail_ops

    def find_eltwise_union_pattern(self):
        ''' find a pattern able to be quantized for s16 eltwise add '''
        def check_eltwise_op(eltwise_op):
            ''' check whether eltwise_op is valid for s16 eltwise add '''
            if EltwiseAddUnion.check_eltwise_add(eltwise_op):
                if not self._check_eltwise_input(eltwise_op.inputs[0].op) or \
                    not self._check_eltwise_input(eltwise_op.inputs[1].op):
                    LOGGER.push_debug_message(
                        'eltwise_op{%s} check inputs fail' % (eltwise_op.name),
                        'EltwiseAddUnion')
                    return False

                self.searched_eltwise_ops.append(eltwise_op.name)

                if not self._check_eltwise_outputs(eltwise_op):
                    LOGGER.push_debug_message(
                        'eltwise_op{%s} check outputs fail' %
                        (eltwise_op.name), 'EltwiseAddUnion')
                    return False
                return True

            LOGGER.push_debug_message(
                'eltwise_op{%s} check eltwise fail' % (eltwise_op.name),
                'EltwiseAddUnion')
            return False

        self.candidate_eltwise = [self.head]
        # check structure
        while self.candidate_eltwise:
            current_op = self.candidate_eltwise.pop(0)
            if not check_eltwise_op(current_op):
                return False
        # check union_ops
        return self._check_union_ops()

    def _check_eltwise_input(self, input_op):
        ''' check whether the eltwise_op's input is valid. There are 3 kinds
            valid inputs as follows:
            Conv2D     Conv2D         Add(searched)
              \\         |                \\
              Add      BiasAdd            Add
                         \\
                         Add
        '''
        # conv with bias
        if input_op.type == 'BiasAdd' and \
            len(input_op.outputs[0].consumers()) == 1:
            input_up_op = input_op.inputs[0].op
            if input_up_op.type in UNION_QUANT_TYPES and\
                len(input_up_op.outputs[0].consumers()) == 1 and\
                cmp_data_format(input_op, input_up_op):
                self.union_ops.append(input_up_op)
                return True
        # conv without bias
        if input_op.type in UNION_QUANT_TYPES and \
            len(input_op.outputs[0].consumers()) == 1:
            self.union_ops.append(input_op)
            return True

        # eltwise_add/relu
        if input_op.name in self.searched_eltwise_ops:
            return True

        return False

    def _check_eltwise_outputs(self, eltwise_op):
        ''' Check whether the eltwise_op's outputs is valid. There are 4 kinds
            valid outputs as follows:
             add        add      add       add
              |          |       / \\      / \\
             Relu       Relu    conv      conv
             / \\       / \\
            conv      Add
            note: conv means quantizable op; add means Add and AddV2
        '''
        if len(eltwise_op.outputs[0].consumers()) == 1 and \
            eltwise_op.outputs[0].consumers()[0].type in BY_PASS_TYPES:
            check_op = eltwise_op.outputs[0].consumers()[0]
            self.searched_eltwise_ops.append(check_op.name)
        else:
            check_op = eltwise_op

        if len(check_op.outputs[0].consumers()) != 2:
            LOGGER.push_debug_message(
                'eltwise{%s} outputs[0] must have 2 consumers' %
                (check_op.name), 'EltwiseAddUnion')
            return False

        def check_eltwise_output(output_op):
            """ Check eltwise's outputs' type """
            is_valid = True

            op_type = output_op.type
            if op_type not in FOLLOW_TYPES:
                is_valid = False
            if op_type in ELTWISE_ADD_TYPES and \
                not EltwiseAddUnion.check_eltwise_add(output_op):
                is_valid = False

            return is_valid

        is_tail = True
        follow_types = set()
        is_valid = True
        quantizable_layers = []
        for output_op in check_op.outputs[0].consumers():
            if not check_eltwise_output(output_op):
                LOGGER.push_debug_message(
                    'eltwise{%s} output{%s} type invalid' %
                    (check_op.name, output_op.name), 'EltwiseAddUnion')
                return False

            op_type = output_op.type
            follow_types.add(op_type)

            if op_type in ELTWISE_ADD_TYPES:
                is_tail = False
                if output_op.name not in self.candidate_eltwise:
                    self.candidate_eltwise.append(output_op)

            if op_type in QUANTIZABLE_TYPES:
                quantizable_layers.append(output_op.name)

        # Maxpool shoule be with quantizable_layers
        if 'MaxPool' in follow_types and not quantizable_layers:
            LOGGER.push_debug_message(
                'MaxPool should be with quantizable layers in eltwise{%s} '
                'outputs' % (check_op.name), 'EltwiseAddUnion')
            is_valid = False
        # output quant_config shoule be same
        if quantizable_layers and not self._cmp_layer_config(
                quantizable_layers):
            LOGGER.push_debug_message(
                'eltwise{%s} outpus quant_config shopuld be same' %
                (check_op.name), 'EltwiseAddUnion')
            is_valid = False
        if is_tail:
            self.tail_ops.append(eltwise_op)

        return is_valid

    def _check_union_ops(self):
        ''' check attrs and quant_config for union_ops'''
        union_op_names = [op.name for op in self.union_ops]
        # check quant_config
        if not self._cmp_layer_config(union_op_names):
            LOGGER.push_debug_message(
                'EltwiseAddUnion._check_union_ops() failed for unequal '
                'quant_config. union_ops is %s.' % (union_op_names))
            return False

        is_valid = True
        global_data_format = None
        for operaion in self.union_ops:
            # check data_format
            if global_data_format is None:
                global_data_format = operaion.get_attr('data_format')
            elif global_data_format != operaion.get_attr('data_format'):
                is_valid = False
                LOGGER.push_debug_message(
                    'EltwiseAddUnion._check_union_ops() failed for unequal '
                    'data_format. union_ops is %s.' % (union_op_names))
                break
            # check dilations
            if operaion.get_attr('dilations') != [1, 1, 1, 1]:
                is_valid = False
                LOGGER.push_debug_message(
                    'EltwiseAddUnion._check_union_ops() failed for invalid '
                    'dilations in %s.' % (operaion.name))
                break

        return is_valid

    def _cmp_layer_config(self, layer_names):
        ''' Cmpare layers' quant_config. If configs of layer in layer_names
        are same(except None) return True, otherwise return False.
        '''
        global_quant_config = self.quant_config.get(layer_names[0])
        if not global_quant_config:
            return False
        for layer_name in layer_names[1:]:
            if self.quant_config.get(layer_name) != global_quant_config:
                return False
        return True
