#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Fuse FusedBatchNororm and CONV2D or DepthwiseConv2dNative for different API.

"""

from google.protobuf import text_format
from amct_tensorflow.proto import \
    inner_scale_offset_record_pb2 # pylint: disable=no-name-in-module
from amct_tensorflow.utils.parse_record_file import RecordFileParser
from amct_tensorflow.optimizer.graph_optimizer import GraphOptimizer
from amct_tensorflow.optimizer.replace_add_pass import ReplaceAddPass
from amct_tensorflow.optimizer.adjust_add_position import AdjustAddPosition
from amct_tensorflow.optimizer.replace_bn_pass import ReplaceBNPass
from amct_tensorflow.optimizer.conv_bn_fusion_pass import ConvBnFusionPass
from amct_tensorflow.optimizer.matmul_bn_fusion_pass import MatmulBnFusionPass
from amct_tensorflow.optimizer.fuse_mul_pass import FuseMulPass
from amct_tensorflow.optimizer.adjust_group_conv_bn_pass \
    import AdjustGroupConvBNPass
from amct_tensorflow.optimizer.delete_identity_pass import DeleteIdentityPass
from amct_tensorflow.utils.log import LOGGER
from amct_tensorflow.optimizer.adjust_batchtospace_bn_pass \
    import AdjustBatchToSpaceBNPass

__all__ = [
    'fuse_bn_quantize_model', 'fuse_bn_save_model', 'fuse_bn_convert_model'
]


def fuse_bn_quantize_model(
        graph, do_fusion, skip_layers, record_file, outputs=None):
    """
    Function: fuse bn for API quantize_model
    Inputs:
        graph: tf.compat.v1.Graph, graph to be fused
        skip_layers: a list containing layers not to be fused.
    Returns:
        graph: tf.compat.v1.Graph, graph fused
    """
    LOGGER.push_info_message('fusing bn for quantize_model', 'fuse_bn')
    optimizer = GraphOptimizer()
    skip_param = {
        'do_fusion': do_fusion,
        'skip_layers': skip_layers,
        'skip_layers_fusible': dict.fromkeys(skip_layers, False)
    }
    optimizer.add_pass(DeleteIdentityPass(outputs=outputs))
    optimizer.add_pass(AdjustAddPosition())
    optimizer.add_pass(ReplaceAddPass(
        is_replace=False, outputs=outputs))
    optimizer.add_pass(ReplaceBNPass(outputs=outputs))
    optimizer.add_pass(AdjustGroupConvBNPass(
        skip_param=skip_param, outputs=outputs))
    optimizer.add_pass(AdjustBatchToSpaceBNPass(
        skip_param=skip_param, outputs=outputs))
    optimizer.add_pass(ConvBnFusionPass(
        is_replace=False, outputs=outputs, skip_param=skip_param))
    optimizer.add_pass(MatmulBnFusionPass(
        is_replace=False, outputs=outputs, skip_param=skip_param))
    optimizer.add_pass(FuseMulPass(is_replace=False, outputs=outputs))

    graph = optimizer.do_optimizer(graph)
    fused_layers = optimizer.get_matched_layers(str(ConvBnFusionPass))

    # write record_file for convert convert_model API
    records = inner_scale_offset_record_pb2.InnerScaleOffsetRecord()
    RecordFileParser.read_record_file(record_file, records)
    skip_layers_fusible = skip_param.get('skip_layers_fusible')
    for layer in skip_layers_fusible:
        if skip_layers_fusible[layer]:
            record_do_fusion(records, layer, do_fusion=False)

    with open(record_file, 'w') as fid:
        fid.write(text_format.MessageToString(records, as_utf8=True))

    LOGGER.push_debug_message('finish writing do_fusion in record_file',
                              'fuse_bn')

    LOGGER.push_debug_message('finish fuse_bn_quantize_model', 'fuse_bn')

    return graph, fused_layers


def fuse_bn_save_model(graph, outputs, skip_layers=None, is_qat=False):
    """
    Function: fuse bn for API save_model
    Inputs:
        graph: tf.compat.v1.Graph, graph to be fused
        outputs: a list containing the names of outputs in graph.
        skip_layers: a list containing layers not to be fused.
    Returns:
        graph: tf.compat.v1.Graph, graph fused
    """
    LOGGER.push_info_message('fusing bn for save_model', 'fuse_bn')
    optimizer = GraphOptimizer()

    skip_param = {'skip_layers': skip_layers}
    optimizer.add_pass(DeleteIdentityPass(outputs=outputs))
    optimizer.add_pass(AdjustAddPosition())
    optimizer.add_pass(ReplaceAddPass(is_replace=True,
                                      outputs=outputs))
    optimizer.add_pass(ReplaceBNPass(outputs=outputs))
    optimizer.add_pass(AdjustGroupConvBNPass(skip_param=skip_param,
                                             outputs=outputs))
    optimizer.add_pass(AdjustBatchToSpaceBNPass(
        skip_param=skip_param, outputs=outputs))
    optimizer.add_pass(
        ConvBnFusionPass(is_replace=True,
                         outputs=outputs,
                         skip_param=skip_param))
    if not is_qat:
        optimizer.add_pass(
            MatmulBnFusionPass(is_replace=True,
                               outputs=outputs,
                               skip_param=skip_param))
    optimizer.add_pass(FuseMulPass(is_replace=True, outputs=outputs))

    graph = optimizer.do_optimizer(graph)
    fused_layers = optimizer.get_matched_layers(str(ConvBnFusionPass))

    LOGGER.push_debug_message('finish fuse_bn_save_model', 'fuse_bn')

    return graph, fused_layers


def fuse_bn_convert_model(graph,
                          outputs,
                          records,
                          skip_layers=None,
                          is_qat=False):
    """
    Function: fuse bn for API convert_model
    Inputs:
        graph: tf.compat.v1.Graph, graph to be fused
        outputs: a list containing the names of outputs in graph
        records: a dictionary recording layers' quant factors.
        skip_layers: a list containing layers not to be fused.
    Returns:
        graph: tf.compat.v1.Graph, graph fused
    """
    LOGGER.push_info_message('fusing bn for convert_model', 'fuse_bn')
    optimizer = GraphOptimizer()

    skip_param = {'skip_layers': skip_layers}

    optimizer.add_pass(DeleteIdentityPass(outputs=outputs))
    optimizer.add_pass(AdjustAddPosition())
    optimizer.add_pass(ReplaceAddPass(
        is_replace=True, outputs=outputs))
    optimizer.add_pass(ReplaceBNPass(outputs=outputs))
    optimizer.add_pass(AdjustGroupConvBNPass(
        skip_param=skip_param, outputs=outputs))
    optimizer.add_pass(AdjustBatchToSpaceBNPass(
        skip_param=skip_param, outputs=outputs))
    optimizer.add_pass(
        ConvBnFusionPass(is_replace=True,
                         outputs=outputs,
                         records=records,
                         skip_param=skip_param))
    if not is_qat:
        optimizer.add_pass(
            MatmulBnFusionPass(is_replace=True,
                               outputs=outputs,
                               records=records,
                               skip_param=skip_param))
    optimizer.add_pass(FuseMulPass(is_replace=True, outputs=outputs))

    graph = optimizer.do_optimizer(graph)
    fused_layers = optimizer.get_matched_layers(str(ConvBnFusionPass))

    LOGGER.push_debug_message('finish fuse_bn_convert_model', 'fuse_bn')

    return graph, fused_layers


def record_do_fusion(records, layer_name, do_fusion):
    """
    Function: Write do_fusion to records
    Parameters: records: ScaleOffsetRecord() object to write
                layer_name: layer name of scale_w, offset_w
                do_fusion: value of do_fusion
    Return: None
    """
    # add to exist record
    for record in records.record:
        if record.key == layer_name:
            record.value.skip_fusion = not do_fusion
            return
    # add a new record
    record = records.record.add()
    record.key = layer_name
    record.value.skip_fusion = not do_fusion
