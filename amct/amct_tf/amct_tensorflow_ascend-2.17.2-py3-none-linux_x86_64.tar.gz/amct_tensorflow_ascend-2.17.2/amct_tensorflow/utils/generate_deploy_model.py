#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Modify graph to a deployed graph.

"""

import amct_tensorflow.optimizer as opt
from amct_tensorflow.optimizer.graph_optimizer import GraphOptimizer


def generate_deploy_model(graph, outputs, records, is_quant_fusion=True, on_ascend=False):
    """
    Function: Modify graph to 'deploy' mode by inserting 'deploy' subgraph
    Inputs:
        graph: the graph to be quantized.
        outputs: a list containing the names of outputs in graph.
        records: a dictionary containing quantization information.
    Returns:
        graph: the graph quantized.
    """
    optimizer = GraphOptimizer()

    # apply dmq_balancer
    dmq_balancer_layers_flag = []
    optimizer.add_pass(opt.GroupConvApplyDMQBalancerPass(records=records,
                                                      skip_layers=dmq_balancer_layers_flag,
                                                      outputs=outputs,
                                                      is_replace=True))
    optimizer.add_pass(opt.ApplyDMQBalancerPass(records=records,
                                                skip_layers=dmq_balancer_layers_flag,
                                                outputs=outputs,
                                                is_replace=True))

    # insert single op for quant behaviours
    optimizer.add_pass(opt.InsertQuantPass(records))
    optimizer.add_pass(opt.InsertDeQuantPass(records, outputs))
    optimizer.add_pass(opt.AdjustGroupConvPass(records, outputs))
    optimizer.add_pass(opt.InsertWeightQuantPass(records))
    optimizer.add_pass(opt.InsertWeightQuantNuqPass(records))
    optimizer.add_pass(opt.InsertBiasQuantPass(records))

    # do fusion for several conditions
    optimizer.add_pass(opt.MultQuantOptimizerPass(records=records))
    if is_quant_fusion:
        optimizer.add_pass(opt.QuantFusionPass(records=records))
    optimizer.add_pass(opt.WeightQuantFusionPass(records=records))
    optimizer.add_pass(opt.ReplaceHalfPrecisionOpPass())
    # Replace single quant op to several quant operations
    optimizer.add_pass(opt.ReplaceQuantPass())
    optimizer.add_pass(opt.ReplaceAntiQuantPass(on_ascend))
    optimizer.add_pass(opt.ReplaceWeightQuantPass(outputs=outputs))
    optimizer.add_pass(opt.ReplaceWeightQuantNuqPass(outputs=outputs))
    optimizer.add_pass(opt.ReplaceBiasQuantPass(outputs=outputs))
    optimizer.add_pass(opt.ReplaceDeQuantPass(outputs, on_ascend))

    # post-quantization optimization
    optimizer.add_pass(opt.ReplaceRelu6Pass())

    graph = optimizer.do_optimizer(graph)

    return graph
