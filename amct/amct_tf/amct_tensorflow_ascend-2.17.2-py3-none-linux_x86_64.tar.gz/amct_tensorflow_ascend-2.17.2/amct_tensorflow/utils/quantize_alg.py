#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
ERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Quantization algorithm module(ARQ IFMR).

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from collections import namedtuple
import tensorflow as tf  # pylint: disable=E0401
from tensorflow.python.ops import gen_control_flow_ops  # pylint: disable=E0401

from amct_tensorflow.utils.quant_op_info import QuantOpInfo
from amct_tensorflow.configuration.check_graph import GraphChecker
from amct_tensorflow.lib.load_custom_op import load
from amct_tensorflow.common.utils import vars_util

_CUSTOM_OP = load()
EPS_VALUE = 1e-12

ActCaliTensors = namedtuple('ActCaliTensors', ['scale_d', 'assign_scale', 'assign_batch_counter', 'batch_counter'])
DecoratedTensors = namedtuple('DecoratedTensors',
    ['enable', 'quant_var', 'quant_var_shape', 'batch_counter', 'one_value'])
SearchNTensors = namedtuple('SearchNTensors', ['shift_n', 'assign_shiftn', 'assign_batch_counter', 'batch_counter'])

__all__ = ["quantize_arq", "quantize_nuq", "quantize_activation", "search_n", "quantize_ifmr_ascend"]


def quantize_nuq(inputs, context, op_type, quant_kwargs):
    """
    Function:Quantize inputs with the algorithm 'NUQ'.
    Inputs:
        inputs:
            inputs[0]: a tensor to be quantized to get scale and offset.
            inputs[1]: a list, tensors to be fake quantized
        context: a string, context for created nodes.
        op_type: a string, type for quantized op
        quant_kwargs: a dictionary, including quantization parameters.
    Returns:
        fake_quant_weights: a list of fake quantized tensor.
        scale_w: a output tensor of the quant_arq op.
    """
    if quant_kwargs.get('num_bits') == vars_util.INT4_BIT:
        raise RuntimeError('quantization algorithm "NUQuantize" cannot supprot 4 bit.')
    with tf.compat.v1.variable_scope(None,
                                     default_name=context + '_NUQ',
                                     values=inputs[1],
                                     reuse=None) as scope:
        scope.set_partitioner(None)

        if op_type == 'Conv2D':
            inputs_to_nuq = tf.compat.v1.transpose(inputs[0],
                                                   perm=[3, 2, 0, 1],
                                                   name='weight_transpose')
        else:
            inputs_to_nuq = inputs[0]

        def insert_nuq():
            '''Inserts the customized nuq quantization op.'''
            scale_shape, scale_length = QuantOpInfo.get_scale_shape_for_nuq(
                inputs[1][0], op_type)
            scale_var = tf.compat.v1.get_variable(
                'scale',
                shape=scale_shape,
                dtype=tf.compat.v1.float32,
                trainable=False,
                collections=[
                    tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                    tf.compat.v1.GraphKeys.MODEL_VARIABLES
                ],
                use_resource=False)

            decorated_tensors = _decorate_enter(
                inputs[0], scale_var,
                quant_kwargs.get('quant_op_names')[0])
            scale_w, _, fake_quant_weights = _CUSTOM_OP.quant_nuq(
                inputs_to_nuq,
                enable=decorated_tensors.enable,
                scale_length=scale_length,
                quant_bits=quant_kwargs.get('num_bits'),
                num_steps=quant_kwargs.get('num_steps'),
                num_of_iteration=quant_kwargs.get('num_of_iteration'),
                with_offset=quant_kwargs.get('with_offset'),
                layer_names=quant_kwargs.get('quant_op_names'),
                record_file_path=quant_kwargs.get('record_file_name'))

            return scale_w, fake_quant_weights

        scale_w, fake_quant_weights = insert_nuq()

        if op_type == 'Conv2D':
            transposed_fq_weights = tf.compat.v1.transpose(
                fake_quant_weights, perm=[2, 3, 1, 0], name='weight_transpose')
        else:
            transposed_fq_weights = fake_quant_weights

        return transposed_fq_weights, scale_w


def quantize_arq(inputs, context, op_type, quant_kwargs):
    """
    Function:Quantize inputs with the algorithm 'ARQ'.
    Inputs:
        inputs:
            inputs[0]: a tensor to be quantized to get scale and offset.
            inputs[1]: a list, tensors to be fake quantized
        context: a string, context for created nodes.
        op_type: a string, type for quantized op
        quant_kwargs: a dictionary, including quantization parameters.
    Returns:
        weight_quants: a list of tensor quantized.
        scale_w: a output tensor of the quant_arq op.
    """

    with tf.compat.v1.variable_scope(None,
                                     default_name=context + '_ARQ',
                                     values=inputs[1],
                                     reuse=None) as scope:
        scope.set_partitioner(None)

        if op_type == 'Conv2DBackpropInput':
            inputs_to_arq = tf.compat.v1.transpose(inputs[0],
                                                   perm=[0, 1, 3, 2],
                                                   name='weight_transpose')
        else:
            inputs_to_arq = inputs[0]

        def insert_arq():
            '''Inserts the customized arq quantization op.'''
            arq_scale_shape, scale_length = QuantOpInfo.get_scale_shape(
                inputs[1][0], quant_kwargs.get('channel_wise'), op_type)
            scale_var = tf.compat.v1.get_variable(
                'scale',
                shape=arq_scale_shape,
                dtype=tf.compat.v1.float32,
                trainable=False,
                collections=[
                    tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                    tf.compat.v1.GraphKeys.MODEL_VARIABLES
                ],
                use_resource=False)
            decorated_tensors = _decorate_enter(
                inputs[0], scale_var,
                quant_kwargs.get('quant_op_names')[0])
            scale_w, _ = _CUSTOM_OP.quant_arq(
                inputs_to_arq,
                enable=decorated_tensors.enable,
                scale_length=scale_length,
                quant_bits=quant_kwargs.get('num_bits'),
                layer_names=quant_kwargs.get('quant_op_names'),
                record_file_path=quant_kwargs.get('record_file_name'))

            assign_scale = tf.compat.v1.assign(
                decorated_tensors.quant_var, tf.compat.v1.reshape(scale_w, decorated_tensors.quant_var_shape))
            return decorated_tensors.quant_var, scale_w, assign_scale

        scale_var, scale_w, assign_scale = insert_arq()

        weight_quants = []
        with tf.compat.v1.control_dependencies([assign_scale]):
            for weight in inputs[1]:
                if quant_kwargs['do_fakequant']:
                    weight_quant = _quant_inputs_by_scale(weight, scale_var, quant_kwargs.get('num_bits'))
                else:
                    weight_quant = tf.compat.v1.identity(weight)
                weight_quants.append(weight_quant)
        return weight_quants, scale_w


def quantize_ifmr_ascend(inputs, context, quant_kwargs):
    """
    Function:Quantize inputs with the algorithm 'IFMR'.
    Inputs:
        inputs: a tensor to be quantized.
        context: a string, context for created nodes.
        quant_kwargs: a dictionary, including quantization parameters.
    Returns:
        act_identities: a list of identity.
        scale_d: a output tensor of the quant_ifmr op.
    """

    with tf.compat.v1.variable_scope(None,
                                     default_name=context + '_IFMR',
                                     values=[inputs[1]],
                                     reuse=None) as scope:
        scope.set_partitioner(None)

        def insert_ifmr():
            '''Inserts the customized ifmr quantization op.'''
            min_value = tf.compat.v1.reduce_min(inputs[0])
            max_value = tf.compat.v1.reduce_max(inputs[0])
            min_value = tf.compat.v1.reshape(min_value, (1, ))
            max_value = tf.compat.v1.reshape(max_value, (1, ))
            range_tensor = tf.compat.v1.concat([min_value, max_value], axis=0)
            hist = tf.compat.v1.histogram_fixed_width(inputs[0],
                                                      range_tensor,
                                                      nbins=128)
            cdf = tf.compat.v1.cumsum(hist)

            scale_d, offset_d = _CUSTOM_OP.IFMR(
                data=inputs[0],
                data_min=min_value,
                data_max=max_value,
                cumsum=cdf,
                min_percentile=quant_kwargs.get('min_percentile'),
                max_percentile=quant_kwargs.get('max_percentile'),
                search_range=quant_kwargs.get('search_range'),
                search_step=quant_kwargs.get('search_step'),
                with_offset=quant_kwargs.get('need_offset'))

            quant_factors = {'scale_d': scale_d, 'offset_d': offset_d}

            return quant_factors

        quant_factors = insert_ifmr()

        return inputs[1], quant_factors


def gen_act_calibration_op(inputs, enable, quant_kwargs):
    """ generate the act calibration operaion"""
    act_algo = quant_kwargs.get("act_algo", "ifmr")
    scale_d = None
    if act_algo == 'ifmr':
        scale_d, _ = _CUSTOM_OP.quant_ifmr(
            inputs[0],
            enable=enable,
            quant_bit_num=quant_kwargs.get('num_bits'),
            with_offset=quant_kwargs.get('need_offset'),
            max_percentile=quant_kwargs.get('max_percentile'),
            min_percentile=quant_kwargs.get('min_percentile'),
            search_range=quant_kwargs.get('search_range'),
            search_step=quant_kwargs.get('search_step'),
            batch_num=quant_kwargs.get('batch_num'),
            layer_names=quant_kwargs.get('quant_op_names'),
            record_file_path=quant_kwargs.get('record_file_name'),
            input_stamp=quant_kwargs.get('input_stamp'))
    if act_algo == 'hfmg':
        scale_d, _ = _CUSTOM_OP.quant_hfmg(
            inputs[0],
            enable=enable,
            quant_bit_num=quant_kwargs.get('num_bits'),
            with_offset=quant_kwargs.get('need_offset'),
            num_of_bins=quant_kwargs.get("num_of_bins"),
            batch_num=quant_kwargs.get('batch_num'),
            layer_names=quant_kwargs.get('quant_op_names'),
            record_file_path=quant_kwargs.get('record_file_name'),
            input_stamp=quant_kwargs.get('input_stamp'))
    return scale_d


def quantize_activation(inputs, context, quant_kwargs):
    """
    Function:Quantize inputs with the algorithm 'IFMR'.
    Inputs:
        inputs: a tensor to be quantized.
        context: a string, context for created nodes.
        quant_kwargs: a dictionary, including quantization parameters.
    Returns:
        act_identities: a list of identity.
        scale_d: a output tensor of the quant_ifmr op.
    """
    with tf.compat.v1.variable_scope(None,
                                     default_name=context + '_IFMR',
                                     values=[inputs[1]],
                                     reuse=None) as scope:
        scope.set_partitioner(None)

        def insert_act_calibration():
            '''Inserts the customized ifmr quantization op.'''
            scale_var = tf.compat.v1.get_variable(
                'scale',
                shape=[1],
                dtype=tf.compat.v1.float32,
                trainable=False,
                collections=[
                    tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                    tf.compat.v1.GraphKeys.MODEL_VARIABLES
                ],
                use_resource=False)

            batch_counter = tf.compat.v1.Variable(0.0,
                                                  name='batch_counter_switch',
                                                  trainable=False)
            one_value = 1.0
            decorated_tensors = _decorate_enter(inputs[0], scale_var,
                                                quant_kwargs.get('quant_op_names')[0],
                                                batch_counter, one_value)
            scale_d = gen_act_calibration_op(inputs, decorated_tensors.enable, quant_kwargs)
            assign_scale = tf.compat.v1.assign(
                decorated_tensors.quant_var, tf.compat.v1.reshape(scale_d, decorated_tensors.quant_var_shape))
            assign_batch_counter = tf.compat.v1.assign_add(
                decorated_tensors.batch_counter, decorated_tensors.one_value)
            return ActCaliTensors._make([scale_d, assign_scale, assign_batch_counter, decorated_tensors.batch_counter])

        cali_tensors = insert_act_calibration()

        with tf.compat.v1.control_dependencies([cali_tensors.assign_scale, cali_tensors.assign_batch_counter]):
            # Build graph structures for quantization.
            op_list = tf.compat.v1.cond(
                tf.compat.v1.less(cali_tensors.batch_counter,
                                  1.0 * quant_kwargs.get('batch_num')),
                lambda: _print_store_act_calibration(quant_kwargs, cali_tensors.batch_counter),
                lambda: _print_success_act_calibration(quant_kwargs))
        if not isinstance(op_list, list):
            op_list = [op_list]

        act_identities = []
        with tf.compat.v1.control_dependencies(op_list):
            for act in inputs[1]:
                act_identity = tf.compat.v1.identity(act)
                act_identities.append(act_identity)
        return act_identities, cali_tensors.scale_d


def _print_store_act_calibration(quant_kwargs, batch_counter):
    """
    Function: Print the process information of ifmr saving data.
    Inputs:
        quant_kwargs: a dictionary, including quantization parameters.
        batch_counter: a tensor, record the current batch number.
    Returns:
        op_list: an op list of printing info.
    """
    op_list = []
    if quant_kwargs.get("act_algo") is None:
        act_algo = 'ifmr'
    else:
        act_algo = quant_kwargs.get("act_algo")
    for quant_op in quant_kwargs.get('quant_op_names'):
        print_op = tf.compat.v1.print(
            'Doing layer: "%s" calibration with %s, already preprocess' % (
                quant_op, act_algo),
            batch_counter,
            'batches, %s(batch_num) batches are needed '
            'in total.' % (quant_kwargs.get('batch_num')),
            output_stream=tf.compat.v1.logging.info)
        op_list.append(print_op)
    return op_list


def _print_success_act_calibration(quant_kwargs):
    """
    Function: Print the information of calibration success.
    Inputs:
        quant_kwargs: a dictionary, including quantization parameters.
    Returns:
        op_list: an op list of printing info.
    """
    op_list = []
    if quant_kwargs.get("act_algo") is None:
        act_algo = 'ifmr'
    else:
        act_algo = quant_kwargs.get("act_algo")
    for quant_op in quant_kwargs.get('quant_op_names'):
        print_op = tf.compat.v1.print(
            'Do layer {} activation calibration with {} success!'.format(
                quant_op, act_algo), output_stream=tf.compat.v1.logging.info)
        op_list.append(print_op)
    return op_list


def gen_search_n_op(inputs, enable, quant_kwargs):
    """ generate the searchn operator"""
    do_searchn = True if quant_kwargs.get('do_searchn') is None else quant_kwargs.get('do_searchn')
    searchn_version = quant_kwargs.get('searchn_version', 'V1')
    shift_n = None
    if searchn_version == 'V1':
        shift_n = _CUSTOM_OP.search_n(
            inputs[0],
            enable=enable,
            scale_d=quant_kwargs.get('act_cali_output'),
            scale_w=quant_kwargs.get('wgt_cali_output'),
            shift_n_length=quant_kwargs.get('shift_n_length'),
            channel_wise=quant_kwargs.get('channel_wise'),
            data_format=quant_kwargs.get('data_format'),
            batch_num=quant_kwargs.get('batch_num'),
            layer_names=quant_kwargs.get('quant_op_names'),
            record_file_path=quant_kwargs.get('record_file_name'),
            retrain_group=bool(quant_kwargs.get('retrain_group')),
            do_searchn=do_searchn)
    if searchn_version == 'V2':
        shift_n = _CUSTOM_OP.search_nv2(
            inputs[0],
            enable=enable,
            scale_d=quant_kwargs.get('act_cali_output'),
            scale_w=quant_kwargs.get('wgt_cali_output'),
            shift_n_length=quant_kwargs.get('shift_n_length'),
            channel_wise=quant_kwargs.get('channel_wise'),
            data_format=quant_kwargs.get('data_format'),
            batch_num=quant_kwargs.get('batch_num'),
            layer_names=quant_kwargs.get('quant_op_names'),
            layer_types=quant_kwargs.get('quant_op_types'),
            record_file_path=quant_kwargs.get('record_file_name'),
            retrain_group=bool(quant_kwargs.get('retrain_group')),
            do_searchn=do_searchn)
    return shift_n


def search_n(inputs, context, quant_kwargs):
    """
    Function:Quantize output with the algorithm search_n.
    Inputs:
        inputs: a tensor to be quantized.
        context: a string, context for created nodes.
        quant_kwargs: a dictionary, including quantization parameters.
    Returns:
        input_indeties: a list of identity.
        shift_n: a output tensor of the search_n op.
    """
    with tf.compat.v1.variable_scope(None,
                                     default_name=context + '_SEARCHN',
                                     values=[inputs[1]],
                                     reuse=None) as scope:
        scope.set_partitioner(None)

        def insert_searchn():
            '''Inserts the customized searchn quantization op.'''
            shift_n_var = tf.compat.v1.get_variable(
                'shift_n',
                shape=[quant_kwargs.get('shift_n_length')],
                dtype=tf.compat.v1.float32,
                trainable=False,
                collections=[
                    tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                    tf.compat.v1.GraphKeys.MODEL_VARIABLES
                ],
                use_resource=False)
            batch_counter = tf.compat.v1.get_variable(
                'batch_counter_switch',
                dtype=tf.compat.v1.float32,
                trainable=False,
                initializer=0.0,
                collections=[
                    tf.compat.v1.GraphKeys.GLOBAL_VARIABLES,
                    tf.compat.v1.GraphKeys.MODEL_VARIABLES
                ])
            one_value = 1.0
            decorated_tensors = _decorate_enter(
                inputs[0], shift_n_var,
                quant_kwargs.get('quant_op_names')[0],
                batch_counter, one_value)
            shift_n = gen_search_n_op(inputs, decorated_tensors.enable, quant_kwargs)
            assign_shiftn = tf.compat.v1.assign(
                decorated_tensors.quant_var, tf.compat.v1.reshape(shift_n, decorated_tensors.quant_var_shape))
            assign_batch_counter = tf.compat.v1.assign_add(
                decorated_tensors.batch_counter, decorated_tensors.one_value)
            return SearchNTensors._make(
                [shift_n, assign_shiftn, assign_batch_counter, decorated_tensors.batch_counter])

        search_n_tensors = insert_searchn()

        with tf.compat.v1.control_dependencies([search_n_tensors.assign_shiftn, search_n_tensors.assign_batch_counter]):
            # print data store info.
            op_list = tf.compat.v1.cond(
                tf.compat.v1.less(search_n_tensors.batch_counter,
                                  1.0 * quant_kwargs.get('batch_num')),
                lambda: _print_store_searchn(quant_kwargs, search_n_tensors.batch_counter),
                lambda: _print_success_searchn(quant_kwargs))

        if not isinstance(op_list, list):
            op_list = [op_list]

        input_indeties = []

        inputs_act = inputs[0].graph.get_operation_by_name(quant_kwargs.get('quant_op_names')[0]).inputs
        info_length = 0
        if len(inputs_act) > 1:
            info_length, _, _, _ = GraphChecker.get_dependency_enter_info(inputs_act[1].op)

        with tf.compat.v1.control_dependencies(op_list):
            for shift_n_input in inputs[1]:
                shift_n_input_identity = tf.compat.v1.identity(
                    _CUSTOM_OP.transparent(shift_n_input))
                if info_length and quant_kwargs.get('is_retrain_node', False):
                    shift_n_input_identity = tf.compat.v1.raw_ops.Exit(data=shift_n_input_identity)
                input_indeties.append(shift_n_input_identity)
        return input_indeties, search_n_tensors.shift_n


def _print_store_searchn(quant_kwargs, batch_counter):
    """
    Function: Print the process information of searchn saving data.
    Inputs:
        quant_kwargs: a dictionary, including quantization parameters.
        batch_counter: a tensor, record the current batch number.
    Returns:
        op_list: an op list of printing info.
    """
    op_list = []
    for quant_op in quant_kwargs.get('quant_op_names'):
        with tf.compat.v1.device('/cpu:0'):
            print_op = tf.compat.v1.print(
                'Doing layer: "%s" search_n_%s, already preprocess' % (
                    quant_op, quant_kwargs.get("searchn_version", "V1")),
                batch_counter,
                'batches, %s(batch_num) batches are needed'
                ' in total.' % (quant_kwargs.get('batch_num')),
                output_stream=tf.compat.v1.logging.info)
        op_list.append(print_op)
    return op_list


def _print_success_searchn(quant_kwargs):
    """
    Function: Print the information of searchn success.
    Inputs:
        quant_kwargs: a dictionary, including quantization parameters.
    Returns:
        op_list: an op list of printing info.
    """
    op_list = []
    for quant_op in quant_kwargs.get('quant_op_names'):
        with tf.compat.v1.device('/cpu:0'):
            print_op = tf.compat.v1.print(
                'Do layer {} activation search_n_{} success!'.format(
                    quant_op, quant_kwargs.get("searchn_version", "V1")),
                output_stream=tf.compat.v1.logging.info)
        op_list.append(print_op)
    return op_list


def _quant_inputs_by_scale(inputs, scale, num_bits=8):
    """
    Function: Quantize input data based on optimal quantization factor scale.
    Inputs:
        inputs: a tensor to be quantized.
        scale: a tensor, quantization factor scale.
        num_bits: a number, indicating the bit for quantization.
    Returns:
        outputs: a tensor quantized.
    """
    if num_bits not in [4, 8]:
        raise ValueError("unsupported quantization bit width: %d" % num_bits)
    ori_type = inputs.dtype
    half_stage = 2**(num_bits - 1)
    inputs_div = tf.compat.v1.divide(tf.compat.v1.cast(inputs, scale.dtype), scale)
    inputs_round = tf.compat.v1.round(inputs_div)
    left_bound = tf.compat.v1.constant(-half_stage, dtype=tf.compat.v1.float32)
    right_bound = tf.compat.v1.constant(half_stage - 1,
                                        dtype=tf.compat.v1.float32)

    inputs_quant = tf.compat.v1.clip_by_value(inputs_round, left_bound,
                                              right_bound)
    outputs = tf.compat.v1.cast(tf.compat.v1.multiply(inputs_quant, scale), ori_type)
    return outputs


def _decorate_enter(input_tensor,
                    quant_var,
                    op_name,
                    batch_counter=None,
                    one_value=None):
    """
    Function: use enter to modify the input parameters.
    Inputs:
        input_tensor: a tensor, data or weight tensor.
        quant_var: a tensor, the quantization factor storage variable.
        op_name: a string, the name of the op to be quantified.
        batch_counter: a tensor, recording the number of batches.
        one_value: a tensor, initial value of the batch counter.
    Returns:
        enable: a tensor, customizing op enable variable.
        quant_var: a tensor, modified quant_var
        quant_var_shape: a list, modified quant_var_shape
        batch_counter: a tensor, modified batch_counter
        one_value: a tensor, modified one_value
    """
    try:
        inputs = input_tensor.graph.get_operation_by_name(op_name).inputs
    except ValueError:
        inputs = input_tensor.graph.get_operation_by_name(op_name.split(':')[0]).inputs
    quant_var_shape = quant_var.shape
    enable = tf.compat.v1.Variable([], name='enable', trainable=False)
    if len(inputs) > 1:
        info_length, frame_name, is_constant, parallel_iterations = \
            GraphChecker.get_dependency_enter_info(inputs[1].op)
        if info_length:
            enable = gen_control_flow_ops.enter(
                enable,
                frame_name=frame_name,
                is_constant=is_constant,
                parallel_iterations=parallel_iterations)
            quant_var = gen_control_flow_ops.ref_enter(
                quant_var,
                frame_name=frame_name,
                is_constant=is_constant,
                parallel_iterations=parallel_iterations)
            quant_var_shape = gen_control_flow_ops.enter(
                quant_var_shape,
                frame_name=frame_name,
                is_constant=is_constant,
                parallel_iterations=parallel_iterations)
            if (batch_counter is not None) and (one_value is not None):
                batch_counter = gen_control_flow_ops.ref_enter(
                    batch_counter,
                    frame_name=frame_name,
                    is_constant=is_constant,
                    parallel_iterations=parallel_iterations)
                one_value = gen_control_flow_ops.enter(
                    one_value,
                    frame_name=frame_name,
                    is_constant=is_constant,
                    parallel_iterations=parallel_iterations)
    enable = tf.cast(enable, input_tensor.dtype)
    return DecoratedTensors._make([enable, quant_var, quant_var_shape, batch_counter, one_value])


def insert_dump(input_tensor, context, dump_config):
    """ Insert dump for input_tensor with dump_config.

    Args:
        input_tensor (tf.tensor): insert dump op after it.
        context (string): the scope
        dump_config (dict): config to do dump, including necessary params

    Returns:
        tf.tensor: dump op's output tensor
    """
    with tf.compat.v1.variable_scope(None,
                                     default_name=context,
                                     values=[input_tensor],
                                     reuse=None) as scope:
        scope.set_partitioner(None)
        output_tensor = _CUSTOM_OP.dump(input_tensor, dump_dir=dump_config['dump_dir'],
                                        name_prefix=dump_config['name_prefix'], batch_num=dump_config['batch_num'])

    return output_tensor
