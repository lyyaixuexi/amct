#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

amct_tensorflow command line tool core funtions.

"""

import os
import sys
import importlib
import copy
import shutil

import tensorflow as tf

import amct_tensorflow as amct
import amct_tensorflow.cmd_line_tools.parser_args as parser_args
import amct_tensorflow.common.cmd_line_utils.arguments_handler as args_handler
from amct_tensorflow.common.cmd_line_utils.data_handler import tmp_dir
from amct_tensorflow.common.cmd_line_utils.data_handler import delete_tmp_dir
import amct_tensorflow.common.cmd_line_utils.data_handler as data_handler
from amct_tensorflow.utils.utils_vars import OP_APPROXIMATION_TYPES
from amct_tensorflow.common.utils import files as files_util
from amct_tensorflow.configuration.configuration import Configuration
from amct_tensorflow.interface.operation_approximator import create_approx_calibrator_impl
from amct_tensorflow.interface.save_approximation_graph import save_appro_graph_impl
from amct_tensorflow.interface.save_model import generate_name
from amct_tensorflow.configuration.get_layers import OpSelector
from amct_tensorflow.utils.log import LOGGER


class Evaluator(amct.CalibrationEvaluatorBase):
    '''
    Evaluator: default evaluator.
    '''
    def __init__(self, args_var, batch_num):
        super().__init__()
        self.input_shape = {}
        for key, val in args_var.input_shape.items():
            self.input_shape[key + ':0'] = val
        self.data_dir = args_var.data_dir
        self.data_types = args_var.data_types
        self.batch_num = batch_num

    def calibration(self, graph, outputs):
        '''
        Function: calibration
        '''
        with graph.as_default():
            with tf.compat.v1.Session(config=tf.compat.v1.ConfigProto(allow_soft_placement=True)) as sess:
                sess.run(tf.compat.v1.global_variables_initializer())
                infer_output = outputs
                for data_map in data_handler.load_data(
                    self.input_shape,
                    self.data_dir,
                    self.data_types,
                    self.batch_num):
                    _ = sess.run(infer_output, feed_dict=data_map)


def load_pb(model_name):
    '''
    Function: Load pb model in the given path to tf.GraphDef
    Arguments:
        model_name: the path to the pb model
    Return: None
    '''
    tf.compat.v1.reset_default_graph()
    with tf.compat.v1.gfile.FastGFile(model_name, 'rb') as file:
        graph_def = tf.compat.v1.GraphDef()
        graph_def.ParseFromString(file.read())
        tf.compat.v1.import_graph_def(graph_def, name='')


def get_node_names(graph, tensor_names):
    '''
    Function: Get the node(op) names of the tensor_names in the given graph.
    Arguments:
        graph: tf.Graph, the graph of the model
        tensor_names: list of str, the names of tensors
    Return:
        op_names: list of str, the corresponding op names of the given tensor_names
    '''
    op_names = list()
    for name in tensor_names:
        tensor_name = graph.get_tensor_by_name(name).op.name
        op_names.append(tensor_name)
    return op_names


def approximate_function(args_var, save_dir, output_nodes):
    '''
    Function: Replace op with approximate implementation.
    Arguments:
        args_var: the parsed arguments to run calibration
        save_dir: approximate pb save dir
        output_nodes: a list of output node name
    Return:
        approximate_pb: approximate pb save path
    '''
    graph = tf.compat.v1.get_default_graph()
    approx_config = Configuration.create_appoximate_config(graph,
        batch_num=args_var.batch_num, config_defination=args_var.calibration_config)

    create_approx_calibrator_impl(graph, approx_config)
    eval_function(args_var, output_nodes, int(approx_config['batch_num']))

    files_util.create_path(save_dir)
    save_dir = os.path.realpath(save_dir)
    approximate_pb = save_appro_graph_impl(graph, output_nodes, save_dir + '/', approx_config)
    return approximate_pb


def eval_function(args_var, output_nodes, batch_num):
    '''
    Function: Eval graph
    Arguments:
        args_var: the parsed arguments to run calibration
        output_nodes: a list of output node name
    Return: None
    '''
    if args_var.evaluator is not None:
        if not os.path.exists(args_var.evaluator):
            raise RuntimeError("evaluator file '{}' not exists!".format(args_var.evaluator))
        evaluator_path, evaluator_file = os.path.split(args_var.evaluator)
        sys.path.append(evaluator_path)
        evaluator = importlib.import_module(evaluator_file.split('.')[0])

        evaluator = evaluator.customize_evaluator
    else:
        evaluator = Evaluator(args_var, batch_num)

    graph = tf.compat.v1.get_default_graph()
    evaluator.calibration(graph, output_nodes)


def approximate_is_enabled(args_var):
    "whether approximate feature is enabled"
    return 'approximate' in args_var.feature


def ptq_is_enabled(args_var):
    "whether ptq feature is enabled"
    return 'ptq' in args_var.feature


def save_approximate_pb(args_var, approximate_pb):
    "copy approximate_pb to dest path"
    save_dir, save_prefix = files_util.split_save_path(args_var.save_path)
    files_util.create_path(save_dir)
    save_model_file = generate_name(save_dir, save_prefix)
    files_util.check_files_exist([save_model_file])
    shutil.copyfile(approximate_pb, save_model_file)


def check_dmq_balancer(graph, config_file):
    '''
    Function: check if config_file indicates dmq_balancer
    Arguments:
        graph: tf.Graph
        config_file: string, config file path
    Return: True if config_file indicates dmq_balancer, False otherwise
    '''
    quant_config = Configuration.parse_config_file(config_file, graph)
    dmq_balancer_enable = False
    for key, _ in quant_config.items():
        if not isinstance(quant_config[key], dict):
            continue
        if quant_config[key].get("dmq_balancer_param"):
            dmq_balancer_enable = True
            break
    return dmq_balancer_enable


def calibration_function(args_var):
    '''
    Function: run amct calibration process
    Arguments:
        args_var: the parsed arguments to run calibration
    Return: None
    '''

    args_handler.calibration_args_checker(args_var)

    tmp = tmp_dir()
    config_file = os.path.join(tmp, 'quant_config.json')
    record_file = os.path.join(tmp, 'record.txt')
    load_pb(args_var.model)

    try:
        output_nodes = get_node_names(tf.compat.v1.get_default_graph(), args_var.outputs)

        if approximate_is_enabled(args_var):
            approximate_pb = approximate_function(args_var, tmp, output_nodes)
            args_var.model = approximate_pb
            load_pb(approximate_pb)
            if not ptq_is_enabled(args_var):
                save_approximate_pb(args_var, approximate_pb)

        if ptq_is_enabled(args_var):
            amct.create_quant_config(
                config_file=config_file,
                graph=tf.compat.v1.get_default_graph(),
                batch_num=args_var.batch_num,
                config_defination=args_var.calibration_config)
            graph = tf.compat.v1.get_default_graph()
            batch_num = int(Configuration.parse_config_file(config_file, graph)['batch_num'])

            output_node_names = copy.deepcopy(output_nodes)
            if check_dmq_balancer(tf.compat.v1.get_default_graph(), config_file):
                amct.quantize_preprocess(
                    graph=tf.compat.v1.get_default_graph(),
                    config_file=config_file,
                    record_file=record_file,
                    outputs=output_nodes
                )
                eval_function(args_var, output_nodes, 1)
                load_pb(args_var.model)
            amct.quantize_model(
                graph=tf.compat.v1.get_default_graph(),
                config_file=config_file,
                record_file=record_file,
                calib_outputs=output_nodes)

            eval_function(args_var, output_nodes, batch_num)

            amct.save_model(
                pb_model=args_var.model,
                outputs=output_node_names,
                record_file=record_file,
                save_path=args_var.save_path)
    finally:
        delete_tmp_dir(tmp)


def convert_function(args_var):
    '''
    Function: run amct convert model process
    Arguments:
        args_var: the parsed arguments to run calibration
    Return: None
    '''
    try:
        tmp = tmp_dir()
        record_file = os.path.join(tmp, 'record.txt')

        load_pb(args_var.model)
        output_node_names = get_node_names(tf.compat.v1.get_default_graph(), args_var.outputs)

        amct.convert_qat_model(
            pb_model=args_var.model,
            outputs=output_node_names,
            save_path=args_var.save_path,
            record_file=record_file)
    finally:
        delete_tmp_dir(tmp)


def main():
    '''
    Function: main function for amct_tensorflow command line tools.
    '''
    args = parser_args.ParserArgs()
    args_var = args.parse_args()

    if args_var.command == 'calibration':
        calibration_function(args_var)
    elif args_var.command == 'convert':
        convert_function(args_var)


if __name__ == '__main__':
    main()
