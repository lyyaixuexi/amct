/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define QuantIfmr Operator Forward Operation on CPU
 *
 * @file ifmr.cc
 *
 * @version 1.0
 */

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "mask.h"
#include "initializer.h"
#include "common.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "util.h"

using namespace tensorflow;

namespace AmctTfOp {
template <typename Device, typename T>
class MaskOp : public OpKernel {
public:
    explicit MaskOp(OpKernelConstruction* context) : OpKernel(context)
    {
        Initializer::GetInstance().Init();
        maskParam.size = 0;
        maskParam.inChannelWidth = 0;
        maskParam.outChannelWidth = 0;
        maskParam.innerJumpsIn = 1;
        maskParam.innerJumpsOut = 1;
    }

    ~MaskOp() override {}

    void Compute(OpKernelContext* context) override
    {
        // Grab the input tensor
        const Tensor& maskTensor = context->input(MASK_INDEX);
        const Tensor& inputTensor = context->input(WEIGHT_INDEX);
        auto maskFlat = maskTensor.flat<T>();
        auto inputFlat = inputTensor.flat<T>();
        OP_REQUIRES(context, inputFlat.size() <= tensorflow::kint32max,
            errors::InvalidArgument("Too many elements in input tensor"));
        maskParam.size = inputFlat.size();
        if (maskParam.size == 0) {
            OP_REQUIRES(context, false, errors::InvalidArgument("MaskOp: inputTensor is empty!"));
        }
        // Create masked output
        Tensor* outputTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(0, inputTensor.shape(), &outputTensor));

        // Compute jump
        maskParam.innerJumpsIn = 1;
        maskParam.innerJumpsOut = 1;
        int inOffset = 2;
        int inChannelAxis = inputTensor.dims() - inOffset;
        int outChannelAxis = inputTensor.dims() - 1;
        for (int axis = inputTensor.dims() - 1; axis > inChannelAxis; --axis) {
            maskParam.innerJumpsIn *= inputTensor.dim_size(axis);
        }
        maskParam.inChannelWidth = inputTensor.dim_size(inChannelAxis);
        maskParam.outChannelWidth = inputTensor.dim_size(outChannelAxis);
        if (maskParam.inChannelWidth == 0 || maskParam.outChannelWidth == 0) {
            OP_REQUIRES(context, false, errors::InvalidArgument("Tensor's dimension is zero."));
        }
        int errorCode = MaskOut<Device, T>()(maskParam, maskFlat.data(), inputFlat.data(),
            outputTensor->flat<T>().data());
        ERROR_CHECK(errorCode);
    }
private:
    struct MaskParam maskParam;
};
}

REGISTER_KERNEL_BUILDER(Name("Mask").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::MaskOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("Mask").Device(DEVICE_CPU).TypeConstraint<double>("T"),
    AmctTfOp::MaskOp<util::CPUDevice, double>);

#ifdef GOOGLE_CUDA
extern template struct AmctTfOp::MaskOut<util::GPUDevice, float>;
REGISTER_KERNEL_BUILDER(Name("Mask").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::MaskOp<util::GPUDevice, float>);
extern template struct AmctTfOp::MaskOut<util::GPUDevice, double>;
REGISTER_KERNEL_BUILDER(Name("Mask").Device(DEVICE_GPU).TypeConstraint<double>("T"),
    AmctTfOp::MaskOp<util::GPUDevice, double>);
#endif

REGISTER_OP("Mask")
    .Attr("T: {float, double}")
    .Input("wgt_input: T")
    .Input("mask: T")
    .Output("masked_wgt: T")
    .SetShapeFn([](::tensorflow::shape_inference::InferenceContext* c) {
        c->set_output(0, c->input(0));
        return tensorflow::Status::OK();
    });
