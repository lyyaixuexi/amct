/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief quant custom op C++ implement. now it has no real quant behaviours.
 *
 * @file quant.cc
 *
 * @version 1.0
 */


#include <cmath>
#include <algorithm>

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "record_scale_offset.h"
#include "ifmr_kernel.h"
#include "arq_kernel.h"
#include "initializer.h"
#include "common.h"
#include "tf_error_check.h"
#include "error_codes.h"

using namespace tensorflow;

namespace AmctTfOp {
template <typename Device, typename T>
class RecordScaleOffsetOp : public OpKernel {
public:
    explicit RecordScaleOffsetOp(OpKernelConstruction* context) : OpKernel(context)
    {
        Initializer::GetInstance().Init();
        OP_REQUIRES_OK(context, context->GetAttr("layer_names", &layerNames));
        OP_REQUIRES_OK(context, context->GetAttr("record_file_path", &recordFilePath));
        OP_REQUIRES_OK(context, context->GetAttr("scale_w_length", &scaleWLength));
        OP_REQUIRES_OK(context, context->GetAttr("is_training", &isTraining));
        OP_REQUIRES_OK(context, context->GetAttr("dst_type", &dstType));
        scaleDCpu.resize(1);
        offsetDCpu.resize(1);
        scaleWCpu.resize(scaleWLength);
        offsetWCpu.resize(scaleWLength);
        dataQuantParam.scale = nullptr;
        dataQuantParam.offset = nullptr;
        dataQuantParam.scaleCpu = nullptr;
        dataQuantParam.offsetCpu = nullptr;
        weightQuantParam.scale = nullptr;
        weightQuantParam.offset = nullptr;
        weightQuantParam.scaleCpu = nullptr;
        weightQuantParam.offsetCpu = nullptr;
        weightQuantParam.scaleWLength = scaleWLength;
        bnParam.scale = nullptr;
        bnParam.variance = nullptr;
        bnParam.epsilon = nullptr;
        bnParam.mul = nullptr;
    }

    ~RecordScaleOffsetOp() override {}

    void Compute(OpKernelContext* context) override
    {
        Tensor scaleD = context->input(SCALED_INDEX);
        Tensor offsetD = context->input(OFFSETD_INDEX);
        Tensor scaleW = context->input(SCALEW_INDEX);
        Tensor offsetW = context->input(OFFSETW_INDEX);
        Tensor scale = context->input(SCALE_INDEX);
        Tensor variance = context->input(VARIANCE_INDEX);
        Tensor epsilon = context->input(EPSILON_INDEX);
        Tensor mul = context->input(MUL_INDEX);

        // create output tensor.
        Tensor* scaleDOut = nullptr;
        Tensor* scaleWOut = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(RECORD_SCALED_OUT_INDEX, scaleD.shape(), &scaleDOut));
        OP_REQUIRES_OK(context, context->allocate_output(RECORD_SCALEW_OUT_INDEX, scaleW.shape(), &scaleWOut));

        dataQuantParam.scaleCpu = scaleDCpu.data();
        dataQuantParam.offsetCpu = offsetDCpu.data();
        dataQuantParam.scale = scaleD.flat<float>().data();
        dataQuantParam.offset = offsetD.flat<int>().data();

        bnParam.scale = scale.flat<float>().data();
        bnParam.variance = variance.flat<float>().data();
        bnParam.epsilon = epsilon.flat<float>().data();
        bnParam.mul = mul.flat<float>().data();

        weightQuantParam.scaleCpu = scaleWCpu.data();
        weightQuantParam.offsetCpu = offsetWCpu.data();
        weightQuantParam.scale = scaleW.flat<float>().data();
        weightQuantParam.offset = offsetW.flat<int>().data();

        if (isTraining) {
            ERROR_CHECK(AmctCommon::TRAINING_ERROR);
        }
        float* scaleDOutPtr = scaleDOut->flat<float>().data();
        float* scaleWOutPtr = scaleWOut->flat<float>().data();
        int errorCode = CopyDataToHost<Device, T>()(
            dataQuantParam, weightQuantParam, bnParam, scaleDOutPtr, scaleWOutPtr);
        ERROR_CHECK(errorCode);
        for (unsigned int i = 0; i < layerNames.size(); i++) {
            ERROR_CHECK(WriteDataToRecordFile(dataQuantParam.scaleCpu, dataQuantParam.offsetCpu,
                layerNames[i], recordFilePath.c_str(), dstType));
            int perScaleLength = weightQuantParam.scaleWLength / layerNames.size();
            ERROR_CHECK(WriteWeightToRecordFile(weightQuantParam.scaleCpu + i * perScaleLength,
                weightQuantParam.offsetCpu + i * perScaleLength, perScaleLength, layerNames[i],
                recordFilePath.c_str()));
        }
    }

private:
    struct RetrainDataQuantParam dataQuantParam;
    struct RetrainWeightQuantParam weightQuantParam;
    struct BnParam bnParam;
    std::vector<std::string> layerNames;
    std::string recordFilePath = "record_file_path_init";
    std::string dstType;
    std::vector<float> scaleDCpu;
    std::vector<int> offsetDCpu;
    std::vector<float> scaleWCpu;
    std::vector<int> offsetWCpu;
    int scaleWLength;
    bool isTraining;
};
}

// Register the CPU kernels.
REGISTER_KERNEL_BUILDER(Name("RecordScaleOffset").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::RecordScaleOffsetOp<util::CPUDevice, float>);

// Register the GPU kernels.
#ifdef GOOGLE_CUDA
extern template struct AmctTfOp::CopyDataToHost<util::GPUDevice, float>;
REGISTER_KERNEL_BUILDER(Name("RecordScaleOffset").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::RecordScaleOffsetOp<util::GPUDevice, float>);
#endif  // GOOGLE_CUDA


REGISTER_OP("RecordScaleOffset")
    .Attr("T: {float16, float32, float64}")
    .Attr("layer_names: list(string)")
    .Attr("record_file_path: string")
    .Attr("scale_w_length: int")
    .Attr("is_training: bool = false")
    .Attr("dst_type: string = 'INT8'")
    .Input("scale_d: float32")
    .Input("offset_d: int32")
    .Input("scale_w: float32")
    .Input("offset_w: int32")
    .Input("scale: float32")
    .Input("variance: float32")
    .Input("epsilon: float32")
    .Input("mul: float32")
    .Output("scale_d_out: T")
    .Output("scale_w_out: T")
    .SetShapeFn([](shape_inference::InferenceContext* c)
    {
        c->set_output(AmctTfOp::RECORD_SCALED_OUT_INDEX, c->input(AmctTfOp::SCALED_INDEX));
        c->set_output(AmctTfOp::RECORD_SCALEW_OUT_INDEX, c->input(AmctTfOp::SCALEW_INDEX));

        return tensorflow::Status::OK();
    })
    .Doc(R"doc(RecordScaleOffset algorithm.)doc");
