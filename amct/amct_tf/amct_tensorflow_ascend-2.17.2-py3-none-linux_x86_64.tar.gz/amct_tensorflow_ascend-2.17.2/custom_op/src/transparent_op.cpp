/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define Transparent Operator Forward Operation on CPU
 *
 * @file transparent.cc
 *
 * @version 1.0
 */

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "transparent.h"
#include "initializer.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "util.h"

using namespace tensorflow;

namespace AmctTfOp {
template <typename T>
int TransparentInternelCpu(const T* inputData, T* outputData, const int size)
{
#pragma omp parallel for
    for (int i = 0; i < size; i++) {
        outputData[i] = inputData[i];
    }
    return AmctCommon::SUCCESS;
}

// CPU specialization of actual computation.
template <typename T>
struct TransparentFunctor<util::CPUDevice, T> {
    int operator()(const T* inputData, T* outputData, const int size)
    {
        CHECK_OK(TransparentInternelCpu(inputData, outputData, size));
        return AmctCommon::SUCCESS;
    }
};

// OpKernel definition.
// template parameter <T> is the datatype of the tensors.
template <typename Device, typename T>
class TransparentOp : public OpKernel {
public:
    explicit TransparentOp(OpKernelConstruction* context) : OpKernel(context) {}

    ~TransparentOp() override {}

    void Compute(OpKernelContext* context) override
    {
        // Grab the input tensor
        const Tensor& inputTensor = context->input(0);

        int size = static_cast<int>(inputTensor.NumElements());

        // Create an output tensor
        Tensor* outputTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(0, inputTensor.shape(), &outputTensor));

        // Do the computation.
        OP_REQUIRES(context, inputTensor.NumElements() <= tensorflow::kint32max,
            errors::InvalidArgument("Too many elements in tensor"));
        int dataBytes = sizeof(T) * size;
        int errorCode = TransparentFunctor<Device, uint8_t>()(
            reinterpret_cast<const uint8_t*>(inputTensor.flat<T>().data()),
            reinterpret_cast<uint8_t*>(outputTensor->flat<T>().data()), dataBytes);
        ERROR_CHECK(errorCode);
    }
};
}

// Register the CPU kernels.
REGISTER_KERNEL_BUILDER(Name("Transparent").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::TransparentOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("Transparent").Device(DEVICE_CPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::TransparentOp<util::CPUDevice, Eigen::half>);

// Register the GPU kernels.
#ifdef GOOGLE_CUDA
extern template struct AmctTfOp::TransparentFunctor<util::GPUDevice, uint8_t>;
REGISTER_KERNEL_BUILDER(Name("Transparent").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::TransparentOp<util::GPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("Transparent").Device(DEVICE_GPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::TransparentOp<util::GPUDevice, Eigen::half>);
#endif  // GOOGLE_CUDA


REGISTER_OP("Transparent")
    .Attr("T: {float16, float32, float64}")
    .Input("x: T")
    .Output("y: T")
    .SetShapeFn([](::tensorflow::shape_inference::InferenceContext* c) {
        c->set_output(0, c->input(0));
        return tensorflow::Status::OK();
    });