/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define QuantIfmr Operator Forward Operation on CPU
 *
 * @file ifmr.cc
 *
 * @version 1.0
 */

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "fast_softmax_op.h"
#include "initializer.h"
#include "common.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "util.h"

using namespace tensorflow;

namespace AmctTfOp {
template <typename Device, typename T>
class FastSoftmaxOp : public OpKernel {
public:
    explicit FastSoftmaxOp(OpKernelConstruction* context) : OpKernel(context)
    {
        Initializer::GetInstance().Init();
        OP_REQUIRES_OK(context, context->GetAttr("a", &a));
        OP_REQUIRES_OK(context, context->GetAttr("b", &b));
        OP_REQUIRES_OK(context, context->GetAttr("clip_value", &clipValue));
        softmaxParam.a = a;
        softmaxParam.b = b;
        softmaxParam.clipValue = clipValue;
        softmaxParam.axis = -1;
        softmaxParam.numDimensions = 0;
        softmaxParam.logitSize = 0;
        softmaxParam.logitShape = nullptr;
    }

    ~FastSoftmaxOp() override {}

    void Compute(OpKernelContext* context) override
    {
        // Grab the input tensor
        const Tensor& logitsTensor = context->input(0);
        auto logitsFlat = logitsTensor.flat<T>();

        // Check axis and input shape
        softmaxParam.numDimensions = logitsTensor.shape().dims();
        if (softmaxParam.axis == -1) {
            softmaxParam.axis = softmaxParam.numDimensions - 1;
        }
        softmaxParam.logitSize = logitsTensor.NumElements();
        std::vector<int> logitShape(softmaxParam.numDimensions, 0);
        for (int i = 0; i < softmaxParam.numDimensions; i++) {
            logitShape[i] = logitsTensor.shape().dim_sizes()[i];
        }
        softmaxParam.logitShape = logitShape.data();

        Tensor* outputTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(0, logitsTensor.shape(), &outputTensor));

        int errorCode = FastSoftmaxFunctor<Device, T>()(
            logitsFlat.data(),
            outputTensor->flat<T>().data(),
            softmaxParam);
        ERROR_CHECK(errorCode);
    }

private:
    struct SoftmaxParam softmaxParam;
    float a = 1.0;
    float b = 1.0;
    float clipValue = -1.0;
};
}

REGISTER_KERNEL_BUILDER(Name("FastSoftmax").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::FastSoftmaxOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("FastSoftmax").Device(DEVICE_CPU).TypeConstraint<double>("T"),
    AmctTfOp::FastSoftmaxOp<util::CPUDevice, double>);

#ifdef GOOGLE_CUDA
REGISTER_KERNEL_BUILDER(Name("FastSoftmax").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::FastSoftmaxOp<util::GPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("FastSoftmax").Device(DEVICE_GPU).TypeConstraint<double>("T"),
    AmctTfOp::FastSoftmaxOp<util::GPUDevice, double>);
#endif

REGISTER_OP("FastSoftmax")
    .Attr("T: {float, double}")
    .Attr("a: float")
    .Attr("b: float")
    .Attr("clip_value: float")
    .Input("logits: T")
    .Output("output: T")
    .SetShapeFn([](::tensorflow::shape_inference::InferenceContext* c) {
        c->set_output(0, c->input(0));
        return tensorflow::Status::OK();
    });
