/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief anti_quant custom op C++ implement. now it has no real quant behaviours.
 *
 * @file anti_quant.cc
 *
 * @version 1.0
 */


#include <cmath>
#include <algorithm>

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "anti_quant.h"
#include "initializer.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "util.h"

using namespace tensorflow;
using namespace util;

namespace AmctTfOp {
template <typename Device, typename T>
class AntiQuantOp : public OpKernel {
public:
    explicit AntiQuantOp(OpKernelConstruction* context) : OpKernel(context)
    {
        OP_REQUIRES_OK(context, context->GetAttr("layer_name", &layerName));
    }

    ~AntiQuantOp() override {}

    void Compute(OpKernelContext* context) override
    {
        const Tensor& input = context->input(ANTI_DATA_IN_INDEX);
        auto inputFlat = input.flat<T>();
        const int inputSize = inputFlat.size();

        Tensor* outputZero = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(ANTI_DATA_OUT_INDEX, input.shape(), &outputZero));
        auto outputZeroFlat = outputZero->flat<T>();
        for (int i = 0; i < inputSize; i++) {
            outputZeroFlat(i) = inputFlat(i);
        }
    }

private:
    std::string layerName = "anti_quant_layer";
    int quantBits = EIGHT;
};
}

REGISTER_KERNEL_BUILDER(Name("AntiQuant").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::AntiQuantOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("AntiQuant").Device(DEVICE_CPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::AntiQuantOp<util::CPUDevice, Eigen::half>);

REGISTER_OP("AntiQuant")
    .Attr("T: {float16, float32, float64}")
    .Attr("layer_name: string")
    .Attr("scale: float")
    .Attr("offset: int")
    .Input("input: T")
    .Output("output: T")
    .SetShapeFn([](shape_inference::InferenceContext* c)
    {
        c->set_output(0, c->input(0));
        return tensorflow::Status::OK();
    })
    .Doc(R"doc(Anti quant algorithm.)doc");
