/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define QuantIfmr Operator Forward Operation on CPU
 *
 * @file ifmr.cc
 *
 * @version 1.0
 */

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "mask_generator.h"
#include "initializer.h"
#include "common.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "util.h"

using namespace tensorflow;

namespace AmctTfOp {
template <typename Device, typename T>
class MaskGenOp : public OpKernel {
public:
    explicit MaskGenOp(OpKernelConstruction* context) : OpKernel(context)
    {
        Initializer::GetInstance().Init();
        maskGenParam.inChannelWidth = 0;
        maskGenParam.outChannelWidth = 0;
        maskGenParam.weightSize = 0;
        maskGenParam.mask = nullptr;
        maskGenParam.maskCpu = nullptr;
    }

    ~MaskGenOp() override {}

    void Compute(OpKernelContext* context) override
    {
        // Grab the input tensor
        const Tensor& remainIn = context->input(0);
        const Tensor& remainOut = context->input(1);
        Tensor* mask = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(0,
            TensorShape({remainIn.NumElements(), remainOut.NumElements()}), &mask));

        maskGenParam.mask = mask->flat<T>().data();

        batchCounter++;
        if (batchCounter == 1) {
            int weightSize = mask->NumElements();
            maskGenParam.weightSize = weightSize;
            maskCpu.resize(weightSize);
            maskGenParam.maskCpu = maskCpu.data();

            maskGenParam.inChannelWidth = remainIn.NumElements();
            maskGenParam.outChannelWidth = remainOut.NumElements();

            int errorCode = GenerateMask<Device, T>()(remainIn.flat<T>().data(), remainOut.flat<T>().data(),
                maskGenParam);
            ERROR_CHECK(errorCode);
        } else {
            int errorCode = IdentityMask<Device, T>()(maskGenParam);
            ERROR_CHECK(errorCode);
        }
    }
private:
    int batchCounter = 0;
    struct MaskGenParam<T> maskGenParam;
    std::vector<T> maskCpu;
};
}

REGISTER_KERNEL_BUILDER(Name("MaskGen").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::MaskGenOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("MaskGen").Device(DEVICE_CPU).TypeConstraint<double>("T"),
    AmctTfOp::MaskGenOp<util::CPUDevice, double>);

#ifdef GOOGLE_CUDA
REGISTER_KERNEL_BUILDER(Name("MaskGen").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::MaskGenOp<util::GPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("MaskGen").Device(DEVICE_GPU).TypeConstraint<double>("T"),
    AmctTfOp::MaskGenOp<util::GPUDevice, double>);
#endif

REGISTER_OP("MaskGen")
    .Attr("T: {float, double}")
    .Input("remain_in_channels: T")
    .Input("remain_out_channels: T")
    .Output("mask: T")
    .SetShapeFn([](shape_inference::InferenceContext* c) {
        c->set_output(0, c->Matrix(c->NumElements(c->input(0)), c->NumElements(c->input(1))));
        return tensorflow::Status::OK();
    });
