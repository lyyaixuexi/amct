/*
* Copyright (c) Huawei Technologies Co., Ltd. 2023. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define DMQBalancer Operator Forward Operation on CPU&GPU
 *
 * @file dmq_balancer_op.cpp
 *
 * @version 1.0
 */

#include <sstream>
#include <vector>

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "dmq_balancer_kernel.h"
#include "initializer.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "common.h"
#include "util.h"
#include "cast_util.h"

using namespace tensorflow;
using namespace DMQBalancerKernel;

namespace AmctTfOp {
template <typename Device, typename T>
class DMQBalancerOp : public OpKernel {
public:
    explicit DMQBalancerOp(OpKernelConstruction* context) : OpKernel(context)
    {
        Initializer::GetInstance().Init();
        OP_REQUIRES_OK(context, context->GetAttr("migration_strength", &migrationStrength));
        OP_REQUIRES_OK(context, context->GetAttr("layer_name", &layerName));
        OP_REQUIRES_OK(context, context->GetAttr("record_file_path", &recordFilePath));
        param.migrationStrength = migrationStrength;
    }

    ~DMQBalancerOp() override {}

    void Compute(OpKernelContext* context) override
    {
        // get and check activation tensor
        const Tensor& actInput = context->input(0);
        OP_REQUIRES(context, actInput.NumElements() <= tensorflow::kint32max,
            errors::InvalidArgument("Too many elements in tensor"));
        param.actSize = actInput.NumElements();

        // get and check weight tensor
        const Tensor& wgtInput = context->input(1);
        OP_REQUIRES(context, wgtInput.NumElements() <= tensorflow::kint32max,
            errors::InvalidArgument("Too many elements in tensor"));
        OP_REQUIRES(context, wgtInput.dtype() == actInput.dtype(),
            errors::InvalidArgument("activation input dtype not equanl to weights input dtype."));
        param.wgtSize = wgtInput.NumElements();

        // check channel num equal
        std::stringstream channelErrorPrint;
        channelErrorPrint << "Check failed: input activation channel num " << actInput.shape().dim_size(0)
            << " unequal to weight channel num " << wgtInput.shape().dim_size(0);
        OP_REQUIRES(context, wgtInput.shape().dim_size(0) == actInput.shape().dim_size(0),
            errors::InvalidArgument(channelErrorPrint.str()));
        param.channelNum = actInput.shape().dim_size(0);
        balanceFactorCpu.resize(param.channelNum);
        param.balanceFactor = balanceFactorCpu.data();

        // get output
        Tensor* balanceFactor = nullptr;
        TensorShape balanceFactorShape({ param.channelNum });
        OP_REQUIRES_OK(context, context->allocate_output(0, balanceFactorShape, &balanceFactor));
        float* balanceFactorPtr = balanceFactor->flat<float>().data();

        const float* actPtr;
        const float* wgtPtr;
        Tensor activationTmp;
        Tensor weightTmp;
        if (std::is_same<Eigen::half, T>::value) {
            // if input is fp16, cast to fp32
            OP_REQUIRES_OK(context,
                context->allocate_temp(DataTypeToEnum<float>::value, actInput.shape(), &activationTmp));
            util::DataCastToFloat32Functor<Device, uint16_t>()(
                reinterpret_cast<const uint16_t*>(actInput.flat<T>().data()),
                activationTmp.flat<float>().data(),
                static_cast<int>(actInput.NumElements()));
            actPtr = activationTmp.flat<float>().data();
            OP_REQUIRES_OK(context,
                context->allocate_temp(DataTypeToEnum<float>::value, wgtInput.shape(), &weightTmp));
            util::DataCastToFloat32Functor<Device, uint16_t>()(
                reinterpret_cast<const uint16_t*>(wgtInput.flat<T>().data()),
                weightTmp.flat<float>().data(),
                static_cast<int>(wgtInput.NumElements()));
            wgtPtr = weightTmp.flat<float>().data();
        } else if (std::is_same<float, T>::value) {
            actPtr = actInput.flat<float>().data();
            wgtPtr = wgtInput.flat<float>().data();
        }
        // calculate tensor balance factor
        int status = DMQBalancer<Device, float>()(actPtr, wgtPtr, param, balanceFactorPtr);
        ERROR_CHECK(status);
        // write result to record file
        ERROR_CHECK(
            WriteTensorBalanceFactorToRecordFile(param.balanceFactor, param.channelNum, layerName, recordFilePath));
    }

private:
    float migrationStrength = 0;
    std::string layerName = "layer_name_init";
    std::string recordFilePath = "record_file_path_init";
    DMQBalancerParam param;
    std::vector<float> balanceFactorCpu;
};
}

REGISTER_KERNEL_BUILDER(Name("DMQBalancer").Device(DEVICE_CPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::DMQBalancerOp<util::CPUDevice, Eigen::half>);
REGISTER_KERNEL_BUILDER(Name("DMQBalancer").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::DMQBalancerOp<util::CPUDevice, float>);

#ifdef GOOGLE_CUDA
REGISTER_KERNEL_BUILDER(Name("DMQBalancer").Device(DEVICE_GPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::DMQBalancerOp<util::GPUDevice, Eigen::half>);
REGISTER_KERNEL_BUILDER(Name("DMQBalancer").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::DMQBalancerOp<util::GPUDevice, float>);
#endif

REGISTER_OP("DMQBalancer")
    .Attr("T: {float16, float32}")
    .Attr("migration_strength: float = 0.5")
    .Attr("layer_name: string")
    .Attr("record_file_path: string")
    .Input("activation: T")
    .Input("weights: T")
    .Output("tensor_balance_factor: float")
    .SetShapeFn([](shape_inference::InferenceContext* c)
    {
        c->set_output(0, c->MakeShape({ c->Dim(c->input(0), 0) }));
        return tensorflow::Status::OK();
    });
