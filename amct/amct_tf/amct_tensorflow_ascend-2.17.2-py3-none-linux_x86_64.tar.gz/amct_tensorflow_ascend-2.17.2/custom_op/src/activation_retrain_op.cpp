/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define ActivationRetrain Operator Forward Operation on CPU
 *
 * @file activation_retrain.cc
 *
 * @version 1.0
 */

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/op_kernel.h"
#include "tensorflow/core/framework/shape_inference.h"

#include "activation_retrain.h"
#include "initializer.h"
#include "tf_error_check.h"
#include "error_codes.h"

using namespace tensorflow;

namespace AmctTfOp {
template <typename Device, typename T>
class ActivationRetrainOp : public OpKernel {
public:
    explicit ActivationRetrainOp(OpKernelConstruction* context) : OpKernel(context)
    {
        Initializer::GetInstance().Init();
        OP_REQUIRES_OK(context, context->GetAttr("quant_bit_num", &quantBitNum_));
        OP_REQUIRES_OK(context, context->GetAttr("fixed_min", &fixedMin_));
        OP_REQUIRES_OK(context, context->GetAttr("ifmr_init", &ifmrInit_));
        batchCounter_ = 0;
        batchNum_ = 1;
        clipMaxPre_ = 0;
        clipMinPre_ = 0;
    }

    ~ActivationRetrainOp() override {}

    void Compute(OpKernelContext* context) override
    {
        const Tensor& inputTensor = context->input(INPUT_INDEX);
        auto input = inputTensor.flat<T>();

        Tensor clipMaxTensor = context->input(CLIPMAX_INDEX);
        auto clipMax = clipMaxTensor.flat<T>();

        Tensor clipMinTensor = context->input(CLIPMIN_INDEX);
        auto clipMin = clipMinTensor.flat<T>();

        Tensor batchNumTensor = context->input(BATCH_NUM_INDEX);
        auto batchNum = batchNumTensor.flat<T>();

        Tensor* outputTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(OUTPUT_INDEX, inputTensor.shape(), &outputTensor));
        auto output = outputTensor->template flat<float>();

        Tensor* scaleTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(SCALE_INDEX, TensorShape({1}), &scaleTensor));
        auto scale = scaleTensor->template flat<float>();

        Tensor* offsetTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(OFFSET_INDEX, TensorShape({1}), &offsetTensor));
        auto offset = offsetTensor->template flat<int>();

        Tensor* clipMaxOutTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(CLIPMAXOUT_INDEX, TensorShape({1}), &clipMaxOutTensor));
        auto clipMaxOut = clipMaxOutTensor->template flat<T>();

        Tensor* clipMinOutTensor = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(CLIPMINOUT_INDEX, TensorShape({1}), &clipMinOutTensor));
        auto clipMinOut = clipMinOutTensor->template flat<T>();

        int statusCode = GetBatchNum<Device, T>()(*batchNum.data(), batchCounter_);
        ERROR_CHECK(statusCode);

        if (ifmrInit_ && (batchCounter_ == 0)) {
            Tensor ifmrData;
            OP_REQUIRES_OK(context, context->allocate_temp(
                DataTypeToEnum<T>::value, TensorShape({inputTensor.NumElements()}), &ifmrData));

            Tensor quantError;
            OP_REQUIRES_OK(context, context->allocate_temp(
                DataTypeToEnum<T>::value, TensorShape({inputTensor.NumElements()}), &quantError));

            AmctCommon::IfmrParam ifmrCommon = {0, static_cast<uint>(quantBitNum_), WITH_OFFSET, false,
                IFMR_SEARCH_START, IFMR_SEARCH_END, SEARCH_STEP, PERCENTILE, PERCENTILE};
            amct_tf::IfmrParam ifmrParam = {ifmrCommon};

            float scaleCpu;
            int offsetCpu;
            DataQuantParam<T> quantParam = {
                scale.data(), offset.data(), &scaleCpu, &offsetCpu, ifmrData.flat<T>().data(),
                quantError.flat<T>().data()};

            std::vector<T> storeData;
            InputParam<T> inputParam = {storeData, static_cast<int>(inputTensor.NumElements()), input.data()};

            statusCode = QuantIfmrFunctor<Device, T>()(ifmrParam, batchCounter_, batchNum_, inputParam, quantParam);
            ERROR_CHECK(statusCode);

            statusCode = UpdateBatchNum<Device, T>()(*batchNum.data());
            ERROR_CHECK(statusCode);

            ClipCalculate<Device, T>()(scale.data(), offset.data(), clipMax.data(), clipMin.data(), quantBitNum_);
            ClipRecord<Device, T>()(clipMax.data(), clipMin.data(), clipMaxPre_, clipMinPre_);
        }

        ClipCheckFunctor<Device, T>()(clipMax.data(), clipMin.data(), clipMaxPre_, clipMinPre_, fixedMin_);

        Input<T> ulqInput = {input.data(), static_cast<int>(inputTensor.NumElements()), clipMax.data(), clipMin.data()};
        Output<T> ulqOutput = {output.data(), scale.data(), offset.data(), clipMaxOut.data(), clipMinOut.data()};

        UlqFunctor<Device, T>()(ulqInput, ulqOutput, quantBitNum_);
    }

private:
    int quantBitNum_;
    bool fixedMin_;
    bool ifmrInit_;
    int batchCounter_;
    int batchNum_;
    T clipMaxPre_;
    T clipMinPre_;
};
}

REGISTER_KERNEL_BUILDER(Name("ActivationRetrain").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::ActivationRetrainOp<util::CPUDevice, float>);

// Register the GPU kernels.
#ifdef GOOGLE_CUDA
extern template struct AmctTfOp::UlqFunctor<util::GPUDevice, float>;
REGISTER_KERNEL_BUILDER(Name("ActivationRetrain").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::ActivationRetrainOp<util::GPUDevice, float>);
#endif // GOOGLE_CUDA

REGISTER_OP("ActivationRetrain")
    .Attr("T: {float}")
    .Attr("quant_bit_num: int = 8")
    .Attr("fixed_min: bool = false")
    .Attr("ifmr_init: bool = true")
    .Attr("layer_names: list(string)")
    .Input("input: T")
    .Input("clip_max: T")
    .Input("clip_min: T")
    .Input("batch_num: T")
    .Output("output: float")
    .Output("scale: float")
    .Output("offset: int32")
    .Output("clip_max_out: T")
    .Output("clip_min_out: T")
    .SetShapeFn([](::tensorflow::shape_inference::InferenceContext* c) {
        shape_inference::ShapeHandle output;
        output = c->MakeShape({1});
        c->set_output(0, c->input(0));
        c->set_output(1, output);
        c->set_output(2, output);
        return tensorflow::Status::OK();
    });
