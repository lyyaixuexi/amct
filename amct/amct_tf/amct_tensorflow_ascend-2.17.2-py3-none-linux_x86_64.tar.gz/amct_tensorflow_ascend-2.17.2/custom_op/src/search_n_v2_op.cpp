/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define SearchNV2 Operator
 *
 * @file search_n_v2.cc
 *
 * @version 1.0
 */

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "search_n_v2_kernel.h"
#include "tf_error_check.h"
#include "initializer.h"
#include "error_codes.h"
#include "cast_util.h"

using namespace tensorflow;
using namespace util;

namespace AmctTfOp {
// OpKernel definition.
// template parameter <T> is the datatype of the tensors.
template <typename Device, typename T>
class SearchNV2Op : public OpKernel {
public:
    explicit SearchNV2Op(OpKernelConstruction* context) : OpKernel(context)
    {
        Initializer::GetInstance().Init();
        OP_REQUIRES_OK(context, context->GetAttr("channel_wise", &(param.channelWise)));
        OP_REQUIRES_OK(context, context->GetAttr("data_format", &(param.dataFormat)));
        OP_REQUIRES_OK(context, context->GetAttr("batch_num", &(batchNum)));
        OP_REQUIRES_OK(context, context->GetAttr("layer_names", &layerNames));
        OP_REQUIRES_OK(context, context->GetAttr("layer_types", &layerTypes));
        OP_REQUIRES_OK(context, context->GetAttr("record_file_path", &recordFilePath));
        OP_REQUIRES_OK(context, context->GetAttr("retrain_group", &retrainGroup));
        OP_REQUIRES_OK(context, context->GetAttr("do_searchn", &doSearchn));
        OP_REQUIRES_OK(context, context->GetAttr("per_tensor", &perTensor));
        channelNum = 1;
        deqScaleCpu.resize(1);
        scaleWeight.resize(1);
        quantParam.bestN = nullptr;
        quantParam.bestNSize = channelNum;
        quantParam.deqScale = nullptr;
        quantParam.deqScaleCpu = nullptr;
        quantParam.isBroadcast = false;
        inputParam.storeError = storeError;
        param.out = nullptr;
        quantParam.channelNum = 1;
        quantParam.deqScaleSize = 1;
        quantParam.quantErrorSum = nullptr;
        quantParam.quantErrorSumSize = 1;
    }

    ~SearchNV2Op() override {}

    void SetupShape(TensorShape inputTensorShape)
    {
        param.shape.resize(inputTensorShape.dim_sizes().size());
        for (unsigned int i = 0; i < param.shape.size(); i++) {
            param.shape[i] = inputTensorShape.dim_sizes()[i];
        }

        if (param.channelWise) {
            if (param.dataFormat == "NCHW" || param.dataFormat == "NCDHW") {
                if (param.shape.size() >= FOUR_DIM) {
                    // when h eq w eq 1; do tensor-wise searchN
                    bool isFit = param.shape[param.shape.size() - CFIRST_H_OFFSET] == 1 && param.shape.back() == 1;
                    // input shape maybe dynamic, set isBroadcast to true when the first batch fit h = w = 1
                    isBroadcast = (batchCounter == 0) ? isFit : isBroadcast; // initialize at first batch
                    isBroadcast = isBroadcast || perTensor;
                }
                channelNum = param.shape[NC_C_DIM];
            } else if (param.dataFormat == "NHWC" || param.dataFormat == "NDHWC") {
                if (param.shape.size() >= FOUR_DIM) {
                    bool isFit = param.shape[param.shape.size() - CLAST_H_OFFSET] == 1 &&
                        param.shape[param.shape.size() - CLAST_W_OFFSET] == 1;
                    isBroadcast = (batchCounter == 0) ? isFit : isBroadcast; // initialize at first batch
                    isBroadcast = isBroadcast || perTensor;
                    channelNum = param.shape.back();
                } else {
                    channelNum = param.shape[NC_C_DIM];
                }
            }
        } else {
            channelNum = 1;
        }
        quantParam.channelNum = channelNum;
    }

    int WriteToFile()
    {
        if (batchCounter == batchNum) {
            inputParam.storeError.clear();
            inputParam.storeError.shrink_to_fit();
            int bestNBroadcast[channelNum] = {0};
            if (isBroadcast) {
                for (int j = 0; j < channelNum; j++) {
                    bestNBroadcast[j] = quantParam.bestN[0];
                }
                quantParam.bestN = bestNBroadcast;
            }
            for (unsigned int i = 0; i < layerNames.size(); i++) {
                if (retrainGroup) {
                    int perChannelNum = channelNum / layerNames.size();
                    CHECK_OK(WriteShiftNToRecordFile(quantParam.bestN + i * perChannelNum, perChannelNum,
                        layerNames[i], recordFilePath));
                } else {
                    CHECK_OK(WriteShiftNToRecordFile(quantParam.bestN, channelNum, layerNames[i], recordFilePath));
                }
            }
        }
        return AmctCommon::SUCCESS;
    }

    void Compute(OpKernelContext* context) override
    {
        const Tensor& inputTensor = context->input(0);
        const Tensor& scaleDTensor = context->input(2);
        const Tensor& scaleWTensor = context->input(3);
        TensorShape inputTensorShape = inputTensor.shape();
        // updata channelNum here
        SetupShape(inputTensorShape);
        // Create an output tensor
        Tensor* outputTensor = nullptr;
        TensorShape outputTensorShape({channelNum});
        OP_REQUIRES_OK(context, context->allocate_output(0, outputTensorShape, &outputTensor));
        // current batch input data size and pointer
        Tensor inputSave;
        inputParam.size = static_cast<int>(inputTensor.NumElements());
        if (std::is_same<Eigen::half, T>::value) {
            OP_REQUIRES_OK(context, context->allocate_temp(DataTypeToEnum<float>::value,
                TensorShape({inputParam.size}), &inputSave));
            DataCastToFloat32Functor<Device, uint16_t>()(
                reinterpret_cast<const uint16_t*>(inputTensor.flat<T>().data()),
                inputSave.flat<float>().data(),
                inputParam.size);
            inputParam.in = inputSave.flat<float>().data();
        } else {
            inputParam.in = inputTensor.flat<float>().data();
        }

        int errorCodeD = FetchScaleFunctor<Device, float>()(&scaleData, scaleDTensor.flat<float>().data(), 1);
        ERROR_CHECK(errorCodeD);
        scaleWeight.resize(channelNum); // scale_w must have same length as channelNum and deqscale
        int errorCodeW = FetchScaleFunctor<Device, float>()(
            scaleWeight.data(), scaleWTensor.flat<float>().data(), channelNum);
        ERROR_CHECK(errorCodeW);

        int bestN[channelNum] = {0};
        quantParam.bestN = bestN;
        quantParam.bestNSize = channelNum;
        if (doSearchn) {
            param.out = outputTensor->flat<float>().data();
            quantParam.isBroadcast = isBroadcast;

            Tensor deqScale;
            Tensor quantErrorSum;
            int blockNum = AMCT_GET_BLOCKS(inputParam.size);
            OP_REQUIRES_OK(context, context->allocate_temp(
                DataTypeToEnum<float>::value, TensorShape({channelNum}), &deqScale));
            OP_REQUIRES_OK(context, context->allocate_temp(
                DataTypeToEnum<float>::value, TensorShape({blockNum}), &quantErrorSum));
            if (batchCounter <= batchNum - 1) {
                deqScaleCpu.resize(channelNum);
                ERROR_CHECK(ComputeDeqScale<float>(deqScaleCpu.data(), scaleWeight.data(), scaleData, channelNum));
                quantParam.deqScaleCpu = deqScaleCpu.data();
            }
            quantParam.deqScale = deqScale.flat<float>().data();
            quantParam.deqScaleSize = channelNum;
            quantParam.quantErrorSum = quantErrorSum.flat<float>().data();
            quantParam.quantErrorSumSize = blockNum;
            if (inputParam.size == 0) {
                OP_REQUIRES(context, false, errors::InvalidArgument("SearchNV2Op: inputTensor is empty!"));
            }
            int status = SearchNV2Functor<Device, float>()(param, batchCounter, batchNum, inputParam, quantParam);
            ERROR_CHECK(status);
        } else {
            batchCounter = batchNum;
        }
        ERROR_CHECK(WriteToFile());
    }

private:
    struct DataParam param;
    AmctCommon::SearchnV2InputParam<float> inputParam;
    struct SearchnV2QuantParam<float> quantParam;
    int batchCounter = 0;
    int batchNum = 0;
    int channelNum = 0;
    std::vector<std::vector<float>> storeError;
    std::vector<std::string> layerNames;
    std::vector<std::string> layerTypes;
    std::string recordFilePath = "record_file_path_init";
    float scaleData = 1;
    std::vector<float> scaleWeight;
    std::vector<float> deqScaleCpu;
    bool isBroadcast = false;
    bool retrainGroup = false;
    bool doSearchn = true;
    bool perTensor = false;
};
}

// Register the CPU kernels.
REGISTER_KERNEL_BUILDER(Name("SearchNV2").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::SearchNV2Op<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("SearchNV2").Device(DEVICE_CPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::SearchNV2Op<util::CPUDevice, Eigen::half>);

// Register the GPU kernels.
#ifdef GOOGLE_CUDA
extern template struct AmctTfOp::SearchNV2Functor<util::GPUDevice, float>;
REGISTER_KERNEL_BUILDER(Name("SearchNV2").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::SearchNV2Op<util::GPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("SearchNV2").Device(DEVICE_GPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::SearchNV2Op<util::GPUDevice, Eigen::half>);
#endif  // GOOGLE_CUDA


REGISTER_OP("SearchNV2")
    .Attr("T: {float16, float32, float64}")
    .Attr("shift_n_length: int = 1")
    .Attr("channel_wise: bool")
    .Attr("data_format: string")
    .Attr("batch_num: int")
    .Attr("layer_names: list(string)")
    .Attr("layer_types: list(string)")
    .Attr("record_file_path: string")
    .Attr("retrain_group: bool = false")
    .Attr("do_searchn: bool = true")
    .Attr("per_tensor: bool = false")
    .Input("in: T")
    .Input("enable: T")
    .Input("scale_d: float")
    .Input("scale_w: float")
    .Output("out: float")
    .SetShapeFn([](::tensorflow::shape_inference::InferenceContext* c) {
        int shiftNLength = 1;
        TF_RETURN_IF_ERROR(c->GetAttr("shift_n_length", &shiftNLength));

        shape_inference::ShapeHandle output;
        output = c->MakeShape({shiftNLength});

        c->set_output(0, output);
        return tensorflow::Status::OK();
    });