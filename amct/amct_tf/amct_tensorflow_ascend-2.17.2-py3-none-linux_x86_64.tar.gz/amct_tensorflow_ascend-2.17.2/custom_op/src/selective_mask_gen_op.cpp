/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define QuantIfmr Operator Forward Operation on CPU
 *
 * @file ifmr.cc
 *
 * @version 1.0
 */
#include <algorithm>
#include <cmath>
#include <sstream>

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "selective_mask_gen_kernel.h"
#include "activation_retrain.h"
#include "initializer.h"
#include "tf_error_check.h"
#include "error_codes.h"

using namespace tensorflow;
using namespace SelectiveMaskGenKernel;

namespace AmctTfOp {
template <typename Device, typename T>
class SelectiveMaskGenOp : public OpKernel {
public:
    explicit SelectiveMaskGenOp(OpKernelConstruction* context) : OpKernel(context)
    {
        OP_REQUIRES_OK(context, context->GetAttr("M", &inputM));
        OP_REQUIRES_OK(context, context->GetAttr("N", &inputN));
        OP_REQUIRES_OK(context, context->GetAttr("prune_axis", &pruneAxis));
        OP_REQUIRES_OK(context, context->GetAttr("update_freq", &updateFreq));
        pruneParam.m = inputM;
        pruneParam.n = inputN;
        pruneParam.pruneAxis = pruneAxis;
        pruneParam.updateFreq = updateFreq;
    }

    ~SelectiveMaskGenOp() override {}

    void Compute(OpKernelContext* context) override
    {
        // get and check weight tensor
        const Tensor& wgtInput = context->input(0);
        OP_REQUIRES(context, wgtInput.NumElements() <= tensorflow::kint32max,
            errors::InvalidArgument("Too many elements in tensor"));
        std::stringstream wgtErrorPrint;
        wgtErrorPrint << "Check failed: prune_axis is " << pruneParam.pruneAxis << ", weight tensor has only "
            << wgtInput.shape().dims() << " dims.";
        OP_REQUIRES(context, wgtInput.shape().dims() >= pruneParam.pruneAxis,
            errors::InvalidArgument(wgtErrorPrint.str()));

        // get and check remain channels
        Tensor remainChannelsTensor = context->input(REMAIN_CHANNELS_INDEX);
        std::stringstream remainChannelsErrorPrint;
        remainChannelsErrorPrint << "Check failed: input remain_channels size " << remainChannelsTensor.NumElements()
            << " unequal to weight tensor shape at prune_axis " << wgtInput.shape().dim_size(pruneParam.pruneAxis);
        OP_REQUIRES(context, wgtInput.shape().dim_size(pruneParam.pruneAxis) == remainChannelsTensor.NumElements(),
            errors::InvalidArgument(remainChannelsErrorPrint.str()));

        // get and check mask container
        Tensor maskContainerTensor = context->input(CONTAINER_INDEX);
        T* maskContainerPtr = maskContainerTensor.flat<T>().data();
        OP_REQUIRES(context, wgtInput.NumElements() == maskContainerTensor.NumElements(),
            errors::InvalidArgument("Check failed: input mask_container size unequal to weight tensor size."));

        // get output
        Tensor* maskOutput = NULL;
        OP_REQUIRES_OK(context, context->allocate_output(0, wgtInput.shape(), &maskOutput));
        T* maskPtr = maskOutput->flat<T>().data();

        // get batch counter
        Tensor batchNumTensor = context->input(BATCH_COUNT_INDEX);
        auto batchNum = batchNumTensor.flat<T>();
        int batchCounter = 0;
        int errorCode = GetBatchNum<Device, T>()(*batchNum.data(), batchCounter);
        ERROR_CHECK(errorCode);

        // update mask container
        bool updateMask = (updateFreq == 0) ? (batchCounter == 0) : (batchCounter % updateFreq == 0);
        if (updateMask) {
            const T* wgtPtr = wgtInput.flat<T>().data();
            pruneParam.shape.resize(wgtInput.shape().dims());
            for (int i = 0; i < wgtInput.shape().dims(); ++i) {
                pruneParam.shape[i] = wgtInput.shape().dim_size(i);
            }
            Tensor remainWgtTmp;
            int axisAfterPadding = static_cast<int>(
                ceil(static_cast<float>(pruneParam.shape[pruneParam.pruneAxis]) / pruneParam.m) * pruneParam.m);
            int remainWgtSize = wgtInput.NumElements() / pruneParam.shape[pruneParam.pruneAxis] * axisAfterPadding;
            OP_REQUIRES_OK(context,
                context->allocate_temp(DataTypeToEnum<T>::value, TensorShape({remainWgtSize}), &remainWgtTmp));
            T* remainWgtPtr = remainWgtTmp.flat<T>().data();
            const T* remainChannelsPtr = remainChannelsTensor.flat<T>().data();
            errorCode = ComputeMask<Device, T>()(wgtPtr, remainChannelsPtr, remainWgtPtr, pruneParam, maskContainerPtr);
            ERROR_CHECK(errorCode);
        }

        errorCode = UpdateBatchNum<Device, T>()(*batchNum.data());
        ERROR_CHECK(errorCode);

        errorCode = IdentityMask<Device, T>()(wgtInput.NumElements(), maskContainerPtr, maskPtr);
        ERROR_CHECK(errorCode);
    }

private:
    int inputM = 0;
    int inputN = 0;
    int pruneAxis = 0;
    int updateFreq = 0;
    struct SelectivePruneParam pruneParam;
};
}

REGISTER_KERNEL_BUILDER(Name("SelectiveMaskGen").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::SelectiveMaskGenOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("SelectiveMaskGen").Device(DEVICE_CPU).TypeConstraint<double>("T"),
    AmctTfOp::SelectiveMaskGenOp<util::CPUDevice, double>);

#ifdef GOOGLE_CUDA
REGISTER_KERNEL_BUILDER(Name("SelectiveMaskGen").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::SelectiveMaskGenOp<util::GPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("SelectiveMaskGen").Device(DEVICE_GPU).TypeConstraint<double>("T"),
    AmctTfOp::SelectiveMaskGenOp<util::GPUDevice, double>);
#endif

REGISTER_OP("SelectiveMaskGen")
    .Attr("T: {float, double}")
    .Attr("N: int = 2")
    .Attr("M: int = 4")
    .Attr("prune_axis: int")
    .Attr("update_freq: int")
    .Input("wgt_input: T")
    .Input("batch_num: T")
    .Input("mask_container: T")
    .Input("remain_channels: T")
    .Output("selective_mask: T")
    .SetShapeFn([](shape_inference::InferenceContext* c)
    {
        c->set_output(0, c->input(0));
        return tensorflow::Status::OK();
    });
