/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief nuq algorithm custom op C++ implement
 *
 * @file nuq.cc
 *
 * @version 1.0
 */

#include <cstdlib>
#include <cstdio>
#include <cfloat>
#include <cmath>
#include <numeric>
#include <vector>

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "nuq_kernel.h"
#include "initializer.h"
#include "common.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "cast_util.h"

using namespace tensorflow;
using namespace util;

namespace AmctTfOp {
constexpr DataType FloatTypeId = DataTypeToEnum<float>::value;
constexpr DataType Int32TypeId = DataTypeToEnum<int>::value;
constexpr DataType Uint32TypeId = DataTypeToEnum<unsigned int>::value;
template <typename Device, typename T>
class QuantNuqOp : public OpKernel {
public:
    void ThrustParamInit(struct AmctCommon::ThrustParam<float>& thrustParam)
    {
        thrustParam.clusterToStorePtr = nullptr;
        thrustParam.clusterDataPtr = nullptr;
        thrustParam.clusterCenterPtr = nullptr;
        thrustParam.weightPtr = nullptr;
        thrustParam.dataClusterPtr = nullptr;
        thrustParam.sumClusterPtr = nullptr;
        thrustParam.weightClusterPtr = nullptr;
        thrustParam.weightDataPtr = nullptr;
        thrustParam.tmpValueDataPtr = nullptr;
        thrustParam.deviceInputPtr = nullptr;
        thrustParam.ddistancePtr = nullptr;
        thrustParam.dcandiDistPtr = nullptr;
        thrustParam.dcumulativeDistancePtr = nullptr;
        thrustParam.canDataPtr = nullptr;
        thrustParam.numCandidate = 0;
        thrustParam.dataLength = 0;
        thrustParam.numSteps = 0;
    }

    explicit QuantNuqOp(OpKernelConstruction* context) : OpKernel(context)
    {
        Initializer::GetInstance().Init();
        // get the attribute of QuantNuqOp
        OP_REQUIRES_OK(context, context->GetAttr("scale_length", &scaleLength));
        OP_REQUIRES_OK(context, context->GetAttr("quant_bits", &quantBits));
        OP_REQUIRES_OK(context, context->GetAttr("num_steps", &numSteps));
        OP_REQUIRES_OK(context, context->GetAttr("num_of_iteration", &numOfIteration));
        OP_REQUIRES_OK(context, context->GetAttr("with_offset", &withOffset));
        OP_REQUIRES_OK(context, context->GetAttr("layer_names", &layerNames));
        OP_REQUIRES_OK(context, context->GetAttr("record_file_path", &recordFilePath));

        scaleCpu.resize(scaleLength);
        offsetCpu.resize(scaleLength);
        clusterCpu.resize(numSteps);
        quantParam.scale = nullptr;
        quantParam.offset = nullptr;
        quantParam.scaleCpu = nullptr;
        quantParam.offsetCpu = nullptr;
        quantParam.cluster = nullptr;
        quantParam.clusterCpu = nullptr;
        quantParam.clusterLength = numSteps;
        quantParam.scaleLength = scaleLength;
        quantParam.quantBits = quantBits;
        quantParam.numSteps = numSteps;
        quantParam.numOfIteration = numOfIteration;
        quantParam.withOffset = withOffset;
        quantParam.layerName = "";
        quantParam.recordFilePath = recordFilePath;
        ThrustParamInit(thrustParam);
    }

    ~QuantNuqOp() override {}

    void Compute(OpKernelContext* context) override
    {
        Tensor input = context->input(NUQ_WEIGHT_INDEX);
        Tensor* scale = nullptr;
        Tensor* offset = nullptr;
        Tensor* weight = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(NUQ_SCALE_INDEX, TensorShape({scaleLength}), &scale));
        OP_REQUIRES_OK(context, context->allocate_output(NUQ_OFFSET_INDEX, TensorShape({scaleLength}), &offset));
        OP_REQUIRES_OK(context, context->allocate_output(NUQ_OUTPUT_WEIGHT_INDEX, input.shape(), &weight));

        const int inputSize = static_cast<int>(input.NumElements());
        const float* inPtr = nullptr;
        float* outPtr = nullptr;
        Tensor inputSave;
        Tensor outputSave;
        if (std::is_same<Eigen::half, T>::value) {
            OP_REQUIRES_OK(context, context->allocate_temp(FloatTypeId, TensorShape({inputSize}), &inputSave));
            DataCastToFloat32Functor<Device, uint16_t>()(reinterpret_cast<const uint16_t*>(input.flat<T>().data()),
                inputSave.flat<float>().data(), inputSize);
            inPtr = inputSave.flat<float>().data();

            OP_REQUIRES_OK(context, context->allocate_temp(FloatTypeId, TensorShape({inputSize}), &outputSave));
            outPtr = outputSave.flat<float>().data();
        } else {
            inPtr = input.flat<float>().data();
            outPtr = weight->flat<float>().data();
        }

        Tensor cluster;
        Tensor clusterData;
        Tensor clusterCenter;
        Tensor weightTensor;
        Tensor dataCluster;
        Tensor sumCluster;
        Tensor weightCluster;
        Tensor weightData;
        Tensor tmpValueData;
        Tensor ddistance;
        Tensor dcandiDist;
        Tensor dcumulativeDistance;
        Tensor canData;

        OP_REQUIRES_OK(context, context->allocate_temp(FloatTypeId, TensorShape({inputSize}), &clusterData));
        OP_REQUIRES_OK(context, context->allocate_temp(FloatTypeId, TensorShape({inputSize}), &weightTensor));
        OP_REQUIRES_OK(context, context->allocate_temp(Uint32TypeId, TensorShape({inputSize}), &dataCluster));
        OP_REQUIRES_OK(context, context->allocate_temp(FloatTypeId, TensorShape({quantParam.numSteps}), &sumCluster));
        OP_REQUIRES_OK(context, context->allocate_temp(Int32TypeId, TensorShape({quantParam.numSteps}), &cluster));
        OP_REQUIRES_OK(context, context->allocate_temp(FloatTypeId, TensorShape({inputSize}), &weightData));
        OP_REQUIRES_OK(context, context->allocate_temp(FloatTypeId, TensorShape({inputSize}), &ddistance));
        OP_REQUIRES_OK(context, context->allocate_temp(FloatTypeId, TensorShape({inputSize}), &dcandiDist));
        OP_REQUIRES_OK(context, context->allocate_temp(FloatTypeId, TensorShape({inputSize}), &dcumulativeDistance));
        OP_REQUIRES_OK(context, context->allocate_temp(Int32TypeId, TensorShape({inputSize}), &canData));
        OP_REQUIRES_OK(context, context->allocate_temp(FloatTypeId,
            TensorShape({quantParam.numSteps}), &weightCluster));
        OP_REQUIRES_OK(context, context->allocate_temp(FloatTypeId,
            TensorShape({quantParam.numSteps}), &clusterCenter));
        OP_REQUIRES_OK(context, context->allocate_temp(FloatTypeId,
            TensorShape({static_cast<int>(AMCT_GET_BLOCKS(inputSize))}), &tmpValueData));

        thrustParam.clusterDataPtr = clusterData.flat<float>().data();
        thrustParam.clusterCenterPtr = clusterCenter.flat<float>().data();
        thrustParam.weightPtr = weightTensor.flat<float>().data();
        thrustParam.dataClusterPtr = dataCluster.flat<unsigned int>().data();
        thrustParam.sumClusterPtr = sumCluster.flat<float>().data();
        thrustParam.weightClusterPtr = weightCluster.flat<float>().data();
        thrustParam.weightDataPtr = weightData.flat<float>().data();
        thrustParam.tmpValueDataPtr = tmpValueData.flat<float>().data();
        thrustParam.ddistancePtr = ddistance.flat<float>().data();
        thrustParam.dcandiDistPtr = dcandiDist.flat<float>().data();
        thrustParam.dcumulativeDistancePtr = dcumulativeDistance.flat<float>().data();
        thrustParam.canDataPtr = canData.flat<int>().data();
        thrustParam.numCandidate = BINARY + static_cast<int>(log(quantParam.numSteps));
        thrustParam.dataLength = inputSize;
        thrustParam.numSteps = quantParam.numSteps;

        // assign the input data to output weight
        IdentityWeightNuq<Device, float>()(inPtr, outPtr, inputSize);

        quantParam.scale = scale->flat<float>().data();
        quantParam.offset = offset->flat<int>().data();
        quantParam.cluster = cluster.flat<int>().data();
        quantParam.scaleCpu = scaleCpu.data();
        quantParam.offsetCpu = offsetCpu.data();
        quantParam.clusterCpu = clusterCpu.data();

        OP_REQUIRES(context, (inputSize != 0), errors::InvalidArgument("NuqOp: inputTensor is empty!"));
        OP_REQUIRES(context, (quantParam.scaleLength != 0), errors::InvalidArgument("NuqOp: ScaleLength is zero!"));

        batchCounter++;
        if (batchCounter == 1) {
            NuqFunctor<Device, float>()(outPtr, inputSize, quantParam, thrustParam);
            for (size_t i = 0; i < layerNames.size(); i++) {
                auto errorCode = WriteNuqRecordToFile(quantParam.scaleCpu, quantParam.offsetCpu, quantParam.clusterCpu,
                    quantParam.scaleLength, quantParam.numSteps, layerNames[i], recordFilePath);
                ERROR_CHECK(errorCode);
            }
        } else {
            IdentityScaleOffsetNuq<Device, float>()(quantParam);
            FakeQuantWithNuq<Device, float>()(quantParam, inPtr, outPtr, inputSize);
        }

        if (std::is_same<Eigen::half, T>::value) {
            DataCastToFloat16Functor<Device, float>()(outPtr,
                reinterpret_cast<uint16_t*>(weight->flat<T>().data()), inputSize);
        }
    }

private:
    int scaleLength = 1;
    int quantBits = 8;
    int numSteps = 32;
    int numOfIteration = 1;
    bool withOffset = false;
    struct WeightNuqQuantParam quantParam;
    struct AmctCommon::ThrustParam<float> thrustParam;
    int batchCounter = 0;
    std::vector<std::string> layerNames;
    std::string recordFilePath = "record_file_path_init";
    std::vector<float> scaleCpu;
    std::vector<int> offsetCpu;
    std::vector<int> clusterCpu;
};
}

REGISTER_KERNEL_BUILDER(Name("QuantNuq").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::QuantNuqOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("QuantNuq").Device(DEVICE_CPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::QuantNuqOp<util::CPUDevice, Eigen::half>);

#ifdef GOOGLE_CUDA
REGISTER_KERNEL_BUILDER(Name("QuantNuq").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::QuantNuqOp<util::GPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("QuantNuq").Device(DEVICE_GPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::QuantNuqOp<util::GPUDevice, Eigen::half>);
#endif


REGISTER_OP("QuantNuq")
    .Attr("T: {float16, float32, float64}")
    .Attr("scale_length: int = 1")
    .Attr("quant_bits: int = 8")
    .Attr("num_steps: int = 32")
    .Attr("num_of_iteration: int = 1")
    .Attr("with_offset: bool = false")
    .Attr("layer_names: list(string)")
    .Attr("record_file_path: string")
    .Input("input: T")
    .Input("enable: T")
    .Output("scale: float")
    .Output("offset: int32")
    .Output("weight: T")
    .SetShapeFn([](shape_inference::InferenceContext* c)
    {
        int scaleLength = 1;
        TF_RETURN_IF_ERROR(c->GetAttr("scale_length", &scaleLength));

        shape_inference::ShapeHandle output;
        output = c->MakeShape({scaleLength});

        c->set_output(0, output);
        c->set_output(1, output);
        c->set_output(2, c->input(0));

        return tensorflow::Status::OK();
    })
    .Doc(R"doc(NUQ quant algorithm.)doc");
