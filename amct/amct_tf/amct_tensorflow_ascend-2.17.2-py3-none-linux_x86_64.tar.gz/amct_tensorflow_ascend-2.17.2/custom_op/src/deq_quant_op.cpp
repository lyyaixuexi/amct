/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief deq_quant custom op C++ implement. now it has no real quant behaviours.
 *
 * @file deq_quant.cc
 *
 * @version 1.0
 */


#include <cmath>
#include <algorithm>

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "deq_quant.h"
#include "initializer.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "util.h"

using namespace tensorflow;

namespace AmctTfOp {
template <typename Device, typename T>
class DeqQuantOp : public OpKernel {
public:
    explicit DeqQuantOp(OpKernelConstruction* context) : OpKernel(context)
    {
        OP_REQUIRES_OK(context, context->GetAttr("layer_name", &layerName));
    }

    ~DeqQuantOp() override {}

    void Compute(OpKernelContext* context) override
    {
        const Tensor& data = context->input(DEQUANT_DATA_IN_INDEX);
        auto dataFlat = data.flat<T>();
        const int dataSize = dataFlat.size();

        Tensor* output = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(DEQUANT_DATA_OUT_INDEX, data.shape(), &output));
        auto outputFlat = output->flat<T>();

        for (int i = 0; i < dataSize; i++) {
            outputFlat(i) = dataFlat(i);
        }
    }

private:
        std::string layerName = "dequant_layer";
};
}

REGISTER_KERNEL_BUILDER(Name("DeqQuant").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::DeqQuantOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("DeqQuant").Device(DEVICE_CPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::DeqQuantOp<util::CPUDevice, Eigen::half>);

REGISTER_OP("DeqQuant")
    .Attr("T: {float16, float32, float64}")
    .Attr("layer_name: string")
    .Attr("ksize: list(int)")
    .Input("input: T")
    .Input("deqscale: uint64")
    .Output("output: T")
    .SetShapeFn([](shape_inference::InferenceContext* c)
    {
        c->set_output(0, c->input(0));
        return tensorflow::Status::OK();
    })
    .Doc(R"doc(Deq quant algorithm.)doc");
