/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define QuantHfmg Operator
 *
 * @file hfmg.cc
 *
 * @version 1.0
 */
#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"
#include "hfmg_kernel.h"
#include "initializer.h"
#include "common.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "cast_util.h"

using namespace tensorflow;
using namespace util;

namespace AmctTfOp {
// OpKernel definition.
// template parameter <T> is the datatype of the tensors.
template <typename Device, typename T>
class QuantHfmgOp : public OpKernel {
public:
    explicit QuantHfmgOp(OpKernelConstruction* context) : OpKernel(context)
    {
        Initializer::GetInstance().Init();
        OP_REQUIRES_OK(context, context->GetAttr("quant_bit_num", &(quantBitNum)));
        OP_REQUIRES_OK(context, context->GetAttr("with_offset", &(withOffset)));
        OP_REQUIRES_OK(context, context->GetAttr("num_of_bins", &(nbins)));
        OP_REQUIRES_OK(context, context->GetAttr("batch_num", &(batchNum)));
        OP_REQUIRES_OK(context, context->GetAttr("layer_names", &layerNames));
        OP_REQUIRES_OK(context, context->GetAttr("record_file_path", &recordFilePath));
        OP_REQUIRES_OK(context, context->GetAttr("input_stamp", &(inputStamp)));
        hfmgParam.quantBitNum = quantBitNum;
        hfmgParam.withOffset = withOffset;
        hfmgParam.nbins = nbins;
    }

    ~QuantHfmgOp() override {}

    int WriteToFile()
    {
        if (batchCounter == batchNum) {
            dataBins.clear();
            dataBins.shrink_to_fit();
            for (unsigned int i = 0; i < layerNames.size(); i++) {
                if (inputStamp == "data") {
                    CHECK_OK(WriteDataToRecordFile(quantParam.scaleCpu, quantParam.offsetCpu,
                        layerNames[i], recordFilePath, "hide"));
                } else {
                    CHECK_OK(WriteWeightToRecordFile(quantParam.scaleCpu, quantParam.offsetCpu,
                        1, layerNames[i], recordFilePath));
                }
            }
        }
        return AmctCommon::SUCCESS;
    }

    void Compute(OpKernelContext* context) override
    {
        // Grab the input tensor
        const Tensor& inputTensor = context->input(0);
        // Create an output tensor
        Tensor* scaleTensor = nullptr;
        TensorShape scaleTensorShape({1});
        OP_REQUIRES_OK(context, context->allocate_output(0, scaleTensorShape, &scaleTensor));
        Tensor* offsetTensor = nullptr;
        TensorShape offsetTensorShape({1});
        OP_REQUIRES_OK(context, context->allocate_output(1, offsetTensorShape, &offsetTensor));
        inputData.size = static_cast<int>(inputTensor.NumElements());

        Tensor inputSave;
        if (std::is_same<Eigen::half, T>::value) {
            OP_REQUIRES_OK(context, context->allocate_temp(DataTypeToEnum<float>::value,
                TensorShape({inputData.size}), &inputSave));
            DataCastToFloat32Functor<Device, uint16_t>()(
                reinterpret_cast<const uint16_t*>(inputTensor.flat<T>().data()),
                inputSave.flat<float>().data(), inputData.size);
            inputData.in = inputSave.flat<float>().data();
        } else {
            inputData.in = inputTensor.flat<float>().data();
        }

        Tensor binCount;
        Tensor l2Loss;
        OP_REQUIRES_OK(context, context->allocate_temp(DataTypeToEnum<int>::value,
            TensorShape({nbins}), &binCount));
        OP_REQUIRES_OK(context, context->allocate_temp(DataTypeToEnum<float>::value,
            TensorShape({nbins}), &l2Loss));
        quantParam.scale = scaleTensor->flat<float>().data();
        quantParam.offset = offsetTensor->flat<int>().data();
        quantParam.scaleCpu = &scaleCpu;
        quantParam.offsetCpu = &offsetCpu;
        quantParam.binCounts = binCount.flat<int>().data();
        quantParam.l2LossTensor = l2Loss.flat<float>().data();
        quantParam.layerNames = layerNames;
        quantParam.recordFilePath = recordFilePath;
        OP_REQUIRES(context, (inputData.size != 0), errors::InvalidArgument("QuantHfmgOp: inputTensor is empty!"));
        // get the min max of each batch Data and calculate the scale, offset;
        ActArqFunctor<Device, float>()(inputData, hfmgParam, quantParam);
        int errorCode = QuantHfmgFunctor<Device, float>()(
            dataBins, hfmgParam, batchCounter, batchNum, inputData, quantParam);
        ERROR_CHECK(errorCode);
        ERROR_CHECK(WriteToFile());
    }

private:

    int quantBitNum;
    bool withOffset;
    int nbins = 1;
    struct HfmgParam hfmgParam;
    float scaleCpu = 1.0;
    int offsetCpu = 0;
    HfmgDataQuantParam<float> quantParam;
    AmctCommon::InputData<float> inputData{0, nullptr};
    std::vector<AmctCommon::DataBin<float>> dataBins;
    int batchCounter = 0;
    int batchNum = 0;
    std::vector<std::string> layerNames;
    std::string recordFilePath = "record_file_path_init";
    std::string inputStamp;
};
}

// Register the CPU kernels.
REGISTER_KERNEL_BUILDER(Name("QuantHfmg").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::QuantHfmgOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("QuantHfmg").Device(DEVICE_CPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::QuantHfmgOp<util::CPUDevice, Eigen::half>);

// Register the GPU kernels.
#ifdef GOOGLE_CUDA
extern template struct AmctTfOp::QuantHfmgFunctor<util::GPUDevice, float>;
REGISTER_KERNEL_BUILDER(Name("QuantHfmg").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::QuantHfmgOp<util::GPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("QuantHfmg").Device(DEVICE_GPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::QuantHfmgOp<util::GPUDevice, Eigen::half>);
#endif  // GOOGLE_CUDA


REGISTER_OP("QuantHfmg")
    .Attr("T: {float16, float32, float64}")
    .Attr("quant_bit_num: int")
    .Attr("with_offset: bool")
    .Attr("num_of_bins: int")
    .Attr("batch_num: int")
    .Attr("layer_names: list(string)")
    .Attr("record_file_path: string")
    .Attr("input_stamp: string = 'data'")
    .Input("in: T")
    .Input("enable: T")
    .Output("scale: float")
    .Output("offset: int32")
    .SetShapeFn([](::tensorflow::shape_inference::InferenceContext* c) {
        shape_inference::ShapeHandle output;
        output = c->MakeShape({1});

        c->set_output(0, output);
        c->set_output(1, output);
        return tensorflow::Status::OK();
    });