/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define IFMR Operator Forward Operation on CPU
 *
 * @file ascend_ifmr.cc
 *
 * @version 1.0
 */

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"
#include "tf_error_check.h"

using namespace tensorflow;

namespace AmctTfOp {
template <typename T>
class IFMROp : public OpKernel {
public:
    explicit IFMROp(OpKernelConstruction* context) : OpKernel(context) {}

    ~IFMROp() override {}

    void Compute(OpKernelContext* context) override {}
};
}

REGISTER_KERNEL_BUILDER(Name("IFMR").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::IFMROp<float>);

REGISTER_OP("IFMR")
    .Attr("T: {float32}")
    .Attr("min_percentile: float = 0.999999")
    .Attr("max_percentile: float = 0.999999")
    .Attr("search_range: list(float) = [0.7, 1.3]")
    .Attr("search_step: float = 0.01")
    .Attr("with_offset: bool = True")
    .Input("data: T")
    .Input("data_min: T")
    .Input("data_max: T")
    .Input("cumsum: int32")
    .Output("scale: T")
    .Output("offset: T")
    .SetIsStateful()
    .SetShapeFn([](::tensorflow::shape_inference::InferenceContext* c) {
        c->set_output(0, c->input(1));
        c->set_output(1, c->input(1));
        return tensorflow::Status::OK();
    });

