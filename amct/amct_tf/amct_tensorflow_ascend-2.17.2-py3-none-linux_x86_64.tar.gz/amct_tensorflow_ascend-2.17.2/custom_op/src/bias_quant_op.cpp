/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief bias_quant custom op C++ implement. now it has no real quant behaviours.
 *
 * @file bias_quant.cc
 *
 * @version 1.0
 */


#include <cmath>
#include <algorithm>

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "bias_quant.h"
#include "initializer.h"
#include "tf_error_check.h"
#include "error_codes.h"
#include "util.h"

using namespace tensorflow;
using namespace util;

namespace AmctTfOp {
template <typename Device, typename T>
class BiasQuantOp : public OpKernel {
public:
    explicit BiasQuantOp(OpKernelConstruction* context) : OpKernel(context)
    {
        OP_REQUIRES_OK(context, context->GetAttr("layer_name", &layerName));
        OP_REQUIRES_OK(context, context->GetAttr("quant_bits", &quantBits));
    }

    ~BiasQuantOp() override {}

    void Compute(OpKernelContext* context) override
    {
        const Tensor& bias = context->input(BIAS_DATA_IN_INDEX);
        auto biasFlat = bias.flat<T>();
        const int biasSize = biasFlat.size();

        Tensor* output = nullptr;
        OP_REQUIRES_OK(context, context->allocate_output(BIAS_DATA_OUT_INDEX, bias.shape(), &output));
        auto outputFlat = output->flat<T>();
        for (int i = 0; i < biasSize; i++) {
            outputFlat(i) = biasFlat(i);
        }
    }

private:
        std::string layerName = "layer_name_init";
        int quantBits = EIGHT;
};
}

REGISTER_KERNEL_BUILDER(Name("BiasQuant").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::BiasQuantOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("BiasQuant").Device(DEVICE_CPU).TypeConstraint<Eigen::half>("T"),
    AmctTfOp::BiasQuantOp<util::CPUDevice, Eigen::half>);

REGISTER_OP("BiasQuant")
    .Attr("T: {float16, float32, float64}")
    .Attr("layer_name: string")
    .Attr("quant_bits: int = 8")
    .Input("bias: T")
    .Input("deqscale: float32")
    .Output("output: T")
    .SetShapeFn([](shape_inference::InferenceContext* c)
    {
        c->set_output(0, c->input(0));
        return tensorflow::Status::OK();
    })
    .Doc(R"doc(Bias quant algorithm.)doc");
