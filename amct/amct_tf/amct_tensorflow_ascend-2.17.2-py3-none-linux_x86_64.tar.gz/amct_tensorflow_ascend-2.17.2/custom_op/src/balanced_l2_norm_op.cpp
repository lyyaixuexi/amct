/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Define QuantIfmr Operator Forward Operation on CPU
 *
 * @file ifmr.cc
 *
 * @version 1.0
 */
#include <algorithm>
#include <cmath>

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"

#include "bcp.h"
#include "activation_retrain.h"
#include "tf_error_check.h"

using namespace tensorflow;

namespace AmctTfOp {
template <typename Device, typename T>
class BalancedL2NormOp : public OpKernel {
public:
    explicit BalancedL2NormOp(OpKernelConstruction* context) : OpKernel(context)
    {
        AmctCommon::Initializer::GetInstance().Init();
        OP_REQUIRES_OK(context, context->GetAttr("N", &inputN));
        OP_REQUIRES_OK(context, context->GetAttr("M", &numOut));
        OP_REQUIRES_OK(context, context->GetAttr("prune_axis", &pruneAxis));
        OP_REQUIRES_OK(context, context->GetAttr("size_splits", &sizeSplits));
        OP_REQUIRES_OK(context, context->GetAttr("prune_ratios", &pruneRatios));
        OP_REQUIRES_OK(context, context->GetAttr("ascend_optimized", &ascendOptimized));
        OP_REQUIRES_OK(context, context->GetAttr("is_group", &isGroupConv));
        pruneParam.pruneAxis = pruneAxis;
        pruneParam.sizeSplits = sizeSplits;
        pruneParam.numSplits = pruneParam.sizeSplits.size();
        pruneParam.numChannels = std::accumulate(pruneParam.sizeSplits.begin(), pruneParam.sizeSplits.end(), 0);
        pruneParam.dropNums.resize(pruneParam.numSplits);
        remainChannelsContainerPtrs.resize(numOut);
        remainChannelsOutPtrs.resize(numOut);
    }

    ~BalancedL2NormOp() override {}

    void CheckDimension(unsigned int nInput, unsigned int nOutput,
        AmctCommon::PruneParam pruneParam, OpKernelContext* context)
    {
        OP_REQUIRES(context, pruneParam.pruneAxis.size() == nInput,
            errors::InvalidArgument("Incorrect number of prune_axis input"));
        if (pruneParam.numSplits > 1) {
            OP_REQUIRES(context, pruneParam.sizeSplits.size() == (nOutput - 1),
                errors::InvalidArgument("Incorrect number of size_splits input"));
            OP_REQUIRES(context, pruneRatios.size() == (nOutput - 1),
                errors::InvalidArgument("Incorrect number of prune_ratios input"));
        } else {
            OP_REQUIRES(context, pruneParam.sizeSplits.size() == nOutput,
                errors::InvalidArgument("Incorrect number of size_splits input"));
            OP_REQUIRES(context, pruneRatios.size() == nOutput,
                errors::InvalidArgument("Incorrect number of prune_ratios input"));
        }
    }

    int ComputeDropNum(AmctCommon::PruneParam &pruneParam, std::vector<float> pruneRatios,
        bool isGroupsConv, bool ascendOptimize)
    {
        if (pruneRatios.empty()) {
            LOG_ERROR("prune ratios can not be empty.");
            return AmctCommon::CONTAINER_EMPTY_ERROR;
        }
        if (isGroupsConv) {
            int totalDropNums = AmctCommon::CalPruneNum(
                pruneParam.numChannels, pruneParam.numSplits, pruneRatios[0], ascendOptimize);
            std::fill(pruneParam.dropNums.begin(), pruneParam.dropNums.end(), totalDropNums / pruneParam.numSplits);
        } else {
            for (int idx = 0; idx < pruneParam.numSplits; ++idx) {
                pruneParam.dropNums[idx] = AmctCommon::CalPruneNum(
                    pruneParam.sizeSplits[idx], 1, pruneRatios[idx], ascendOptimize);
            }
        }
        return AmctCommon::SUCCESS;
    }

    void Compute(OpKernelContext* context) override
    {
        unsigned int nInput = inputN;
        unsigned int nOutput = numOut;
        CheckDimension(nInput, nOutput, pruneParam, context);
        OpInputList wgtInputs;
        OP_REQUIRES_OK(context, context->input_list("wgt_inputs", &wgtInputs));

        // get batch counter
        Tensor batchNumTensor = context->input(inputN);
        auto batchNum = batchNumTensor.flat<T>();
        int errorCode = GetBatchNum<Device, T>()(*batchNum.data(), batchCounter);
        ERROR_CHECK(errorCode);

        // get container and output pointers
        for (int idx = 0; idx < numOut; ++idx) {
            Tensor remainChannelsContainer = context->input(inputN + 1 + idx);
            remainChannelsContainerPtrs[idx] = remainChannelsContainer.flat<T>().data();
            Tensor* result = nullptr;
            if (idx < pruneParam.numSplits) {
                OP_REQUIRES_OK(context, context->allocate_output(idx, TensorShape({sizeSplits[idx]}), &result));
            } else {
                OP_REQUIRES_OK(
                    context, context->allocate_output(idx, TensorShape({pruneParam.numChannels}), &result));
            }
            remainChannelsOutPtrs[idx] = &result->flat<T>()(0);
        }

        if (batchCounter == 0) {
            std::vector<const T*> wgtPtrs(wgtInputs.size());
            std::vector<int> wgtSizes(wgtInputs.size(), 0);
            std::vector<int> innerJumps(wgtInputs.size(), 1);
            for (int idx = 0; idx < wgtInputs.size(); ++idx) {
                auto weightFlat = wgtInputs[idx].flat<T>();
                wgtPtrs[idx] = weightFlat.data();
                OP_REQUIRES(context, wgtInputs[idx].NumElements() <= tensorflow::kint32max,
                    errors::InvalidArgument("Too many elements in tensor"));
                wgtSizes[idx] = wgtInputs[idx].NumElements();
                for (int axis = wgtInputs[idx].shape().dims() - 1; axis > pruneParam.pruneAxis[idx]; --axis) {
                    innerJumps[idx] *= wgtInputs[idx].shape().dim_size(axis);
                }
            }
            errorCode = ComputeDropNum(pruneParam, pruneRatios, isGroupConv, ascendOptimized);
            ERROR_CHECK(errorCode);
            errorCode = AmctCommon::ComputeRemainOut<Device, T>()(
                wgtPtrs, wgtSizes, innerJumps, pruneParam, remainChannelsContainerPtrs);
            ERROR_CHECK(errorCode);
            errorCode = UpdateBatchNum<Device, T>()(*batchNum.data());
            ERROR_CHECK(errorCode);
        }
        errorCode = AmctCommon::IdentityOutChannel<Device, T>()(pruneParam,
            remainChannelsContainerPtrs, remainChannelsOutPtrs);
        ERROR_CHECK(errorCode);
    }

private:
    int inputN = 0;
    std::vector<int> pruneAxis;
    std::vector<int> sizeSplits;
    std::vector<float> pruneRatios;
    bool ascendOptimized = true;
    bool isGroupConv = false;
    int batchCounter = 0;
    AmctCommon::PruneParam pruneParam;
    int numOut = 1;
    std::vector<T*> remainChannelsContainerPtrs;
    std::vector<T*> remainChannelsOutPtrs;
};
}

REGISTER_KERNEL_BUILDER(Name("BalancedL2Norm").Device(DEVICE_CPU).TypeConstraint<float>("T"),
    AmctTfOp::BalancedL2NormOp<util::CPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("BalancedL2Norm").Device(DEVICE_CPU).TypeConstraint<double>("T"),
    AmctTfOp::BalancedL2NormOp<util::CPUDevice, double>);

#ifdef GOOGLE_CUDA
REGISTER_KERNEL_BUILDER(Name("BalancedL2Norm").Device(DEVICE_GPU).TypeConstraint<float>("T"),
    AmctTfOp::BalancedL2NormOp<util::GPUDevice, float>);
REGISTER_KERNEL_BUILDER(Name("BalancedL2Norm").Device(DEVICE_GPU).TypeConstraint<double>("T"),
    AmctTfOp::BalancedL2NormOp<util::GPUDevice, double>);
#endif

REGISTER_OP("BalancedL2Norm")
    .Attr("T: {float, double}")
    .Attr("N: int")
    .Attr("M: int")
    .Attr("prune_axis: list(int)") // N
    .Attr("size_splits: list(int)") // 1 or M - 1
    .Attr("prune_ratios: list(float)")
    .Attr("ascend_optimized: bool")
    .Attr("is_group: bool")
    .Input("wgt_inputs: N * T")
    .Input("batch_num: T")
    .Input("remain_channels_container: M * T")
    .Output("remain_channels: M * T")
    .SetShapeFn([](shape_inference::InferenceContext* c)
    {
        std::vector<int> sizeSplits;
        TF_RETURN_IF_ERROR(c->GetAttr("size_splits", &sizeSplits));
        int numSplit = sizeSplits.size();
        int numChannels = std::accumulate(sizeSplits.begin(), sizeSplits.end(), 0);

        for (int i = 0; i <= numSplit; i++) {
            if (i < numSplit) {
                c->set_output(i, c->MakeShape({sizeSplits[i]}));
            } else {
                if (numSplit > 1) {
                    c->set_output(i, c->MakeShape({numChannels}));
                }
            }
        }
        return tensorflow::Status::OK();
    });
