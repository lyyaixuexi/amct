/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Declare IFMR Operator Forward Operation
 *
 * @file ifmr.h
 *
 * @version 1.0
 */
#ifndef IFMR_KERNEL_H
#define IFMR_KERNEL_H

#include <vector>
#include "common.h"
#include "ifmr.h"

namespace amct_tf {
    // Define the structure of data quantification
    struct IfmrParam {
        AmctCommon::IfmrParam ifmrCommon;
    };
}

namespace AmctTfOp {
// Define the structure of data quantification
template <typename T>
struct ErrorParam {
    int n;
    bool isMaxPos;
    T* beforeQuantData;
    T* quantError;
    T min;
    T max;
};

// Define the structure of data quantification
template <typename T>
struct DataQuantParam {
    float* scale;
    int* offset;
    float* scaleCpu;
    int* offsetCpu;
    T* ifmrData;
    T* quantError;
    std::vector<std::string> layerNames;
    std::string recordFilePath;
};

// Define the structure of data quantification
template <typename T>
struct InputParam {
    std::vector<T> storeData;
    int size;
    const T* in;
};

template <typename Device, typename T>
struct QuantIfmrFunctor {
    int operator()(struct amct_tf::IfmrParam ifmrParam, int& batchCounter, int& batchNum,
        struct InputParam<T>& inputParam, struct DataQuantParam<T> quantParam) const;
};

template <typename T>
int CalScaleOffset(T max, T min, float& scaleCpu, int& offsetCpu, struct AmctCommon::IfmrParam ifmrParam);
}

#endif // IFMR_KERNEL_H
