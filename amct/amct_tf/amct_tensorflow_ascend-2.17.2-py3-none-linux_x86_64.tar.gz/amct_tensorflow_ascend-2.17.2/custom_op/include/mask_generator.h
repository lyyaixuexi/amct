/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2021. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief mask generator header file
 *
 * @file mask_generator.h in tensorflow common op
 *
 * @version 1.0
 */
#ifndef MASK_GENERATOR_H
#define MASK_GENERATOR_H

namespace AmctTfOp {
template <typename T>
struct MaskGenParam {
    int inChannelWidth;
    int outChannelWidth;
    int weightSize;
    T* mask;
    T* maskCpu;
};

template <typename Device, typename T>
struct GenerateMask {
    int operator()(const T* remainIn, const T* remainOut, struct MaskGenParam<T> maskGenParam) const;
};

template <typename Device, typename T>
struct IdentityMask {
    int operator()(struct MaskGenParam<T> maskGenParam) const;
};
}

#endif // MASK_GENERATOR_H
