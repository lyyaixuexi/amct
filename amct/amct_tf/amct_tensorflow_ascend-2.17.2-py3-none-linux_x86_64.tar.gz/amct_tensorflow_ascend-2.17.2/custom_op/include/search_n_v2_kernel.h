/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Declare SEARCH_N Operator Forward Operation
 *
 * @file search_n_v2_kernel.h
 *
 * @version 1.0
 */
#ifndef SEARCH_N_V2_KERNEL_H
#define SEARCH_N_V2_KERNEL_H

#include <vector>
#include <string>
#include "common.h"
#include "search_n_v2.h"

namespace AmctTfOp {
// Define the structure of data quantification
template <typename T>
struct SearchnV2QuantParam {
    // whether reduce error per tensor
    bool isBroadcast;
    // host pointer of shift N value, size eq channelNum;
    int* bestN;
    // size of bestN
    int bestNSize;
    // device pointer of quantErrorSum, size is AMCT_GET_BLOCKS(searchNDataSize)
    T* quantErrorSum;
    // size of device pointer quantErrorSum
    int quantErrorSumSize;
    // device pointer of deq scale
    float* deqScale;
    // host pointer of deq scale
    float* deqScaleCpu;
    // size of deqScale and deqScaleCpu
    int deqScaleSize;
    // channelNum of target operator of search_n_v2
    int channelNum;
};

// Define the structure of data quantification
struct DataParam {
    std::vector<int> shape;
    bool channelWise;
    std::string dataFormat;
    float* out;
};


template <typename Device, typename T>
struct SearchNV2Functor {
    int operator()(struct DataParam& param, int& batchCounter, int& batchNum,
        AmctCommon::SearchnV2InputParam<T>& inputParam, struct SearchnV2QuantParam<T>& quantParam) const;
};


template <typename Device, typename T>
struct FetchScaleFunctor {
    int operator()(T* scaleHost, const T* scaleInput, int channelNum) const;
};
}

#endif // SEARCH_N_V2_KERNEL_H
