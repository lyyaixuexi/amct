/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this
 * file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief simulate protbuf behavior
 *
 * @version 1.0
 */
#ifndef PROTO_PROTO_H
#define PROTO_PROTO_H

#include <string>
#include <sstream>
#include <map>
#include "proto_data.h"

namespace amct_tf {
class Proto {
public:
    explicit Proto(std::string name): name_(name), level_(0) {}
    Proto(std::string name, size_t level): name_(name), level_(level) {}
    virtual int Init()
    {
        for (auto& ele: children_) {
            int ret = (ele.second.first)->Init();
            if (ret != AmctCommon::SUCCESS) {
                return ret;
            }

            ret = (ele.second.second)->Init();
            if (ret != AmctCommon::SUCCESS) {
                return ret;
            }
        }
        return AmctCommon::SUCCESS;
    }

    virtual ~Proto()
    {
        for (auto& ele: children_) {
            delete ele.second.first;
            delete ele.second.second;
        }
    }

    bool IsWhiteSpace(char ch) const
    {
        if (ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r') {
            return true;
        }
        return false;
    }

    bool IsSeparator(char ch) const
    {
        if (IsWhiteSpace(ch) || ch == ':' || ch == '{') {
            return true;
        }
        return false;
    }

    bool IsMessage(const std::string& content, size_t pos) const
    {
        char ch = '\0';
        for (size_t i = pos; i < content.size(); i++) {
            if (IsWhiteSpace(content[i])) {
                continue;
            }
            ch = content[i];
            break;
        }
        return ch == '{';
    }

    void GetMessageSeg(std::string& content, size_t pos, std::string& value, size_t& nextPos) const
    {
        size_t leftBrace = 0;
        size_t rightBrace = 0;
        size_t begin = 0;
        size_t end = 0;
        bool inDoubleQuotation = false;
        for (size_t i = pos; i < content.size(); i++) {
            if (content[i] == '"') {
                inDoubleQuotation = !inDoubleQuotation;
            }
            if (!inDoubleQuotation && content[i] == '{') {
                if (leftBrace == 0) {
                    begin = i;
                }
                leftBrace++;
            }
            if (!inDoubleQuotation && content[i] == '}') {
                rightBrace++;
                if (rightBrace == leftBrace) {
                    end = i;
                    nextPos = i + 1;
                    break;
                }
            }
        }
        value = content.substr(begin + 1, (end - begin) - 1);
        return;
    }

    void GetFieldSeg(std::string& content, size_t pos, std::string& value, size_t& nextPos) const
    {
        bool foundColon = false;
        bool beginFlag = false;
        size_t begin = 0;
        size_t end = 0;
        for (size_t i = pos; i < content.size(); i++) {
            if (!foundColon && content[i] == ':') {
                foundColon = true;
                continue;
            }

            if (!beginFlag && foundColon && !IsWhiteSpace(content[i])) {
                beginFlag = true;
                begin = i;
            }

            if (beginFlag && IsWhiteSpace(content[i])) {
                end = i;
                nextPos = i;
                break;
            }
        }
        value = content.substr(begin, end - begin);
        return;
    }

    bool GetSegmentation(std::string& content, std::string& name, std::string& value, size_t& nextPos) const
    {
        bool foundName = false;
        size_t offset = 0;

        // get field name
        for (size_t i = nextPos; i < content.size(); i++) {
            if (!foundName && IsWhiteSpace(content[i])) {
                continue;
            }
            if (!foundName) {
                foundName = true;
                offset = i;
            }
            if (IsSeparator(content[i])) {
                name = content.substr(offset, i - offset);
                offset = i;
                break;
            }
        }

        bool messageFlag = IsMessage(content, offset);
        if (messageFlag) {
            GetMessageSeg(content, offset, value, nextPos);
        } else {
            GetFieldSeg(content, offset, value, nextPos);
        }
        return foundName;
    }

    void AddChild(std::string name, Proto* proto, Data* data)
    {
        children_[name] = {proto, data};
        return;
    }

    bool HasChild(std::string name)
    {
        return children_.find(name) != children_.end();
    }

    virtual int Parse(std::string& content, Data& data)
    {
        std::string name;
        std::string value;
        size_t nextPos = 0;
        while (GetSegmentation(content, name, value, nextPos)) {
            if (!HasChild(name)) {
                return AmctCommon::RECORD_FILE_PARSE_ERROR;
            }

            Proto* proto = GetProto(name);
            NULLPTR_CHECK(proto);
            Data* subData = GetData(name);
            NULLPTR_CHECK(subData);
            subData->ClearData();

            int ret = proto->Parse(value, *subData);
            if (ret != AmctCommon::SUCCESS) {
                return ret;
            }

            ret = data.AddData(name, subData);
            if (ret != AmctCommon::SUCCESS) {
                return ret;
            }
        }
        return AmctCommon::SUCCESS;
    }

protected:
    std::string name_;
    size_t level_;

private:
    Proto* GetProto(std::string name)
    {
        return children_[name].first;
    }

    Data* GetData(std::string name)
    {
        return children_[name].second;
    }

    std::map<std::string, std::pair<Proto*, Data*>> children_;
};

class BoolProto : public Proto {
public:
    explicit BoolProto(std::string name): Proto(name) {}
    BoolProto(std::string name, size_t level): Proto(name, level) {}
    ~BoolProto() override {}

    int Parse(std::string& content, Data& data) override
    {
        bool tmp = false;
        if (content == "true") {
            tmp = true;
        }
        data.AddData(name_, tmp);
        return AmctCommon::SUCCESS;
    }
};

class FloatProto : public Proto {
public:
    explicit FloatProto(std::string name): Proto(name) {}
    FloatProto(std::string name, size_t level): Proto(name, level) {}
    ~FloatProto() override {}

    int Parse(std::string& content, Data& data) override
    {
        std::istringstream iss(content);
        float tmp;
        iss >> tmp;
        data.AddData(name_, tmp);
        return AmctCommon::SUCCESS;
    }
};

class IntProto : public Proto {
public:
    explicit IntProto(std::string name): Proto(name) {}
    IntProto(std::string name, size_t level): Proto(name, level) {}
    ~IntProto() override {}

    int Parse(std::string& content, Data& data) override
    {
        std::istringstream iss(content);
        int tmp;
        iss >> tmp;
        data.AddData(name_, tmp);
        return AmctCommon::SUCCESS;
    }
};

class UnsignedIntProto : public Proto {
public:
    explicit UnsignedIntProto(std::string name): Proto(name) {}
    UnsignedIntProto(std::string name, size_t level): Proto(name, level) {}
    ~UnsignedIntProto() override {}

    int Parse(std::string& content, Data& data) override
    {
        std::istringstream iss(content);
        size_t tmp;
        iss >> tmp;
        data.AddData(name_, tmp);
        return AmctCommon::SUCCESS;
    }
};

class StringProto : public Proto {
public:
    explicit StringProto(std::string name): Proto(name) {}
    StringProto(std::string name, size_t level): Proto(name, level) {}
    ~StringProto() override {}

    int Parse(std::string& content, Data& data) override
    {
        size_t begin = content.find_first_of('"');
        size_t end = content.find_last_of('"');
        std::string value = content.substr(begin + 1, (end - begin) - 1);
        data.AddData(name_, value);
        return AmctCommon::SUCCESS;
    }
};

} // end of namespace amct_tf

#endif