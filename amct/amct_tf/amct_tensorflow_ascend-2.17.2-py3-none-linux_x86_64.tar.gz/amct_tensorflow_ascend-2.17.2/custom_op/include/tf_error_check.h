/*
* Copyright (c) Huawei Technologies Co., Ltd. 2022-2022. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this
 * file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief define tf erro check
 *
 * @file tf_error_check.h
 *
 * @version 1.0
 */

#include <map>
#include <string>
#include "error_codes.h"
#include "tensorflow/core/framework/op_kernel.h"

namespace TfError {
class TfErrorCheck {
public:
    static void ErrorCheck(tensorflow::OpKernelContext* context, int errorCode)
    {
        static std::map<int, std::string> errorMessage = {
            std::pair<int, std::string>(AmctCommon::CUDA_MEMCPY_ERROR, "cudaMemcpy ERROR!"),
            std::pair<int, std::string>(AmctCommon::DEQ_SCALE_ERROR,
                "Deq_scale is less than FLT_MIN or Deq_scale is larger than FLT_MAX!"),
            std::pair<int, std::string>(AmctCommon::INPUT_CHANNEL_ERROR,
                "The number of input channels is inconsistent!"),
            std::pair<int, std::string>(AmctCommon::SCALED_NOT_EXIT_ERROR, "The record file's info has not scale_d!"),
            std::pair<int, std::string>(AmctCommon::RECORD_NOT_EXIT_ERROR, "Record file is not exit!"),
            std::pair<int, std::string>(AmctCommon::RECORD_FILE_OPEN_ERROR, "Record file open error!"),
            std::pair<int, std::string>(AmctCommon::SCALE_LENGTH_ERROR,
                "Scalew's length isn't equal to deqscale's length!"),
            std::pair<int, std::string>(AmctCommon::ZERO_DIVISION_ERROR, "The divisor is ZERO!"),
            std::pair<int, std::string>(AmctCommon::SCALEW_ERROR,
                "Scalew is less than FLT_MIN or ScaleW is larger than FLT_MAX!"),
            std::pair<int, std::string>(AmctCommon::SCALED_ERROR,
                "Scaled is less than FLT_MIN or Scaled is larger than FLT_MAX!"),
            std::pair<int, std::string>(AmctCommon::TRAINING_ERROR,
                "The BN is training mode and does not support quantization. "
                "You need to set the is_training attribute of the BN to false.!"),
            std::pair<int, std::string>(AmctCommon::CUDA_ASYNC_ERROR, "CUDA SYNC ERROR!"),
            std::pair<int, std::string>(AmctCommon::NULL_PTR_ERROR, "Null Ptr ERROR!"),
            std::pair<int, std::string>(AmctCommon::RECORD_FILE_PARSE_ERROR, "Invalid proto record file."),
            std::pair<int, std::string>(AmctCommon::TENSOR_BALANCE_FACTOR_ERROR,
                "tensor balance factor is less than FLT_EPSILON or larger than 1/FLT_EPSILON!"),
        };
        if (errorMessage.find(errorCode) != errorMessage.end()) {
            OP_REQUIRES(context, false, tensorflow::errors::InvalidArgument(errorMessage[errorCode]));
        } else if (errorCode != AmctCommon::SUCCESS) {
            std::string errStr = "OP compute failed, please refer to ERROR log above.";
            OP_REQUIRES(context, false, tensorflow::errors::InvalidArgument(errStr));
        }
    }
};
}

#define ERROR_CHECK(errorCode) TfError::TfErrorCheck::ErrorCheck(context, errorCode)