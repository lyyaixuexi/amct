/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this
 * file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief define the synchronization function
 *
 * @file initializer.h
 *
 * @version 1.0
 */
#ifndef INITIALIZER_H
#define INITIALIZER_H

#include <semaphore.h>

namespace AmctTfOp {
// Define the structure of initializer for sync.
class Initializer {
public:
    static Initializer& GetInstance()
    {
        static Initializer initializer;
        return initializer;
    }

    void Init()
    {
        if (!initFlag) {
            sem_init(&semaphore, 0, 1);
            initFlag = true;
        }
    }

    sem_t semaphore;
    bool initFlag = false;
};
}

#endif // INITIALIZER_H
