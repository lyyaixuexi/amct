/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2019-2021. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief mask header file
 *
 * @file mask.h in amct tensorflow common op
 *
 * @version 1.0
 */
#ifndef FAST_SOFTMAX_H
#define FAST_SOFTMAX_H


namespace AmctTfOp {
struct SoftmaxParam {
    float a;
    float b;
    float clipValue;
    int axis;
    int logitSize;
    int numDimensions;
    int* logitShape;
};

template <typename Device, typename T>
struct FastSoftmaxFunctor {
    int operator()(const T* logits, T* output, struct SoftmaxParam& softmaxParam) const;
};
}

#endif // MASK_H