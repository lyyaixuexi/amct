/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Declare IFMR Operator Forward Operation
 *
 * @file ifmr.h
 *
 * @version 1.0
 */
#ifndef RECORD_QUANT_FACTORS_H
#define RECORD_QUANT_FACTORS_H

namespace AmctTfOp {
constexpr int SCALED_INDEX = 0;
constexpr int OFFSETD_INDEX = 1;
constexpr int SCALEW_INDEX = 2;
constexpr int OFFSETW_INDEX = 3;
constexpr int LAYERS_INDEX = 4;
constexpr int RECORD_OUT_INDEX = 0;

// Define the structure of data quantification
struct DataQuantFactors {
    float* scale;
    int* offset;
    float* scaleCpu;
    int* offsetCpu;
};

// Define the structure of data quantification
struct WeightQuantFactors {
    float* scale;
    int* offset;
    float* scaleCpu;
    int* offsetCpu;
    int scaleWLength;
};


template <typename Device, typename T>
struct CopyDataToHost {
    int operator()(struct DataQuantFactors dataQuantParam) const;
};
}

#endif // RECORD_QUANT_FACTORS_H
