/*
* Copyright (c) Huawei Technologies Co., Ltd. 2023-2023. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Declare IFMR Operator Forward Operation
 *
 * @file dmq_balancer_kernel.h
 *
 * @version 1.0
 */
#ifndef DMQ_BALANCER_KERNEL_H
#define DMQ_BALANCER_KERNEL_H

namespace DMQBalancerKernel {
struct DMQBalancerParam {
    float migrationStrength;
    unsigned int channelNum;
    unsigned int actSize;
    unsigned int wgtSize;
    float* balanceFactor;
};

/*
Function: DMQBalancer()
Notice:
    const float* activation: pointer of activation tensor data, data length is param.actSize
    const float* weight: pointer of weight tensor data, data length is param.wgtSize
    const float* weight: pointer of output tensor data, data length is param.channelNum
*/
template <typename Device, typename T>
struct DMQBalancer {
    int operator()(const float* activation, const float* weight, DMQBalancerParam &param, float* balanceFactor) const;
};
}

#endif // DMQ_BALANCER_KERNEL_H
