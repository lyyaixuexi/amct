/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief arq head file
 *
 * @file arq.h
 *
 * @version 1.0
 */

#ifndef ARQ_KERNEL_H
#define ARQ_KERNEL_H

#include <string>
#include "arq.h"

namespace AmctTfOp {
constexpr int ARQ_WEIGHT_INDEX = 0;
constexpr int ARQ_SCALE_INDEX = 0;
constexpr int ARQ_OFFSET_INDEX = 1;

// Define the structure of data quantification
struct WeightQuantParam {
    float* scale;
    int* offset;
    float* scaleCpu;
    int* offsetCpu;
    int scaleNumber;
    int quantBits;
    std::string layerName;
    std::string recordFilePath;
};

template <typename Device, typename T>
struct FindMaxMin {
    int operator()(const int size, const T* in, struct WeightQuantParam quantParam) const;
};

template <typename Device, typename T>
struct IdentityScaleOffset {
    int operator()(struct WeightQuantParam quantParam) const;
};
}

#endif // ARQ_KERNEL_H
