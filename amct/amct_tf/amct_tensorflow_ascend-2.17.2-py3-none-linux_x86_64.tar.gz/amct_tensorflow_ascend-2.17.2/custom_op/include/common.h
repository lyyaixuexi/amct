/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this
 * file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief define the synchronization function
 *
 * @file common.h
 *
 * @version 1.0
 */
#ifndef COMMON_H
#define COMMON_H

#include <string>

namespace AmctTfOp {
int WriteWeightToRecordFile(const float* scale, const int* offset, const int scaleLength,
    const std::string& layerName, const std::string& recordFilePath);

// write nuq record to record file
int WriteNuqRecordToFile(const float* scale, const int* offset, const int* cluster,
    const int scaleLength, const int clusterLength, const std::string& layerName, const std::string& recordFilePath);

// write activation record
int WriteDataToRecordFile(const float* scale, const int* offset, const std::string& layerName,
    const std::string& recordFilePath, std::string dstType = "INT8");

int WriteShiftNToRecordFile(const int* shiftN, const int scaleLength, const std::string& layerName,
    const std::string& recordFilePath);

int WriteTensorBalanceFactorToRecordFile(const float* tensorBalanceFactor, const int factorSize,
    const std::string& layerName, const std::string& recordFilePath);

template <typename T>
int ComputeDeqScale(float* deqScale, const T* scaleWeight, T scaleData, int channelNum);

bool ValueCheck(float value);

void ConvertLayerName(std::string& oriLayerName, const std::string& subStr, const std::string& replaceStr);
}

#endif // COMMON_H
