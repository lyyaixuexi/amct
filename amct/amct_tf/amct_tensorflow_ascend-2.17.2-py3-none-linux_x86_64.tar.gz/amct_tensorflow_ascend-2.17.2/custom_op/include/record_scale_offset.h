/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Declare IFMR Operator Forward Operation
 *
 * @file ifmr.h
 *
 * @version 1.0
 */
#ifndef RECORD_SCALE_OFFSET_H
#define RECORD_SCALE_OFFSET_H

namespace AmctTfOp {
constexpr int SCALED_INDEX = 0;
constexpr int OFFSETD_INDEX = 1;
constexpr int SCALEW_INDEX = 2;
constexpr int OFFSETW_INDEX = 3;
constexpr int SCALE_INDEX = 4;
constexpr int VARIANCE_INDEX = 5;
constexpr int EPSILON_INDEX = 6;
constexpr int MUL_INDEX = 7;
constexpr int RECORD_SCALED_OUT_INDEX = 0;
constexpr int RECORD_SCALEW_OUT_INDEX = 1;

// Define the structure of data quantification
struct RetrainDataQuantParam {
    float* scale;
    int* offset;
    float* scaleCpu;
    int* offsetCpu;
};

// Define the structure of data quantification
struct RetrainWeightQuantParam {
    float* scale;
    int* offset;
    float* scaleCpu;
    int* offsetCpu;
    int scaleWLength;
};

// Define the structure of data quantification
struct BnParam {
    float* scale;
    float* variance;
    float* epsilon;
    float* mul;
};

template <typename Device, typename T>
struct CopyDataToHost {
    int operator()(struct RetrainDataQuantParam dataQuantParam, const struct RetrainWeightQuantParam weightQuantParam,
        const struct BnParam bnParam, float* scaleDOutPtr, float* scaleWOutPtr) const;
};
}

#endif // RECORD_SCALE_OFFSET_H
