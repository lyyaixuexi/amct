/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief dump head file, define the structure of data quantification
 *
 * @file dump.h
 *
 * @version 1.0
 */

#ifndef DUMP_KERNEL_H
#define DUMP_KERNEL_H

#include <string>
#include <vector>

namespace amct_tf {
struct DumpParam {
    std::string dumpDir;
    std::string namePrefix;
    int batchCounter;
    std::vector<float> inputShape;
    unsigned int inputShapeLength;
};

template <typename Device, typename T>
struct DumpFunctor {
    int operator()(const T* dataPtr, unsigned int length, struct DumpParam param) const;
};

template <typename Device, typename T>
struct CopyDataFunctor {
    int operator()(const T* srcPtr, unsigned int length, T* destPtr) const;
};
} // namespace amct_tf

#endif // DUMP_KERNEL_H
