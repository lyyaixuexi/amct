/*
* Copyright (c) Huawei Technologies Co., Ltd. 2019-2019. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Apache License for more details at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @brief Declare HFMG Operator Forward Operation
 *
 * @file hfmg_kernel.h
 *
 * @version 1.0
 */
#ifndef HFMG_KERNEL_H
#define HFMG_KERNEL_H

#include <vector>
#include "common.h"
#include "hfmg.h"

namespace AmctTfOp {
// Define the structure of data quantification
struct HfmgParam {
    int quantBitNum;
    bool withOffset;
    int nbins;
    bool needDump;
    std::string dumpDir;
    bool isGroup;
    std::string splitName;
};

// Define the structure of data quantification
template <typename T>
struct HfmgDataQuantParam {
    float* scale;
    int* offset;
    float* scaleCpu;
    int* offsetCpu;
    int* binCounts;
    float* l2LossTensor;
    std::vector<std::string> layerNames;
    std::string recordFilePath;
};


template <typename Device, typename T>
struct QuantHfmgFunctor {
    int operator()(std::vector<AmctCommon::DataBin<T>>& dataBins, struct HfmgParam& hfmgParam,
        int& batchCounter, int& batchNum,
        AmctCommon::InputData<T>& inputData, HfmgDataQuantParam<T>& quantParam) const;
};


template <typename Device, typename T>
struct ActArqFunctor {
    int operator()(struct AmctCommon::InputData<T>& inputData, struct HfmgParam& hfmgParam,
        struct HfmgDataQuantParam<T>& quantParam) const;
};
}

#endif // HFMG_KERNEL_H
