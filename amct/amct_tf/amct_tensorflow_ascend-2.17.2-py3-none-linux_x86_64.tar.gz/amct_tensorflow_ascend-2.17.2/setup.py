#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

package script.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import sys
import shutil
import glob
import multiprocessing
from multiprocessing import Process
from multiprocessing import Queue
import tarfile

import setuptools
from setuptools.command.build_ext import build_ext

# ensure Build Equivalence
tarfile.TarFile.format = tarfile.GNU_FORMAT
os.environ['SOURCE_DATE_EPOCH'] = \
    str(int(os.path.getctime(os.path.realpath(__file__))))

CUR_DIR = os.path.split(os.path.realpath(__file__))[0]
VERSION_FILE = os.path.join(CUR_DIR, 'amct_tensorflow', '.version')


def is_build_whl():
    """judge if is build whl package"""
    package_name = os.getenv('AMCT_TF_PACKAGE_NAME')
    if package_name is not None and 'bdist_wheel' in sys.argv:
        return True
    return False


def is_build_targz():
    """judge if is build targz package"""
    package_name = os.getenv('AMCT_TF_PACKAGE_NAME')
    if package_name is not None and 'sdist' in sys.argv:
        return True
    return False


def is_install_targz():
    """judge if is install targz package"""
    if is_build_targz() or is_build_whl():
        return False
    with open(VERSION_FILE, 'r') as fid:
        lines = fid.readlines()
    content = [line.replace("\n", "") for line in lines]
    if 'sdist' in content:
        return True
    return False


def modify_version_file():
    """add info to version file"""
    if not is_build_whl() and not is_build_targz():
        return
    package_name = os.getenv('AMCT_TF_PACKAGE_NAME')
    if 'ascend' in package_name:
        with open(VERSION_FILE, 'a') as fid:
            fid.write('\nascend')
    build_mod = 'bdist_wheel' if is_build_whl() else 'sdist'
    with open(VERSION_FILE, 'a') as fid:
        fid.write('\n' + build_mod)


def rollback_version_file():
    """rollback modification to version file"""
    if not is_build_whl() and not is_build_targz():
        return
    version = get_version()
    with open(VERSION_FILE, 'w') as fid:
        fid.write(version + '\n')


def get_package_name():
    """get package name"""
    if is_build_targz() or is_build_whl():
        package_name = os.getenv('AMCT_TF_PACKAGE_NAME')
        package_name = package_name.replace("\n", "")
    else:
        package_name = 'amct_tensorflow'
        with open(VERSION_FILE, 'r') as fid:
            lines = fid.readlines()
        content = [line.replace("\n", "") for line in lines]
        if 'ascend' in content:
            package_name = package_name + '_ascend'
    return package_name


def get_version():
    """get version"""
    with open(VERSION_FILE, 'r') as fid:
        lines = fid.readlines()
    version = lines[0].replace("\n", "")
    return version


def get_auxiliary_files():
    """get some files to add in package"""
    file_list = ['lib/*.so', 'pattern/*.json']
    proto_files = [
        os.path.join('proto', file_name)
        for file_name in os.listdir('amct_tensorflow/proto')
        if '.proto' in file_name
    ]
    common_proto_files = [
        os.path.join('common/proto', file_name)
        for file_name in os.listdir('amct_tensorflow/common/proto')
        if '.proto' in file_name
    ]
    csv_files = [
        os.path.join('capacity', file_name)
        for file_name in os.listdir('amct_tensorflow/capacity')
        if '.csv' in file_name
    ]
    file_list.extend(proto_files)
    file_list.extend(common_proto_files)
    file_list.extend(csv_files)
    if 'ascend' not in get_package_name():
        file_list = [
            file_name
            for file_name in file_list
            if 'ascend' not in file_name
        ]
    return file_list


def is_gpu_available(com_queue):
    """Check whether gpu is available"""
    import tensorflow as tf  # pylint: disable=import-error, C0415
    os.environ['TF_CPP_MIN_LOG_LEVEL'] = '1'
    ret = tf.test.is_gpu_available() and 'ascend' not in get_package_name()
    com_queue.put(ret)


def use_cuda():
    """Check whether gpu is available in another process"""
    cuda_flag = False
    com_queue = Queue()
    pro = Process(target=is_gpu_available, args=(com_queue, ))
    pro.start()
    pro.join()
    if com_queue.get(True):
        cuda_flag = True
        with open(VERSION_FILE, 'a') as fid:
            fid.write('\n' + 'gpu')
    return cuda_flag


class BuildExtensionAcc(build_ext):
    """a class to enable parallel compile"""
    def initialize_options(self):
        """set parallel to cpu num"""
        super().initialize_options()
        try:
            cpu_count = len(os.sched_getaffinity(0))
        except AttributeError:
            cpu_count = multiprocessing.cpu_count()
        self.parallel = cpu_count


class BuildTool():  # pylint: disable=R0903, R0902
    """tool for setup"""
    def __init__(self):
        self.packages = self._get_packages()
        self.lib_files = self._get_lib_files()
        self.compile_files = self._get_lib_files()
        self.compile_files.append('include/*.h')
        self.set_platform()
        self.package_data = self._get_package_data()
        self.enable_cuda = False
        self.tf_compile_flags = None
        self.tf_link_flags = None
        self.tf_lib_dir = None
        self.tf_include_dir = None
        self.build_args = self.add_custom_ops()

    @staticmethod
    def _get_packages():
        packages = setuptools.find_packages()
        packages.append('custom_op')
        if 'ascend' not in get_package_name():
            if 'amct_tensorflow.interface_ascend' in packages:
                packages.remove('amct_tensorflow.interface_ascend')
        return packages

    @staticmethod
    def _get_lib_files():
        exclude_files = [
            'ascend_anti_quant_op.cpp', 'ascend_dequant_op.cpp', 'ascend_quant_op.cpp',
            'ascend_weight_quant_op.cpp'
        ]
        lib_files = []
        for src_file in glob.glob(
                os.path.join(CUR_DIR, 'custom_op', 'src', '*')):
            if 'ascend' in get_package_name():
                found = False
                for exclude_file in exclude_files:
                    if exclude_file in src_file:
                        found = True
                        break
                if found:
                    continue
            lib_files.append(src_file)
        return lib_files

    def set_platform(self):
        """ set platform"""
        if is_build_targz():
            platform = os.getenv('AMCT_TENSORFLOW_PLATFORM').replace("\n", "")
            self.platform = platform

    def create_cpp_extension(self, file_name):
        '''
        Creates a :class:`setuptools.Extension` for C++.
        All arguments are forwarded to the :class:`setuptools.Extension`
        constructor.
        '''
        op_name = os.path.splitext(os.path.split(file_name)[1])[0]
        lib_name = 'amct_tensorflow_ops_' + op_name
        kwargs = {}
        kwargs['language'] = 'c++'

        extra_compile_args = kwargs.get('extra_compile_args', [])
        extra_compile_args += self.tf_compile_flags
        if self.enable_cuda:
            extra_compile_args.append('-DGOOGLE_CUDA=1')
        kwargs['extra_compile_args'] = extra_compile_args

        extra_link_args = kwargs.get('extra_link_args', [])
        extra_link_args += self.tf_link_flags
        quantize_lib_dir = os.path.join(CUR_DIR, 'amct_tensorflow/lib')
        extra_link_args.append('-L' + quantize_lib_dir)
        if self.enable_cuda:
            extra_link_args.append('-l:libquant_gpu.so')
        else:
            extra_link_args.append('-l:libquant.so')
        kwargs['extra_link_args'] = extra_link_args

        library_dirs = kwargs.get('library_dirs', [])
        library_dirs.append(self.tf_lib_dir)
        kwargs['library_dirs'] = library_dirs

        include_dirs = kwargs.get('include_dirs', [])
        include_dirs.append(self.tf_include_dir)
        include_dirs.append(os.path.join(CUR_DIR, 'custom_op', 'include'))
        kwargs['include_dirs'] = include_dirs

        return setuptools.Extension(lib_name, [file_name], **kwargs)

    def add_custom_ops(self):
        """set ext_modules for compile amct custom ops"""
        build_args = {}
        if not is_install_targz():
            return build_args

        import tensorflow as tf  # pylint: disable=import-error, C0415
        self.enable_cuda = use_cuda()
        self.tf_compile_flags = tf.sysconfig.get_compile_flags()
        self.tf_link_flags = tf.sysconfig.get_link_flags()
        self.tf_lib_dir = tf.sysconfig.get_lib()
        self.tf_include_dir = tf.sysconfig.get_include()

        ext_modules = [
            self.create_cpp_extension(file_name)
            for file_name in self.lib_files
        ]
        build_args['ext_modules'] = ext_modules
        build_args['cmdclass'] = {'build_ext': BuildExtensionAcc}
        return build_args

    def _get_package_data(self):
        args = {'': ['.version'], 'amct_tensorflow': get_auxiliary_files()}
        if is_build_targz():
            args['custom_op'] = self.compile_files
        return args


def main():
    """ main function of setup.py"""
    modify_version_file()
    build_tool = BuildTool()
    version = get_version()
    package_name = get_package_name()
    try:
        setuptools.setup(
            name=package_name,
            version=version,
            description='Ascend Model Compression Toolkit for TensorFlow',
            url='',
            author='Huawei Technologies Co., Ltd.',
            license='Apache 2.0',
            packages=build_tool.packages,
            entry_points={
                "console_scripts": [
                    "amct_tensorflow=amct_tensorflow.cmd_line_tools.command:main",
                ]
            },
            classifiers=[
                'Development Status :: 5 - Production/Stable',
                'Intended Audience :: Developers',
                'Intended Audience :: Science/Research',
                'Topic :: Scientific/Engineering :: Artificial Intelligence',
                'Programming Language :: C++',
                'Programming Language :: Python :: 3'
            ],
            # no essential requirements, install_requires is []
            extras_require={"tf": ["tensorflow==1.15"]},
            package_data=build_tool.package_data,
            **build_tool.build_args)
    except Exception as exce:  # pylint: disable=try-except-raise, unused-variable
        raise
    finally:
        rollback_version_file()

    # add platform name to package
    if is_build_targz():
        shutil.move(
            os.path.join(CUR_DIR, 'dist/{}-{}.tar.gz'.format(package_name, version)),
            os.path.join(CUR_DIR, 'dist/{}-{}-py3-none-{}.tar.gz'.format(package_name, version, build_tool.platform)))


if __name__ == '__main__':
    main()
